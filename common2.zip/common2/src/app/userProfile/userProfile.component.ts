import { Observable } from 'rxjs/Observable';
import { BasicValidators } from '../shared/services/basicValidators';
import { UserService } from '../manage/users/service/user.service';
import { User } from '../manage/users/user.data';
import { ChangeDetectorRef, Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NotyService } from 'sensorthink-commoncontrols/src/services/noty.service';
import { AuthService } from "../auth/auth.service";

@Component({
    templateUrl: 'userProfile.component.html'
})
export class UserProfileComponent {
    userProfileForm: FormGroup;
    user: User = new User();
    isLoading: any = false;
    dummyUser: any;
    constructor(private fb: FormBuilder, private cdr: ChangeDetectorRef, private _userService: UserService, private notify: NotyService, private authService: AuthService) {
        this.createForm();
    }
   
    createForm() {
        this.userProfileForm = this.fb.group({
            userLogin: [null, Validators.required],
            firstName: [null, Validators.required],
            lname: [null, Validators.required],
            email: [null, BasicValidators.email],
        });
        let userId = this.authService.getUserDataFromToken();
        this.setUserInfo(userId);
    }

    setUserInfo(userObj, callback?) {
        var self = this;
        if (userObj) {
            this._userService.getUserDetailsByUserId(userObj.sub).subscribe((user) => {
                if (user) {
                    this.user = Object.assign({}, user);
                    this.dummyUser = Object.assign({}, user);
                    self.cdr.detectChanges();
                }
            });
        }
    }

    save() {
        this.isLoading = true;
        if (this.user.userLogin && this.user.userId) {
            this._userService.updateUser(this.user).subscribe((user) => {
                this.user = user;
                this.dummyUser = Object.assign({}, user);
                this.isLoading = false;
                this.notify.success("User profile updated successfully.");
            }, (err) => {
                this.notify.error("Error occurred. Could not update the user.");
                this.isLoading = false;
            });
        }
    }
    onCancelChangePassword() {
         this.user = Object.assign({}, this.dummyUser);
    }
}