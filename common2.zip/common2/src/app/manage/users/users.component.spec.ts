import { UserService } from './service/user.service';
import { ManageModule } from './../manage.module';
import { RouterStub } from '../../../test/routerStub';
import { UsersComponent } from './users.component';
import { DebugElement } from '@angular/core';
import { async, ComponentFixture, fakeAsync, TestBed, tick } from '@angular/core/testing';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { NotyService } from 'sensorthink-commoncontrols/src/services/noty.service';
class MockUserService {
    getUsers(): Observable<any> { return Observable.of({}); }
    addUser(): Observable<any> { return Observable.of({}); }    
}

describe('USERS:... Component', () => {

    let component: UsersComponent;
    let fixture: ComponentFixture<UsersComponent>;
    let de: DebugElement;
    let el: HTMLElement;
    let service;
    let noty;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [ManageModule],
            providers: [{ provide: UserService, useClass: MockUserService },
            { provide: Router, useClass: RouterStub }, NotyService]
        })
        fixture = TestBed.createComponent(UsersComponent);
        component = fixture.componentInstance;
        service = fixture.debugElement.injector.get(UserService);
        noty = fixture.debugElement.injector.get(NotyService);
    }));

    it('should have a defined component', () => {
        expect(component).toBeDefined();
    });

    describe('When we call get all users data', () => {
        it(' should get all users', () => {
            fixture.detectChanges();
            spyOn(service, 'getUsers').and.returnValue(Observable.of({ content: [{}, {}] }));
            spyOn(component, 'setPagerConfig');
            component.getAllUsers(1, '');
            expect(component.users.length).toBe(2);
        })
    });

    describe('When we call setPagerConfig', () => {
        it(' should set the pager config', () => {
            component.setPagerConfig(10, 1, 5);
            expect(component.pagerConfig.totalItems).toBe(10);
            expect(component.pagerConfig.currentPage).toBe(1);
            expect(component.pagerConfig.itemsPerPage).toBe(5);
        })
    });

    describe('When we call onPageSizeChanged, onPageChanged, onSortChanged', () => {
        beforeEach(() => {
            component.setPagerConfig(10, 1, 1);
        })
        it(' should change the size of page with more users data', () => {
            spyOn(component, 'getAllUsers');
            component.onPageSizeChanged(10);
            expect(component.pagerConfig.itemsPerPage).toBe(10);
            expect(component.getAllUsers).toHaveBeenCalled();
        })
        it(' should change the page with next users data', () => {
            let pager = { page: 2 }
            spyOn(component, 'getAllUsers');
            component.onPageChanged(pager);
            expect(component.pagerConfig.currentPage).toBe(2);
            expect(component.getAllUsers).toHaveBeenCalled();

        })
        it(' should get sorted users data', () => {
            let args = ['firstName', 'asc']
            spyOn(component, 'getAllUsers');
            component.onSortChanged(args);
            expect(component.sortArgs).toBe('firstName,asc');
            expect(component.getAllUsers).toHaveBeenCalled();
        })
    });

    describe('When we call onSaveUser method', () => {
        beforeEach(() => {
            component.setPagerConfig(10, 1, 1);
        })
        it(' should close the popup window and save the user details in database', () => {
            expect(component.userForm).toBeDefined();
            spyOn(component.userForm, 'save').and.returnValue(Observable.of({}));
            spyOn(component, 'getAllUsers');
            component.onSaveUser();
            expect(component.userForm.save).toHaveBeenCalled();
            expect(component.getAllUsers).toHaveBeenCalled();
        })
    });   

    describe('When searchInputFilterData', () => {
        let input, isFirstLoad = true;
        beforeEach(function () {
            input = component.searchTxt;
            component.setPagerConfig(10, 1, 1);
        });
        it(' should set to a valid search text', fakeAsync(() => {
            spyOn(component, 'getAllUsers');
            component.searchInputFilterData();
            expect(component.searchTxt).toBe(input);
            tick(1000);
            fixture.detectChanges();
            expect(component.getAllUsers).toHaveBeenCalled();
        }))
        it(' should be first load', () => {
            component.searchInputFilterData();
            expect(component.isFirstLoad).toBeFalsy();
        })
    });
});
