import { MockHttpService } from './../../../../test/mockHttp.service';
import { SharedModule } from './../../../shared/shared.module';
import { UserService } from './user.service';
import { inject, TestBed } from '@angular/core/testing';
import { HttpModule, RequestMethod, Response, ResponseOptions, XHRBackend } from '@angular/http';
import { MockBackend } from '@angular/http/testing';
import { HttpService } from 'sensorthink-commoncontrols/src/common.module';

describe('Service: UserService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [HttpModule, SharedModule],
            providers: [UserService, { provide: HttpService, useClass: MockHttpService },
                { provide: XHRBackend, useClass: MockBackend }]
        }).compileComponents();
    })

    it('can instantiate service when inject service',
        inject([UserService], (service: UserService) => {
            expect(service instanceof UserService).toBe(true);
        }));

    it('can provide the mockBackend as XHRBackend',
        inject([XHRBackend], (backend: MockBackend) => {
            expect(backend).not.toBeNull('backend should be provided');
        }));

    describe('When get all user', () => {
        let backend: MockBackend;
        let service: UserService;
        let response: Response;
        const mockResponse = [{ userId: 1, status: true, userLogin: 'Admin', firstName: 'ad', lastName: 'min' },
        { userId: 1, status: true, userLogin: 'Admin', firstName: 'ad', lastName: 'min' }
        ];
        beforeEach(inject([HttpService, XHRBackend], (httpService: HttpService, be: MockBackend) => {
            backend = be;
            service = new UserService(httpService);
            let options = new ResponseOptions({ status: 200, body: { data: [] } });
            response = new Response(options);
        }));

        it(' should get users data list',
            inject([], () => {
                backend.connections.subscribe((connection) => {
                    connection.mockRespond(new Response(new ResponseOptions({ body: JSON.stringify(mockResponse) })));
                });
                service.getUsers(1, 10, "userName,asc", '').subscribe((res) => {
                    expect(res.length).toBe(mockResponse.length);
                }, (err) => {
                    console.log(err);
                })
            }));
    });

    describe('When ', () => {
        let backend: MockBackend;
        let service: UserService;
        let response: Response;
        let user = { userId: 2, status: true, userLogin: 'Admin', firstName: 'ad', lastName: 'min' };
        const mockResponse = { userId: 2, status: true, userLogin: 'Admin', firstName: 'ad', lastName: 'min' };

        beforeEach(inject([HttpService, XHRBackend], (httpService: HttpService, be: MockBackend) => {
            backend = be;
            service = new UserService(httpService);
            let options = new ResponseOptions({ status: 200, body: { data: [] } });
            response = new Response(options);
        }));

        it('get user by id should get user data',
            inject([], () => {
                backend.connections.subscribe((connection) => {
                    connection.mockRespond(new Response(new ResponseOptions({ body: JSON.stringify(mockResponse) })));
                });
                service.getUser(user.userId).subscribe((res) => {
                    expect(res.userId).toBe(mockResponse.userId);
                }, (err) => {
                    console.log(err);
                })
            }));
        it('addUser should Add new user data',
            inject([], () => {
                backend.connections.subscribe((connection) => {
                    expect(connection.request.method).toBe(RequestMethod.Post);
                    connection.mockRespond(new Response(new ResponseOptions({ body: JSON.stringify(mockResponse) })));
                });
                service.addUser(user).subscribe((res) => {
                    expect(res).toBeDefined();
                    expect(res.status).toBe(true);
                }, (err) => {
                    console.log(err);
                })
            }));
        it("updateUser should Update existing user's data",
            inject([], () => {
                backend.connections.subscribe((connection) => {
                    expect(connection.request.method).toBe(RequestMethod.Put);
                    connection.mockRespond(new Response(new ResponseOptions({ body: JSON.stringify(mockResponse) })));
                });
                service.updateUser(user).subscribe((res) => {
                    expect(res).toBeDefined();
                    expect(res.status).toBe(true);
                }, (err) => {
                    console.log(err);
                })
            }));
        it("deleteUser should delete user",
            inject([], () => {
                backend.connections.subscribe((connection) => {
                    expect(connection.request.method).toBe(RequestMethod.Delete);
                    connection.mockRespond(new Response(new ResponseOptions({ body: JSON.stringify(mockResponse) })));
                });
                service.deleteUser(user.userId).subscribe((res) => {
                    expect(res).toBeDefined();
                    expect(res.status).toBe(null);
                }, (err) => {
                    console.log(err);
                })
            }));
    });
});