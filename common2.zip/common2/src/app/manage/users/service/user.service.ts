import { Injectable } from '@angular/core';
import { HttpService } from 'sensorthink-commoncontrols/src/common.module';

@Injectable()
export class UserService {

  constructor(private $http: HttpService) { }

  getUsers(pageNumber: number, pageSize: number, sortArgs?: string, searchText: string = "") {
    let sortArg = sortArgs.split(",");
    let http = this.$http.iotContext.url("/api/users/search").addParam("pageNumber", pageNumber).addParam("pageSize", pageSize)
    if (sortArg.length === 2)
      http.addParam("sortByColumn", sortArg[0]).addParam("sortByDirection", sortArg[1])
    http.addParam("searchText", searchText)
    return http.get().map(res => res.json());
  }

  getUser(userId) {
    return this.$http.iotContext.url("/api/users/" + userId).get()
      .map(res => res.json());
  }
  /**
   * This method will returns user details based Login-User Id.
   * @param userId - Used id that user uses while login.
   */
  getUserDetailsByUserId(userId:string) {
    return this.$http.iotContext.url("/api/users/userLogin").addParam("userLogin",userId).get().map(res=>res.json());      
  }

  addUser(user) {
    var data = JSON.stringify(user);
    return this.$http.iotContext.url("/api/users").post(data)
      .map(res => res.json());
  }

  updateUser(user) {
    var data = JSON.stringify(user);
    return this.$http.iotContext.url("/api/users/" + user.userId).put(data).map(res => res.json());
  }

  deleteUser(userId) {
    return this.$http.iotContext.url("/api/users/" + userId).delete()
      .map(res => res);
  }

  getAllCompany() {
    return this.$http.iotContext.url("/api/company").get()
      .map(res => res.json());
  }


}
