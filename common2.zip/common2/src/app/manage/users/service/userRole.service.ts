import { Injectable } from '@angular/core';
import { HttpService } from 'sensorthink-commoncontrols/src/common.module';

@Injectable()
export class UserRoleService {

    constructor(private $http: HttpService) {
    }
    /**
     * This returns all the roles.
     */
    getRoles(){
        return this.$http.iotContext.url("/api/roles/").get().map(res=>res.json());               
    }
    /**
     * This returns all permissions based on roleId group by section name.
     * @param roleId :number
     */
     getRolesById(roleId:number){
        return this.$http.iotContext.url("/api/roles/"+roleId+"/permissionsgroupbypermissiongroup").get().map(res=>res.json());
    }
}