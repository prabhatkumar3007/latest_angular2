import { AuthService } from './../../auth/auth.service';
import { UserPermissionView } from './userPermissionView.component';
import { Observable } from 'rxjs/Observable';
import { BasicValidators } from '../../shared/services/basicValidators';
import { UserService } from './service/user.service';
import { User, UserRoles } from './user.data';
import { UserRoleService } from './service/userRole.service';
import { ChangeDetectorRef, Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthPermissionService } from "sensorthink-commoncontrols/src/utils.module";
import { SessionStorage } from 'sensorthink-commoncontrols/lib/webStore.module';
import { NotyService } from 'sensorthink-commoncontrols/src/services/noty.service';
import { IMultiSelectOption, IMultiSelectTexts, IMultiSelectSettings } from 'angular-2-dropdown-multiselect';

@Component({
  selector: 'user-modal',
  templateUrl: 'userForm.component.html'
})
export class UserFormComponent {
  form: FormGroup;
  title: string;
  user: User = new User();
  isEditMode: boolean = false;
  userRoles = [];
  userSelectedRoles = [];
  userPermissions = [];
  isSuperAdmin: boolean = false;
  jwt: any;
  nRightClicks = 0;

  companies: IMultiSelectOption[] = [];
  dropdownTexts: IMultiSelectTexts = {
    checkAll: 'Select all',
    uncheckAll: 'Unselect all',
    checked: 'item selected',
    checkedPlural: 'items selected',
    searchPlaceholder: 'Find',
    defaultTitle: 'Select Company',
    allSelected: 'All selected',
  };

  dropdownSettings: IMultiSelectSettings = {
    enableSearch: false,
    checkedStyle: 'checkboxes',
    buttonClasses: 'dropdown-toggle btn btn-default',
    dynamicTitleMaxItems: 1,
    displayAllSelectedText: true,
    showCheckAll: false,
    showUncheckAll: true
  };
  selectedCompanies: number[];

  constructor(
    private fb: FormBuilder,
    private cdr: ChangeDetectorRef,
    private _userService: UserService,
    private _userRoleService: UserRoleService,
    private _authPermissionService: AuthPermissionService,
    private _authPermission: AuthService,
    private notify: NotyService
  ) {
    this.getRoles();
    this.initializeMasterData();
  }

  ngOnInit() {
    this.isSuperAdmin = this._authPermissionService.isSuperAdmin();
    this.jwt = this._authPermission.getUserDataFromToken();
    this.createForm();
  }

  initializeMasterData() {
    let promises = [
      this._userService.getAllCompany(),
    ]

    Observable.forkJoin(promises).subscribe((res) => {
      let company = (res[0].constructor === Array) ? res[0] : [res[0]];
      this.setCompanyData(company)
    });
  }

  setCompanyData(company) {

    let companies = [];
    if (company.length > 0) {
      for (let comp of company) {
        comp.id = comp.companyId;//for multiselect you need id property
        companies.push(comp);
      }
      this.companies = companies;
    }
  }

  getRoles() {
    this._userRoleService.getRoles().subscribe((roles) => {
      if (roles) {
        this.userRoles = this.filterRoles(roles);
      }
    }, err => {
      this.notify.error("Roles not found.");
    });
  }

  filterRoles(roles) {
    if (this.isSuperAdmin) {
      return roles;
    } else {
      let roleWithoutSuperAdmin = [];

      roles.forEach(element => {
        if (!(element.name.toLowerCase() == "super_admin")) {
          roleWithoutSuperAdmin.push(element);
        }
      });
      return roleWithoutSuperAdmin;
    }
  }

  createForm(userObject?) {

    var formObject = {
      userLogin: [null, Validators.required],
      firstName: [null, Validators.required],
      lname: [null, Validators.required],
      email: [null, BasicValidators.email],
      status: [true]
    };

    if (this.isSuperAdmin) {
      formObject["companyModel"] = [this.selectedCompanies, Validators.required]
      if (userObject) {
        if (userObject.companies && userObject.companies.length > 0) {

          this.selectedCompanies = [];
          for (let company of userObject.companies) {
            this.selectedCompanies.push(company.companyId);
          }
          if (this.selectedCompanies.length == 0) {
            this.selectedCompanies = null;
          }
        }
      }
    }
    this.form = this.fb.group(formObject);
  }

  setUserInfo(userObj, callback?) {
    var self = this;
    this.userSelectedRoles = [];
    
    if (userObj) {  // in edit mode
      this.createForm(userObj);
      this.user = new User();
      this.cdr.detectChanges();// this is done to reset the form and resolve error of blank data on clicking edit on same row.
      this.isEditMode = true;
      this.form.controls['userLogin'].disable({ emitEvent: false });
      this.form.controls['status'].enable({ emitEvent: false });
      this._userService.getUserDetailsByUserId(userObj.userLogin).subscribe((user) => {
        if (user) {
          this.user = Object.assign({}, user);
          let result = this.allowUserToSave();
          this.initializeRole(this.user.roles);
          self.cdr.detectChanges();
          callback(result);
        } else {
          callback(false);
        }
      });
    }
    else {// in new
      this.form.controls['userLogin'].enable({ emitEvent: false });
      this.form.controls['status'].disable({ emitEvent: false });
      this.createForm();
      this.user = new User();
      let result = this.allowUserToSave();
      this.isEditMode = false;
      this.user.active = true;
      callback(result);
    }
  }

  allowUserToSave() {
    let result={showForm: true,message:""};
    if (!this.isSuperAdmin) {
      if (this.user && this.user.roles && this.user.roles.length>0) {       

        for (let role of this.user.roles)
          if (role["name"].toLowerCase()==="super_admin") {
            result={showForm: false,message:"You donot have rights to update the super Admin record."};
          return result;
          }

        if (this.user.userLogin == this.jwt.sub) {                    
          result={showForm: false,message:"Please visit My profile page to update record."};
          return result;
        }
      }
    }
    return result;

  }

  onRightClick(event) {
    this.nRightClicks++;
    return false;
  }

  save() {
    var result;
    this.user.roles = this.getAllSelectedRoles();
    if (this.isSuperAdmin) {
      this.user.companies = this.getAllSelectedCompanies();
    }

    if (this.user.userLogin && this.user.userId) {
      result = this._userService.updateUser(this.user);
    } else {
      result = this._userService.addUser(this.user)
    }
    this.isEditMode = false;
    return result;
  }

  onRoleClick(id, event) {
    if (event.target.checked) {
      this.userSelectedRoles.push(id);
    } else {
      if (this.userSelectedRoles.length > 0) {
        let index = this.userSelectedRoles.indexOf(id);
        if (index >= 0) {
          this.userSelectedRoles.splice(index, 1);
        }
      }
    }
  }

  initializeRole(roles: any[]) {
    for (let role of roles) {
      this.userSelectedRoles.push(role.roleId);
    }
  }

  getAllSelectedRoles() {
    let roles = [];
    for (let id of this.userSelectedRoles) {
      roles.push({ roleId: id });
    }
    return roles;
  }

  getAllSelectedCompanies() {
    let roles = [];
    for (let id of this.selectedCompanies) {
      roles.push({ companyId: id });
    }
    return roles;
  }

  checkRoles(roleId) {
    if (this.user.roles) {
      for (let role of this.user.roles) {
        if (roleId == role.roleId) {
          return true;
        }
      }
    }
    return false;
  }
}