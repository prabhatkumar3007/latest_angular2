import { FilterParams, ActionButtons } from 'sensorthink-commoncontrols/src/components/advancedFilter/advancedFilter.data';
import 'rxjs/add/operator/debounceTime';
import { UserService } from './service/user.service';
import { UserFormComponent } from './userForm.component';
import { ChangeDetectorRef, Component, OnInit, ViewChild } from '@angular/core';
import { FormControl } from '@angular/forms';
import { ModalDirective } from 'ng2-bootstrap';
import { NotyService } from 'sensorthink-commoncontrols/src/services/noty.service';
import { Roles } from './user.data';

@Component({
  templateUrl: 'users.component.html'
})
export class UsersComponent implements OnInit {
  filterConfig: FilterParams;
  public users: any[];
  public angular: any;
  public modelTitle: String;
  public submitText: String;
  public pagerConfig: any;
  public isLoading: boolean = false;
  public sortArgs: string;
  isFirstLoad: boolean = false;
  public isAdd: boolean = false;
  public sideBarVisible: boolean = false;
  searchTxt = '';
  searchTxtControl = new FormControl();
  callBack = this.onCheckBoxChecked.bind(this);
  selectedCheckboxCount = [];
  @ViewChild(UserFormComponent) userForm: UserFormComponent;
  @ViewChild('userModal') public userModal: ModalDirective;

  constructor(private _service: UserService, private _cdr: ChangeDetectorRef, private noty: NotyService, ) {
    this.sortArgs = "userLogin,asc";
    this.filterConfig = new FilterParams();
    this.filterConfig.actionSubSection.isExportTo = false;
    this.filterConfig.actionSubSection.isChangeState = false;
    this.filterConfig.actionButtons = [new ActionButtons("Edit", true, this.onEditUserModal.bind(this)), new ActionButtons("Delete", true, this.onDeleteUserModal.bind(this))];
  }

  ngOnInit() {
    this.searchInputFilterData()
    this.setPagerConfig(0, 0);
    this.getAllUsers(1, this.sortArgs);
  }

  searchInputFilterData() {
    this.searchTxtControl.valueChanges
      .debounceTime(1000)
      .subscribe(newValue => {
        this.searchTxt = newValue.trim();
        if (((this.searchTxt.length >= 1 || this.searchTxt.length === 0) && this.searchTxt !== "") || this.isFirstLoad) {
          this.isFirstLoad = (this.searchTxt.length === 0) ? false : true;
          this.getAllUsers(this.pagerConfig.currentPage, this.sortArgs, this.searchTxt);
        }
      });
  }

  setPagerConfig(totalItems, currentPage, itemsPerPage?) {
    this.pagerConfig = {
      totalItems: totalItems,
      currentPage: currentPage || 1,
      itemsPerPage: itemsPerPage || 10,
      smallnumPages: 0
    }
  }

  onOpenUserModal(user?) {
    this.modelTitle = (user === undefined) ? "CREATE NEW USER" : "EDIT USER";
    this.submitText = (user === undefined) ? "Create" : "Save"
    var self = this;

    this.userForm.setUserInfo(user, function (data) {
      if (data != undefined && data) {
        if (data.showForm) {
          self.userModal.show();
        } else {
          self.noty.error(data.message);
        }
      }
    });

  }

  getAllUsers(pageNumber: number, sortArgs: string, searchTxt?: string) {
    this.isLoading = true;
    this._service.getUsers(pageNumber, this.pagerConfig.itemsPerPage, sortArgs, searchTxt).subscribe((users) => {
      if (users) {
        this.setPagerConfig(users.totalElements, this.pagerConfig.currentPage, this.pagerConfig.itemsPerPage)
        this.users = this.setCompanyData(users.content);
      }
      this.isLoading = false;
    });
  }

  setCompanyData(users) {
    let newList = [];
    users.forEach(element => {
      let companyName = "";
      element.companies.forEach(company => {
        companyName = companyName + company.name + ",";
      });
      if (companyName.length > 0) {
        companyName = companyName.substring(0, companyName.length - 1);
      }
      element.companyName = companyName;
      newList.push(element);
    });
    return newList;
  }


  onSaveUser() {
    this.isAdd = false;
    if (this.userForm.user && this.userForm.user.userId == undefined) {
      this.isAdd = true;
    }
    this.selectedCheckboxCount = [];

    this.userForm.save().subscribe(
      (res) => {
        this.userModal.hide();
        this.getAllUsers(this.pagerConfig.currentPage, this.sortArgs, this.searchTxt);
        if (this.isAdd) {
          this.noty.success("User created successfully.");
        } else {
          this.noty.success("User updated successfully.");
        }
      }, err => {
        if (err.status === 409)
          this.noty.error("User Id already exists in system. Please change the user id.");
        return false;
      });
  }

  onPageSizeChanged(pageSize) {
    this.pagerConfig.itemsPerPage = pageSize;
    this.getAllUsers(1, this.sortArgs);
    this._cdr.detectChanges();
  }

  onPageChanged(pager) {
    this.pagerConfig.currentPage = pager.page;
    this.selectedCheckboxCount = [];
    this.getAllUsers(pager.page, this.sortArgs, this.searchTxt);
  }

  onSortChanged(sortArgs) {
     if (sortArgs[0].pop)
      this.sortArgs = sortArgs[0][0] + "," + sortArgs[0][1];
    else
      this.sortArgs = sortArgs[0] + "," + sortArgs[1];
    this.getAllUsers(this.pagerConfig.currentPage, this.sortArgs, this.searchTxt);
  }

  applyFormatting(columns) {
    this.getAllUsers(this.pagerConfig.currentPage, this.sortArgs);
  }

  onCheckBoxChecked(user, e) {
    if (e.target.checked === undefined)
      return;
    if (e.target.checked) {
      this.selectedCheckboxCount.push(user);
    }
    else {
      this.selectedCheckboxCount.splice(this.selectedCheckboxCount.indexOf(user), 1);
    }
  }

  onEditUserModal() {
    if (this.validate()) {
      this.onOpenUserModal(this.selectedCheckboxCount[0]);
    }
  }

  onDeleteUserModal() {
    if (this.validate(true)) {
      var self = this.selectedCheckboxCount[0];
      this.selectedCheckboxCount = [];
      this.noty.confirm().then(() => {
        this._service.deleteUser(self.userId)
          .subscribe(res => {
            this.noty.success("User deleted successfully.");
            this.getAllUsers(this.pagerConfig.currentPage, this.sortArgs);
          },
          err => {
            this.noty.error("Error occurred.Could not delete the user.");
          });
      }, err => {
        this.getAllUsers(this.pagerConfig.currentPage, this.sortArgs);
      })
    }
  }

  validate(isDelete?: boolean) {
    if (this.selectedCheckboxCount.length > 1) {
      this.noty.error("Please select only one user.")
      return false;
    }
    if (this.selectedCheckboxCount.length === 0) {
      this.noty.error("Please select at least one user.");
      return false;
    }
    if (isDelete) {
      let user = this.selectedCheckboxCount[0];
      if (user.roles) {
        for (let role of user.roles)
          if (role.name.toLowerCase()==="super_admin") {
            this.noty.error("Could not delete super admin.");
            return false;
          }
      }
      if (user.userLogin == this.userForm.jwt.sub) {      
          this.noty.error("Could not delete record.");                        
          return false;
        }

    }
    return true;
  }

}