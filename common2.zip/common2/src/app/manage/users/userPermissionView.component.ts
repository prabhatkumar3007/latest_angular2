import { Component, Input, OnInit } from '@angular/core';
import { UserRoleService } from './service/userRole.service';

@Component({
    selector: 'userPermission-view',
    templateUrl: 'userPermissionView.component.html'
})

export class UserPermissionView {
    
    constructor(private _userRoleService: UserRoleService) {  }

    userPermissions: any;
    isDataFound: boolean = true;
    isSuperAdmin: boolean = false;
    arrayOfKeys = [];
    @Input() userRoleId: number;
    @Input() roleName: string;

    ngOnInit() {        
        if (this.roleName) {
            this.isSuperAdmin = this.roleName.indexOf("SUPER") > -1;
            if(this.isSuperAdmin) {this.isDataFound = false; }
        }
        if(!this.isSuperAdmin){
            this.getPermissionsByRoleId(this.userRoleId);            
        }
    }

    getPermissionsByRoleId(roleId) {
        this._userRoleService.getRolesById(roleId).subscribe((permisions) => {
            if (permisions) {
                this.userPermissions = permisions;
                this.arrayOfKeys = Object.keys(this.userPermissions)
            }
        }, err => {
            this.isDataFound = false;
        })
    };
}