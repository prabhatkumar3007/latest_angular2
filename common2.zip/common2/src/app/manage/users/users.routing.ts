import { AuthGuard } from '../../auth/auth-guard.service';
import { PreventUnsavedChangesGuard } from '../../shared/services/prevent-unsaved-changes-guard.service';
import { UserFormComponent } from './userForm.component';
import { UsersComponent } from './users.component';
import { RouterModule } from '@angular/router';

export const UsersRouting = RouterModule.forChild([
  {
    path: 'users/:id',
    component: UserFormComponent,
    canActivate: [AuthGuard],
    data: { permission: ['user'] },
    canDeactivate: [PreventUnsavedChangesGuard]
  },
  {
    path: 'users/new',
    component: UserFormComponent,
    canActivate: [AuthGuard],
    data: { permission: ['user'] },
    canDeactivate: [PreventUnsavedChangesGuard]
  },
  { path: 'users', component: UsersComponent, canActivate: [AuthGuard], data: { permission: ['user','User'] } },
]);