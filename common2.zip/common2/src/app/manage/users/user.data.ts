export class User {
    userId: number;
    name: string;
    active: boolean;
    userLogin: string;
    password: any = "5f4dcc3b5aa765d61d8327deb882cf99";
    firstName: string;
    lastName: string;
    middleInitial: string;
    title: string;
    email: string;
    phone: string;
    fax: string;
    jobTitle: string
    cellPhone: string;
    country: string;
    language: string;
    variant: string;
    dateFormat: string;
    timeZone: string;
    roles:UserRoles[];    
    companies:any[];  
}

export class UserRoles{
    userRoleId:number;
    userId:number;
    roleId:number;  
    rolePermissions:RolePermissions[];  
}

export class Roles{
    roleId:number;
    name:string;    
    description:string
    active:boolean;
    company:string;    
}

export class RolePermissions{
    rolePermissionId:number;
    roleId:number;    
    permissionId:number;
}