import { ManageModule } from './../manage.module';
import { UserService } from './service/user.service';
import { User } from './user.data';
import { ComponentFixture, TestBed, async } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement, Directive } from '@angular/core';
import { UserFormComponent } from './userForm.component';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { RouterStub } from '../../../test/routerStub';

class MockUserService {
    updateUser(): Observable<any> { return Observable.of({}); };
    addUser(): Observable<any> { return Observable.of({}); };
}

describe('USERFORM:... Component', () => {

    let component: UserFormComponent;
    let fixture: ComponentFixture<UserFormComponent>;
    let de: DebugElement;
    let el: HTMLElement;
    let service;
    let FormBuilderObj;
    let user = new User();
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [ManageModule],
            providers: [{ provide: UserService, useClass: MockUserService },
            { provide: Router, useClass: RouterStub }, FormBuilder]
        })
        fixture = TestBed.createComponent(UserFormComponent);
        component = fixture.componentInstance;
        service = fixture.debugElement.injector.get(UserService);
        FormBuilderObj = fixture.debugElement.injector.get(FormBuilder);
    }));

    it('should have a defined component', () => {
        expect(component).toBeDefined();
    });

    describe('When we call setUserInfo', () => {
        let userObj = {};
        beforeEach(() => {
            spyOn(component, 'createForm');
            component.setUserInfo(userObj);
        })
        it(' should set user edit mode', () => {
            expect(component.isEditMode).not.toBeFalsy();
            component.form.controls['userLogin'].disable({ emitEvent: false });
            component.form.controls['status'].enable({ emitEvent: false });
            this.user = Object.assign({}, userObj);
        })
        it(' should set user add mode', () => {
            component.form.controls['userLogin'].enable({ emitEvent: false });
            component.form.controls['status'].disable({ emitEvent: false });
            expect(component.createForm).toHaveBeenCalled();
        })
    });

    describe('When we call save', () => {
        it(' should save a new user ', () => {
            user.userId = null;
            spyOn(service, 'addUser').and.returnValue(Observable.of(user));
            let res = component.save();
            expect(res.value).toBe(user);
        })
        it(' should udpate an existing user ', () => {
            user.userId = 1;
            spyOn(service, 'updateUser').and.returnValue(Observable.of(user));
            let res = component.save();
            expect(user.userId).toBe(1);
        })
    });
});
