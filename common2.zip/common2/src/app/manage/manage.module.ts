import { UsersRouting } from './users/users.routing';
import { RouterModule } from '@angular/router';
import { ControlsModule } from './../controls/controls.module';
import { SharedModule } from './../shared/shared.module';
import { UserService } from './users/service/user.service';
import { UserRoleService } from './users/service/userRole.service';
import { UserFormComponent } from './users/userForm.component';
import { UsersComponent } from './users/users.component';
import { IotRouteMessagesComponent } from './messages/iotRouteMessages.component';
import { HubRouteMessagesComponent } from './messages/hubRouteMessages.component';
import { MessagesService } from './messages/messages.service'
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ModalModule } from 'ng2-bootstrap/modal';
import { UserPermissionView } from './users/userPermissionView.component';
import { MultiselectDropdownModule } from 'angular-2-dropdown-multiselect';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule,
    ControlsModule,
    SharedModule,
    ModalModule.forRoot(),
    UsersRouting,
    MultiselectDropdownModule
  ],
  declarations: [
    UserFormComponent,
    UsersComponent,
    IotRouteMessagesComponent,
    HubRouteMessagesComponent,
    UserPermissionView
  ],
  exports: [
    UserFormComponent,
    UsersComponent,
    IotRouteMessagesComponent,
    HubRouteMessagesComponent,
    UserPermissionView
  ],
  providers: [UserService,UserRoleService,MessagesService]
})
export class ManageModule { }