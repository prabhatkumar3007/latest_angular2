import { ShareDataService } from 'sensorthink-commoncontrols/src/services/shareDataService';
import { NotyService } from 'sensorthink-commoncontrols/src/services/noty.service';
import {
  Component,
  OnInit,
  ViewChild
} from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { MessagesService } from './messages.service';
import { Router } from '@angular/router';
import { DragulaService } from "ng2-dragula";
import { FormControl } from '@angular/forms';
import { FilterParams, ActionButtons } from 'sensorthink-commoncontrols/src/components/advancedFilter/advancedFilter.data';
import { AdvanceFilterService } from "./../../shared/services/advanceFilterIot.service";
import { AdvancedFilterComponent } from "sensorthink-commoncontrols/src/components/advancedFilter/advancedFilter.component";

declare var moment: any

@Component({
  templateUrl: 'hubRouteMessages.component.html'

})
export class HubRouteMessagesComponent implements OnInit {
  public hubData: any;
  public sortArgs: string;
  public pagerConfig: any;
  isFirstLoad: boolean = false;
  searchTxt = '';
  searchTxtControl = new FormControl();
  appliedFilterData: FilterParams;
  public sideBarVisible: boolean;
  public filterConfig: FilterParams;
  callBack = this.onCheckBoxChecked.bind(this);
  isLoading: boolean = false;
  AllHubRouteName = [];
  AllMessages = [];
  loadSavedFilters: any;
  public masterData: any = { messageType: [], iotRouteName: [] };
  @ViewChild(AdvancedFilterComponent) advanceFilter: AdvancedFilterComponent;

  constructor(private service: MessagesService, private sharedService: ShareDataService, private router: Router, private notyService: NotyService, private filterService: AdvanceFilterService) {
    this.sortArgs = "messageId,desc";
    this.initializeMasterData();
    this.filterConfig = this.createFilterParams();
    this.pagerConfig = {
      totalItems: 64,
      currentPage: 1,
      smallnumPages: 0,
    }
  }
  initializeMasterData() {
    let promises = [
      this.service.getMessageTypes(),
      this.service.getHubRoutes()
    ]

    Observable.forkJoin(promises).subscribe((res) => {
      this.masterData.companies = (res[0].constructor === Array) ? res[0] : [res[0]];
      this.masterData.iotRouteName = res[1];
      if (res[0] && res[1]) {
        this.masterData.companies.forEach(el => {
          this.AllMessages.push(el.instance.code)
        });
        this.masterData.iotRouteName.content.forEach(el => {
          this.AllHubRouteName.push(el.routeName)
        });
      }
    })
  }
  setPagerConfig(totalItems, currentPage, itemsPerPage?) {
    this.pagerConfig = {
      totalItems: totalItems,
      currentPage: currentPage || 1,
      itemsPerPage: itemsPerPage || 10,
      smallnumPages: 0
    }
  }
  ngOnInit() {
    this.searchInputFilterData();
    this.setPagerConfig(0, 0);
    this.getSavedFilterDataList();
    this.loadHubRouteData(1, this.sortArgs, this.appliedFilterData, this.searchTxt)
  }
  getSavedFilterDataList() {
    this.filterService.getAllLoadSaveFilterData('HUBROUTE').then((res) => {
      this.loadSavedFilters = this.filterService.createFilterObjectFormat(res)
      if (this.loadSavedFilters) {
        this.filterConfig.saveLoadFilter.options = this.loadSavedFilters;
      }
      this.isLoading = false;
    })
  }
  searchInputFilterData() {
    this.searchTxtControl.valueChanges
      .debounceTime(1000)
      .subscribe(newValue => {
        this.searchTxt = newValue.trim();
        if (((this.searchTxt.length >= 1 || this.searchTxt.length === 0) && this.searchTxt !== "") || this.isFirstLoad) {
          this.isFirstLoad = (this.searchTxt.length === 0) ? false : true;
          this.loadHubRouteData(this.pagerConfig.currentPage, this.sortArgs, this.appliedFilterData, this.searchTxt);
        }
      });
  }
  loadHubRouteData(pageNumber: number, sortArgs: string, filterObj, searchTxt?: string) {
    this.isLoading = true;
    this.service.getHubRouteData(pageNumber, this.pagerConfig.itemsPerPage, sortArgs, filterObj, searchTxt).subscribe((data) => {
      if (data) {
        this.setPagerConfig(data.totalElements, this.pagerConfig.currentPage, data.size)
        this.hubData = data.content;
      } else {
        this.setPagerConfig(0, this.pagerConfig.currentPage, this.pagerConfig.itemsPerPage)
        this.hubData = [];
      }
      this.isLoading = false;
    });
  }
  onHubSortChanged(sortArgs) {
    if (sortArgs[0].pop)
      this.sortArgs = sortArgs[0][0] + "," + sortArgs[0][1];
    else
      this.sortArgs = sortArgs[0] + "," + sortArgs[1];
    this.loadHubRouteData(this.pagerConfig.currentPage, this.sortArgs, this.appliedFilterData, this.searchTxt);
  }
  onHubPageSizeChanged(pageSize) {
    this.pagerConfig.itemsPerPage = pageSize;
    this.loadHubRouteData(1, this.sortArgs, this.appliedFilterData, this.searchTxt);
  }
  onHubPageChanged(pager) {
    this.pagerConfig.currentPage = pager.page;
    this.loadHubRouteData(pager.page, this.sortArgs, this.appliedFilterData, this.searchTxt);
  }
  filterApplied(filterObj: FilterParams) {
    this.appliedFilterData = JSON.parse(JSON.stringify(filterObj));
    //todo: used from --- http://stackoverflow.com/questions/728360/how-do-i-correctly-clone-a-javascript-object    
    this.loadHubRouteData(this.pagerConfig.currentPage, this.sortArgs, this.appliedFilterData, this.searchTxt);
  }
  clearFilters() {
    this.appliedFilterData = null;
    this.filterConfig = this.createFilterParams();
    this.loadHubRouteData(this.pagerConfig.currentPage, this.sortArgs, this.appliedFilterData, this.searchTxt);
  }
  onRemoveFilter(filterObj: FilterParams) {
    this.loadHubRouteData(this.pagerConfig.currentPage, this.sortArgs, this.appliedFilterData, this.searchTxt);
  }
  onResendMessage() {
    let updateArray = this.updateObjectArray(this.service.selectedState);
    this.service.resendMessages(updateArray, "hub").subscribe((res) => {
      this.notyService.success("Selected message(s) successfully sent.");
      this.loadHubRouteData(this.pagerConfig.currentPage, this.sortArgs, this.appliedFilterData, this.searchTxt);
      this.service.selectedState = [];
    },
      (err) => {
        this.service.selectedState = [];
      });
  }
  updateObjectArray(array) {
    let a = [];
    array.forEach(e => {
      let b = { "module": "hub", "messageId": e.messageId }
      a.push(b);
    });
    return a;
  }
  onCheckBoxChecked(iot, e) {
    if (e.target.checked == true) {
      this.service.selectedState.push(iot);
      let prevVal = this.service.selectedState[0].status;
      let isStateValid = true;
      this.service.selectedState.forEach(el => {
        if (el.status !== prevVal)
          isStateValid = false;
      });
      if (!isStateValid) {
        this.service.selectedState.splice(this.service.selectedState.indexOf(iot), 1);
        this.notyService.error("Selected routes do not have the same status. Please select routes of similar status")
        e.target.checked = false;
      }
    }
    else {
      this.service.selectedState.splice(this.service.selectedState.indexOf(iot), 1);
    }
  }
  createFilterParams(): FilterParams {
    let params = new FilterParams(); // initialises to default on object creation
    params.state.isVisible = false;
    params.site.isVisible = false;
    params.shift.isVisible = false;
    params.aging.isVisible = false;
    params.priority.isVisible = false;
    params.baseMetric.isVisible = false;
    params.otherMetric.isVisible = false;
    params.routeName.isVisible = true;
    params.messageType.isVisible = true;
    params.actionButtons = [new ActionButtons("Resend Message", true, this.onResendMessage.bind(this))];
    params.actionSubSection.isChangeState = false;
    params.actionSubSection.isExportTo = false;
    params.actionSubSection.isTransaction = false;
    params.taskType.isVisible = false;
    params.routeName.options = this.AllHubRouteName;
    params.messageType.options = this.AllMessages;
    params.dateRange.from = moment(new Date()).format("YYYY-MM-DDT00:00:00");
    params.dateRange.to = moment(new Date()).format("YYYY-MM-DDT23:59:59");
    if (this.loadSavedFilters) {
      params.saveLoadFilter.options = this.loadSavedFilters;
    }
    return params;
  }
  applyFormatting(columns) {
    this.loadHubRouteData(this.pagerConfig.currentPage, this.sortArgs, this.appliedFilterData, this.searchTxt);
  }
  onSaveFilterClick(saveFilterObject: FilterParams) {
    if (this.appliedFilterData) {
      this.isLoading = true;
      if (saveFilterObject.saveFilterName.selectedValue && saveFilterObject.saveFilterName.selectedValue !== '') {
        if (saveFilterObject.filterId) {
          this.filterService.updateFilters('HUBROUTE', this.appliedFilterData).subscribe((res) => {
            this.notyService.success(saveFilterObject.saveFilterName.selectedValue + " filter is updated successfully.");
            this.getSavedFilterDataList();
            this.resetDropDownOptions(saveFilterObject);
          }, err => {
            this.isLoading = false;
            this.notyService.error(err);
          });
        } else {
          //new filter 
          this.filterService.saveNewFilters('HUBROUTE', this.appliedFilterData, saveFilterObject.saveFilterName.selectedValue).subscribe((res) => {
            this.notyService.success(saveFilterObject.saveFilterName.selectedValue + " filter is saved successfully.");
            this.getSavedFilterDataList();
            this.resetDropDownOptions(saveFilterObject);
          }, err => {
            this.isLoading = false;
            if (err.status === 409)
              this.notyService.error('Filter name is already exist');
            else
              this.notyService.error(err);
          });
        }
      } else {
        this.notyService.error("Please enter filter name.");
        this.isLoading = false;
      }
    } else
      this.notyService.error("Please click on apply button to apply filters.");
  }
  onLoadFilterCall(loadFilterObj: FilterParams) {
    if (loadFilterObj.saveLoadFilter.selectedValue && loadFilterObj.saveLoadFilter.selectedValue !== '') {
      this.filterService.getLoadSaveFilterData('HUBROUTE', loadFilterObj.saveLoadFilter.selectedValue).then((res) => {
        if (res) {
          let result: FilterParams = JSON.parse(res.value)
          this.resetDropDownOptions(result);
          this.filterConfig = this.filterService.resetFilterObject(result);
          this.filterConfig.saveLoadFilter.options = this.loadSavedFilters;
          this.filterConfig.saveLoadFilter.selectedValue = loadFilterObj.saveLoadFilter.selectedValue;
          this.filterConfig.saveFilterName.selectedValue = loadFilterObj.saveLoadFilter.selectedValue;
          this.filterConfig.filterId = res.id;
          this.filterApplied(result);
          let dates = this.filterService.setDateForFilter(result.dateRange.from, result.dateRange.to)
          if (this.advanceFilter && this.advanceFilter.fromDatePicker && this.advanceFilter.fromDatePicker.datepickerObj) {
            this.advanceFilter.fromDatePicker.datepickerObj.selectDate([dates[0]]);
          }
          if (this.advanceFilter && this.advanceFilter.toDatePicker && this.advanceFilter.toDatePicker.datepickerObj) {
            this.advanceFilter.toDatePicker.datepickerObj.selectDate([dates[1]]);
          }
        }
      }, err => {
        this.notyService.error(err);
      });
    } else {
      this.clearFilters();
    }
  }
  resetDropDownOptions(saveFilterObject) {
    this.filterConfig = saveFilterObject;
    this.filterConfig.routeName.options = this.AllHubRouteName;
    this.filterConfig.messageType.options = this.AllMessages;
  }
}