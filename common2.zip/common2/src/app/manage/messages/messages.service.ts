import { Injectable } from '@angular/core'
import { HttpService } from 'sensorthink-commoncontrols/src/common.module';
import { UtilService } from "sensorthink-commoncontrols/src/services/util.service";


@Injectable()
export class MessagesService {
    public selectedState = [];
    public selectedRouteName = [];
    constructor(private $http: HttpService, private _utilService: UtilService) { }

    getIotRouteData(pageNumber?: number, pageSize?: number, sortArgs?: string, filterObj?: any, searchText: string = "") {
        let sortArg = sortArgs.split(",");
        let route: any;
        if (!filterObj) {
            route = {
                "startDate": "",
                "endDate": "",
                "status": [],
                "agingFrom": "",
                "agingTo": "",
                "pageNumber": pageNumber,
                "pageSize": pageSize,
                "module": "iot",
                "orderBy": [
                    { "sortBy": sortArg[0], "direction": sortArg[1] }
                ],
                "messageId": searchText
            }
        } else {
            route = {
                "startDate": filterObj.dateRange.from || null,
                "endDate": filterObj.dateRange.to || null,
                "routeName": filterObj.routeName.selectedValue || null,
                "messageType": filterObj.messageType.selectedValue || null,
                "pageNumber": pageNumber,
                "pageSize": pageSize,
                "module": "iot",
                "orderBy": [
                    { "sortBy": sortArg[0], "direction": sortArg[1] }
                ],
                "messageId": searchText
            }
        }
        let data = JSON.stringify(route);
        let http = this.$http.iotContext.url("/api/message")
        return http.post(data).map((res) => {
            let obj = res.json();
            if (obj)
                this._utilService.setTimeZone(obj.content, ["createdTime", "modifiedTime"]);
            return obj;
        });
    }

    getHubRouteData(pageNumber?: number, pageSize?: number, sortArgs?: string, filterObj?: any, searchText: string = "") {
        let sortArg = sortArgs.split(",");
        let route: any;
        if (!filterObj) {
            route = {
                "startDate": "",
                "endDate": "",
                "status": [],
                "agingFrom": "",
                "agingTo": "",
                "pageNumber": pageNumber,
                "pageSize": pageSize,
                "module": "hub",
                "orderBy": [
                    { "sortBy": sortArg[0], "direction": sortArg[1] }
                ],
                "messageId": searchText
            }
        } else {
            route = {
                "startDate": filterObj.dateRange.from || null,
                "endDate": filterObj.dateRange.to || null,
                "routeName": filterObj.routeName.selectedValue || null,
                "messageType": filterObj.messageType.selectedValue || null,
                "pageNumber": pageNumber,
                "pageSize": pageSize,
                "module": "hub",
                "orderBy": [
                    { "sortBy": sortArg[0], "direction": sortArg[1] }
                ],
                "messageId": searchText
            }
        }
        let data = JSON.stringify(route);
        let http = this.$http.iotContext.url("/api/message")
        return http.post(data).map((res) => {
            let obj = res.json();
            if (obj)
                this._utilService.setTimeZone(obj.content, ["createdTime", "modifiedTime"]);
            return obj;
        });
    }
    resendMessages(messageId, Type) {
        if (Type == "iot")
            return this.$http.iotContext.url("/api/message/resendMessage").post(messageId);
        else
            return this.$http.iotContext.url("/api/message/resendMessage").post(messageId);
    }
    getMessageTypes() {
        return this.$http.iotContext.url("/api/common/messagetype").get().map(res => {
            let options = []
            res.json().forEach(opt => {
                options.push({
                    id: opt.messageTypeId,
                    name: opt.code,
                    instance: opt
                })
            });
            return options;
        });
    }
    getIotRoutes(pageNumber?: number, pageSize?: number, sortArgs?: string, searchText: string = "") {
        //let sortArg = sortArgs.split(",");
        let route: any;
        route = {
            "fromDate": "",
            "endDate": "",
            "status": [],
            "agingFrom": "",
            "agingTo": "",
            "pageNumber": pageNumber,
            "pageSize": pageSize,

            "searchText": searchText
        }
        let data = JSON.stringify(route);
        let http = this.$http.iotContext.url("/api/routes/search")
        return http.post(data).map((res) => {
            let obj = res.json();
            return obj;
        });
    }
    getHubRoutes(pageNumber?: number, pageSize?: number, sortArgs?: string, searchText: string = "") {
        //let sortArg = sortArgs.split(",");
        let route: any;
        route = {
            "fromDate": "",
            "endDate": "",
            "status": [],
            "agingFrom": "",
            "agingTo": "",
            "pageNumber": pageNumber,
            "pageSize": pageSize,

            "searchText": searchText
        }
        let data = JSON.stringify(route);
        let http = this.$http.iotContext.url("/api/hubroutes/search")
        return http.post(data).map((res) => {
            let obj = res.json();
            return obj;
        });
    }
    getMessageHubType() {
        return this.$http.iotContext.url("/api/common/messagetype").get().map(res => {
            let options = []
            res.json().forEach(opt => {
                options.push({
                    id: opt.messageTypeId,
                    name: opt.code,
                    instance: opt
                })
            });
            return options;
        });
    }
}