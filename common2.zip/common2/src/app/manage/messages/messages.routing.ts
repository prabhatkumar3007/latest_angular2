// import { AuthGuard } from '../../auth/auth-guard.service';
// import { PreventUnsavedChangesGuard } from '../../shared/services/prevent-unsaved-changes-guard.service';
// import { IotRouteMessagesComponent } from './iotRouteMessages.component';
// import { HubRouteMessagesComponent } from './hubRouteMessages.component';
// import { RouterModule } from '@angular/router';

// export const MessagesRouting = RouterModule.forChild([
//   { path: 'iotRoute-monitor', component: IotRouteMessagesComponent }
// ]);