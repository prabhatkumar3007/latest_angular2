import { HttpService } from 'sensorthink-commoncontrols/src/common.module';
import { ManageModule } from './manage/manage.module';
import { IGlobals } from 'sensorthink-commoncontrols/src/services/IGlobal.interface';
import { AppComponent } from './app.component';
import { routing } from './app.routing';
import { AuthGuard } from './auth/auth-guard.service';
import { AuthService } from './auth/auth.service';
import { ConfigureModule } from './configure/configure.module';
import { MonitorModule } from './monitor/monitor.module'
import { HomeComponent } from './homePage.component';
import { LoginComponent } from './login.component';
import { NotFoundComponent } from './shared/components/not-found.component';
import { Globals } from './shared/services/globals.service';
import { PreventUnsavedChangesGuard } from './shared/services/prevent-unsaved-changes-guard.service';
import { SharedModule } from './shared/shared.module';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Http } from '@angular/http';
import { BrowserModule } from '@angular/platform-browser';
import { LocalStorageService, WebStorageModule } from 'sensorthink-commoncontrols/lib/webStore.module';
import { AuthPermissionService } from 'sensorthink-commoncontrols/src/utils.module';

export function httpServiceFactory(http: Http): HttpService {
  return new HttpService(http, new Globals());
}

export let HttpServiceProvider =
  {
    provide: HttpService,
    useFactory: httpServiceFactory,
    deps: [Http]
  };

@NgModule({
  imports: [
    BrowserModule,
    FormsModule,
    SharedModule,
    ConfigureModule,
    MonitorModule,
    routing,
    WebStorageModule,
    ManageModule
  ],
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    NotFoundComponent
  ],
  providers: [HttpServiceProvider, { provide: 'globalConfig', useClass: Globals }, AuthService, AuthGuard,
    PreventUnsavedChangesGuard, LocalStorageService, AuthPermissionService],
  bootstrap: [AppComponent]
})
export class AppModule { }