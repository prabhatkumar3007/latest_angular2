import { Injectable } from '@angular/core'
import { HttpService } from 'sensorthink-commoncontrols/src/common.module';

@Injectable()
export class MonitorService {
    public selectedState = [];
    public selectedRouteName = [];
    constructor(private $http: HttpService) { }

    getIotRouteData(pageNumber?: number, pageSize?: number, sortArgs?: string, searchText: string = "") {
        let sortArg = sortArgs.split(",");
        let route: any;
        route = {
            "fromDate": "",
            "endDate": "",
            "status": [],
            "agingFrom": "",
            "agingTo": "",
            "pageNumber": pageNumber,
            "pageSize": pageSize,
            "orderBy": [
                { "sortBy": sortArg[0], "direction": sortArg[1] }
            ],
            "searchText": searchText
        }
        let data = JSON.stringify(route);
        let http = this.$http.iotContext.url("/api/routes/monitor")
        return http.post(data).map((res) => {
            let obj = res.json();
            return obj;
        });
    }

    getHubRouteData(pageNumber?: number, pageSize?: number, sortArgs?: string, searchText: string = "") {
        let sortArg = sortArgs.split(",");
        let route: any;
        route = {
            "fromDate": "",
            "endDate": "",
            "status": [],
            "agingFrom": "",
            "agingTo": "",
            "pageNumber": pageNumber,
            "pageSize": pageSize,
            "orderBy": [
                { "sortBy": sortArg[0], "direction": sortArg[1] }
            ],
            "searchText": searchText
        }
        let data = JSON.stringify(route);
        let http = this.$http.iotContext.url("/api/hubroutes/monitor")
        return http.post(data).map((res) => {
            let obj = res.json();
            return obj;
        });
    }
    startRoute(routeName,RouteType) {
        if(RouteType == "iot")
        return this.$http.iotContext.url("/api/routes").put(routeName);
        else
        return this.$http.iotContext.url("/api/hubroutes").put(routeName);
    }
    stopRoute(routeName,RouteType) {
        if(RouteType == "iot")
        return this.$http.iotContext.url("/api/routes").put(routeName);
        else
        return this.$http.iotContext.url("/api/hubroutes").put(routeName);
    }
}