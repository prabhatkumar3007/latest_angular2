import { ShareDataService } from 'sensorthink-commoncontrols/src/services/shareDataService';
import { NotyService } from 'sensorthink-commoncontrols/src/services/noty.service';
import {
  Component,
  OnInit
} from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { MonitorService } from './monitor.service';
import { Router } from '@angular/router';
import { DragulaService } from "ng2-dragula";
import { FormControl } from '@angular/forms';
import { FilterParams, ActionButtons } from 'sensorthink-commoncontrols/src/components/advancedFilter/advancedFilter.data';

declare var moment: any

@Component({
  templateUrl: 'iotRouteMonitor.component.html'

})
export class IotRouteMonitorComponent implements OnInit {
  public iotData: any;
  public sortArgs: string;
  public pagerConfig: any;
  isFirstLoad: boolean = false;
  searchTxt = '';
  searchTxtControl = new FormControl();
  public sideBarVisible: boolean;
  public filterConfig: FilterParams;
  tableId: any = 'iotRouteList';
  callBack = this.onCheckBoxChecked.bind(this);
  isLoading: boolean = false;

  constructor(private service: MonitorService, private sharedService: ShareDataService, private router: Router, private notyService: NotyService) {
    this.sortArgs = "routeId,desc";
    this.pagerConfig = {
      totalItems: 64,
      currentPage: 1,
      smallnumPages: 0,
    }
    this.filterConfig = new FilterParams();
    this.filterConfig.actionButtons = [new ActionButtons("Start Route", true, this.onStartRoute.bind(this)), new ActionButtons("Stop Route", true, this.onStopRoute.bind(this))];
    this.filterConfig.actionSubSection.isChangeState = false;
    this.filterConfig.actionSubSection.isExportTo = false;
    this.filterConfig.actionSubSection.isTransaction = false;
  }
  setPagerConfig(totalItems, currentPage, itemsPerPage?) {
    this.pagerConfig = {
      totalItems: totalItems,
      currentPage: currentPage || 1,
      itemsPerPage: itemsPerPage || 10,
      smallnumPages: 0
    }
  }
  ngOnInit() {
    this.searchInputFilterData();
    this.setPagerConfig(0, 0);
    this.loadIotRouteData(1, this.sortArgs)
  }
  searchInputFilterData() {
    this.searchTxtControl.valueChanges
      .debounceTime(1000)
      .subscribe(newValue => {
        this.searchTxt = newValue.trim();
        if (((this.searchTxt.length >= 1 || this.searchTxt.length === 0) && this.searchTxt !== "") || this.isFirstLoad) {
          this.isFirstLoad = (this.searchTxt.length === 0) ? false : true;
          this.loadIotRouteData(this.pagerConfig.currentPage, this.sortArgs, this.searchTxt);
        }
      });
  }
  loadIotRouteData(pageNumber: number, sortArgs: string, searchTxt?: string) {
    this.isLoading = true;
    this.service.getIotRouteData(pageNumber, this.pagerConfig.itemsPerPage, sortArgs, searchTxt).subscribe((data) => {
      if (data) {
        this.setPagerConfig(data.totalElements, this.pagerConfig.currentPage, data.size)
        this.iotData = data.content;
        this.iotData.forEach((el, index) => {
          if (el.activeSince == "") {
            this.iotData[index].activeSince = "Just now";
          }
          if (el.status == false) {
            this.iotData[index].activeSince = " - "
          }
        });
      } else {
        this.setPagerConfig(0, this.pagerConfig.currentPage, this.pagerConfig.itemsPerPage)
        this.iotData = [];
      }
      this.isLoading = false;
    });
  }
  onIotSortChanged(sortArgs) {
    if (sortArgs[0].pop)
      this.sortArgs = sortArgs[0][0] + "," + sortArgs[0][1];
    else
      this.sortArgs = sortArgs[0] + "," + sortArgs[1];
    this.loadIotRouteData(this.pagerConfig.currentPage, this.sortArgs);
  }
  onIotPageSizeChanged(pageSize) {
    this.pagerConfig.itemsPerPage = pageSize;
    this.loadIotRouteData(1, this.sortArgs);
  }
  onIotPageChanged(pager) {
    this.pagerConfig.currentPage = pager.page;
    this.loadIotRouteData(pager.page, this.sortArgs);
  }
  onPageChanged(pager) {
    this.pagerConfig.currentPage = pager.page;
    this.loadIotRouteData(pager.page, this.sortArgs);
  }
  onStartRoute() {
    if (this.service.selectedState.length == 0) {
      this.notyService.error("Please select one Route.")
    } else {
      let updateArray = this.updateObjectArray(this.service.selectedState, "start");
      if (this.service.selectedState[0].status == true) {
        this.notyService.error("Route already in Active Status.")
      }
      else {
        this.service.startRoute(updateArray, "iot").subscribe((res) => {
          this.notyService.success("Route(s) is Active.");
          this.loadIotRouteData(this.pagerConfig.currentPage, this.sortArgs);
          this.service.selectedState = [];
        });
      }
    }
  }
  updateObjectArray(array, type) {
    if (type == "start") {
      let a = [];
      array.forEach(e => {
        let b = { "routeName": e.routeName, "action": "startRoute" }
        a.push(b);
      });
      return a;
    } else {
      let a = [];
      array.forEach(e => {
        let b = { "routeName": e.routeName, "action": "stopRoute" }
        a.push(b);
      });
      return a;
    }
  }
  onStopRoute() {
    if (this.service.selectedState.length == 0) {
      this.notyService.error("Please select one Route.")
    } else {
      let updateArray = this.updateObjectArray(this.service.selectedState, "stop");
      if (this.service.selectedState[0].status == true) {
        this.service.stopRoute(updateArray, "iot").subscribe((res) => {
          this.notyService.success("Route(s) is Inactive.");
          this.loadIotRouteData(this.pagerConfig.currentPage, this.sortArgs);
          this.service.selectedState = [];
        });
      }
      else {
        this.notyService.error("Route already in Inactive Status.")
      }
    }
  }
  onCheckBoxChecked(iot, e) {
    if (e.target.checked == true) {
      this.service.selectedState.push(iot);
      let prevVal = this.service.selectedState[0].status;
      let isStateValid = true;
      this.service.selectedState.forEach(el => {
        if (el.status !== prevVal)
          isStateValid = false;
      });
      if (!isStateValid) {
        this.service.selectedState.splice(this.service.selectedState.indexOf(iot), 1);
        this.notyService.error("Selected routes do not have the same status. Please select routes of similar status")
        e.target.checked = false;
      }
    }
    else {
      this.service.selectedState.splice(this.service.selectedState.indexOf(iot), 1);
    }
  }
  applyFormatting(columns) {
    this.loadIotRouteData(this.pagerConfig.currentPage, this.sortArgs);
  }
}


