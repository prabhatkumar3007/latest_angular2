import { MonitorService } from './monitor.service';
import { AccordionModule } from 'ng2-bootstrap/accordion';
import { CommonModule } from '@angular/common';
import { ControlsModule } from '../controls/controls.module';
import { IotRouteMonitorComponent } from './iotRouteMonitor.component';
import { HubRouteMonitorComponent } from './hubRouteMonitor.component';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
//import { KeysPipe } from '../shared/components/objectKeyFilter.pipe';
import { NgModule } from '@angular/core';
import { PopoverModule } from 'ng2-bootstrap/popover';
import { RouterModule } from '@angular/router';
import { SharedModule } from '../shared/shared.module';
import { TabsModule } from 'ng2-bootstrap';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule,
    HttpModule,
    AccordionModule.forRoot(),
    TabsModule,
    ControlsModule,
    PopoverModule,
    SharedModule
  ],
  declarations: [
    IotRouteMonitorComponent,
    HubRouteMonitorComponent
  ],
  exports: [
    IotRouteMonitorComponent,
    HubRouteMonitorComponent
  ],
  providers: [
    MonitorService
  ]
})
export class MonitorModule {
}