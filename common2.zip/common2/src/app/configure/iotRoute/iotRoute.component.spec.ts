import { ComponentFixture, TestBed, async, tick, fakeAsync } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement, Directive } from '@angular/core';
import { IotRouteComponent } from './iotRoute.component';
import { IotRouteService } from '../services/iotRoute.service';
import { ConfigureModule } from '../configure.module';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { ModalDirective } from 'ng2-bootstrap';
import { RouterStub } from '../../../test/routerStub';
import { NotyService } from 'sensorthink-commoncontrols/src/services/noty.service';

class MockUserService {
    getIotRoutes(): Observable<any> { return Observable.of({}); }
    deleteIotRoute(): Observable<any> { return Observable.of({}); }

}
describe('iotRout:... Component', () => {

    let component: IotRouteComponent;
    let fixture: ComponentFixture<IotRouteComponent>;
    let de: DebugElement;
    let el: HTMLElement;
    let service;
    let noty;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [ConfigureModule],
            providers: [{ provide: IotRouteService, useClass: MockUserService },
            { provide: Router, useClass: RouterStub }, NotyService]
        })
        fixture = TestBed.createComponent(IotRouteComponent);
        component = fixture.componentInstance;
        service = fixture.debugElement.injector.get(IotRouteService);
        noty = fixture.debugElement.injector.get(NotyService);
    }));

    it('should have a defined component', () => {
        expect(component).toBeDefined();
    });

    describe('When we call get all route data', () => {
        it(' should get all routes', () => {
            // fixture.detectChanges();
            spyOn(service, 'getIotRoutes').and.returnValue(Observable.of({ content: [{}, {}] }));
            spyOn(component, 'setPagerConfig');
            component.getAllRoutes(1, 'routeId,desc');
            expect(component.allRouteData.length).toBe(2);
        })
    });

    describe('When we call setPagerConfig', () => {
        it(' should set the pager config', () => {
            component.setPagerConfig(10, 1, 5);
            expect(component.pagerConfig.totalItems).toBe(10);
            expect(component.pagerConfig.currentPage).toBe(1);
            expect(component.pagerConfig.itemsPerPage).toBe(5);
        })
    });

    describe('When we call onPageSizeChanged, onPageChanged, onSortChanged', () => {
        beforeEach(() => {
            component.setPagerConfig(10, 1, 1);
        })
        it(' should change the size of page with more users data', () => {
            spyOn(component, 'getAllRoutes');
            component.onPageSizeChanged(10);
            expect(component.pagerConfig.itemsPerPage).toBe(10);
            expect(component.getAllRoutes).toHaveBeenCalled();
        })
        it(' should change the page with next users data', () => {
            let pager = { page: 2 }
            spyOn(component, 'getAllRoutes');
            component.onPageChanged(pager);
            expect(component.pagerConfig.currentPage).toBe(2);
            expect(component.getAllRoutes).toHaveBeenCalled();

        })
        it(' should get sorted users data', () => {
            let args = ['routeId', 'asc']
            spyOn(component, 'getAllRoutes');
            component.onSortChanged(args);
            expect(component.sortArgs).toBe('r,o');
            expect(component.getAllRoutes).toHaveBeenCalled();
        })
    });

    // describe('When we call onSaveRoute method', () => {
    //     beforeEach(() => {
    //         component.setPagerConfig(10, 1, 1);
    //     })
    //     it(' should close the popup window and save the route details in database', () => {
    //          spyOn(component, 'onSaveIotForm').and.returnValue(Observable.of({}));
    //          spyOn(component, 'getAllRoutes');
    //          component.onSaveIotForm();
    //          expect(component.iotRouteForm.save).toHaveBeenCalled();
    //          expect(component.getAllRoutes).toHaveBeenCalled();
    //     })
    // });

    // describe('When deleteRoute', () => {
    //     beforeEach(() => {
    //         component.setPagerConfig(10, 1, 1);
    //     })

    //     it(' should delete the route ', () => {
    //         let routes = { routeName: 'y', routeId: 2 }
    //         expect(routes.routeId).toEqual(2);
    //         spyOn(window, 'confirm').and.returnValue(true)
    //         spyOn(service, 'deleteIotRoute').and.returnValue(Observable.of({}));
    //         spyOn(component, 'getAllRoutes');
    //         expect(component.getAllRoutes).toHaveBeenCalled();
    //     })
    // });

    describe('When searchInputFilterData', () => {
        let input, isFirstLoad = true;
        beforeEach(function () {
            input = component.searchTxt;
            component.setPagerConfig(10, 1, 1);
        });
        it(' should set to a valid search text', fakeAsync(() => {
            spyOn(component, 'getAllRoutes');
            component.searchInputFilterData();
            expect(component.searchTxt).toBe(input);
            tick(1000);
        }))
        it(' should be first load', () => {
            component.searchInputFilterData();
            expect(component.isFirstLoad).toBeFalsy();
        })
    });
});
