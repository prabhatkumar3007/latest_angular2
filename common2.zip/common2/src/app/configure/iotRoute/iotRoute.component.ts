import { element } from 'protractor';
import { ChangeDetectorRef, Component, OnInit, ViewChild } from '@angular/core';
import { FilterParams,ActionButtons } from 'sensorthink-commoncontrols/src/components/advancedFilter/advancedFilter.data';
import { FormBuilder, FormGroup } from '@angular/forms';
import { FormControl } from '@angular/forms';
import { IotRoute } from '../configure.data';
import { IotRouteService } from '../services/iotRoute.service';
import { ModalDirective } from 'ng2-bootstrap';
import { NotyService } from 'sensorthink-commoncontrols/src/services/noty.service';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/throttleTime';
import 'rxjs/add/observable/fromEvent';
import { IotRouteFormComponent, } from './iotRouteForm.component';

@Component({
  templateUrl: 'iotRoute.component.html'
})
export class IotRouteComponent implements OnInit {
  iotChildForm: FormGroup;
  public modalTitle: String;
  public submitText: String;
  public allRouteData: any;
  public loadForm: boolean = false;
  public pagerConfig: any;
  public sortArgs: string;
  public sideBarVisible: boolean;
  public filterConfig: FilterParams;
  public appliedFilterData: FilterParams;
  callBack = this.onCheckBoxChecked.bind(this)
  isLoading: boolean = false;
  isFirstLoad: boolean = false;
  searchTxt = '';
  searchTxtControl = new FormControl();
  selectedCheckboxCount = [];
  myOptions: any;
  @ViewChild(IotRouteFormComponent) iotRouteForm: IotRouteFormComponent;
  @ViewChild('iotRouteModal') public iotRouteModal: ModalDirective;

  constructor(private service: IotRouteService, private noty: NotyService, private _cdr: ChangeDetectorRef) {
    this.sortArgs = "routeId,desc";
    this.filterConfig = this.createFilterParams();
    this.pagerConfig = {
      totalItems: 64,
      currentPage: 1,
      smallnumPages: 0,
    }
    this.service.selectedRoute = undefined;

    this.filterConfig = new FilterParams();
    this.filterConfig.actionButtons = [new ActionButtons("Edit",true,this.onEditIotRouteModal.bind(this)), new ActionButtons("Delete",true,this.onDeleteIotRouteModal.bind(this))];
    this.filterConfig.actionSubSection.isChangeState = false;
    this.filterConfig.actionSubSection.isExportTo = false;
    this.filterConfig.actionSubSection.isTransaction = false;
  }
  setPagerConfig(totalItems, currentPage, itemsPerPage?) {
    this.pagerConfig = {
      totalItems: totalItems,
      currentPage: currentPage || 1,
      itemsPerPage: itemsPerPage || 10,
      smallnumPages: 0
    }
  }
  ngOnInit() {
    this.searchInputFilterData();
    this.setPagerConfig(0, 0);
    this.getAllRoutes(1, this.sortArgs);
  }

  searchInputFilterData() {
    this.searchTxtControl.valueChanges
      .debounceTime(1000)
      .subscribe(newValue => {
        this.searchTxt = newValue.trim();
        if (((this.searchTxt.length >= 1 || this.searchTxt.length === 0) && this.searchTxt !== "") || this.isFirstLoad) {
          this.isFirstLoad = (this.searchTxt.length === 0) ? false : true;
          this.getAllRoutes(this.pagerConfig.currentPage, this.sortArgs, this.searchTxt);
        }
      });
  }
  onOpenIotRouteModal(iot?) {
    if (iot === undefined) {
      this.service.selectedRoute = undefined;
    }
    this.modalTitle = (iot === undefined) ? "CREATE A NEW ROUTE" : "EDIT ROUTE";
    this.submitText = (iot === undefined) ? "Create" : "Save";
    this.loadForm = true;
    this.iotRouteModal.show();
    setTimeout(() => {
      if (this.iotRouteForm)
        this.iotChildForm = this.iotRouteForm.iotForm;
    })

  }
  getAllRoutes(pageNumber: number, sortArgs: string, searchTxt?: string) {
    this.isLoading = true;
    this.service.getIotRoutes(pageNumber, this.pagerConfig.itemsPerPage, sortArgs, searchTxt).subscribe((routes) => {
      if (routes) {
        this.setPagerConfig(routes.totalElements, this.pagerConfig.currentPage, routes.size)
        this.allRouteData = routes.content;
      } else {
        this.setPagerConfig(0, this.pagerConfig.currentPage, this.pagerConfig.itemsPerPage)
        this.allRouteData = [];
      }
      this.isLoading = false;
    });
  }

  onSaveIotForm() {
    this.iotRouteForm.save().subscribe(
      res => {
        this.loadForm = false;
        this.selectedCheckboxCount = [];
        this.getAllRoutes(1, this.sortArgs);
        this.iotRouteModal.hide();
        this.service.selectedRoute = undefined;
        this._cdr.detectChanges();
        if(res.type == "create")
        this.noty.success("IOT Route created successfully.");
        else
        this.noty.success(" IOT route updated successfully.");
      },
      (err) => {
        if (err.status === 409) {
          this.noty.error("Route name already exists.")
        }
        else if (err.headers && err.headers.get('error') === "Transformation xml is invalid") {
          this.noty.error("Transformation xml is invalid")
        } else {
          this.noty.error(err)
        }
      });
  }

  onCancelClick() {
    this.selectedCheckboxCount = [];
    this.iotRouteModal.hide();
    this.iotRouteForm.iotRoute = new IotRoute();
    this.loadForm = false;
    this.getAllRoutes(this.pagerConfig.currentPage, this.sortArgs);
  }
  onSortChanged(sortArgs) {
    if (sortArgs[0].pop)
      this.sortArgs = sortArgs[0][0] + "," + sortArgs[0][1];
    else
      this.sortArgs = sortArgs[0] + "," + sortArgs[1];
    this.getAllRoutes(this.pagerConfig.currentPage, this.sortArgs);
  }
  onPageSizeChanged(pageSize) {
    this.pagerConfig.itemsPerPage = pageSize;
    this.getAllRoutes(1, this.sortArgs);
  }
  onPageChanged(pager) {
    this.pagerConfig.currentPage = pager.page;
    this.getAllRoutes(pager.page, this.sortArgs);
  }
  onCheckBoxChecked(iot, e) {
    if (e.target.checked === undefined)
      return;
    if (e.target.checked) {
      this.selectedCheckboxCount.push(iot);
      this.service.selectedRoute = { ...iot };
    }
    else {
      this.selectedCheckboxCount.splice(this.selectedCheckboxCount.indexOf(iot), 1);
      //this.service.selectedRoute = undefined;
    }
  }
  onEditIotRouteModal() { //edit
    if (this.selectedCheckboxCount.length > 1) {
      this.noty.error("Please select only one route")
    } else if (this.selectedCheckboxCount.length === 0) {
      this.noty.error("Please select at least one route")
    } else {
      this.onOpenIotRouteModal(this.selectedCheckboxCount[0]);
    }
  }
  onDeleteIotRouteModal() {
    if (this.selectedCheckboxCount.length == 0) {
      this.noty.error("Please select at least one route")
    } else {
      this.noty.confirm().then(() => {        
        this.service.deleteIotRoute(this.getRouteIds())
          .subscribe(res => {
            this.selectedCheckboxCount = [];
            this.noty.success("Iot Route deleted successfully.");
            this.getAllRoutes(1, this.sortArgs);
          },
          err => {
            this.noty.error("Could not delete this route.")
            this.selectedCheckboxCount = [];
            this.getAllRoutes(1, this.sortArgs);
          });
      })
    }
    //delete
  }
  getRouteIds(){
    let idList=[];
    this.selectedCheckboxCount.forEach(element => {
      idList.push(element.routeId);
    });
    return idList;
  }
  createFilterParams(): FilterParams {
    let params = new FilterParams(); // initialises to default on object creation
    params.state.isVisible = false;
    params.site.isVisible = false;
    params.baseMetric.isVisible = false;
    params.otherMetric.isVisible = false;
    return params;
  }
  applyFormatting(columns) {
    this.getAllRoutes(this.pagerConfig.currentPage, this.sortArgs);
  }
}