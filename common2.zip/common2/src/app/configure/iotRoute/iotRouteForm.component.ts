import { element } from 'protractor';
import { Component, Input, OnInit } from '@angular/core';
import { ConnectionType, IotRoute, IotRouteEndPoint, IotRouteEndPointConfig } from '../configure.data';
import { DragulaService } from 'ng2-dragula';
import { FileService } from 'sensorthink-commoncontrols/src/common.module';
import { FormBuilder, FormGroup, FormArray } from '@angular/forms';
import { IotRouteService } from '../services/iotRoute.service';
import { NotyService } from 'sensorthink-commoncontrols/src/services/noty.service';
import { Observable } from 'rxjs/Observable';
import { SessionStorage } from 'sensorthink-commoncontrols/lib/webStore.module';

declare let $: any;
declare let moment: any;

@Component({
  selector: 'iotRoute-modal',
  templateUrl: 'iotRouteForm.component.html'
})

export class IotRouteFormComponent implements OnInit {
  endpointSequence: any[];
  selectedFile: EventTarget;
  iotForm: FormGroup;
  title: string;
  isEditMode: boolean = false;
  fromEndPointOptions: Array<IotRouteEndPoint> = new Array<IotRouteEndPoint>();
  toEndPointOptions: Array<IotRouteEndPoint> = new Array<IotRouteEndPoint>();
  toAddMultipleEndPoint = [{ toEndPointValue: '' }];
  fromEndPoint: any;
  isOutbond: boolean;
  routeClassData: any;
  allRouteClassData: any;
  outboundRouteClasses = [];
  inboundRouteClasses = [];
  allCompany: any;
  transformationClassData: any;
  allTransformationClassData: any;  
  outboundTransformClasses = [];
  inboundTransformClasses = [];
  connectionTypeData: any;
  endPointData: any;
  isInOut: boolean = false;
  transformationInboundData = [];
  routeClassInboundData = [];
  tempRouteClassData: any;
  tempTransformationData: any;
  modifiedTimeDateFormat: any;
  createdTimeDateFormat: any;
  transformationMappingFile = { name: undefined };
  transformationTypeData = [
    { name: "Delimited", value: "DELIMITED" },
    { name: "Fixed width", value: "FIXEDWIDTH" }
  ];
  iotRoute: IotRoute = new IotRoute();
  isSuperAdmin: boolean = false;
  dummyToEndPointArry: any = [1, 1];

  constructor(private service: IotRouteService, private fb: FormBuilder, private dragulaService: DragulaService, private fileService: FileService, private noty: NotyService) {
    this.createForm();
    this.setDnDOptions();
    this.iotRoute.direction = 'Inbound'
    this.transformationMappingFile.name = 'Upload File';
  }

  createForm() {
    this.iotForm = this.service.initializeFormObject(this.fb, !this.service.selectedRoute ? true : false);
    this.isSuperAdmin = this.service.checkSuperAdmin();
  }

  ngOnInit() {
    this.getAllPromises();
  }

  getAllPromises() {
    let promises = [
      this.service.getConnectionType(),
      this.service.getRouteClass(),
      this.service.getTransformationClass(),
      this.service.getAllCompany(),
      this.service.getAllEndPoint()
    ]
    Observable.forkJoin(promises).subscribe((res) => {

      this.outboundRouteClasses = [];
      this.inboundRouteClasses = [];
      this.outboundTransformClasses = [];
      this.inboundTransformClasses = [];

      this.connectionTypeData = res[0];
      this.routeClassData = res[1];
      this.allRouteClassData = res[1];
      
      this.allRouteClassData.forEach(element => {
        if (element.toLowerCase().indexOf("outbound") > -1) {
          this.outboundRouteClasses.push(element);
        } else {
          this.inboundRouteClasses.push(element);
        }
      });

      this.tempRouteClassData = this.routeClassData;
      this.transformationClassData = res[2];
      this.allTransformationClassData = res[2];
      this.tempTransformationData = this.transformationClassData;      

      this.allTransformationClassData.forEach(element => {
        if (element.toLowerCase().indexOf("outbound") > -1) {
          this.outboundTransformClasses.push(element);
        } else {
          this.inboundTransformClasses.push(element);
        }
      });

      if (this.iotRoute.direction == 'Inbound') {

        //this.transformationInboundData.push(this.transformationClassData[0], this.transformationClassData[2]);
        this.transformationClassData =this.inboundTransformClasses;// this.transformationInboundData;
        //this.routeClassInboundData.push(this.routeClassData[0], this.routeClassData[2]);
        this.routeClassData =this.inboundRouteClasses; //this.routeClassInboundData;
      } else {
        this.routeClassData =this.outboundRouteClasses;// res[1];
        this.transformationClassData =this.outboundTransformClasses; //res[2];
      }
      if (res[3].constructor === Array)
        this.allCompany = res[3]
      else
        this.allCompany = [res[3]]
      this.endPointData = res[4]
      this.endPointData = this.endPointData.content
      if (this.service.selectedRoute) {
        this.isEditMode = true;
        this.onchangeDirection(this.service.selectedRoute.direction);
        this.modifiedTimeDateFormat = this.service.selectedRoute.modifiedTime;
        this.createdTimeDateFormat = this.service.selectedRoute.createdTime
        this.service.selectedRoute.modifiedTime = this.reSetDate(this.service.selectedRoute.modifiedTime, 'MM/DD/YYYY HH:mm:ss');
        this.service.selectedRoute.createdTime = this.reSetDate(this.service.selectedRoute.createdTime, 'MM/DD/YYYY HH:mm:ss');
        for (let i = 0; i < this.service.selectedRoute.endpoint.length; i++) {
          if (this.service.selectedRoute.endpoint[i].direction == "from") {
            this.fromEndPoint = this.endPointData.find(e => e.endpointConfigId == this.service.selectedRoute.endpoint[i].endpointConfig.endpointConfigId);
          } else {
            let config = this.endPointData.find(e => e.endpointConfigId == this.service.selectedRoute.endpoint[i].endpointConfig.endpointConfigId);
            this.service.addEndpointToForm(this.iotForm, this.fb, config);
          }
        }
        this.service.selectedRoute.company = this.service.selectedRoute.company.companyId;
        for (let i = 0; i < this.service.selectedRoute.endpoint.length; i++) {
          this.service.selectedRoute.endpoint[i].endpointConfig.company = 2;
        }
        this.iotRoute = this.service.selectedRoute;
        this.dummyToEndPointArry = this.iotRoute.endpoint;
        this.iotRoute.company = this.allCompany.find(com => com.companyId === this.service.selectedRoute.company);
        this.iotRoute.createdBy = this.iotRoute.createdBy.userId;
        this.iotRoute.modifiedBy = this.iotRoute.modifiedBy.userId;
      }
    })
  }

  setDnDOptions() {
    try {
      this.dragulaService.setOptions('bag-endpoint', {
        moves: function (el, container, handle) {
          if (handle.className.indexOf)
            return handle.className.indexOf('drag-handle') >= 0;
          return false;
        }
      });
    } catch (error) {
      // Intentionally left blank.
    }
    this.dragulaService.drop.subscribe((value) => {
      this.onDrop(value.slice(1));
    });
  }

  private onDrop(args) {
    setTimeout(() => {
      let [e, el] = args; //element, elementList
      this.endpointSequence = [];
      for (let i = 0; i < el.children.length; i++) {
        let selIdx = $(el.children[i]).find("select").val().split(":")[0];
        this.endpointSequence.push(parseInt(selIdx));
      }
    })
  }

  save() {
    if (this.iotForm.invalid === true) {
      return Observable.throw("Please fill required Field")
    } else {
      this.iotRoute.endpoint = this.dummyToEndPointArry;
      let toEndPoint = [];
      for (var i = 1; i < this.dummyToEndPointArry.length; i++) {
        toEndPoint.push(this.dummyToEndPointArry[i].endpointConfig.endpointUrl)
      }
      if (this.isSameEndPoint(this.iotRoute.endpoint) && this.isSameToEndpoint(toEndPoint)) {
        this.iotRoute.transformationType = this.getTransformationType(this.iotRoute.transformationClass);
        if (this.iotRoute.routeId) {//Edit
          this.iotRoute.company = this.iotRoute.company.companyId;
          this.iotRoute.createdTime = this.createdTimeDateFormat;
          this.iotRoute.modifiedTime = this.modifiedTimeDateFormat;
         
          this.iotRoute.endpoint.pop();
          (<FormArray>this.iotForm.controls["toAddMultipleEndPoint"]).controls.forEach(ctrl => {
            let endpoint = (<FormGroup>ctrl).controls["endPointValue"].value;
            let toEndpoint = this.iotRoute.endpoint.find(r => r.endpointConfig.endpointUrl === endpoint.endpointUrl && r.direction == "to")
            if (!toEndpoint)
              this.iotRoute.endpoint.push(new IotRouteEndPoint("to", "1", endpoint));
          });
          this.updateEndpointSequence(this.iotRoute.endpoint);
          return this.service.updateRoute(this.iotRoute)
        } else {//Add
          let endPointUrl: any;
          let connectionType: any;
          let companyId: any;
         
          this.iotForm.value.toAddMultipleEndPoint.forEach((el, i) => {
            endPointUrl = (el.endPointValue.endpointUrl);
            connectionType = (el.endPointValue.connectionType);
            companyId = (el.endPointValue.company ? el.endPointValue.company.companyId : null)
            // let endPointConfig = new IotRouteEndPointConfig(companyId, el.endPointValue.endpointConfigId, endPointUrl, "", connectionType);
            // let endPoint = new IotRouteEndPoint("to", (i + 1), endPointConfig);
            // this.iotRoute.endpoint.push(endPoint); //need to discuss this code
            this.isInOut = true;
          });
          return this.service.addRoute({ ...this.iotRoute }, (this.iotRoute.company ? this.iotRoute.company.companyId : null))
        }
      }
    }
  }

  updateEndpointSequence(endPoints) {
    if (this.endpointSequence)
      this.endpointSequence.forEach((e, idx) => {
        let endpoint = this.endPointData[e];
        let selEndpoint = endPoints.find(e => e.endpointConfig.endpointConfigId === endpoint.endpointConfigId);
        if (selEndpoint)
          selEndpoint.endpointSequence = idx + 1;
      })
  }

  getTransformationType(transformationClass) {
    if (transformationClass.toLowerCase() === "FixedWidthTransformer".toLowerCase() || transformationClass.toLowerCase() === "OutboundFixedWidthTransformer".toLowerCase())
      return "FIXEDWIDTH";
    if (transformationClass.toLowerCase() === "InboundBinaryFileTransformer" || transformationClass.toLowerCase() === "OutboundBinaryFileTransformer")
      return "BINARY";

    return "DELIMITED";
  }

  setFromEndPoint() {
    if (this.fromEndPoint) {
      if (this.dummyToEndPointArry[0]) {
        this.dummyToEndPointArry.splice(0, 1);
      }
      let endPointConfig = new IotRouteEndPointConfig((this.fromEndPoint.company ? this.fromEndPoint.company.companyId : null), this.fromEndPoint.endpointConfigId, this.fromEndPoint.endpointUrl, "", this.fromEndPoint.connectionType);
      let endPoint = new IotRouteEndPoint("from", "1", endPointConfig);
      this.dummyToEndPointArry.unshift(endPoint);
    }
  }
  addToEndPoint(val, i) {
    let endPointConfig = new IotRouteEndPointConfig((val.company ? val.company.companyId : null), val.endpointConfigId, val.endpointUrl, "", val.connectionType);
    let endPoint = new IotRouteEndPoint("to", i + 1, endPointConfig);
    if (this.dummyToEndPointArry[i + 1]) {
      this.dummyToEndPointArry.splice(i + 1, 1, endPoint);
    }
  }

  addMultipleToEndPoint(event?) {
    this.dummyToEndPointArry.push(1); //
    this.service.addEndpointToForm(this.iotForm, this.fb);
  }

  deleteMultipleToEndPoint(ep, i) {
    let selectedEndpoint = (<FormGroup>ep).controls["endPointValue"].value;
    let ctrls = (<FormArray>this.iotForm.controls["toAddMultipleEndPoint"]).controls;
    this.dummyToEndPointArry.splice(i + 1, 1);
    if (ctrls.length == 1) {
      this.noty.error("Cannot remove the last entry")
    } else {
      // setTimeout(() => {
      // this.toAddMultipleEndPoint.splice(this.toAddMultipleEndPoint.indexOf(index), 1);
      ctrls.splice(ctrls.indexOf(ep), 1);
      let endpoint = this.iotRoute.endpoint.find(e => e.endpointConfig.endpointUrl === selectedEndpoint.endpointUrl)
      if (endpoint) {
        this.iotRoute.endpoint.splice(this.iotRoute.endpoint.indexOf(endpoint), 1);
      }
      // }, 1000);
    }
  }

  onChange(event: EventTarget) {
    let eventObj: MSInputMethodContext = <MSInputMethodContext>event;
    let target: HTMLInputElement = <HTMLInputElement>eventObj.target;
    let files: FileList = target.files;
    this.transformationMappingFile = files[0];
    this.selectedFile = event
  }

  upload(event: EventTarget) {
    this.fileService.readTextFile(this.selectedFile).subscribe(txt => {
      this.iotRoute.transformationMapping = txt;
    });
  }
  isSameEndPoint(arry) {
    if (arry) {
      let fromEnd = arry[0].endpointConfig.endpointUrl;
      for (var i = 1; i < arry.length; i++) {
        if (fromEnd === arry[i].endpointConfig.endpointUrl) {
          this.noty.error("From end point and To end point could not be same.")
          return false;
        }
      }
      return true;
    }
  }
  isSameToEndpoint(array) {
    for (let i = 0; i < array.length; i++) {
      for (let j = i + 1; j < array.length; j++) {
        if ((array[i] == array[j])) {
          this.noty.error(" To end point could not be same.")
          return false
        }
      }
    }
    return true
  }
  onchangeDirection(val) {
    if (val == "Outbound") {
      this.service.addOutBoundFields(this.iotForm, this.fb, true);
      this.routeClassInboundData = [];
      this.transformationInboundData = [];
      this.routeClassData = undefined;
      this.transformationClassData = undefined;

      //this.routeClassInboundData.push(this.tempRouteClassData[1], this.tempRouteClassData[2]);
      this.routeClassInboundData.push(this.tempRouteClassData[1], this.tempRouteClassData[2]);
      this.routeClassData =this.outboundRouteClasses; //this.routeClassInboundData;
      //this.transformationInboundData.push(this.tempTransformationData[1], this.tempTransformationData[3]);
      this.transformationClassData =this.outboundTransformClasses; this.transformationInboundData;

      this.isOutbond = true;
    } else {
      this.service.addOutBoundFields(this.iotForm, this.fb, false);
      this.routeClassInboundData = [];
      this.transformationInboundData = [];
      this.routeClassData = undefined;
      this.transformationClassData = undefined;

      //this.routeClassInboundData.push(this.tempRouteClassData[0], this.tempRouteClassData[2]);
      this.routeClassData =this.inboundRouteClasses; //this.routeClassInboundData;
      //this.transformationInboundData.push(this.tempTransformationData[0], this.tempTransformationData[2]);
      this.transformationClassData =this.inboundTransformClasses //this.transformationInboundData;
      this.isOutbond = false;
    }
  }
  reSetDate(date, args?: any) {
    let d = new Date(date)
    let formatedDate = moment(d).format(args) || moment(d).format('MM/DD/YYYY')
    return formatedDate;
  }
}