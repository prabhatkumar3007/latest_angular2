import { ControlsModule } from '../controls/controls.module';
import { SharedModule } from '../shared/shared.module';
import { EndPointComponent } from './endPoint/endPoint.component';
import { EndPointFormComponent } from './endPoint/endpointForm.component';
import { HubRouteComponent } from './hubRoute/hubRoute.component';
import { HubRouteFormComponent } from './hubRoute/hubRouteForm.component';
import { IotRouteComponent } from './iotRoute/iotRoute.component';
import { IotRouteFormComponent } from './iotRoute/iotRouteForm.component';
import { IotRouteService } from './services/iotRoute.service';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { MultiselectDropdownModule } from 'angular-2-dropdown-multiselect';
import { ModalModule } from 'ng2-bootstrap/modal';
import { PopoverModule } from 'ng2-bootstrap/popover';
import { CommonUtilsModule } from 'sensorthink-commoncontrols/src/common.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule,
    ControlsModule,
    SharedModule,
    ModalModule.forRoot(),
    PopoverModule.forRoot(),
    MultiselectDropdownModule,
  ],
  declarations: [
    IotRouteComponent,
    HubRouteComponent,
    IotRouteFormComponent,
    HubRouteFormComponent,
    EndPointComponent,
    EndPointFormComponent
  ],
  exports: [
    CommonUtilsModule,
    IotRouteComponent,
    HubRouteComponent,
    IotRouteFormComponent,
    HubRouteFormComponent,
    EndPointComponent,
    EndPointFormComponent
  ],
  providers: [
    IotRouteService
  ]
})
export class ConfigureModule {

}