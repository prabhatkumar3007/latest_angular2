import { RouterModule } from '@angular/router';

export const configureRouting = RouterModule.forChild([
  
  // { path: 'iotroute', component: IotRouteComponent, canActivate: [ AuthGuard ] }
  
]);