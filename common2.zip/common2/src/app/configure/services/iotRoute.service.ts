import { HubRouteModel, IotRouteEndPointConfig, IotRoute, HubEndpoint, HubMessageRoute } from './../configure.data';
import { Injectable } from '@angular/core';
import { FormArray, FormControl, Validators } from '@angular/forms';
import { EndPoint } from '../endPoint.data';
import { HttpService } from 'sensorthink-commoncontrols/src/common.module';
import { AuthPermissionService } from 'sensorthink-commoncontrols/src/utils.module';

@Injectable()
export class IotRouteService {
    public selectedRoute: IotRoute;
    public selectedHubRoute: HubRouteModel;
    public selectedEndPoint: EndPoint;
    public selectedValue = [];

    constructor(private $http: HttpService, private authPermissionService: AuthPermissionService) {

    }

    initializeFormObject(fb, createFirstElement = true) {
        let iotForm = {
            transformationMapping: [null, Validators.required],
            fromEndPoint: [null, Validators.required],
            routeName: [null, Validators.required],
            endpoint: false,            
            name: false,
            direction: false,
            enableOnStartup: false,
            enableHeartbeatAck: false,
            enableAck: false,
            enableHubDelivery: false,
            enableHeartbeat: false,
            enableConnectionRetry: false,
            source: [null, Validators.required],
            routeClass: [null, Validators.required],
            allCompany: false,
            transformationClass: [null, Validators.required],
            persistMessage: false,
            active: false,
            modifiedBy: [{ value: '', disabled: true }],
            modifiedTime: [{ value: '', disabled: true }],
            createdTime: [{ value: '', disabled: true }],
            createdBy: [{ value: '', disabled: true }],
            company: [null],
            toAddMultipleEndPoint: createFirstElement ? fb.array([this.createEndpointFormGroup(fb)]) : fb.array([])
        };

        if (this.checkSuperAdmin()) {
            iotForm.company = [null, Validators.required];
        }
        return fb.group(iotForm);
    }
    initializeEndPointFormObject(fb) {

        return fb.group({
            endPointUrl: [null, Validators.required],
            company: [null],
            connectionType: [null, Validators.required],
            discription: [null, Validators.required],
        });
    }

    createEndpointFormGroup(fb, value?: any) {
        return fb.group({
            endPointValue: [value ? value : null, Validators.required]
        });
    }
    addEndpointToForm(form, fb, value?: any) {
        let control = <FormArray>form.controls['toAddMultipleEndPoint'];
        control.push(this.createEndpointFormGroup(fb, value))
    }

    addOutBoundFields(form, fb, isAdd: boolean, value?: any) {
        if (isAdd) {
            form.addControl('heartbeatInterval', new FormControl(null, Validators.required));
            form.addControl('maxRedeliveries', new FormControl(null, [Validators.required]));
            form.addControl('connectionRetryDelay', new FormControl(null, Validators.required));
            form.addControl('redeliveryDelay', new FormControl(null, Validators.required));
        }
        else {
            form.removeControl('heartbeatInterval');
            form.removeControl('maxRedeliveries');
            form.removeControl('connectionRetryDelay');
            form.removeControl('redeliveryDelay');
        }
    }

    getConnectionType() {
        return this.$http.iotContext.url("/api/routes/connectiontype").get()
            .map(res => res.json());
    }
    getRouteClass() {
        return this.$http.iotContext.url("/api/routes/routeclass").get()
            .map(res => res.json());
    }
    getTransformationClass() {
        return this.$http.iotContext.url("/api/routes/transformationclass").get()
            .map(res => res.json());
    }
    getAllCompany() {
        return this.$http.iotContext.url("/api/company").get()
            .map(res => res.json());
    }
    addRoute(iotRoute, companyId) {
        iotRoute.company = companyId;
        var data = JSON.stringify(iotRoute);
        return this.$http.iotContext.url("/api/routes/create").post(data)
            .map((res) => {
            let obj = res.json();
            if (obj)
                obj.type = "create";
            return obj;
        });
    }
    updateRoute(iotRoute) {
        var data = JSON.stringify(iotRoute);
        return this.$http.iotContext.url("/api/routes/" + iotRoute.routeId).put(data)
            .map((res) => {
            let obj = res.json();
            if (obj)
                obj.type = "update";
            return obj;
        });
    }
    addEndPoint(endPoint) {
        var data = JSON.stringify(endPoint);
        return this.$http.iotContext.url("/api/endpoint").post(data)
            .map((res) => {
                let obj = res.json();
                if (obj)
                    obj.type = "create";
                return obj;
            });
    }
    updateEndPoint(endPoint) {
        var data = JSON.stringify(endPoint);
        return this.$http.iotContext.url("/api/endpoint/" + endPoint.endpointConfigId).put(data)
            .map((res) => {
                let obj = res.json();
                if (obj)
                    obj.type = "update";
                return obj;
            });
    }
    getIotRoutes(pageNumber?: number, pageSize?: number, sortArgs?: string, searchText: string = "") {
        let sortArg = sortArgs.split(",");
        let route: any;
        route = {
            "fromDate": "",
            "endDate": "",
            "status": [],
            "agingFrom": "",
            "agingTo": "",
            "pageNumber": pageNumber,
            "pageSize": pageSize,
            "orderBy": [
                { "sortBy": sortArg[0], "direction": sortArg[1] }
            ],
            "searchText": searchText
        }
        let data = JSON.stringify(route);
        let http = this.$http.iotContext.url("/api/routes/search")
        return http.post(data).map((res) => {
            let obj = res.json();
            return obj;
        });
    }


    deleteIotRoute(iotRouteIds) {        

        return this.$http.iotContext.url("/api/routes/" + iotRouteIds.join()).delete()
            .map(res => res)
    }

    deleteEndPoint(endpointConfigId) {
        return this.$http.iotContext.url("/api/endpoint/" + endpointConfigId).delete().map(res => res)
    }
    // ############################ HUB ROUTE METHOD ################################

    getHubRoutes(pageNumber?: number, pageSize?: number, sortArgs?: string, searchText: string = "") {
        let sortArg = sortArgs.split(",");
        let route: any;
        route = {
            "pageNumber": pageNumber,
            "pageSize": pageSize,
            "orderBy": [
                { "sortBy": sortArg[0], "direction": sortArg[1] }
            ],
            "source": "",
            "enableOnStartup": "",
            "destination": "",
            "messageType": "",
            "searchText": searchText
        }

        let data = JSON.stringify(route);
        let http = this.$http.iotContext.url("/api/hubroutes/search")
        return http.post(data).map((res) => {
            let obj = res.json();
            if (obj)
                obj.contentLength = obj.content.length;
            return obj;
        });
    }

    // parseDataForListView(obj) {
    //     let dataset = [];
    //     obj.forEach(rowItem => {
    //         rowItem.hubMessageRoute.forEach(hubObj => {
    //             let row: any = {
    //                 routeName: rowItem.routeName,
    //                 persistMessage: rowItem.persistMessage,
    //                 enableOnStartup: rowItem.enableOnStartup,
    //                 healthStatus: rowItem.healthStatus,
    //                 active: rowItem.active,
    //                 company: rowItem.company,
    //                 source: hubObj.source,
    //                 destination: hubObj.destination,
    //                 code: hubObj.messageType.code
    //             }
    //             dataset.push(row);
    //         });
    //     });
    //     return dataset;
    // }

    getAllEndPoint(pageNumber?: number, pageSize?: number, sortArgs?: string, searchText: string = "") {
        let route: any;
        if (pageNumber !== undefined) {
            let sortArg = sortArgs.split(",");

            route = {
                "pageNumber": pageNumber,
                "pageSize": pageSize,
                "orderBy": [
                    { "sortBy": sortArg[0], "direction": sortArg[1] }
                ],
                "searchText": searchText
            }
        } else {
            route = {
                "orderBy": [{
                    "sortBy": "connectionType",
                    "direction": "asc"
                }],
                "pageSize": 15,
                "searchText": ""
            }
        }
        let data = JSON.stringify(route);
        let http = this.$http.iotContext.url("/api/endpoint/search")
        return http.post(data).map((res) => {
            let obj = res.json();
            return obj;
        });
    }

    getMessageTypes() {
        return this.$http.iotContext.url("/api/common/messagetype").get().map(res => {
            let options = []
            res.json().forEach(opt => {
                options.push({
                    id: opt.messageTypeId,
                    name: opt.code,
                    instance: opt
                })
            });
            return options;
        });
    }

    deleteHubRoute(iotRouteId) {
        return this.$http.iotContext.url("/api/hubroutes/" + iotRouteId).delete()
            .map(res => res)
    }

    createHubRoute(hubRouteModel) {
        let model = this.parseModelForApi(hubRouteModel);
        return this.$http.iotContext.url("/api/hubroutes").post(model)
            .map(res => res).toPromise();
    }

    updateHubRoute(hubRouteModel) {
        let model = this.parseModelForApi(hubRouteModel);
        return this.$http.iotContext.url("/api/hubroutes/" + hubRouteModel.hubRouteId).put(model)
            .map(res => res).toPromise();
    }

    private parseModelForApi(hubRouteModel) {
        let model = new HubRouteModel();
        let isSuperAdmin = this.checkSuperAdmin();
        model.hubRouteId = hubRouteModel.hubRouteId;
        model.routeName = hubRouteModel.routeName;
        model.persistMessage = hubRouteModel.persistMessage;
        model.enableOnStartup = hubRouteModel.enableOnStartup;
        model.active = hubRouteModel.active;
        model.healthStatus = 1;        
        model.company = hubRouteModel.company ? hubRouteModel.company.companyId : null;        

        let endPointConfig = new IotRouteEndPointConfig(hubRouteModel.fromEndPoint.company ? hubRouteModel.fromEndPoint.company.companyId : null, hubRouteModel.fromEndPoint.endpointConfigId, hubRouteModel.fromEndPoint.endpointUrl, "", hubRouteModel.fromEndPoint.connectionType);
        let fromEndPoint = new HubEndpoint("from", endPointConfig, hubRouteModel.fromEndPoint.hubEndpointId);

        model.hubEndpoint.push(fromEndPoint);

        hubRouteModel.toEndPoints.forEach(ep => {
            let epc = new IotRouteEndPointConfig(ep.company ? ep.company.companyId : null, ep.endpointConfigId, ep.endpointUrl, "", ep.connectionType);
            model.hubEndpoint.push(new HubEndpoint("to", epc, ep.hubEndpointId));
        });

        hubRouteModel.selectedMessageTypes.forEach(msgType => {           
            let  companyId =  hubRouteModel.company ? hubRouteModel.company.companyId : null;            
            let hubMessageRoute = new HubMessageRoute(msgType.source,
                msgType.destination, companyId, msgType.messageType.instance, msgType.hubMessageRouteId);
            model.hubMessageRoute.push(hubMessageRoute);
        });

        return model;
    }

    checkSuperAdmin() {
        return this.authPermissionService.isSuperAdmin();
    }
}
