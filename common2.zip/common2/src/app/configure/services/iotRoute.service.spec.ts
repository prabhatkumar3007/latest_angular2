import { MockHttpService } from '../../../test/mockHttp.service';
import { SharedModule } from '../../shared/shared.module';
import { IotRouteService } from './iotRoute.service';
import { inject, TestBed } from '@angular/core/testing';
import { HttpModule, RequestMethod, Response, ResponseOptions, XHRBackend } from '@angular/http';
import { MockBackend } from '@angular/http/testing';
import { HttpService } from 'sensorthink-commoncontrols/src/common.module';
import { AuthPermissionService } from 'sensorthink-commoncontrols/src/utils.module';

describe('Service: UserService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [HttpModule, SharedModule],
            providers: [IotRouteService, { provide: HttpService, useClass: MockHttpService },
                { provide: XHRBackend, useClass: MockBackend }, AuthPermissionService]
        }).compileComponents();
    })

    it('can instantiate service when inject service',
        inject([IotRouteService], (service: IotRouteService) => {
            expect(service instanceof IotRouteService).toBe(true);
        }));

    it('can provide the mockBackend as XHRBackend',
        inject([XHRBackend], (backend: MockBackend) => {
            expect(backend).not.toBeNull('backend should be provided');
        }));

    describe('When get all user', () => {
        let backend: MockBackend;
        let service: IotRouteService;
        let response: Response;
        const mockResponse = [{ userId: 1, status: true, userLogin: 'Admin', firstName: 'ad', lastName: 'min' },
        { userId: 1, status: true, userLogin: 'Admin', firstName: 'ad', lastName: 'min' }
        ];
        beforeEach(inject([HttpService, XHRBackend, AuthPermissionService], (httpService: HttpService, be: MockBackend, authPermissionService: AuthPermissionService) => {
            backend = be;
            service = new IotRouteService(httpService, authPermissionService);
            let options = new ResponseOptions({ status: 200, body: { data: [] } });
            response = new Response(options);
        }));

        it(' should get users data list',
            inject([], () => {
                backend.connections.subscribe((connection) => {
                    connection.mockRespond(new Response(new ResponseOptions({ body: JSON.stringify(mockResponse) })));
                });
                service.getIotRoutes(1, 10, "userName,asc", '').subscribe((res) => {
                    expect(res.length).toBe(mockResponse.length);
                }, (err) => {
                    console.log(err);
                })
            }));
    });

    describe('When ', () => {
        let backend: MockBackend;
        let service: IotRouteService;
        let response: Response;
        let user = { userId: 2, status: true, userLogin: 'Admin', firstName: 'ad', lastName: 'min' };
        const mockResponse = { userId: 2, status: true, userLogin: 'Admin', firstName: 'ad', lastName: 'min' };

        beforeEach(inject([HttpService, XHRBackend, AuthPermissionService], (httpService: HttpService, be: MockBackend, authPermissionService: AuthPermissionService) => {
            backend = be;
            service = new IotRouteService(httpService, authPermissionService);
            let options = new ResponseOptions({ status: 200, body: { data: [] } });
            response = new Response(options);
        }));
        it('addUser should Add new user data',
            inject([], () => {
                backend.connections.subscribe((connection) => {
                    expect(connection.request.method).toBe(RequestMethod.Post);
                    connection.mockRespond(new Response(new ResponseOptions({ body: JSON.stringify(mockResponse) })));
                });
                service.addRoute(user, 2).subscribe((res) => {
                    expect(res).toBeDefined();
                    expect(res.status).toBe(true);
                }, (err) => {
                    console.log(err);
                })
            }));
        it("updateUser should Update existing user's data",
            inject([], () => {
                backend.connections.subscribe((connection) => {
                    expect(connection.request.method).toBe(RequestMethod.Put);
                    connection.mockRespond(new Response(new ResponseOptions({ body: JSON.stringify(mockResponse) })));
                });
                service.updateRoute(user).subscribe((res) => {
                    expect(res).toBeDefined();
                    expect(res.status).toBe(true);
                }, (err) => {
                    console.log(err);
                })
            }));
        it("deleteUser should delete user",
            inject([], () => {
                backend.connections.subscribe((connection) => {
                    expect(connection.request.method).toBe(RequestMethod.Delete);
                    connection.mockRespond(new Response(new ResponseOptions({ body: JSON.stringify(mockResponse) })));
                });
                service.deleteIotRoute(user.userId).subscribe((res) => {
                    expect(res).toBeDefined();
                    expect(res.status).toBe(null);
                }, (err) => {
                    console.log(err);
                })
            }));
    });
});