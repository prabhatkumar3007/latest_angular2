export class EndPoint {
    endpointParams: string = null;
    endpointUrl: string = undefined;
    company: any;
    description: string;
    endpointConfigId: number;
    connectionType: ConnectionType;
}
export class ConnectionType {
    connectionTypeId: number;
    name: string;
    description: string
    constructor(connectionTypeId: number, name: string, description: string) {
        this.connectionTypeId = connectionTypeId;
        this.name = name;
        this.description = description;
    }
}