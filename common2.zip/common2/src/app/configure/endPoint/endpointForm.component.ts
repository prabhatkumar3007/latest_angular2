import { Component, Input, ChangeDetectorRef, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { BasicValidators } from '../../shared/services/basicValidators';
import { EndPoint, ConnectionType } from '../endPoint.data';
import { IotRouteService } from '../services/iotRoute.service';
import { RequestOptions } from "@angular/http/http";
import { Observable } from "rxjs/Observable";
import { NotyService } from "sensorthink-commoncontrols/src/services/noty.service";

declare let $: any;

@Component({
  selector: 'endPoint-modal',
  templateUrl: 'endPointForm.component.html'
})

export class EndPointFormComponent implements OnInit {
  endPointForm: FormGroup;
  ConnectionTypeData: any;
  allCompany: any;
  endPoint: EndPoint = new EndPoint;
  connectionType: any;
  isSuperAdmin: boolean = false;
  companyName: any;
  constructor(private service: IotRouteService, private fb: FormBuilder, private noty: NotyService) {
    this.endPointForm = this.service.initializeEndPointFormObject(fb);

  }

  ngOnInit() {
    this.getAllPromises();
    this.isSuperAdmin = this.service.checkSuperAdmin();
  }
  setFormData(endPointobj) {
    this.endPointForm = this.service.initializeEndPointFormObject(this.fb);
    //console.log(endPointobj)
  }
  getAllPromises() {
    let promises = [
      this.service.getConnectionType(),
      this.service.getAllCompany()
    ]
    Observable.forkJoin(promises).subscribe((res) => {
      this.ConnectionTypeData = res[0];
      if (res[1].constructor === Array)
        this.allCompany = res[1]
      else
        this.allCompany = [res[1]]
      if (this.service.selectedEndPoint) {
        this.endPoint = this.service.selectedEndPoint;
        this.connectionType = this.ConnectionTypeData.find(ct => ct.connectionTypeId === this.service.selectedEndPoint.connectionType.connectionTypeId);
        this.endPoint.company = this.allCompany.find(com => com.companyId === this.service.selectedEndPoint.company.companyId);
        this.endPoint.description = this.service.selectedEndPoint.description
      }
    })
  }
  save() {
    if (this.endPointForm.invalid === true) {
      this.noty.error("Please fill required Field")
    } else {
      var result;
      this.endPoint.company = this.endPoint.company ? this.endPoint.company.companyId : null;
      let connectionType = new ConnectionType(this.connectionType.connectionTypeId, this.connectionType.description, this.connectionType.name);
      this.endPoint.connectionType = connectionType;
      if (this.endPoint.endpointConfigId) {
        result = this.service.updateEndPoint(this.endPoint)
      } else {
        result = this.service.addEndPoint(this.endPoint)
      }
      return result;
    }
  }
}