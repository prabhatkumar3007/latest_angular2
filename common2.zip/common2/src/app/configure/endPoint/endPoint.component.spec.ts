import { ComponentFixture, TestBed, async, tick, fakeAsync } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement, Directive } from '@angular/core';
import { EndPointComponent } from './endPoint.component';
import { IotRouteService } from '../services/iotRoute.service';
import { ConfigureModule } from '../configure.module';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { ModalDirective } from 'ng2-bootstrap';
import { RouterStub } from '../../../test/routerStub';
import { NotyService } from 'sensorthink-commoncontrols/src/services/noty.service';

class MockUserService {
    getIotRoutes(): Observable<any> { return Observable.of({}); }
    deleteIotRoute(): Observable<any> { return Observable.of({}); }

}
fdescribe('endPoint:... Component', () => {

    let component: EndPointComponent;
    let fixture: ComponentFixture<EndPointComponent>;
    let de: DebugElement;
    let el: HTMLElement;
    let service;
    let noty;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [ConfigureModule],
            providers: [{ provide: IotRouteService, useClass: MockUserService },
            { provide: Router, useClass: RouterStub }, NotyService]
        })
        fixture = TestBed.createComponent(EndPointComponent);
        component = fixture.componentInstance;
        service = fixture.debugElement.injector.get(IotRouteService);
        noty = fixture.debugElement.injector.get(NotyService);
    }));

    it('should have a defined component', () => {
        expect(component).toBeDefined();
    });
    describe('When we call onSaveUser method', () => {
        beforeEach(() => {
            component.setPagerConfig(10, 1, 1);
        })
        it(' should close the popup window and save the user details in database', () => {
            expect(component.endPointForm).toBeDefined();
            spyOn(component.endPointForm, 'save').and.returnValue(Observable.of({}));
            spyOn(component, 'allEndPointData');
            component.onSaveIotForm();
            expect(component.endPointForm.save).toHaveBeenCalled();
            expect(component.endPointForm).toHaveBeenCalled();
        })
    });

});
