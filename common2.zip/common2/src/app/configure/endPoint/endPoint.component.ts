import 'rxjs/add/operator/debounceTime';
import { IotRouteService } from '../services/iotRoute.service';
import { EndPointFormComponent } from './endpointForm.component';
import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { ConnectionType, EndPoint } from '../endPoint.data';
import { ModalDirective } from 'ng2-bootstrap';
import { FilterParams, ActionButtons } from 'sensorthink-commoncontrols/src/components/advancedFilter/advancedFilter.data';
import { NotyService } from 'sensorthink-commoncontrols/src/services/noty.service';

@Component({
  templateUrl: 'endPoint.component.html'
})
export class EndPointComponent implements OnInit {
  endpointChildForm: FormGroup;
  public modelTitle: String;
  public submitText: String;
  public allEndPointData: any;
  public loadForm: boolean = false;
  public filterConfig: FilterParams;
  public appliedFilterData: FilterParams;
  public pagerConfig: any;
  public sortArgs: string;
  public sideBarVisible:boolean;
  callBack = this.onCheckBoxChecked.bind(this)
  isLoading: boolean = false;
  isFirstLoad: boolean = false;
  searchTxt = '';
  isChecked: boolean = false;
  searchTxtControl = new FormControl();
  selectedCheckboxCount = [];
  @ViewChild(EndPointFormComponent) endPointForm: EndPointFormComponent;
  @ViewChild('endPointModal') public endPointModal: ModalDirective;

  constructor(private service: IotRouteService, private noty: NotyService) {
    this.sortArgs = "endpointUrl,desc";
    this.filterConfig = this.createFilterParams();
    this.pagerConfig = {
      totalItems: 64,
      currentPage: 1,
      smallnumPages: 0,
    }

    this.filterConfig = new FilterParams();
    this.filterConfig.actionButtons = [new ActionButtons("Edit", true, this.onEditEndPointRouteModal.bind(this)), new ActionButtons("Delete", true, this.onDeleteEndPointRouteModal.bind(this))];
    this.filterConfig.actionSubSection.isChangeState = false;
    this.filterConfig.actionSubSection.isExportTo = false;
    this.filterConfig.actionSubSection.isTransaction = false;
  }
  setPagerConfig(totalItems, currentPage, itemsPerPage?) {
    this.pagerConfig = {
      totalItems: totalItems,
      currentPage: currentPage || 1,
      itemsPerPage: itemsPerPage || 10,
      smallnumPages: 0
    }
  }

  ngOnInit() {
    this.searchInputFilterData();
    this.setPagerConfig(0, 0);
    this.getAllEndPoints(1, this.sortArgs);
  }
  searchInputFilterData() {
    this.searchTxtControl.valueChanges
      .debounceTime(1000)
      .subscribe(newValue => {
        this.searchTxt = newValue.trim();
        if (((this.searchTxt.length >= 1 || this.searchTxt.length === 0) && this.searchTxt !== "") || this.isFirstLoad) {
          this.isFirstLoad = (this.searchTxt.length === 0) ? false : true;
          this.getAllEndPoints(this.pagerConfig.currentPage, this.sortArgs, this.searchTxt);
        }
      });
  }

  onOpenendPointModal(endPoint?) {
    if (endPoint === undefined)
      this.service.selectedEndPoint = undefined;
    this.modelTitle = (endPoint === undefined) ? "ADD NEW END POINT" : "EDIT END POINT";
    this.submitText = (endPoint === undefined) ? "Add" : "Save";
    this.loadForm = true;
    this.endPointModal.show();
    setTimeout(() => {
      if (this.endPointForm)
        this.endpointChildForm = this.endPointForm.endPointForm;
    })
  }
  getAllEndPoints(pageNumber: number, sortArgs: string, searchTxt?: string) {
    this.isLoading = true;
    this.service.getAllEndPoint(pageNumber, this.pagerConfig.itemsPerPage, sortArgs, searchTxt).subscribe((endPoints) => {
      if (endPoints) {
        this.setPagerConfig(endPoints.totalElements, this.pagerConfig.currentPage, endPoints.size)
        this.allEndPointData = endPoints.content;
      } else {
        this.setPagerConfig(0, this.pagerConfig.currentPage, this.pagerConfig.itemsPerPage)
        this.allEndPointData = [];
      }
      this.isLoading = false;
    });
  }

  onSaveIotForm() {
    this.endPointForm.save().subscribe(
      res => {
        this.loadForm = false;
        this.service.selectedEndPoint = undefined;
        this.endPointForm.endPoint = new EndPoint();
        this.endPointForm.connectionType = [];
        this.endPointModal.hide();
        this.getAllEndPoints(this.pagerConfig.currentPage, this.sortArgs);
        this.selectedCheckboxCount = [];
        if (res.type == "create")
          this.noty.success("End Point created successfully.");
        else
          this.noty.success("End Point updated successfully.");
      },
      err => {
        if (err.status === 409) {
          this.noty.error("Endpoint name already exists.")
        }
        else
          this.noty.error(err)
        this.endPointModal.hide();
      });
  }
  onCancelClick() {
    this.loadForm = false;
    this.endPointModal.hide();
    this.service.selectedEndPoint = undefined;
    this.getAllEndPoints(this.pagerConfig.currentPage, this.sortArgs);
    this.selectedCheckboxCount = [];
    // this.endPointForm.endPoint = new EndPoint();
    // this.endPointForm.connectionType = [];
  }
  onPageSizeChanged(pageSize) {
    this.pagerConfig.itemsPerPage = pageSize;
    this.getAllEndPoints(1, this.sortArgs);
  }
  onPageChanged(pager) {
    this.pagerConfig.currentPage = pager.page;
    this.getAllEndPoints(pager.page, this.sortArgs);
  }
  onSortChanged(sortArgs) {
    if (sortArgs.length === 1)
      this.sortArgs = sortArgs[0][0] + "," + sortArgs[0][1];
    else
      this.sortArgs = sortArgs[0] + "," + sortArgs[1];
    this.getAllEndPoints(this.pagerConfig.currentPage, this.sortArgs);
  }
  onCheckBoxChecked(endPoint, e) {
    if(endPoint.company == null)
      endPoint.company = "";
    if (e.target.checked) {
      this.selectedCheckboxCount.push(endPoint);
      this.service.selectedEndPoint = Object.assign({}, endPoint);
    }
    else {
      this.selectedCheckboxCount.splice(this.selectedCheckboxCount.indexOf(endPoint), 1);
      this.service.selectedEndPoint = undefined;
    }
  }
  onEditEndPointRouteModal() { //edit
    if (this.selectedCheckboxCount.length > 1) {
      this.noty.error("Please select only one end point")
    } else if (this.selectedCheckboxCount.length === 0) {
      this.noty.error("Please select at least one end point")
    } else {
      if (this.selectedCheckboxCount.length == 1)
        this.service.selectedEndPoint = Object.assign({}, this.selectedCheckboxCount[0]);
      this.onOpenendPointModal(this.selectedCheckboxCount[0]);
    }
  }
  onDeleteEndPointRouteModal() {
    let updateArray = this.updateObjectArray(this.selectedCheckboxCount);
    if (this.selectedCheckboxCount.length > 1) {
      this.noty.error("Please select only one end point")
    } else {
      this.noty.confirm().then(() => {
        this.service.deleteEndPoint(this.selectedCheckboxCount[0].endpointConfigId)
          .subscribe(res => {
            this.selectedCheckboxCount = [];
            this.noty.success("End Point deleted successfully.");
            this.getAllEndPoints(this.pagerConfig.currentPage, this.sortArgs);
          },
          err => {
            this.noty.error("Could not delete the End Point.")
          });
      });
    }
    //delete
  }
  updateObjectArray(array) {
    let a = [];
    array.forEach(e => {
      let b = { "module": "iot", "messageId": e.endpointConfigId }
      a.push(b);
    });
    return a;
  }
  createFilterParams(): FilterParams {
    let params = new FilterParams(); // initialises to default on object creation
    params.state.isVisible = false;
    params.site.isVisible = false;
    params.baseMetric.isVisible = false;
    params.otherMetric.isVisible = false;
    return params;
  }
  applyFormatting(columns) {
    this.getAllEndPoints(this.pagerConfig.currentPage, this.sortArgs);
  }
}