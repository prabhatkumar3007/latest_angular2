import { IotRouteService } from '../services/iotRoute.service';
import { Component, DoCheck } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { NotyService } from 'sensorthink-commoncontrols/src/services/noty.service';

declare let $: any;

@Component({
  selector: 'hubRoute-modal',
  templateUrl: 'hubRouteForm.component.html'
})

export class HubRouteFormComponent implements DoCheck {
  arrMessageType: any
  private checkFormValid = new Subject<boolean>();
  public masterData: any = { companies: [], endpoints: [], messageTypes: [] };
  public hubRouteModel: any = {
    routeName: '',
    selectedMessageTypes: [{ source: undefined, destination: '', messageType: undefined }],
    fromEndPoint: undefined,
    toEndPoints: new Array<any>(),
    persistMessage: false,
    active: false,
    enableOnStartup: false
  };
  isSuperAdmin: boolean = false;

  get isFormValid() {
    return this.checkFormValid.asObservable();
  }

  constructor(private service: IotRouteService, private noty: NotyService) {
    this.hubRouteModel.toEndPoints.push({});
    this.initializeMasterData();
    this.isSuperAdmin = service.checkSuperAdmin();
  }

  ngDoCheck() {
    this.ValidateForm();
  }

  initializeMasterData() {
    let promises = [
      this.service.getAllCompany(),
      this.service.getAllEndPoint(),
      this.service.getMessageTypes()
    ]

    Observable.forkJoin(promises).subscribe((res) => {
      this.masterData.companies = (res[0].constructor === Array) ? res[0] : [res[0]];
      this.masterData.endpoints = res[1];
      this.masterData.messageTypes = res[2];

      if (this.service.selectedHubRoute) {
        let route = this.service.selectedHubRoute;
        this.hubRouteModel.hubRouteId = route.hubRouteId,
          this.hubRouteModel.routeName = route.routeName,
          this.hubRouteModel.persistMessage = route.persistMessage
        this.hubRouteModel.active = route.active
        this.hubRouteModel.enableOnStartup = route.enableOnStartup
        this.hubRouteModel.company = this.masterData.companies.find(c => c.companyId === route.company.companyId);
        //load from endpoint
        let fromEndpoint = route.hubEndpoint.find(h => h.direction == "from")
        this.hubRouteModel.fromEndPoint = this.masterData.endpoints.content.find(e => e.endpointConfigId === fromEndpoint.endpointConfig.endpointConfigId);
        this.hubRouteModel.fromEndPoint.hubEndpointId = fromEndpoint.hubEndpointId;

        //load to endpoint
        this.hubRouteModel.toEndPoints = [];
        route.hubEndpoint.forEach(ep => {
          if (ep.direction === "to") {
            let endpoint = this.masterData.endpoints.content.find(e => e.endpointConfigId === ep.endpointConfig.endpointConfigId)
            endpoint.hubEndpointId = ep.hubEndpointId;
            this.hubRouteModel.toEndPoints.push(endpoint);
          }
        });

        //load to messageTypes
        this.hubRouteModel.selectedMessageTypes = [];
        route.hubMessageRoute.forEach(ep => {
          let msgType = this.masterData.messageTypes.find(msg => msg.id === ep.messageType.messageTypeId);
          this.hubRouteModel.selectedMessageTypes.push({ source: ep.source, destination: ep.destination, messageType: msgType, hubMessageRouteId: ep.hubMessageRouteId });
        });
      }
    })
  }

  addToEndPoint() {
    this.hubRouteModel.toEndPoints.push({});
  }

  deleteToEndPoint(itm) {
    let idx = this.hubRouteModel.toEndPoints.indexOf(itm);
    this.hubRouteModel.toEndPoints.splice(idx, 1);
  }

  addMessageType() {
    this.hubRouteModel.selectedMessageTypes.push({ source: undefined, destination: '', messageType: undefined })
  }

  deleteMessageType(msgType) {
    let idx = this.hubRouteModel.selectedMessageTypes.indexOf(msgType);
    this.hubRouteModel.selectedMessageTypes.splice(idx, 1);
  }

  ValidateForm() {
    let isValid = true;
    if (this.hubRouteModel.routeName === "")
      isValid = false;
    else if (this.hubRouteModel.fromEndPoint === undefined)
      isValid = false;
    else if (this.hubRouteModel.destination === "")
      isValid = false;
    else if (this.hubRouteModel.source === "")
      isValid = false;
    else {
      this.hubRouteModel.toEndPoints.forEach(element => {
        if (element && !element.connectionType)
          isValid = false;
      });
      this.hubRouteModel.selectedMessageTypes.forEach(msg => {
        if (msg.source === undefined || msg.destination === '' || msg.messageType === undefined)
          isValid = false;
      });
    }

    this.checkFormValid.next(isValid);
  }

  saveHubRoute() {
    let duplicateResult: boolean = this.duplicateChecker(this.hubRouteModel.selectedMessageTypes);
    let duplicateFromAndToEndPoint: boolean = this.duplicateCheckerForRoute(this.hubRouteModel.fromEndPoint, this.hubRouteModel.toEndPoints)
    let duplicateToEndPoint: boolean = this.duplicateCheckerForToRoute(this.hubRouteModel.toEndPoints)
    if (duplicateFromAndToEndPoint == true) {
      this.noty.error("From end point and To end point could not be same.");
      return false;
    }
    else if (duplicateToEndPoint == true) {
      this.noty.error("To end point could not be same.");
      return false;
    }
    else {
      if (duplicateResult == false) {
        return this.service.createHubRoute(this.hubRouteModel).then(res => {
          this.noty.success("Hub route created successfully.")
          return true;
        }, err => {
          if (err.status === 409)
            this.noty.error("Duplicate Hub Route name.");
          return false;
        });
      } else {
        this.noty.error("Duplicate Source,Destination and Message Type.");
        return false;
      }
    }
  }
  duplicateCheckerForRoute(fromEndPoint, toEndpoints) {
    for (let i = 0; i < toEndpoints.length; i++) {
      if (fromEndPoint.endpointUrl == toEndpoints[i].endpointUrl)
        return true
    }
    return false
  }
  duplicateCheckerForToRoute(duplicateVal) {
    for (let i = 0; i < duplicateVal.length; i++) {
      for (let j = i + 1; j < duplicateVal.length; j++) {
        if ((duplicateVal[i].endpointUrl == duplicateVal[j].endpointUrl)) {
          return true
        }
      }
    }
    return false
  }
  duplicateChecker(duplicateVal) {
    for (let i = 0; i < duplicateVal.length; i++) {
      for (let j = i + 1; j < duplicateVal.length; j++) {
        if ((duplicateVal[i].destination == duplicateVal[j].destination) && (duplicateVal[i].source == duplicateVal[j].source) && (duplicateVal[i].messageType.instance.code == duplicateVal[j].messageType.instance.code)) {
          return true
        }
      }
    }
    return false
  }

  updateHubRoute() {
    let duplicateResult: boolean = this.duplicateChecker(this.hubRouteModel.selectedMessageTypes);
    let duplicateFromAndToEndPoint: boolean = this.duplicateCheckerForRoute(this.hubRouteModel.fromEndPoint, this.hubRouteModel.toEndPoints);
    let duplicateToEndPoint: boolean = this.duplicateCheckerForToRoute(this.hubRouteModel.toEndPoints);
    if (duplicateFromAndToEndPoint == true) {
      this.noty.error("From end point and To end point could not be same.");
      return false;
    } 
    else if (duplicateToEndPoint == true) {
      this.noty.error("To end point could not be same.");
      return false;
    }
    else {
      if (duplicateResult == false) {
        return this.service.updateHubRoute(this.hubRouteModel).then(res => {
          this.noty.success("Hub route updated successfully.")
        }, err => {
          this.noty.error(err);
        });
      } else {
        this.noty.error("Duplicate Source,Destination and Message Type.");
        return false;
      }
    }
  }
}