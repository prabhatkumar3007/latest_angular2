import { ChangeDetectorRef, Component, OnInit, ViewChild } from '@angular/core';
import { FormControl } from '@angular/forms';
import { ModalDirective } from 'ng2-bootstrap';
import { IotRouteService } from '../services/iotRoute.service';
import { HubRouteFormComponent } from './hubRouteForm.component';
import { FilterParams, ActionButtons } from 'sensorthink-commoncontrols/src/components/advancedFilter/advancedFilter.data';
import { NotyService } from 'sensorthink-commoncontrols/src/services/noty.service';


@Component({
  templateUrl: 'hubRoute.component.html'
})
export class HubRouteComponent implements OnInit {
  public hubRouteModel: any = {
    modelTitle: '',
    submitText: ''
  }
  public allRouteData: Array<any>;
  public loadForm: boolean = false;
  public pagerConfig: any;
  public sortArgs: string;
  public sideBarVisible: boolean;
  public isFormValid: boolean = false;
  public callBack = this.onCheckBoxChecked.bind(this)
  private subscription: any;
  iotObj: any;
  isLoading: boolean = false;
  isFirstLoad: boolean = false;
  searchTxt = '';
  searchTxtControl = new FormControl();
  selectedCheckboxCount = [];
  myOptions: any;
  filterConfig: FilterParams
  hideActions: boolean = false;
  @ViewChild(HubRouteFormComponent) hubRouteForm: HubRouteFormComponent;
  @ViewChild('hubRouteModal') public hubRouteModal: ModalDirective;

  constructor(private service: IotRouteService, private noty: NotyService, private _cdr: ChangeDetectorRef) {
    this.sortArgs = "hubRouteId,desc";
    this.pagerConfig = {
      totalItems: 64,
      currentPage: 1,
      smallnumPages: 0,
    }
    this.filterConfig = new FilterParams();
    this.filterConfig.actionButtons = [new ActionButtons("Edit", true, this.onEditHubRouteModal.bind(this)), new ActionButtons("Delete", true, this.onDeleteHubRouteModal.bind(this))];
    this.filterConfig.actionSubSection.isChangeState = false;
    this.filterConfig.actionSubSection.isExportTo = false;
    this.filterConfig.actionSubSection.isTransaction = false;
  }

  ngOnInit() {
    this.searchInputFilterData();
    this.setPagerConfig(0, 0);
    this.getAllRoutes(1, this.sortArgs);
  }

  ngOnChanges() {
  }

  setPagerConfig(totalItems, currentPage, itemsPerPage?) {
    this.pagerConfig = {
      totalItems: totalItems,
      currentPage: currentPage || 1,
      itemsPerPage: itemsPerPage || 10,
      smallnumPages: 0
    }
  }


  searchInputFilterData() {
    this.searchTxtControl.valueChanges
      .debounceTime(1000)
      .subscribe(newValue => {
        this.searchTxt = newValue.trim();
        if (((this.searchTxt.length >= 1 || this.searchTxt.length === 0) && this.searchTxt !== "") || this.isFirstLoad) {
          this.isFirstLoad = (this.searchTxt.length === 0) ? false : true;
          this.getAllRoutes(this.pagerConfig.currentPage, this.sortArgs, this.searchTxt);
        }
      });
  }
  onOpenHubRouteModal(hub?) {
    if (hub === undefined) {
      this.service.selectedHubRoute = undefined;
    }
    else
      this.service.selectedHubRoute = hub;
    this.hubRouteModel.modelTitle = (hub === undefined) ? "CREATE A NEW ROUTE" : "EDIT ROUTE";
    this.hubRouteModel.submitText = (hub === undefined) ? "Create" : "Save";
    this.loadForm = true;
    this.hubRouteModal.show();
    this.subscribeToFormModal();
  }

  private subscribeToFormModal() {
    if (this.subscription)
      this.subscription.unsubscribe();
    setTimeout(() => {
      if (this.hubRouteForm)
        this.subscription = this.hubRouteForm.isFormValid.subscribe(res => {
          this.isFormValid = res;
        });
    })
  }

  getAllRoutes(pageNumber: number, sortArgs: string, searchTxt?: string) {
    this.selectedCheckboxCount = [];
    this.isLoading = true;
    this.service.getHubRoutes(pageNumber, this.pagerConfig.itemsPerPage, sortArgs, searchTxt).subscribe((routes) => {
      if (routes) {
        routes.numberOfElements = routes.contentLength;
        this.setPagerConfig(routes.totalElements, routes.totalPages, routes.size)
        this.allRouteData = routes.content;
      } else {
        this.setPagerConfig(0, this.pagerConfig.currentPage, this.pagerConfig.itemsPerPage)
        this.allRouteData = [];
      }
      this.isLoading = false;
    });
  }
  onSaveIotForm(evt?) {
    if (this.hubRouteModel.submitText === "Create") {
      this.hubRouteForm.saveHubRoute().then((res) => {
        if (res) {
          this.getAllRoutes(this.pagerConfig.currentPage, this.sortArgs);
          this.onCancelClick();
        }
      }, err => {
        this.noty.error(err);
        this.hubRouteModel.hide();
      });
    }
    else {
      this.hubRouteForm.updateHubRoute().then(() => {
        this.getAllRoutes(this.pagerConfig.currentPage, this.sortArgs);
        this.onCancelClick();
      }, (err) => {
        this.noty.error(err);
        this.hubRouteModel.hide();
      });
    }
  }
  onCancelClick() {
    this.hubRouteModal.hide();
    this.getAllRoutes(this.pagerConfig.currentPage, this.sortArgs);
    this.loadForm = false;
  }
  onSortChanged(sortArgs) {
    if (sortArgs[0].pop)
      this.sortArgs = sortArgs[0][0] + "," + sortArgs[0][1];
    else
      this.sortArgs = sortArgs[0] + "," + sortArgs[1];

    this.getAllRoutes(this.pagerConfig.currentPage, this.sortArgs);
  }
  onPageSizeChanged(pageSize) {
    this.pagerConfig.itemsPerPage = pageSize;
    this.getAllRoutes(1, this.sortArgs);
  }
  onPageChanged(pager) {
    this.pagerConfig.currentPage = pager.page;
    this.getAllRoutes(pager.page, this.sortArgs);
  }
  onCheckBoxChecked(hub, e) {
    if (e.target.checked == true) {
      this.service.selectedValue.push(hub)
    }
    else {
      this.service.selectedValue.splice(this.service.selectedValue.indexOf(hub), 1)
    }
  }
  onEditHubRouteModal() { //edit
    if (this.service.selectedValue.length > 1) {
      this.noty.error("Please select only one route");
    } else if (this.service.selectedValue.length === 0) {
      this.noty.error("Please select at least one route")
    }else{
      this.onOpenHubRouteModal(this.service.selectedValue[0]);
      this.service.selectedValue = [];
    }
    
  }
  onDeleteHubRouteModal() {
    if (this.service.selectedValue.length > 1) {
      this.noty.error("Please select only one route")
    } else {
      this.noty.confirm().then(() => {
        this.service.deleteHubRoute(this.service.selectedValue[0].hubRouteId)
          .subscribe(res => {
            this.service.selectedValue = [];
            this.noty.success("Hub Route deleted successfully.");
            this.getAllRoutes(1, this.sortArgs);
          },
          err => {
            this.noty.error("Error deleting route. Please contact Administrator.")
          });
      }, (err) => { });
    }
  }
  //delete
  applyFormatting(columns) {
    this.getAllRoutes(this.pagerConfig.currentPage, this.sortArgs);
  }
}