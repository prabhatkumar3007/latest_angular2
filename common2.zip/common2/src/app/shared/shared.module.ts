import { ControlsModule } from '../controls/controls.module';
import { DatePipe } from './components/dateFormater.pipe';
import { FooterComponent } from './components/footer.component';
import { MultiselectComponent } from './components/multiselect.component';
import { NavComponent } from './components/nav.component';
import { NavBarComponent } from './components/navbar.component';
import { PaginationComponent } from './components/pagination.component';
import { SpinnerComponent } from './components/spinner.component';
import { ClickOutside } from './directives/clickOutside.directive';
import { Globals } from './services/globals.service';
import { AdvanceFilterService } from './services/advanceFilterIot.service';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { HttpModule } from '@angular/http';
import { RouterModule } from '@angular/router';
import { MultiselectDropdownModule } from 'angular-2-dropdown-multiselect';
import { ModalModule } from 'ng2-bootstrap/modal';
import { PopoverModule } from 'ng2-bootstrap/popover';
import { NoAccessComponent } from './components/no-access.component';
import { AlertSubscriptionComponent } from '../alertSubscription/alertSubscription.component';
import { AlertSubscriptionService } from '../alertSubscription/alertSubscriptionService/alertSubscription.service';
import { OrderByPipe } from "./components/orderBy.pipe";
import { ChangePasswordService } from "../changePassword/services/changePassword.service";
import { ChangePasswordComponent } from "../changePassword/changePassword.component";
import { UserProfileComponent } from "../userProfile/userProfile.component";
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { EqualValidator } from "../shared/directives/equalValidator.directive";

import { KeysPipe } from './components/objectKeyFilter.pipe';
import { DateFormatter } from './components/dateFormatePipe.pipe';
import { TitleCase } from './components/camelCaseFilter.pipe';
import { TitleFormatter } from './components/titleFormatter.pipe';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    RouterModule,
    HttpModule,
    ControlsModule,
    PopoverModule.forRoot(),
    ModalModule.forRoot(),
    MultiselectDropdownModule,
    ReactiveFormsModule
  ],
  declarations: [
    PaginationComponent,
    SpinnerComponent,
    MultiselectComponent,
    NavBarComponent,
    NavComponent,
    FooterComponent,
    DatePipe,
    ClickOutside,
    NoAccessComponent,
    AlertSubscriptionComponent,
    ChangePasswordComponent,
    UserProfileComponent,
    OrderByPipe,
    EqualValidator,
    TitleCase,
    DateFormatter,
    KeysPipe,
    TitleFormatter
  ],
  exports: [
    PaginationComponent,
    SpinnerComponent,
    MultiselectComponent,
    NavBarComponent,
    NavComponent,
    FooterComponent,
    DatePipe,
    ClickOutside,
    NoAccessComponent,
    AlertSubscriptionComponent,
    ChangePasswordComponent,
    UserProfileComponent,
    OrderByPipe, 
    EqualValidator
  ],
  providers: [
    Globals,
    AlertSubscriptionService,
    ChangePasswordService,
    AdvanceFilterService
  ]
})
export class SharedModule { }