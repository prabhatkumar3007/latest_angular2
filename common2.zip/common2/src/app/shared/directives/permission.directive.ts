
import { element } from 'protractor';
import { Directive, ElementRef, HostListener, Input,Output, OnInit } from '@angular/core';
import { AuthPermissionService } from "sensorthink-commoncontrols/src/utils.module";
import { AuthService } from './../../auth/auth.service';

@Directive({
    selector: '[permission]'
})

export class PermissionDirective {

    private _manage: boolean = false;
    private _view: boolean = false;
    private _monitor: boolean = false;
    private _hasAccess: boolean = false;
    private _modulePermission = [];    
    @Input() moduleName: string | Array<string>;
    @Input() isMenu: boolean;   

    constructor(private _el: ElementRef, private _authPermissionService: AuthPermissionService,private _authService: AuthService) { };

    ngOnInit() {
        if(this._authPermissionService.permissions && this._authPermissionService.permissions.length==0){                                
                this._authPermissionService.setLoggedInUserPermissions(this._authService.userPermissons);
        } 

        if (this._authPermissionService.isSuperAdmin()) {             
            return true;
         }
        if (this.moduleName instanceof Array) { //Hide tab and sub menu
            for (let mod of this.moduleName) {
                this._modulePermission = this._modulePermission.concat(this._authPermissionService.getPermissionByModule(mod));
            }
            this._manage = this._authPermissionService.canManage(this._modulePermission);
            this._view = this._authPermissionService.canView(this._modulePermission);
            this._monitor = this._authPermissionService.canMonitor(this._modulePermission);
            if (!this._manage && !this._view && !this._monitor) {
                this.hide();
            } else if (this._view || this._manage || this._monitor) {
                this.show();
            }
        } else {// hide menu and page level element
            this._modulePermission = this._authPermissionService.getPermissionByModule(this.moduleName);
            this._manage = this._authPermissionService.canManage(this._modulePermission);
            this._view = this._authPermissionService.canView(this._modulePermission);
            this._monitor = this._authPermissionService.canMonitor(this._modulePermission);
            if (this._view && !this.isMenu) {
                this.hide();
            } else if (this._manage) {
                this.show();
            } else if (this._monitor) {
                this.show();// TODO: Don't know what to do?
            } else if (!this._manage && !this._view) {
                this.hide();
            }
        }
    };

    hide() {
        this._el.nativeElement.style.display = "none";
    };
    show() {
        this._el.nativeElement.style.display = "";
    };
}
