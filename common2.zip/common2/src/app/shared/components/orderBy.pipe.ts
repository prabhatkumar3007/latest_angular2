import { Pipe, PipeTransform } from "@angular/core";
@Pipe({
    name: 'orderBy'
})
export class OrderByPipe implements PipeTransform {
    transform(array: Array<any>, orderField: string, orderType: boolean): Array<string> {
        array.sort((a: any, b: any) => {
            let ae = this.getValue(a, orderField);
            let be =  this.getValue(b, orderField);
            if (ae == undefined && be == undefined) return 0;
            if (ae == undefined && be != undefined) return orderType ? 1 : -1;
            if (ae != undefined && be == undefined) return orderType ? -1 : 1;
            if (ae == be) return 0;
            return orderType ? (ae.toString().toLowerCase() > be.toString().toLowerCase() ? -1 : 1) : (be.toString().toLowerCase() > ae.toString().toLowerCase() ? -1 : 1);
        });

        return array;
    }
    private getValue(obj, property) {
        if (property.indexOf(".") >= 0) {
            if (obj[property.split(".")[0]])
                obj = obj[property.split(".")[0]];
        } else {
            obj = obj[property];
            return obj;
        }
        if (Object.prototype.toString.call(obj) === '[object Array]')
            return obj;
        return this.getValue(obj, property.substring(property.indexOf(".") + 1));
    };
}