import { Globals } from './../services/globals.service';
import { Component } from '@angular/core';
import { AuthService } from '../../auth/auth.service';
import { Router, NavigationStart, NavigationEnd } from '@angular/router';
import { Location, PlatformLocation } from '@angular/common';
import { AuthPermissionService } from 'sensorthink-commoncontrols/src/utils.module';
@Component({
  selector: 'navbar',
  templateUrl: 'navbar.component.html'
})
export class NavBarComponent {
  routeActiveClass: string;
  isManageTab: any;
  isHidden: number = 1;
  isExecute: boolean = false;
  imgSrc: string = "../resources/images/operationImg.png";
  isProcessTab: boolean = false;
  isOperationTab: boolean = false;
  isConfigureTab: boolean = false;
  operations: any = ['waves', 'orders', 'pickcontainers', 'packcontainers', 'shipcontainers']; //added routing tabs for operations
  process: any = ['picking', 'shipping'];
  configure: any = ['iotroute', 'hubroute', 'endroute'];
  canRedirectToWES: boolean = false;
  isIot: boolean = false

  constructor(private _loginService: AuthService, private _router: Router, pltFormLoc: PlatformLocation, private _authPermissionService: AuthPermissionService) {
    _router.events.subscribe((event) => {
      if (event instanceof NavigationStart) {
        let routeValue = (event.url.split('?'))[0].split('/');
        this.changeRoute(routeValue[1])
      }
    });
    this.getRouteActiveLink();
    pltFormLoc.onPopState(() => {
       if (pltFormLoc.hash === "#/home") {
        this.executeClick();
      }
    });
    this.canRedirectToWES = this._authPermissionService.hasAccessWESWebsite();
  }

  getRouteActiveLink() {
    this.routeActiveClass = "active"
    this._router.events.subscribe((val) => {
      // see also 
      if (val instanceof NavigationEnd) {
        if (val.url === "/iotRoute-monitor" || val.url === "/hubRoute-monitor")
          this.routeActiveClass = "active"
        else
          this.routeActiveClass = '';
      }
    });
  }

  changeRoute(routeValue) {
    if (!(this.operations.indexOf(routeValue) == -1))
      this.onTabClick('OPERATIONS');
    if (!(this.process.indexOf(routeValue) == -1))
      this.onTabClick('PROCESS');
    if (!(this.configure.indexOf(routeValue) == -1))
      this.onTabClick('CONFIGURE');
  }
  logout() {
    this._loginService.logout().subscribe(
      data => { },
      err => this.logoutFail(err)
    )
  }

  logoutFail(err: any) {
    console.log(err);
  }

  executeClick(): void {
    this.isExecute = false;
    window.location.href = new Globals().baseApiUrl_Wes;
  }
  userClick(): void {
    this._router.navigateByUrl('/users');
  }
  onTabClick(value) {
    this.isOperationTab = false;
    this.isProcessTab = false;
    this.isConfigureTab = false;
    this.isManageTab = false;
    switch (value) {
      case 'USER':
        this.isManageTab = true;
        this._router.navigateByUrl('/users');
        break;
        case 'MESSAGES':
        this.isManageTab = true;
        break;
      case "CONFIGURE":
        this.isConfigureTab = true;
        break;
      default:
        break;
    }
  }
}