import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { IMultiSelectOption, IMultiSelectTexts, IMultiSelectSettings } from 'angular-2-dropdown-multiselect';

@Component({
  selector: 'multiselect',
  template: `
      <ss-multiselect-dropdown [options]="options" [texts]="myTexts" [settings]="mySettings" [(ngModel)]="optionsModel" (ngModelChange)="onChange($event)"></ss-multiselect-dropdown>
    `
})
export class MultiselectComponent implements OnInit {
  @Input() options: IMultiSelectOption[];
  optionsModel: number[] = [];
  mySettings: IMultiSelectSettings;
  myTexts: IMultiSelectTexts;
  @Output() onSelect: EventEmitter<any> = new EventEmitter<any>();

  constructor() { }
  ngOnInit() {
    this.mySettings = {
      enableSearch: true,
      checkedStyle: 'checkboxes',
      buttonClasses: 'btn btn-default btn-block',
      dynamicTitleMaxItems: 0,
      displayAllSelectedText: false,
      showCheckAll: false,
      showUncheckAll: true
    };
    this.myTexts = {
      checkAll: 'Select all',
      uncheckAll: 'Unselect all',
      checked: 'item selected',
      checkedPlural: 'items selected',
      searchPlaceholder: 'Find',
      defaultTitle: 'Select',
      allSelected: 'All selected',
    };
  }
  onChange(item) {
    this.onSelect.emit(item);
  }
}