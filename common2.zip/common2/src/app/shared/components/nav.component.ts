import { ChangeDetectorRef, Component, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { ModalDirective } from 'ng2-bootstrap';
import { SessionStorage } from 'sensorthink-commoncontrols/lib/webStore.module';
import { HighAlert, LowAlert, MediumAlert } from 'sensorthink-commoncontrols/src/alerts/alert.data';
import { AlertService } from 'sensorthink-commoncontrols/src/alerts/alert.service';
import { ViewAllComponent } from 'sensorthink-commoncontrols/src/alerts/viewAll.component';
import { JwtHelper } from 'sensorthink-commoncontrols/src/services/jwtHelper.service';
import { ShareDataService } from 'sensorthink-commoncontrols/src/services/shareDataService';

import { AuthService } from '../../auth/auth.service';

declare var $: any
declare var moment: any

@Component({
  selector: 'navbar-new',
  templateUrl: 'nav.component.html'
})
export class NavComponent {
  isHidden: number = 1;
  highAlerts: Array<HighAlert>;
  mediumAlerts: Array<MediumAlert>;
  lowAlerts: Array<LowAlert>;
  timeoutId: any;
  isAlertDetail: boolean = false;
  selectedAlert: any;
  viewData: any;
  alertMessageNo: number;
  sortArgs: string;
  fDate: Date;
  tDate: Date;

  @SessionStorage() public accessToken: any;
  @SessionStorage() public userInfo: any;
  @ViewChild('viewAllModal') public viewAllModal: ModalDirective;
  @ViewChild(ViewAllComponent) viewAll: ViewAllComponent;

  constructor(private _loginService: AuthService, private alertService: AlertService, private router: Router, private _cdr: ChangeDetectorRef, private dates: ShareDataService, private jwtHelper: JwtHelper) {
    this.sortArgs = "createdTime,desc";
  }

  ngAfterViewInit() {
    this.initializeAlerts(this.sortArgs);
    if (!this.checkIsJWTExpired())
      this._loginService.silentAuthentication();
    else
      this.router.navigate(['login']);
  }

  initializeAlerts(sortArgs) {
    this.alertService.getHighAlertNotifications(sortArgs).subscribe(alerts => this.highAlerts = alerts);
    this.alertService.getMediumAlertNotifications(sortArgs).subscribe(alerts => this.mediumAlerts = alerts);
    this.alertService.getLowAlertNotifications(sortArgs).subscribe(alerts => this.lowAlerts = alerts);

    this.timeoutId = setInterval(() => {
      this.alertService.getHighAlertNotifications(sortArgs).subscribe(alerts => this.highAlerts = alerts);
      this.alertService.getMediumAlertNotifications(sortArgs).subscribe(alerts => this.mediumAlerts = alerts);
      this.alertService.getLowAlertNotifications(sortArgs).subscribe(alerts => this.lowAlerts = alerts);
    }, 60 * 1000); //called every 2 mins
  }

  checkIsJWTExpired() {
    let jwt = JSON.parse(window.atob(this.accessToken.token.split('.')[1]));
    if (jwt.exp < Date.now() / 1000) {
      return true;
    }
    return false;
  }

  markAsRead(alert) {
    this.alertService.markAsRead(alert.id).subscribe((res) => {
      alert.isRead = true;
      this.isAlertDetail = true;
      this.selectedAlert = alert;
    });
  }

  closeDetail() {
    this.isAlertDetail = false;
    this.selectedAlert = undefined;
  }

  resetPopOvers(popOvers) {
    if (popOvers)
      popOvers.forEach(element => {
        element.hide();
      });
    this.isAlertDetail = false;
    this.selectedAlert = undefined;
  }

  ngOnDestroy() {
    if (this.timeoutId) {
      clearInterval(this.timeoutId);
    }
  }

  logout() {
    this._loginService.logout().subscribe(
      data => {
        this.accessToken = null;
        this.userInfo = null;
        window.sessionStorage.removeItem("angular2ws_accessToken");
        window.sessionStorage.removeItem("angular2ws_userInfo");
        window.sessionStorage.removeItem("angular2ws_permissions");
        this.router.navigate(['login']);
      },
      err => this.logoutFail(err)
    )
  }

  logoutFail(err: any) {
    this.accessToken = null;
    window.sessionStorage.removeItem("angular2ws_accessToken");
    this.router.navigate(['login']);
  }

  onAlertViewAllModal(popoverId, section, length) {
    this.alertMessageNo = length;
    this.viewAllModal.show();
    popoverId.hide();
    setTimeout(() => {
      this.viewAll.isModalShown = true;
      this.fDate = this.dates.getDate()[0] || moment(new Date()).format("YYYY-MM-DDT00:00:00") + this.jwtHelper.token.companyTimeZone;
      this.tDate = this.dates.getDate()[1] || moment(new Date()).format("YYYY-MM-DDT23:59:59") + this.jwtHelper.token.companyTimeZone;
      this.viewAll.viewAllData(section, this.sortArgs, this.fDate, this.tDate);
    }, 500);


  }
}