import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-no-access',
  templateUrl: './no-access.component.html' 
})
export class NoAccessComponent implements OnInit {
  private sub;
  private page:string = "";
  public hasPageAccess:boolean = false;

  constructor(private route: ActivatedRoute, private router: Router) { 

  }

  ngOnInit() {
     this.sub = this.route
      .queryParams
      .subscribe(params => {
        // Defaults to 0 if no query param provided.
        this.page = params['page'] ;
        if(this.page != "" && this.page != undefined ){
          this.hasPageAccess = true;
        }
      });
  }
   ngOnDestroy() {
    this.sub.unsubscribe();
  }

}
