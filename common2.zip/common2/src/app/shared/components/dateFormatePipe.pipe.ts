import { Pipe, PipeTransform } from '@angular/core';

/*
 * Changes the case of the first letter of a given number of words in a string.
*/

@Pipe({ name: 'dateFormatter', pure: false })
export class DateFormatter implements PipeTransform {
    transform(input: string, length: number): string {
       // return input.length > 0 ? input.replace(/([a-z])([A-Z])/g, '$1 $2') : '';
        var data;
        input = input.substr(0, input.indexOf(' '));
        data = input.substr(0, 2) + '/' + input.substr(2, 2) + '/' + input.substr(4, input.length)
        return data;
    }
}