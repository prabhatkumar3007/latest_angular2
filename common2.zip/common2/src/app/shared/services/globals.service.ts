import { Injectable } from '@angular/core';
import { IGlobals } from 'sensorthink-commoncontrols/src/services/IGlobal.interface';
import config from '../../../config.json';

Injectable()
export class Globals implements IGlobals {
    baseApiUrl_Wes = config.baseUrl_Wes;
    baseApiUrl_Iot = config.baseUrl_Iot;
}