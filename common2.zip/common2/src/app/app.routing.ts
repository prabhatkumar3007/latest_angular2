import { Component } from '@angular/core';
import { AuthGuard } from './auth/auth-guard.service';
import { EndPointComponent } from './configure/endPoint/endPoint.component';
import { HubRouteComponent } from './configure/hubRoute/hubRoute.component';
import { IotRouteComponent } from './configure/iotRoute/iotRoute.component';
import { IotRouteMonitorComponent } from './monitor/iotRouteMonitor.component';
import { HubRouteMonitorComponent } from './monitor/hubRouteMonitor.component';
import { AlertSubscriptionComponent } from './alertSubscription/alertSubscription.component';
import { ChangePasswordComponent } from './changePassword/changePassword.component';
import { UserProfileComponent } from './userProfile/userProfile.component';
import { IotRouteMessagesComponent } from './manage/messages/iotRouteMessages.component';
import { HubRouteMessagesComponent } from './manage/messages/hubRouteMessages.component';
import { LoginComponent } from './login.component';
import { NotFoundComponent } from './shared/components/not-found.component';
import { NoAccessComponent } from './shared/components/no-access.component';
import { RouterModule } from '@angular/router';

export const routing = RouterModule.forRoot([
  { path: '', component: IotRouteMonitorComponent, canActivate: [AuthGuard], data: { permission: ['routeMonitor','Monitor'] } },
  { path: 'login', component: LoginComponent },
  { path: 'iotRoute-monitor', component: IotRouteMonitorComponent, canActivate: [AuthGuard], data: { permission: ['routeMonitor','Monitor'] } },
  { path: 'hubRoute-monitor', component: HubRouteMonitorComponent, canActivate: [AuthGuard], data: { permission: ['routeMonitor','Monitor'] } },
  { path: 'iotRoute-messages', component: IotRouteMessagesComponent, canActivate: [AuthGuard], data: { permission: ['message','Message'] } },
  { path: 'hubRoute-messages', component: HubRouteMessagesComponent, canActivate: [AuthGuard], data: { permission: ['message','Message'] } },
  { path: 'alertsubscription', component: AlertSubscriptionComponent, canActivate: [AuthGuard], data: { permission: ['alert','Alert'] } },
  { path: 'changepassword', component: ChangePasswordComponent },
  { path: 'userprofile', component: UserProfileComponent },
  { path: 'iot-route', component: IotRouteComponent, canActivate: [AuthGuard], data: { permission: ['iotRoute','Iot Route'] } },
  { path: 'hub-route', component: HubRouteComponent, canActivate: [AuthGuard], data: { permission: ['hubRoute','Hub Route'] } },
  { path: 'end-point', component: EndPointComponent, canActivate: [AuthGuard], data: { permission: ['endPoint','End Point'] } },
  { path: 'not-found', component: NotFoundComponent },
  { path: 'no-access', component: NoAccessComponent },
  { path: '**', redirectTo: 'not-found' }
], { useHash: true });