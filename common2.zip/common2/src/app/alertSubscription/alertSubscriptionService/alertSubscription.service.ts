import { Injectable } from '@angular/core';
import { HttpService } from 'sensorthink-commoncontrols/src/common.module';

@Injectable()
export class AlertSubscriptionService {
  constructor(private $http: HttpService) { }
  getAlertSubscriptions() {
    return this.$http.iotContext.url("/api/alerts/subcriptions").get().map(res=>res.json());
  }
  updateAlertSubscriptions(alerts) {
    let data = JSON.stringify(alerts);
    return this.$http.iotContext.url("/api/alerts/subcriptions").put(data).map((res)=>res.json());
  }
}