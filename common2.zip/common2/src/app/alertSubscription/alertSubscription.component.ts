import { Component, OnInit } from '@angular/core';
import { AlertSubscriptionService } from './alertSubscriptionService/alertSubscription.service';
import { NotyService } from 'sensorthink-commoncontrols/src/services/noty.service';

@Component({
    templateUrl: 'alertSubscription.html'
})

export class AlertSubscriptionComponent {
    public pagerConfig: any;
    public isLoading: boolean = false;
    public allAlertSubscriptionData: any = [];
    public unSavedData: any;
    public isAvailable: boolean = false;

    constructor(private service: AlertSubscriptionService, private noty: NotyService, ) { }
    /**
     * Method to call initialization
     */
    ngOnInit() {
        this.getAllAlertSubscriptions();
    }
    /**
     * Method to update Alert Subscription Data
     */
    onUpdateAlert() {
        this.isLoading = true;
        let updateArray = this.updateObjectArray(this.allAlertSubscriptionData);
        this.service.updateAlertSubscriptions(updateArray).subscribe((data) => {
            this.getAllAlertSubscriptions();
            this.noty.success("Alert Subscription is updated successfully.");
        });
    }
    /**
     * 
     * @param array : update the object as per PUT/API required 
     */
    updateObjectArray(array) {
        let a = [];
        array.forEach(e => {
            let b = { "alertSubscriptionId": e.alertSubscriptions[0].alertSubscriptionId, "alertConfigId": e.alertConfigId, "active": e.alertSubscriptions[0].active, "enableEmail": e.alertSubscriptions[0].enableEmail, "enableSms": e.alertSubscriptions[0].enableSms, "enableDashboard": e.alertSubscriptions[0].enableDashboard, "createdTime": e.alertSubscriptions[0].createdTime, "company": e.alertSubscriptions[0].company.companyId, "user": e.alertSubscriptions[0].user.userId, "createdBy": e.alertSubscriptions[0].createdBy.userId, "additionalEmail": null }
            a.push(b);
        });
        return a;
    }
    /**
     * method to cancel button click
     */
    onCancelAlert() {
        this.allAlertSubscriptionData = JSON.parse(JSON.stringify(this.unSavedData));
    }
    /**
     * Method to give get call to all records from API/DB
     */
    getAllAlertSubscriptions() {
        this.isLoading = true;
        this.service.getAlertSubscriptions().subscribe((res) => {
            if (res) {
                this.allAlertSubscriptionData = res;
                this.isAvailable = this.isDataAvailable();

            } else {
                this.allAlertSubscriptionData = [];
            }
            this.isLoading = false;
            this.unSavedData = JSON.parse(JSON.stringify(this.allAlertSubscriptionData));
        });
    }
    isDataAvailable() {
        for (var i = 0; i < this.allAlertSubscriptionData.length; i++) {
            if (this.allAlertSubscriptionData[i].alertSubscriptions.length > 0) {
                return true;
            }
        }
        return false;
    }
}