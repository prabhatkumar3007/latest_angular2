import { Validators } from '@angular/forms';
import { Injectable } from '@angular/core';
import { HttpService } from 'sensorthink-commoncontrols/src/common.module';

@Injectable()
export class ChangePasswordService {
  constructor(private $http: HttpService) { }
  
  updateChangePassword(passwd) {
    let data = JSON.stringify(passwd);
    return this.$http.iotContext.url("/api/users/password").put(data).map((res)=>res.json());
  }
  
}