import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ChangePasswordService } from './services/changePassword.service';
import { NotyService } from 'sensorthink-commoncontrols/src/services/noty.service';
import { FormBuilder, FormGroup, FormArray } from '@angular/forms';
import { BasicValidators } from '../shared/services/basicValidators';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ChangePassword } from "../changePassword/changePasswod.interface.data";
import { AuthService } from "../auth/auth.service";

declare let swal: any;
@Component({
    templateUrl: 'changePassword.component.html'
})

export class ChangePasswordComponent {
    public isLoading: boolean = false;
    user: ChangePassword;
    strongRegex: any;

    constructor(private service: ChangePasswordService, private userService: AuthService, private fb: FormBuilder, private noty: NotyService, private router: Router) { }
    ngOnInit() {
        this.init();
    }
    init() {
        this.user = {
            currentPassword: '',
            password: '',
            confirmPassword: ''
        }
    }
    save(model: ChangePassword, isValid: boolean) {
        let isSamePasswordEntered = false;
        isSamePasswordEntered = this.validateCurrentPassword(model.currentPassword, model.password);
        if (isValid && isSamePasswordEntered) {
            this.isLoading = true;
            let userId = this.userService.getUserDataFromToken();
            if (userId.sub) {
                let changePass = { userLogin: null, currentPassword: null, newPassword: null }
                changePass.currentPassword = this.convertBase64(model.currentPassword);
                changePass.newPassword = this.convertBase64(model.password);
                changePass.userLogin = userId.sub
                this.service.updateChangePassword(changePass).subscribe((data) => {
                    this.isLoading = false;
                    window.sessionStorage.removeItem("angular2ws_accessToken");
                    window.sessionStorage.removeItem("angular2ws_userInfo");
                    window.sessionStorage.removeItem("angular2ws_permissions");
                    this.confirm().then(res => {
                        this.router.navigate(['login']);
                    });
                }, (err) => {
                    this.noty.error("Incorrect current password.");
                    this.isLoading = false;
                });
            }
        }
    }
    validateCurrentPassword(current, newPassword) {
        if (current === newPassword) {
            this.noty.error("Current password and New password cannot be same.");
            return false;
        }
        return true;
    }
    convertBase64(string) {
        let str = string;
        str = btoa(string);
        return str;
    }
    confirm() {
        return swal({
            title: 'Password changed.',
            text: "Please re-login with new password!",
            type: 'success',
            showCancelButton: false,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Re-Login',
            allowOutsideClick: false
        })
    }
    /**
     * Method to reset the form
     */
    onCancelChangePassword() {
        this.init();
    }
}