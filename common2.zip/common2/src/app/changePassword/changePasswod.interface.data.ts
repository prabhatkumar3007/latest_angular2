export interface ChangePassword {
    currentPassword: string;
    password: string;
    confirmPassword: string;
}