import { Headers, Http, RequestOptionsArgs, Response } from "@angular/http";

import { Injectable } from '@angular/core';

@Injectable()
export class MockHttpService {
    private _url: string;
    private baseUrl: string;

    get wesContext(): any {
        this.baseUrl = "";
        return this.getContext();
    };

    get iotContext(): any {
        this.baseUrl = "";
        return this.getContext();
    };

    getContext() {
        let context = {
            url: this.url.bind(this),
            addParam: this.addParam.bind(this),
            get: this.get.bind(this),
            post: this.post.bind(this),
            put: this.put.bind(this),
            delete: this.delete.bind(this)
        }
        return context;
    }

    constructor(private _http: Http) {

    }

    private url(url: string) {
        this._url = this.baseUrl + url;
        return this;
    }

    private addParam(key: string, value: string | number): MockHttpService {
        if (value != undefined) {
            if (this._url.indexOf("?") >= 0)
                this._url += "&" + key + "=" + value;
            else
                this._url += "?" + key + "=" + value;
        }
        return this;
    }

    private get(contentType?: string) {
        if (this._url) {
            return this._http.get(this._url, {});
        }
    }

    private post(data, contentType?: string) {
        if (this._url) {
            return this._http.post(this._url, {});
        }
    }

    private put(data, contentType?: string) {
        if (this._url) {
            return this._http.put(this._url, {});
        }
    }

    private delete(contentType?: string) {
        if (this._url) {
            return this._http.delete(this._url, {});
        }
    }

    private setBaseUrl(url) {
        this.baseUrl = url;
    }

    private getBaseUrl() {
        return this.baseUrl;
    }
}