export class RouterStub {
    navigateByUrl(url: string) { return url; };
     navigate(url: string) { return url; }
}