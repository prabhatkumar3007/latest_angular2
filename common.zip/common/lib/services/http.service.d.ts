import { IGlobals } from './IGlobal.interface';
import { Http } from '@angular/http';
export declare class HttpService {
    private _http;
    private globalConfig;
    private _url;
    private baseUrl;
    accessToken: any;
    readonly wesContext: any;
    readonly iotContext: any;
    constructor(_http: Http, globalConfig: IGlobals);
    getContext(): {
        url: any;
        addParam: any;
        get: any;
        post: any;
        put: any;
        delete: any;
    };
    private createHeader(contentType?);
    private url(url);
    private addParam(key, value);
    private get(contentType?);
    private post(data, contentType?);
    private put(data, contentType?);
    private delete(contentType?);
    private refreshToken();
    private setBaseUrl(url);
    private getBaseUrl();
}
