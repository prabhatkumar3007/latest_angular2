export declare class NotyService {
    config: any;
    private defaultMessage;
    success(message: string): void;
    error(message: string | any): void;
    warning(message: string): void;
    confirm(): any;
    closeAll(): void;
}
