export declare class JwtHelper {
    private accessToken;
    readonly token: any;
}
