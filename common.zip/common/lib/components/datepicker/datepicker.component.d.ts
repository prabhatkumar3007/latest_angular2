import { JwtHelper } from './../../services/jwtHelper.service';
import { ElementRef, EventEmitter } from '@angular/core';
export declare class DatePickerComponent {
    private elementRef;
    private jwtHelper;
    isDay: boolean;
    isWeek: boolean;
    datepickerObj: any;
    config: any;
    inSelectionProcess: boolean;
    lastSelectedTS: any;
    roundTimeToMinute: number;
    dates: any;
    showDayWeekOptions: boolean;
    inputWidth: string;
    datepickerConfig: any;
    onDateChanged: EventEmitter<any>;
    constructor(elementRef: ElementRef, jwtHelper: JwtHelper);
    ngOnInit(): void;
    setDatePickerConfig(isWeek: boolean): void;
    initialiseDatePicker(explicit: boolean): void;
    setDate(isDay: boolean): void;
    toggleWeek(flag: boolean): void;
    dateChange(date: any): void;
}
