import { SimpleChange } from '@angular/core/core';
import { ElementRef } from '@angular/core';
export declare class ShiftPopoverComponent {
    private elementRef;
    model: any;
    onShiftChange: any;
    shift: any;
    shiftTitle: string;
    constructor(elementRef: ElementRef);
    ngOnChanges(changes: SimpleChange): void;
    onDataChange(data: any): void;
}
