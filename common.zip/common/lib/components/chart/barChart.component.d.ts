export declare class BarChartComponent {
    options: any;
    chartData: any;
    chartDataProcess: any;
    height: number;
    isXAxisDateType: boolean;
    isWeek: boolean;
    decimalPlaces: number;
    xAxisDateFormat: string;
    ticks: number;
    private days;
    ngOnChanges(changes: any): void;
    ngOnInit(): void;
}
