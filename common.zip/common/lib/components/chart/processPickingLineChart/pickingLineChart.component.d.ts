export declare class PickingLineChartComponent {
    pickingLineData: any;
    chartHeight: number;
    isXAxisDateType: boolean;
    xAxisDateFormat: string;
    isWeek: boolean;
    decimalPlaces: number;
}
