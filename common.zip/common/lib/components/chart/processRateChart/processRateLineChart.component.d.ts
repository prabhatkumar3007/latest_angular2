export declare class ProcessRateLineChartComponent {
    processRateData: any;
    chartHeight: number;
    isXAxisDateType: boolean;
    isWeek: boolean;
    xAxisDateFormat: string;
    xTicks: number;
    decimalPlaces: number;
}
