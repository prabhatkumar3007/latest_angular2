export declare class ProcessRateInfoComponent {
    chartData: any;
    chartDataProcess: any;
    ngAfterViewInit(): void;
}
