export declare class ProcessSection {
    Key: string;
    Value: number;
    PercentageWidth: string;
    constructor(key: any, value: any);
}
export declare class ProcessData {
    Group: string;
    TotalProcess: number;
    ProcessTime: string;
    DataPoints: ProcessSection[];
    constructor(averageProcessTime: any);
    addProcessValues(objProcessSection: any): void;
    calculatePercentageWidths(): void;
}
