export declare class OrdersPickedComponent {
    chartData: any;
    chartDataProcess: any;
    options: any;
    ngAfterViewInit(): void;
}
