export declare class LineChartComponent {
    chartData: any;
    chartDataProcess: any;
    height: number;
    showLegend: boolean;
    isWeek: boolean;
    xTicks: number;
    tickValues: any;
    decimalPlaces: number;
    isXAxisDateType: boolean;
    xAxisDateFormat: string;
    private isInitialized;
    options: any;
    private days;
    ngOnChanges(changes: any): void;
    ngOnInit(): void;
}
