import { EventEmitter } from '@angular/core';
export declare class PageSizeComponent {
    pagerConfig: any;
    onPageSizeChanged: EventEmitter<any>;
    pageSizes: number[];
    currentSize: number;
    fromVal: any;
    toVal: any;
    ngOnChanges(): void;
    sizeChanged(size: number): void;
}
