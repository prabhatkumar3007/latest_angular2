import { EventEmitter } from '@angular/core';
export declare class PagerComponent {
    pagerConfig: any;
    pagerChanged: EventEmitter<any>;
    currentPage: number;
    maxValue: number;
    refreshPager: boolean;
    ngOnChanges(changes: any): void;
    pageChanged(event: any): void;
}
