export declare class PopoverHtmlComponent {
    dropDownTitle: String;
    dropDownList: any;
    titleValue: string;
    value: string;
    onChange: any;
    onDataChange(data: any): void;
}
