import { EventEmitter } from '@angular/core';
export declare class FormattingTab {
    columns: Array<any>;
    onApplyFormatting: EventEmitter<any>;
    applyFilter(): void;
    clearFilter(): void;
}
