export declare class AdvancedFilterStore {
    getFilter(key: any): any;
    addFilter(key: any, value: any): void;
    removeFilter(key: any): void;
}
