export declare class Status {
    selectedStates: any;
    isVisible: boolean;
}
export declare class FromTo {
    from: any | Date;
    to: any | Date;
    isVisible: boolean;
}
export declare class Type extends FromTo {
    pick: boolean;
    pack: boolean;
    ship: boolean;
}
export declare class Aging extends FromTo {
    fromSeconds: number;
    toSeconds: number;
}
export declare class PickMethod {
    Method: Array<string>;
    selectedMethod: string;
    isVisible: boolean;
}
export declare class DropdownType {
    options: any;
    selectedValue: any;
    isVisible: boolean;
}
export declare class ActionSubSections {
    isChangeState: boolean;
    isExportTo: boolean;
    isTransaction: boolean;
}
export declare class FilterParams {
    state: Status;
    dateRange: FromTo;
    aging: Aging;
    type: Type;
    priority: FromTo;
    pickMethod: PickMethod;
    weightRange: FromTo;
    columns: Array<string>;
    site: DropdownType;
    baseMetric: DropdownType;
    otherMetric: DropdownType;
    actionButtons: Array<any>;
    actionSubSection: ActionSubSections;
    constructor();
}
