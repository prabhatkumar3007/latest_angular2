import './polyfills.ts';

import { platformBrowserDynamic, } from '@angular/platform-browser-dynamic';
import { enableProdMode } from '@angular/core';
import { SensorThinkControlsModule } from './controls.module';
import { CommonUtilsModule } from './common.module';

platformBrowserDynamic().bootstrapModule(SensorThinkControlsModule);
