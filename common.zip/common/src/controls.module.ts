import { AdvancedFilterComponent } from './components/advancedFilter/advancedFilter.component';
import { AdvancedFilterStore } from './components/advancedFilter/advancedFilterStore.service';
import { FormattingTab } from './components/advancedFilter/formatting.advancedFilter.component';
import { AppliedFilterDataComponent } from './components/advancedFilter/selectedAppliedFilter.component';
import { DataGrid, GridColumn } from './components/datatable/datagrid.component';
import { DataGridService } from './components/datatable/datagrid.service';
import { PagerComponent } from './components/datatable/pager.component';
import { PageSizeComponent } from './components/datatable/pageSize.component';
import { DatePickerComponent } from './components/datepicker/datepicker.component';
import { PopoverHtmlComponent } from './components/popover/popover.component';
import { ShiftPopoverComponent } from './components/shiftPopover/shiftPopover.component';
import { SliderComponent } from './components/slider/slider.component';
import { DatePipe } from './pipes/dateFormater.pipe';
import { DateFormaterPipe } from './pipes/dateFormaterPipe.pipe';
import { OrderByPipe } from './pipes/orderBy.pipe';
import { JwtHelper } from './services/jwtHelper.service';
import { NotyService } from './services/noty.service';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { PaginationModule } from 'ng2-bootstrap/pagination';
import { PopoverModule } from 'ng2-bootstrap/popover';

export { IGlobals } from './services/IGlobal.interface';
export { DatePickerComponent } from './components/datepicker/datepicker.component'
export { SliderComponent } from './components/slider/slider.component'
export { ShiftPopoverComponent } from './components/shiftPopover/shiftPopover.component'
export { DataGrid, GridColumn } from './components/datatable/datagrid.component';
export { DataGridService } from './components/datatable/datagrid.service';
export { PagerComponent } from './components/datatable/pager.component';
export { PageSizeComponent } from './components/datatable/pageSize.component';
export { FilterParams,ActionButtons } from './components/advancedFilter/advancedFilter.data';
import { TruncatePipe } from './pipes/truncate.pipe';

@NgModule({
    imports: [
        FormsModule,
        CommonModule,
        PopoverModule.forRoot(),
        PaginationModule.forRoot(),
    ],
    declarations: [
        DatePipe,
        DateFormaterPipe,
        OrderByPipe,
        DatePickerComponent,
        SliderComponent,
        ShiftPopoverComponent,
        DataGrid,
        GridColumn,
        PagerComponent,
        PageSizeComponent,
        PopoverHtmlComponent,
        AdvancedFilterComponent,
        FormattingTab,
        AppliedFilterDataComponent,
        TruncatePipe
    ],
    exports: [
        DatePipe,
        DateFormaterPipe,
        OrderByPipe,
        DatePickerComponent,
        SliderComponent,
        ShiftPopoverComponent,
        DataGrid,
        GridColumn,
        PagerComponent,
        PageSizeComponent,
        PopoverHtmlComponent,
        AdvancedFilterComponent,
        FormattingTab,
        AppliedFilterDataComponent
    ],
    providers: [
        DataGridService,
        AdvancedFilterStore,
        JwtHelper,
        NotyService
    ]
})
export class SensorThinkControlsModule { }
