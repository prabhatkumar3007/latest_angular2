import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/toPromise';
export class MockShiftService {
    getAllShift() {
        return Observable.of([{}]).toPromise();
    }
}