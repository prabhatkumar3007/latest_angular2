import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AlertService } from './alerts/alert.service';
import { AlertDetailComponent } from './alerts/alertDetail.component';
import { ViewAllComponent } from './alerts/viewAll.component';
import { SensorThinkControlsModule } from './controls.module';
import { AuthPermissionService } from './services/authPermission.service';
import { FileService } from './services/file.service';
import { ShareDataService } from './services/shareDataService';
import { UtilService } from './services/util.service';

export { HttpService } from './services/http.service';
export { FileService } from './services/file.service';
export { AlertService } from './alerts/alert.service';
export { ShareDataService } from './services/shareDataService';

@NgModule({
    imports: [
        FormsModule,
        CommonModule,
        SensorThinkControlsModule
    ],
    declarations: [
        AlertDetailComponent,
        ViewAllComponent,
    ],
    exports: [
        AlertDetailComponent,
        ViewAllComponent,
    ],
    providers: [
        FileService,
        AlertService,
        ShareDataService,
        AuthPermissionService,
        UtilService
    ]
})
export class CommonUtilsModule { }
