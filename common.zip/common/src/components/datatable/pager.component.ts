import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
    selector: 'pager',
    template: `<table class="pull-right">
                        <tr>
                        <td>
                            <pagination *ngIf="refreshPager" [totalItems]="pagerConfig?.totalItems" [(ngModel)]="currentPage" [maxSize]="5" class="pagination-sm"
                            (pageChanged)="pageChanged($event)" previousText="&lsaquo; Prev" nextText="Next &rsaquo;" 
                            firstText="&laquo;" lastText="&raquo;" [itemsPerPage]="pagerConfig?.itemsPerPage"></pagination>
                        </td>
                            <td style="padding-left:10px">
                            <small>Page</small>
                            <input type="number" class="form-control input-sm text_align_center" [(ngModel)]="currentPage"  [max]="maxValue" min="1"
                                style="width:50px;display:inline-block;padding: 5px;"/>
                        </td>
                        </tr>
                    </table>`
})
export class PagerComponent {
    @Input() pagerConfig: any;
    @Output() pagerChanged: EventEmitter<any> = new EventEmitter<any>();
    currentPage: number = 1;
    maxValue: number = 1;
    refreshPager = true;

    ngOnChanges(changes) {
        if (changes.pagerConfig.currentValue.itemsPerPage !== (changes.pagerConfig.previousValue && changes.pagerConfig.previousValue.itemsPerPage)) {
            this.refreshPager = false;
            this.refreshPager = true;
        }
        let pages = Math.ceil(this.pagerConfig.totalItems / this.pagerConfig.itemsPerPage);
        this.maxValue = pages;
    }

    public pageChanged(event: any): void {
        if (this.currentPage > 0 && (this.currentPage + "") !== "") {
            this.currentPage = event.page;
            this.pagerChanged.emit(event);
        }
    }
}
