import { SensorThinkControlsModule } from '../../controls.module';
import { DataGrid } from './datagrid.component';
import { DebugElement } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';


describe('DataGrid Component', () => {

    let comp: DataGrid;
    let fixture: ComponentFixture<DataGrid>;
    let de: DebugElement;
    let el: HTMLElement;

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [SensorThinkControlsModule], // declare the test component
        });

        fixture = TestBed.createComponent(DataGrid);
        comp = fixture.componentInstance; // DatePickerComponent test instance
        // query for the title <h1> by CSS element selector
        de = fixture.debugElement.query(By.css('ul'));
        el = de.nativeElement;
    });


    describe('Name of the group', () => {

    });

});
