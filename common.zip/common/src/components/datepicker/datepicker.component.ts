import { JwtHelper } from './../../services/jwtHelper.service';
import { Component, ElementRef, EventEmitter, Input, Output } from '@angular/core';

declare var $: any
declare var moment: any

@Component({
    selector: 'date-picker',
    templateUrl: 'datepicker.component.html'
})

export class DatePickerComponent {
    isDay: boolean = true;
    isWeek: boolean = false;
    datepickerObj: any;
    config: any;
    inSelectionProcess: boolean = false;
    lastSelectedTS: any;

    @Input() roundTimeToMinute: number;
    @Input() dates: any;
    @Input() showDayWeekOptions: boolean;
    @Input() inputWidth: string;
    @Input() datepickerConfig: any;
    @Output() onDateChanged: EventEmitter<any> = new EventEmitter();

    constructor(private elementRef: ElementRef, private jwtHelper: JwtHelper) { }

    ngOnInit() {
        if (this.showDayWeekOptions === undefined)
            this.showDayWeekOptions = true;
        else
            this.showDayWeekOptions = false;
        if (this.dates) {
            this.isWeek = this.dates.isWeek;
            this.isDay = !this.dates.isWeek;
        }
        this.setDatePickerConfig(this.isWeek);
        this.initialiseDatePicker(false);
        if (this.dates) {
            if (this.dates.isWeek) {
                if (this.dates.dates)
                    this.datepickerObj.selectDate([this.dates.dates[0], this.dates.dates[1]]);
            }
            else {
                if (this.dates.dates && this.dates.dates.length > 0)
                    this.datepickerObj.selectDate([this.dates.dates[0]]);
            }
        }
    }

    setDatePickerConfig(isWeek: boolean) {
        this.config = {
            language: 'en',
            dateFormat: 'mm/dd/yyyy',
            position: "bottom right",
            autoClose: true
        }
        if (this.datepickerConfig)
            this.config = Object.assign(this.config, this.datepickerConfig);
        if (!isWeek) {
            this.config.onSelect = ((formattedDate, date, inst) => {
                this.dateChange(inst.selectedDates); // callback event
            });
        }
        else {
            this.config.range = true;
            this.config.multipleDatesSeparator = ' - ';
            // this.config.multipleDates = true;
            this.config.onSelect = ((formattedDate, date, inst) => {
                let send = true;
                if (this.inSelectionProcess === false) {
                    this.inSelectionProcess = true;
                    let firstDate = moment(date[0], "MM-DD-YYYY").day(0);
                    let lastDate = moment(date[0], "MM-DD-YYYY").day(6);
                    inst.clear();
                    inst.selectDate([firstDate._d, lastDate._d]);
                    if (typeof (event) == 'object') {
                        if (event.timeStamp - this.lastSelectedTS < 300) {
                            send = false;
                        }
                        this.lastSelectedTS = event.timeStamp;
                    }
                    if (send)
                        this.dateChange(inst.selectedDates); // callback event
                    this.inSelectionProcess = false;
                }
            });
        }
    }

    initialiseDatePicker(explicit: boolean) {
        if (this.datepickerObj)
            this.datepickerObj.destroy();
        $(this.elementRef.nativeElement).find(".date-text").datepicker(this.config)
        this.datepickerObj = $(this.elementRef.nativeElement).find(".date-text").data('datepicker');

        //adding event to open calendar when clicking on the icon
        $(this.elementRef.nativeElement).find(".fa-calendar").off("click").on("click", e => {
            e.stopPropagation();
            this.datepickerObj.show();
        });
        if (this.dates === undefined || explicit || this.dates.dates.length === 0)
            this.setDate(this.isDay);
    }

    setDate(isDay: boolean) {
        if (isDay) {
            this.datepickerObj.date = (this.roundTimeToMinute === undefined ? new Date() : moment(new Date()).round(this.roundTimeToMinute, "minutes")._d);
            this.datepickerObj.selectDate(this.datepickerObj.date);
        }
        else {
            let firstDate = moment(new Date(), "MM-DD-YYYY").day(0);
            let lastDate = moment(new Date, "MM-DD-YYYY").day(6);
            this.datepickerObj.selectDate([firstDate._d, lastDate._d]);
        }
    }

    toggleWeek(flag: boolean) {
        if (flag) {
            this.isDay = false;
            this.isWeek = true;
        }
        else {
            this.isDay = true;
            this.isWeek = false;
        }
        this.setDatePickerConfig(this.isWeek);
        this.initialiseDatePicker(true);
    }

    dateChange(date) {
        let fromDate;
        let toDate;
        if (date && date.length <= 1) {
            fromDate = moment(date[0]).format("YYYY-MM-DDT00:00:00") + this.jwtHelper.token.companyTimeZone;
            toDate = moment(date[0]).format("YYYY-MM-DDT23:59:59") + this.jwtHelper.token.companyTimeZone;
        }
        else {
            fromDate = moment(date[0]).format("YYYY-MM-DDT00:00:00") + this.jwtHelper.token.companyTimeZone;
            toDate = moment(date[1]).format("YYYY-MM-DDT23:59:59") + this.jwtHelper.token.companyTimeZone;
        }
        this.onDateChanged.emit({ dates: date, isWeek: this.isWeek, formattedDates: [fromDate, toDate] });
    }
}   