import { Component, Input } from '@angular/core';

@Component({
  selector: 'picking-info',
  templateUrl: 'pickingLineChartInfo.component.html'
})
export class PickingLineChartInfoComponent {
  chartData: any = [];
  @Input() chartDataProcess: any;
  ngAfterViewInit() {
    this.chartData.push(this.chartDataProcess);

  }
}