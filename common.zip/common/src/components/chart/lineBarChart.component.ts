import { Component, Input } from '@angular/core';
declare let d3: any;
declare let moment: any;

@Component({
  selector: 'line-bar-chart',
  template: `<app-nvd3 [options]="options" [data]="chartData"></app-nvd3>`
})
export class LineBarChartComponent {
  chartData: any;
  @Input() options: any;
  @Input() chartDataProcess: any;
  @Input() height: number;
  @Input() isXAxisDateType: boolean;
  @Input() isWeek: boolean;
  @Input() decimalPlaces: number;
  @Input() xAxisDateFormat: string;
  @Input("tick-values") tickValues: any;

  private days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]

  ngOnInit() { }

  ngOnChanges(changes) {
    if (changes.chartDataProcess && changes.chartDataProcess.currentValue) {
      this.chartData = this.chartDataProcess;
    }
    if (changes.tickValues && changes.tickValues.currentValue && this.options) {
      this.options.chart.xAxis.tickValues = this.tickValues;
    }
    if (changes.tickValues && changes.tickValues.currentValue === undefined && this.options) {
      this.options.chart.xAxis.tickValues = undefined;
    }
  }
  ngAfterViewInit() {
    this.chartData = this.chartDataProcess;
  }
}
