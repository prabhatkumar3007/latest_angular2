import { Injectable } from '@angular/core';
declare var moment: any;

Injectable()
export class ChartService {

    getTicksForChart(data, intervalInMinutes: number = 15) {
        let minTime, maxTime, loopTime;
        let tmpArray = [];
        data.forEach(obj => {
            if (obj.values)
                obj.values.forEach(element => {
                    if (minTime === undefined)
                        minTime = element.x;
                    else if (element.x < minTime)
                        minTime = element.x;

                    if (maxTime === undefined)
                        maxTime = element.x;
                    else if (maxTime < element.x)
                        maxTime = element.x;
                });
        });
        do {
            minTime = moment(minTime)
            tmpArray.push(minTime.valueOf());
            minTime = minTime.add({ minutes: intervalInMinutes });
        } while (minTime < maxTime)
        return tmpArray;
    }

    //TODO: merge this functions
    getTicksForChartForAnalysis(data, intervalInMinutes: number = 15) {
        let minTime, maxTime, loopTime;
        let tmpArray = [];
        data.forEach(obj => {
            if (obj.values)
                obj.values.forEach(element => {
                    if (minTime === undefined)
                        minTime = element.x;
                    else if (element.x < minTime)
                        minTime = element.x;

                    if (maxTime === undefined)
                        maxTime = element.x;
                    else if (maxTime < element.x)
                        maxTime = element.x;
                });
        });
        var hours = Math.round(Math.abs(minTime - maxTime) / 36e5);
        if (hours > 1)
            intervalInMinutes = 15;
        do {
            minTime = moment(minTime)
            tmpArray.push(minTime.valueOf());
            minTime = minTime.add({ minutes: intervalInMinutes });
        } while (minTime <= maxTime)
        return tmpArray;
    }
}