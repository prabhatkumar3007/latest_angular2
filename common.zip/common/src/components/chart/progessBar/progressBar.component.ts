import { ProcessData } from './services/progressBar.data';
import { Component, EventEmitter, Input, Output } from '@angular/core';


@Component({
    selector: 'process-bar',
    templateUrl: 'progressBar.component.html'
})

export class ProgressBarComponent {
    @Input() processData: ProcessData;
    @Output() sectionCallback: EventEmitter<any> = new EventEmitter<any>();

    private hasCallback: boolean = false;

    ngOnInit() {
        this.hasCallback = this.sectionCallback.observers.length > 0;
    }

    applyBgColor(key) {
        let colors = { Complete: 'color_bg_green', "In Progress": 'color_bg_blue', Pending: 'color_bg_yellow', Exception: 'color_bg_light_red' };

        return colors[key];
    }

    sectionClickCallback(data) {
            if (this.sectionCallback)
                this.sectionCallback.emit(data);
    }
}