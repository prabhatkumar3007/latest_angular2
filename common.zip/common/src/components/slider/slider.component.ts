import { AfterViewInit, Component, ElementRef, EventEmitter, Input, Output, ViewEncapsulation } from '@angular/core';
declare var $: any

@Component({
    selector: 'slider',
    template: `<input type="text"/>`,
    styleUrls: ['slider.component.css'],
    encapsulation: ViewEncapsulation.None
})

export class SliderComponent implements AfterViewInit {
    @Input('slider-min') min: number;
    @Input('slider-max') max: number;
    @Input('slider-step') step: number;
    @Input('init-value') initValue: Array<number> | number;
    @Input() value: Array<number> | number;

    @Output() onSlide: EventEmitter<any> = new EventEmitter();
    private sliderElem: any;

    constructor(private el: ElementRef) { }

    ngAfterViewInit() {
        this.sliderElem = $(this.el.nativeElement).find("input[type=text]").slider({
            min: this.min,
            max: this.max,
            step: this.step || 1,
            value: this.initValue
        }).on("change", () => {
            this.onChange(this.sliderElem.getValue())
        }).data('slider');
    }

    onChange(value) {
        this.onSlide.emit(value);
    }

    ngOnChanges(changes) {
        if (changes.value && changes.value.currentValue) {
            if (this.sliderElem)
                this.sliderElem.setValue(changes.value.currentValue);
        }
    }

}
