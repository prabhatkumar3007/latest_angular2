import { SimpleChange } from '@angular/core/core';
import { Component, ElementRef, EventEmitter, Input, Output } from '@angular/core';
declare var $: any
declare var moment: any

@Component({
    selector: 'shift-popover',
    template: `<popover-html [dropDownTitle]="shiftTitle" [dropDownList]="shift" titleValue="name" (onChange)="onDataChange($event)"></popover-html>`
})

export class ShiftPopoverComponent {
    @Input() model: any;
    @Output() onShiftChange: any = new EventEmitter();
    @Input() shift: any;
    public shiftTitle: string;

    constructor(private elementRef: ElementRef) { }


    ngOnChanges(changes: SimpleChange) {
        if (changes["shift"] && changes["shift"].currentValue)
            if (this.model)
                this.shiftTitle = this.model;
            else
                this.shiftTitle = this.shift[0].name;
    }

    onDataChange(data) {
        this.shiftTitle = data.name;
        this.onShiftChange.emit(data);
    }
}   