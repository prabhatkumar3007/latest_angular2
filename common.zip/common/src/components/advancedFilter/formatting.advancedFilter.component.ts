import { Component, EventEmitter, Input, Output } from '@angular/core';
declare var moment: any
@Component({
    selector: 'formatting-tab',
    templateUrl: 'formatting.advancedFilter.template.html'
})

export class FormattingTab {
    public showHideColumnsExpanded:boolean;
    public freezeColumnsExpanded:boolean;
    @Input() columns: Array<any>;
    @Output() onApplyFormatting: EventEmitter<any> = new EventEmitter<any>();

    applyFilter() {
        this.onApplyFormatting.emit(this.columns);
    }

    clearFilter() {
        this.columns.forEach(col => {
            col.freezeColumn = false;
            col.visible = true;
        });
        this.onApplyFormatting.emit(this.columns);
    }
}