import { AdvancedFilterStore } from './advancedFilterStore.service';
import { AdvancedFilterComponent } from './advancedFilter.component';
import { AppliedFilterDataComponent } from './selectedAppliedFilter.component';
import { FormattingTab } from './formatting.advancedFilter.component';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';

@NgModule({
    //     imports: [
    //         FormsModule,
    //         CommonModule
    //     ],
    //     declarations: [
    //         AdvancedFilterComponent,
    //         FormattingTab,
    //         AppliedFilterDataComponent,
    //     ],
    //     exports: [
    //         FormattingTab,
    //         AdvancedFilterComponent,
    //         AppliedFilterDataComponent
    //     ],
    //     providers: [
    //         AdvancedFilterStore
    //     ]
})
export class AdvancedFilterModule { }
