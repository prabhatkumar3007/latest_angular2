import { Component, EventEmitter, Input, Output, ViewChild } from '@angular/core';
import { AuthPermissionService } from './../../services/authPermission.service';
import { JwtHelper } from './../../services/jwtHelper.service';
import { DataGridService } from './../datatable/datagrid.service';
import { FilterParams } from './advancedFilter.data';
import { AdvancedFilterStore } from './advancedFilterStore.service';
import { DatePickerComponent } from "../datepicker/datepicker.component";

declare var moment: any
declare var $: any

@Component({
    selector: 'advanced-filter',
    templateUrl: 'advancedFilter.template.html'
})

export class AdvancedFilterComponent {
    @Input() config: FilterParams;
    @Input("table-id") tableId: string;
    @Input() showFilters: boolean = true;
    @Input() showActions: boolean = true;
    @Input() showFormatting: boolean = true;
    @Input() showSaveFilters: boolean = true;
    @Input() showTimePicker: boolean = false;
    @Input() filterHeight: string;
    @Input() addTimeZone: boolean = true;
    @Input() dateFormat: string = "YYYY-MM-DDT00:00:00";
    @Input() moduleName: string;

    @Output() onApply: EventEmitter<FilterParams> = new EventEmitter<FilterParams>();
    @Output() onContainerType: EventEmitter<FilterParams> = new EventEmitter<FilterParams>();
    @Output() onShift: EventEmitter<FilterParams> = new EventEmitter<FilterParams>();
    @Output() onRemoveFilter: EventEmitter<FilterParams> = new EventEmitter<FilterParams>();
    @Output() onApplyFormatting: EventEmitter<any> = new EventEmitter<any>();
    @Output() onApplySaveFilter: EventEmitter<FilterParams> = new EventEmitter<FilterParams>();
    @Output() onLoadFilter: EventEmitter<FilterParams> = new EventEmitter<FilterParams>();

    public isStateFilter: boolean = true;
    public isContainerTypeFilter: boolean = true;
    public priorityExpanded: boolean;
    public statusExpanded: boolean;
    public statusExport: boolean;
    public columns: any;
    public dateFrom = { dates: [] };
    public dateTo = { dates: [] };
    public dates = { dates: [] };
    public toDateFormat: string = "YYYY-MM-DDT23:59:59"
    public isCorrectDate:boolean = false;
    public datePickerConfig: any = {
        maxDate: moment(new Date()).endOf('day')._d,
        position: "bottom left",
    }
    @ViewChild('fromDate') fromDatePicker: DatePickerComponent;
    @ViewChild('toDate') toDatePicker: DatePickerComponent;

    constructor(private dataGridService: DataGridService, private filterStore: AdvancedFilterStore, private jwtHelper: JwtHelper, private _authPermissionService: AuthPermissionService) { }

    ngOnInit() {
        if (this.showTimePicker) {
            this.datePickerConfig.timepicker = true;
            this.datePickerConfig.minutesStep = 15;
            this.datePickerConfig.timeFormat = "hh:ii";
        }
        if (this.moduleName != undefined && this.moduleName != "") {
            if (this._authPermissionService.isSuperAdmin()) {
                this.showActions = true;
            } else {
                let permissions = this._authPermissionService.getPermissionByModule(this.moduleName);
                if (permissions.length <= 0) {
                    this.showActions = false;
                } else {
                    this.showActions = !this._authPermissionService.canView(permissions);
                }

            }
        }
    }
    ngOnChanges() {
        if (this.config.dateRange.from && this.config.dateRange.to) {
            this.dates.dates = [moment(new Date(this.config.dateRange.from)).startOf('day')._d, moment(new Date(this.config.dateRange.to)).endOf('day')._d];
        }
    }

    ngAfterViewInit() {
        if (this.config) {
            this.config.aging.fromSeconds = this.convertToSeconds(this.config.aging.from);
            this.config.aging.toSeconds = this.convertToSeconds(this.config.aging.to);
        }

        if (this.config.state.selectedStates.length === 0) {
            this.isStateFilter = false;
        }
        if (this.config.containerTypes.selectedStates.length === 0) {
            this.isContainerTypeFilter = false;
        }

        if (this.tableId)
            this.columns = this.dataGridService.getColumns(this.tableId);

        if (this.filterHeight)
            $("#wrapper").css("min-height", this.filterHeight);
    }

    setStateValues(item, e) {
        item.checked = e;
    }
    setContainerValues(item, e) {
        item.checked = e;
    }

    setAgingValues(values: Array<number>) {
        this.config.aging.from = values[0];
        this.config.aging.to = values[1];
        this.config.aging.fromSeconds = this.convertToSeconds(values[0]);
        this.config.aging.toSeconds = this.convertToSeconds(values[1]);
    }

    setInputAgingValues(fromAge, toAge) {
        let result = this.calculateRangevalues(fromAge, toAge, 1, 30);
        this.config.aging.from = result.from;
        this.config.aging.to = result.to;
    }

    setTypeValues(values: Array<number | Date>) {
        this.config.type.from = Number(values[0]);
        this.config.type.to = Number(values[1]);
    }

    setPriorityValues(values: Array<number>) {
        let result = this.calculateRangevalues(values[0], values[1], 1, 100);
        this.config.priority.from = result.from;
        this.config.priority.to = result.to;
    }
    setInputPriorityValues(v1, v2) {
        let values = [];
        values.push(v1, Number(v2));
        this.setPriorityValues(values);
    }

    setWeightRangeValues(values: Array<number | Date>) {
        this.config.weightRange.from = values[0];
        this.config.weightRange.to = values[1];
    }
    setTimeRangeValues(values: Array<number | Date>) {
        this.config.timeRange.from = values[0];
        this.config.timeRange.to = values[1];
    }

    applyFilter() {
        this.onApply.emit(this.config);
    }
    onSaveFilter() {
        this.onApplySaveFilter.emit(this.config)
    }
    onSaveLoadFilterChange(value) {
        this.onLoadFilter.emit(this.config);
    }

    onTaskTypeChange(value) {
        this.config.taskType.selectedValue = value;
    }
    onShiftChange(value) {
        this.config.shift.selectedValue = value;
    }
    onUserChange(value) {
        this.config.user.selectedValue = value;
    }
    onExtBatchChange(value) {
        this.config.extBatchContainer.selectedValue = value;
    }
    onContainerIdChange(value) {
        this.config.containerIds.selectedValue = value;
    }
    onVirtualContainetIdChange(value) {
        this.config.virtualContainetIds.selectedValue = value;
    }
    onRouteNameChange(value) {
        this.config.routeName.selectedValue = value;
    }
    onMessageTypeChange(value) {
        this.config.messageType.selectedValue = value;
    }
    removeFilters() {
        this.config.state.selectedStates.forEach(element => {
            element.checked = false;
        });
        this.onRemoveFilter.emit();
    }

    setDateFrom(date) {
        this.config.dateRange.from = moment(date.dates[0]).format(this.dateFormat);
        if (this.addTimeZone)
            this.config.dateRange.from += this.jwtHelper.token.companyTimeZone;
        this.isCorrectDate = this.checkDateRange(this.config.dateRange.from, this.config.dateRange.to);
    }

    setDateTo(date) {
        this.config.dateRange.to = moment(date.dates[0]).format(this.toDateFormat);
        if (this.addTimeZone)
            this.config.dateRange.to += this.jwtHelper.token.companyTimeZone;
        this.isCorrectDate = this.checkDateRange(this.config.dateRange.from, this.config.dateRange.to)
    }

    convertToSeconds(days: number) {
        return (24 * 60 * 60) * days;
    }

    applyFormatting(columns) {
        let cols = [];
        columns.forEach(col => {
            let obj: any = {};
            obj.id = col.id;
            obj.freezeColumn = col.freezeColumn;
            obj.visible = col.visible;
            cols.push(obj);
        });
        this.filterStore.addFilter(this.tableId, cols);
        this.onApplyFormatting.emit(columns);
    }
    calculateRangevalues(fromValue, toValue, minValue, maxValue) {
        let result = { from: fromValue, to: toValue };
        if (Number(fromValue) >= minValue && Number(fromValue) <= maxValue && Number(toValue) >= minValue && Number(toValue) <= maxValue) {
            if (Number(toValue) < Number(fromValue)) {
                result.from = Number(fromValue);
                result.to = Number(fromValue);
            } else {
                result.from = Number(fromValue);
                result.to = Number(toValue);
            }
        } else {
            result.from = minValue;
            result.to = maxValue;
        }
        return result;
    }
    checkDateRange(fromDate, toDate){
        let fDate = new Date(fromDate);
        let tDate = new Date(toDate)
        if(fDate <= tDate)
            return false;
        else 
            return true;
    }
}
