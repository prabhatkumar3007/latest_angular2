import { Injectable } from '@angular/core';

@Injectable()
export class AdvancedFilterStore {

    getFilter(key) {
        if (window.sessionStorage["fltr_" + key])
            return JSON.parse(window.sessionStorage["fltr_" + key]);
        return;
    }

    addFilter(key, value) {
        window.sessionStorage["fltr_" + key] = JSON.stringify(value);
    }

    removeFilter(key) {
        window.sessionStorage.removeItem("fltr_" + key);
    }
}
