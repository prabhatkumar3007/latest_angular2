import { FilterParams } from './advancedFilter.data';
import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
    selector: 'applied-filter-data',
    templateUrl: 'selectedAppliedFilter.component.html'
})

export class AppliedFilterDataComponent {

    @Input() filterParamsData: FilterParams;
    @Output() onRemoveFilter: EventEmitter<FilterParams> = new EventEmitter<FilterParams>();
    public selectedStates: string = "";
    public selectedContainerTypes: string = "";
    ngOnChanges(changes) {
        if (changes.filterParamsData.currentValue) {
            let stateValues = "";
            this.filterParamsData.state.selectedStates.forEach(element => {
                if (element.checked) {
                    stateValues += element.text + ","
                }
            });
            this.selectedStates = stateValues.slice(0, -1); //remove last comma;

            let containerTypesValues = "";
            this.filterParamsData.containerTypes.selectedStates.forEach(element => {
                if (element.checked) {
                    containerTypesValues += element.text + ","
                }
            });
            this.selectedContainerTypes = containerTypesValues.slice(0, -1); //remove last comma;
        }
    }

    resetFilter(value) {
        if ((value === 'priority') || (value === 'dateRange') || (value === 'timeRange')) {
            this.resetvalues(value);
        } else if (value === 'state' || value === 'containerTypes') {
            if (value === 'state')
                this.selectedStates = "";
            else
                this.selectedContainerTypes = "";
            this.filterParamsData[value].selectedStates.forEach(element => {
                element.checked = false;
            });
        } else if (value === 'aging') {
            this.filterParamsData[value].from = null;
            this.filterParamsData[value].to = null;
            this.filterParamsData[value].fromSeconds = null;
            this.filterParamsData[value].toSeconds = null;
        } else {
            this.filterParamsData[value].selectedValue = '';
        }
        this.onRemoveFilter.next(this.filterParamsData);
    }
    resetvalues(val) {
        this.filterParamsData[val].from = null;
        this.filterParamsData[val].to = null;
    }
}