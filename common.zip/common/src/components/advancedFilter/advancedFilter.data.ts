export class Status {
    selectedStates: any = [];
    isVisible: boolean = true;
}

export class FromTo {
    from: any | Date;
    to: any | Date;
    isVisible: boolean = true;
}

export class TimeFromTo {
    from: any | TimeRanges;
    to: any | TimeRanges;
    isVisible: boolean = true;
}

export class Type extends FromTo {
    pick: boolean;
    pack: boolean;
    ship: boolean;
}

export class Aging extends FromTo {
    fromSeconds: number;
    toSeconds: number;
}


export class PickMethod {
    Method: Array<string>;
    selectedMethod: string;
    isVisible: boolean = true;
}

export class DropdownType {
    options: any = [];
    selectedValue: any;
    isVisible: boolean = true;
}

export class ActionSubSections {
    isChangeState: boolean = true;
    isExportTo: boolean = true;
    isTransaction: boolean = true;
}
export class InputType {
    selectedValue: any;
    isVisible: boolean = true;
}
export class FilterParams {
    filterId:any;
    state: Status = new Status();
    containerTypes: Status = new Status();
    dateRange: FromTo = new FromTo();
    aging: Aging = new Aging();
    type: Type = new Type();
    priority: FromTo = new FromTo();
    pickMethod: PickMethod = new PickMethod();
    weightRange: FromTo = new FromTo();
    timeRange: TimeFromTo = new TimeFromTo();
    columns: Array<string>;
    site: DropdownType = new DropdownType();
    shift: DropdownType = new DropdownType();
    containerIds: DropdownType = new DropdownType();
    virtualContainetIds: DropdownType = new DropdownType();
    saveLoadFilter: DropdownType = new DropdownType();
    user: InputType = new InputType();
    saveFilterName: InputType = new InputType();
    extBatchContainer: DropdownType = new DropdownType();
    taskType: DropdownType = new DropdownType();
    routeName: DropdownType = new DropdownType();
    messageType: DropdownType = new DropdownType();
    baseMetric: DropdownType = new DropdownType();
    otherMetric: DropdownType = new DropdownType();
    actionButtons: Array<ActionButtons> = new Array<ActionButtons>();
    actionSubSection: ActionSubSections = new ActionSubSections();

    constructor() {
        this.filterId = null;
        this.aging.from = 1;
        this.aging.to = 30;
        this.type.pick = true;
        this.type.pack = false;
        this.type.ship = false;
        this.type.from = 1;
        this.type.to = 1;
        this.priority.from = 1;
        this.priority.to = 100;
        this.type.isVisible = false;
        this.weightRange.isVisible = false;
        this.timeRange.isVisible = false;
        this.site.isVisible = false;
        this.shift.isVisible = true;
        this.containerIds.isVisible = false;
        this.virtualContainetIds.isVisible = false;
        this.taskType.isVisible = false;
        this.routeName.isVisible = false;
        this.messageType.isVisible = false;
        this.user.isVisible = false;
        this.extBatchContainer.isVisible = false;
        this.baseMetric.isVisible = false;
        this.otherMetric.isVisible = false;
        this.actionSubSection.isChangeState = true;
        this.actionSubSection.isExportTo = true;
        this.actionSubSection.isTransaction = true;
        this.saveFilterName.selectedValue = '';
    }
}

export class ActionButtons {
    private buttonText: string;
    private showPermission: boolean = true;
    private callback: any;
    private isDisabled:boolean = false;
    private errorMessage:string;
    constructor(buttonText: string, showPermission: boolean, callback: any,isDisabled?:boolean,errorMessage?:string) {
        this.buttonText = buttonText;
        this.showPermission = showPermission;
        this.callback = callback;
        this.isDisabled = isDisabled;
        this.errorMessage = errorMessage;
    }
}