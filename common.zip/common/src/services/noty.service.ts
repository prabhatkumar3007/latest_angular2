import { Injectable } from '@angular/core';
declare var $: any
declare var noty: any
declare let swal: any;

@Injectable()
export class NotyService {
    config: any = {
        theme: "metroui",
        layout: "topCenter",
        animation: {
            open: "animated flipInX", // Animate.css class names
            close: "animated flipOutX", // Animate.css class names
        },
        closeWith: ["click"],
        timeout: 10000,
        killer: true
    }

    private defaultMessage: string = "Error occured, Please contact Administrator.";

    success(message: string) {
        let settings = Object.assign({}, this.config);
        settings.type = 'success'
        settings.text = '<i class="glyphicon glyphicon-ok-sign" aria-hidden="true"></i>&nbsp;&nbsp;' + message;
        this.closeAll();
        var n = noty(settings)
    }

    error(message: string | any) {
        let errMessage = (' ' + this.defaultMessage).slice(1);
        if (typeof (message) === "object") {
            if (message.status === 401) {
                errMessage = "Your session has expired. Please re-login.";
            }
            else if (message.status === 404) {
                errMessage = this.defaultMessage;
            }
        }
        else
            errMessage = (message == '' ? this.defaultMessage : message);
        let settings = Object.assign({}, this.config);
        settings.type = 'error'
        settings.text = '<i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;&nbsp;' + errMessage;
        this.closeAll();
        var n = noty(settings)
    }

    warning(message: string) {
        let settings = Object.assign({}, this.config);
        settings.type = 'warning'
        settings.text = '<i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;&nbsp;' + message;
        this.closeAll();
        var n = noty(settings)
    }

    /**
     * Display confirm message. 
     * @param title :'Are you sure?'
     * @param text : "You won't be able to revert this!"
     * @param type :'warning'
     * @param showCancelButton :true or false
     * @param confirmButtonColor :'#3085d6'
     * @param cancelButtonColor :'#d33'
     * @param confirmButtonText :'Yes, delete it!'
     */
    confirm(title?: string, text?: string, type?: string, showCancelButton?: boolean, confirmButtonColor?: string, cancelButtonColor?: string, confirmButtonText?: string) {
        return swal({
            title: title ? title : 'Are you sure?',
            text: text ? text : "You won't be able to revert this!",
            type: type ? type : 'warning',
            showCancelButton: showCancelButton != undefined ? showCancelButton : true,
            confirmButtonColor: confirmButtonColor ? confirmButtonColor : '#3085d6',
            cancelButtonColor: cancelButtonColor ? cancelButtonColor : '#d33',
            confirmButtonText: confirmButtonText ? confirmButtonText : 'Yes, delete it!'
        })
    }

    closeAll() {
        $.noty.clearQueue(); // Clears the notification queue
        $.noty.closeAll(); // Close all notifications
    }
}