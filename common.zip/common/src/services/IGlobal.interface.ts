export interface IGlobals {
    baseApiUrl_Wes: string;
    baseApiUrl_Iot: string;
}