import { JwtHelper } from './jwtHelper.service';
import { Injectable } from '@angular/core';
declare let moment: any;
@Injectable()
export class UtilService {

    constructor(private jwtHelper: JwtHelper) { }

    setTimeZone(data: any, fields: Array<string>) {
        if (data)
            data.forEach(d => {
                fields.forEach(f => {
                    if (d[f]) {
                        d[f] = d[f].substring(0, d[f].length - 5);
                        d[f] += this.jwtHelper.token.companyTimeZone;
                    }
                });
            });
    }
    convertToCompanyTimeZone(date, format?) {
        let dt = date.substring(0, 19);
        let tz = this.jwtHelper.token.companyTimeZone;
        let d = moment(dt).utcOffset(tz)._d;
        if (format != undefined && format != "") {
            return moment(d).format(format);
        }
        return d;
    }
}