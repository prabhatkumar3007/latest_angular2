import { SessionStorage } from '../webStore.module';
import { Injectable } from '@angular/core';

@Injectable()
export class JwtHelper {
    // use this property for property binding
    @SessionStorage() private accessToken: any;

    get token(): any {
        let jwt = JSON.parse(window.atob(this.accessToken.token.split('.')[1]));
        return jwt;
    }
}