import { SessionStorage } from '../webStore.module';
import { IGlobals } from './IGlobal.interface';
import { Injectable } from '@angular/core';
import { Headers, Http } from '@angular/http';


@Injectable()
export class HttpService {
  private _url: string;
  private baseUrl: string;
  @SessionStorage() public accessToken: any;

  get wesContext(): any {
    this.baseUrl = this.globalConfig.baseApiUrl_Wes;
    return this.getContext();
  };

  get iotContext(): any {
    this.baseUrl = this.globalConfig.baseApiUrl_Iot;
    return this.getContext();
  };

  constructor(private _http: Http, private globalConfig: IGlobals) {
    this.baseUrl = globalConfig.baseApiUrl_Wes;
  }

  getContext() {
    let context = {
      url: this.url.bind(this),
      addParam: this.addParam.bind(this),
      get: this.get.bind(this),
      post: this.post.bind(this),
      put: this.put.bind(this),
      delete: this.delete.bind(this)
    }
    return context;
  }

  private createHeader(contentType?: string) {
    let headers = new Headers();
    headers.append('Content-Type', contentType ? contentType : 'application/json');
    if (this.accessToken)
      headers.append('X-Authorization', 'Bearer ' + this.accessToken.token);
    return headers;
  }

  private url(url: string) {
    this._url = this.baseUrl + url;
    return this;
  }

  private addParam(key: string, value: string | number): HttpService {
    if (value != undefined) {
      if (this._url.indexOf("?") >= 0)
        this._url += "&" + key + "=" + value;
      else
        this._url += "?" + key + "=" + value;
    }
    return this;
  }

  private get(contentType?: string) {
    let headers = this.createHeader(contentType);
    if (this._url) {
      return this._http.get(this._url, {
        headers: headers
      });
    }
  }

  private post(data, contentType?: string) {
    let headers = this.createHeader(contentType);
    if (this._url) {
      return this._http.post(this._url, data, {
        headers: headers
      });
    }
  }

  private put(data, contentType?: string) {
    let headers = this.createHeader(contentType);
    if (this._url) {
      return this._http.put(this._url, data, {
        headers: headers
      });
    }
  }

  private delete(contentType?: string) {
    let headers = this.createHeader(contentType);
    if (this._url) {
      return this._http.delete(this._url, {
        headers: headers
      });
    }
  }

  private refreshToken() {
    let headers = new Headers();
    headers.append('X-Authorization', 'Bearer ' + this.accessToken.refreshToken);
    return this._http.get(this._url, {
      headers: headers
    });
  }

  private setBaseUrl(url) {
    this.baseUrl = url;
  }

  private getBaseUrl() {
    return this.baseUrl;
  }
}