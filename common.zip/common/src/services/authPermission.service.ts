import { Injectable } from '@angular/core';

@Injectable()
export class AuthPermissionService {

  public permissions=[];

  private _userIOTPermissions;
  private _userWESPermissions;
  private _iotPermissionPrefix: string = 'platform';
  private _wesPermissionPrefix: string = 'wes';
  private _permissionManage: string = 'manage';// perform CRUD operation
  private _permissionView: string = 'view';
  private _permissionMonitor: string = 'monitor';

  /**
   * Get all IOT permissions array.
   */
  get userIOTPermissons(): any {
    if (this._userIOTPermissions && this._userIOTPermissions.length>0 ){
        return this._userIOTPermissions;
    } else
    {
      this.setUserPermissionInformation()
      return this._userIOTPermissions;
    }
      
  }

  /**
   * Get all WES permissions array
   */
  get userWESPermissons(): any {
    if (this._userWESPermissions && this._userWESPermissions.length > 0)
    {
      return this._userWESPermissions;
    } else {
      this.setUserPermissionInformation()
      return this._userWESPermissions;
    }
  }

  /**
   * Get user permissions array. 
   */
  get userPermissions(): any {
    return this.permissions;
  }

  /**
   * This function will get users permisssion from auth service
   * @param permissions :permission array from token
   */
  setLoggedInUserPermissions(permissions) {
    this.permissions = permissions;
  }

  /**
   * Function to separate permission information for both IOT and WES
   */
  setUserPermissionInformation(): void {
    this._userIOTPermissions = [];
    this._userWESPermissions = [];
    let appPermissions = this.userPermissions;
    for (let permission of appPermissions) {
      if (permission.indexOf(this._iotPermissionPrefix) > -1) {
        this._userIOTPermissions.push(permission)
      } else if (permission.indexOf(this._wesPermissionPrefix) > -1) {
        this._userWESPermissions.push(permission);
      }
    }
  }
  /**
   * Function to check if permissions array contais 'manage','view' and 'monitor' keyword.
   * @param permissions : Permission belong to module
   * @param userCan : Can user manage or view or monitor
   */
  hasPermission(permissions, userCan): boolean {
    for (let element of permissions)
      if (element.indexOf(userCan) > -1) {
        return true;
      }
    return false;
  }

  /**
   * Function to check if user has access to IOT website so he can navigate from WES to IOT website.
   */
  hasAccessIOTWebsite(): boolean {
    return this.hasPermission(this.userPermissions, this._iotPermissionPrefix);
  }
   /**
   * Function to check if user has access to WES website so he can navigate from IOT to WES website.
   */
  hasAccessWESWebsite(): boolean {
    return this.hasPermission(this.userPermissions, this._wesPermissionPrefix);
  }

  /**
   * Function to check if permissions array contais 'manage' keyword.
   * @param permissions : array of permissions
   */
  canManage(permissions): boolean {
    return this.hasPermission(permissions, this._permissionManage);
  }

  /**
   * Function to check if permissions array contais 'view' keyword.
   * @param permissions : array of permissions
   */
  canView(permissions): boolean {
    return this.hasPermission(permissions, this._permissionView);
  }

  /**
   * Function to check if permissions array contais 'monitor' keyword.
   * @param permissions : array of permissions
   */
  canMonitor(permissions): boolean {
    return this.hasPermission(permissions, this._permissionMonitor);
  }

  /**
   * It returns the user permission for IOT based on module i.e. hubRoute,iotRoute
   * @param moduleName : permission last section i.e. hubRoute,iotRoute,endpoint,all,sortPlan   
   */
  getIOTPermissionByModule(moduleName: string): any[] {
    if (moduleName == undefined || moduleName == "") { return []; }
    let appPermissions = this.userIOTPermissons;
    return this._filterPermissionByModule(appPermissions, moduleName.toLowerCase());
  }
  /**
  * It returns the user permission based on common module Name i.e. alert. It searches module name in all the permissions that user has.
  * @param moduleName : permission last section i.e. hubRoute,iotRoute,endpoint,all,sortPlan   
  */
  getPermissionByModule(moduleName: string): any[] {
    if (moduleName == undefined || moduleName == "") { return []; }
    let appPermissions = this.userPermissions;
    return this._filterPermissionByModule(appPermissions, moduleName.toLowerCase());
  }
  /**
   * It returns the permission for WES based on module name i.e. all,sortPlan
   * @param moduleName : permission name last section i.e. all,sortPlan etc...
   */
  getWESPermissionByModule(moduleName: string): any[] {
    if (moduleName == undefined || moduleName == "") { return []; }
    let appPermissions = this.userWESPermissons;
    return this._filterPermissionByModule(appPermissions, moduleName.toLowerCase());
  }

  private _filterPermissionByModule(appPermissions, moduleName) {
    let userHasAccess = [];
    if (appPermissions) {
      for (let permission of appPermissions) {
        let lowerCasePermission = permission.toLowerCase();
        if (lowerCasePermission.indexOf(moduleName) > -1) {
          userHasAccess.push(lowerCasePermission);
        }
      }
    }
    return userHasAccess;
  }
  /**
   * Function to check if user is super admin
   */
  isSuperAdmin(): boolean {
    return this.userPermissions.indexOf('super_admin') > -1;
  }

}