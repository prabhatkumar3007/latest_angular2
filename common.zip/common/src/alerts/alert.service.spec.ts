import { HttpService } from './../services/http.service';
import { MockHttpService } from './../test/mockHttp.service';
import { HighAlert, LowAlert, MediumAlert } from './alert.data';
import { AlertService } from './alert.service';
import { inject, TestBed } from '@angular/core/testing';
import { HttpModule, Response, ResponseOptions, XHRBackend } from '@angular/http';
import { MockBackend } from '@angular/http/testing';

describe('Service: AlertService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [HttpModule],
            providers: [AlertService, { provide: HttpService, useClass: MockHttpService },
                { provide: XHRBackend, useClass: MockBackend }]
        }).compileComponents();
    })

    it('can instantiate service when inject service',
        inject([AlertService], (service: AlertService) => {
            expect(service instanceof AlertService).toBe(true);
        }));

    it('can provide the mockBackend as XHRBackend',
        inject([XHRBackend], (backend: MockBackend) => {
            expect(backend).not.toBeNull('backend should be provided');
        }));

    describe('When getAlerts', () => {
        let backend: MockBackend;
        let service: AlertService;
        let response: Response;
        const mockResponse = [{
            "alertMessageRecipientId": 6, "readTime": null, "userId": 2, "read": false,
            "alertMessage": {
                "alertMessageId": 6, "subject": "Validation Failed",
                "message": "\nInvalid Number\nInvalid AlphaNumeric\n58244hjioio|TOTRQ|867053hfghfgh",
                "createdTime": "04/05/2017 18:01:56", "expiryTime": null, "severity": 1, "resolved": false
            }
        },
        {
            "alertMessageRecipientId": 7, "readTime": null, "userId": 2, "read": false,
            "alertMessage": {
                "alertMessageId": 7, "subject": "Validation Failed",
                "message": "\nInvalid Number\nInvalid AlphaNumeric\n58244hjioio|TOTRQ|867053hfghfgh", "createdTime": "04/05/2017 18:01:56", "expiryTime": null, "severity": 1, "resolved": false
            }
        }];
        beforeEach(inject([HttpService, XHRBackend], (httpService: HttpService, be: MockBackend) => {
            backend = be;
            service = new AlertService(httpService);
            let options = new ResponseOptions({ status: 200, body: { data: [] } });
            response = new Response(options);
        }));

        it(' should get alerts with High Notifications',
            inject([], () => {
                backend.connections.subscribe((connection) => {
                    connection.mockRespond(new Response(new ResponseOptions({ body: JSON.stringify(mockResponse) })));
                });
                service.getHighAlertNotifications("1,CreatedTime", "04072017 00:00:00", "04072017 23:59:59", false).subscribe((res) => {
                    expect(res.length).toBe(mockResponse.length);
                    expect(res[0] instanceof HighAlert).toBe(true);
                }, (err) => {
                    console.log(err);
                })
            }));

        it(' should get alerts with Medium Notifications',
            inject([], () => {
                backend.connections.subscribe((connection) => {
                    connection.mockRespond(new Response(new ResponseOptions({ body: JSON.stringify(mockResponse) })));
                });
                service.getMediumAlertNotifications("1,CreatedTime", "04072017 00:00:00", "04072017 23:59:59", false).subscribe((res) => {
                    expect(res.length).toBe(mockResponse.length);
                    expect(res[0] instanceof MediumAlert).toBe(true);
                }, (err) => {
                    console.log(err);
                })
            }));

        it(' should get alerts with Low Notifications',
            inject([], () => {
                backend.connections.subscribe((connection) => {
                    connection.mockRespond(new Response(new ResponseOptions({ body: JSON.stringify(mockResponse) })));
                });
                service.getLowAlertNotifications("1,CreatedTime", "04072017 00:00:00", "04072017 23:59:59", false).subscribe((res) => {
                    expect(res.length).toBe(mockResponse.length);
                    expect(res[0] instanceof LowAlert).toBe(true);
                }, (err) => {
                    console.log(err);
                })
            }));
    });

    describe('When markAsRead', () => {
        let backend: MockBackend;
        let service: AlertService;
        let response: Response;
        beforeEach(inject([HttpService, XHRBackend], (httpService: HttpService, be: MockBackend) => {
            backend = be;
            service = new AlertService(httpService);
            let options = new ResponseOptions({ status: 200, body: { text: "done" } });
            response = new Response(options);
        }));

        it(' mark the alert as read', inject([], () => {
            backend.connections.subscribe((connection) => {
                connection.mockRespond(response);
            });
            service.markAsRead(1).subscribe((res) => {
                expect(res.text).toBe("done");
            }, (err) => {
                console.log(err);
            })
        }));
    });
});
