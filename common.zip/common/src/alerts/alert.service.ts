import { SessionStorage } from '../storage';
import { HttpService } from './../services/http.service';
import { HighAlert, LowAlert, MediumAlert } from './alert.data';
import { Injectable } from '@angular/core';
import { URLSearchParams } from '@angular/http';

declare var moment: any

@Injectable()
export class AlertService {
    @SessionStorage() public accessToken: any;

    constructor(private $http: HttpService) { }

    getHighAlertNotifications(sortArgs?: string, fromDate?: any, toDate?: any, showOnlyRead?: boolean, pageNumber?: number, pageSize?: number, platForm?: string) {
        let sortArg = sortArgs.split(",");
        
        let http = this.setContext(platForm).url("/api/alerts").addParam("severity", 1).addParam("fromDate", fromDate).addParam("toDate", toDate);
        if (sortArg.length >= 2)
            http.addParam("sortBy", sortArg[0]).addParam("sortDirection", sortArg[1]) //API data is not avaibale uncomment after it available
        if (showOnlyRead === undefined)
            http.addParam("read", 0)

        http._url = http._url.replace(/\+/g, "%2B");
        return http.get().map(res => {
            let alerts = [];
            if (res.text() !== "")
                res.json().forEach(itm => {
                    let dt = this.parseDate(itm.alertMessage.createdTime);
                    alerts.push(new HighAlert(itm.alertMessage.alertMessageId, itm.alertMessage.subject, itm.alertMessage.message, dt, itm.read, 'High'));
                });
            return alerts;
        });
    }

    getMediumAlertNotifications(sortArgs?: string, fromDate?: any, toDate?: any, showOnlyRead?: boolean, pageNumber?: number, pageSize?: number, platForm?: string) {
        let sortArg = sortArgs.split(",");
        let http = this.setContext(platForm).url("/api/alerts").addParam("severity", 2).addParam("fromDate", fromDate).addParam("toDate", toDate);
        if (sortArg.length >= 2)
            http.addParam("sortBy", sortArg[0]).addParam("sortDirection", sortArg[1]) //API data is not avaibale uncomment after it available
        if (showOnlyRead === undefined)
            http.addParam("read", 0)
        http._url = http._url.replace(/\+/g, "%2B");
        return http.get().map(res => {
            let alerts = [];
            if (res.text() !== "")
                res.json().forEach(itm => {
                    let dt = this.parseDate(itm.alertMessage.createdTime);
                    alerts.push(new MediumAlert(itm.alertMessage.alertMessageId, itm.alertMessage.subject, itm.alertMessage.message, dt, itm.read, 'Medium'));
                });
            return alerts;
        });
    }

    getLowAlertNotifications(sortArgs?: string, fromDate?: any, toDate?: any, showOnlyRead?: boolean, pageNumber?: number, pageSize?: number, platForm?: string) {
        let sortArg = sortArgs.split(",");
        let http = this.setContext(platForm).url("/api/alerts").addParam("severity", 3).addParam("fromDate", fromDate).addParam("toDate", toDate);
        if (sortArg.length >= 2)
            http.addParam("sortBy", sortArg[0]).addParam("sortDirection", sortArg[1]) //API data is not avaibale uncomment after it available
        if (showOnlyRead === undefined)
            http.addParam("read", 0)
        http._url = http._url.replace(/\+/g, "%2B");
        return http.get().map(res => {
            let alerts = [];
            if (res.text() !== "")
                res.json().forEach(itm => {
                    let dt = this.parseDate(itm.alertMessage.createdTime);
                    alerts.push(new LowAlert(itm.alertMessage.alertMessageId, itm.alertMessage.subject, itm.alertMessage.message, dt, itm.read, 'Low'));
                });
            return alerts;
        });
    }

    markAsRead(alertId: number) {
        let data = new URLSearchParams();
        data.append('alertIds', alertId + '');

        return this.$http.wesContext.url("/api/alerts/bulk/markasread").put(data, "application/x-www-form-urlencoded")
            .map(res => {
                return res.json()
            });
    }

    parseDate(date) {
        return new Date(date);
    }
    setContext(platForm: string) {
        if (platForm !=undefined && platForm!= "" && platForm.toLowerCase() === 'wes')
            return this.$http.wesContext;
        else
            return this.$http.iotContext;
    }
}
