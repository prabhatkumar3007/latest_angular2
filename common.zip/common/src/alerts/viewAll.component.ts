import { AuthPermissionService } from './../services/authPermission.service';
import { ShareDataService } from './../services/shareDataService';
import { AlertService } from './alert.service';
import { ChangeDetectorRef, Component, EventEmitter, Output, Input } from '@angular/core';

declare var $: any
declare var moment: any

@Component({
  selector: 'view-all-modal',
  templateUrl: 'viewAll.component.html',
  styles: [`
  .dataTableLayout {
      table-layout:fixed;
    width:100%;
    }`]
})
export class ViewAllComponent {
  public alertViewAllData: any;
  public prioritySelected: string;
  public markAsReadList = [];
  public onCheckBoxChecked: any;
  public datePickerConfig: any;
  public dataTableConfig: any;
  public sortArgs: string;
  public fromDate: any;
  public toDate: any;
  public isModalShown: boolean = false;
  public showMarkAsRead = false;
  @Input() platForm: string;// wes or iot   
  @Output() notify: EventEmitter<number> = new EventEmitter<number>();

  constructor(private alertService: AlertService, private _cdr: ChangeDetectorRef, private setDate: ShareDataService, private _authPermissionService: AuthPermissionService) {
    this.onCheckBoxChecked = this.onChecked.bind(this);
    this.datePickerConfig = {
      maxDate: new Date(),
      minDate: moment(new Date()).subtract(1, 'M')._d
    };

    this.dataTableConfig = {
      "createdRow": (row, data, dataIndex) => {
        if (!data["isRead"]) {
          $(row).addClass('alert-unread');
        }
      }
    }
    this.sortArgs = "createdTime,desc";
    this.prioritySelected = 'High';
  }
  ngOnInit() {
    let permissions = [];
    if (this.platForm && this.platForm.toLowerCase() == "wes") {
      permissions = this._authPermissionService.getPermissionByModule("all");
    } else {
      permissions = this._authPermissionService.getPermissionByModule("alert");
    }
    if (permissions.length > 0) {
      if (this._authPermissionService.canView(permissions)) {
        this.showMarkAsRead = false;
        return;
      }
      if (this._authPermissionService.canManage(permissions)) {
        this.showMarkAsRead = true;
      }
    }
  }
  ngAfterViewInit() {
    this._cdr.detectChanges();
  }

  onChecked(dataContext) {
    if (this.markAsReadList.indexOf(dataContext) > -1) {
      this.markAsReadList.splice(dataContext, 1);
    } else {
      this.markAsReadList.push(dataContext);
    }
  }


  markAsRead() {
    this.markAsReadList.forEach((alert) => {
      this.alertService.markAsRead(alert.id).subscribe((res) => {
        alert.isRead = true;
        this.viewAllData(this.prioritySelected, this.sortArgs, this.fromDate, this.toDate);
      });
    });
  }

  priorityChange(value) {
    this.viewAllData(value, this.sortArgs, this.fromDate, this.toDate);
  }
  viewAllData(section, sortArgs?: any, fromDate?: any, toDate?: any) {
    this.alertViewAllData = null;
    this.prioritySelected = section;
    switch (section) {
      case 'High':
        this.alertService.getHighAlertNotifications(sortArgs, fromDate, toDate, false, null, null, this.platForm).subscribe(alerts => {
          this.alertViewAllData = alerts;
          this.notify.emit(this.alertViewAllData.length);
        });
        break;

      case 'Medium':
        this.alertService.getMediumAlertNotifications(sortArgs, fromDate, toDate, false, null, null, this.platForm).subscribe(alerts => {
          this.alertViewAllData = alerts;
          this.notify.emit(this.alertViewAllData.length);
        });
        break;

      case 'Low':
        this.alertService.getLowAlertNotifications(sortArgs, fromDate, toDate, false, null, null, this.platForm).subscribe(alerts => {
          this.alertViewAllData = alerts;
          this.notify.emit(this.alertViewAllData.length);
        });
        break;
    }
  }
  viewAllCallback(date) {
    if (date) {
      if (date && date.dates.length <= 1) {
        this.fromDate = moment(date.dates[0]).format("YYYY-MM-DDT00:00:00Z");
        this.toDate = moment(date.dates[0]).format("YYYY-MM-DDT23:59:59Z");
      }
      else {
        this.fromDate = moment(date.dates[0]).format("YYYY-MM-DDT00:00:00Z");
        this.toDate = moment(date.dates[1]).format("YYYY-MM-DDT23:59:59Z");
      }
      if (this.isModalShown) {
        this.setDate.setDate(this.fromDate, this.toDate);
        this.viewAllData(this.prioritySelected, this.sortArgs, this.fromDate, this.toDate);
      }

    }

  }

  onSortChanged(sortArgs) {
    this.sortArgs = sortArgs[0] + "," + sortArgs[1];
    this.viewAllData(this.prioritySelected, this.sortArgs, this.fromDate, this.toDate);
  }
}