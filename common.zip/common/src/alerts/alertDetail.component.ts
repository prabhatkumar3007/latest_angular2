import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
    selector: 'alert-detail',
    templateUrl: 'alertDetail.template.html'
})
export class AlertDetailComponent {
    @Input() headerClass: string
    @Input() alert: any
    @Output() onClose: EventEmitter<any> = new EventEmitter<any>();

    closeDetail() {
        this.onClose.emit(null);
    }
}