declare var moment: any;

export interface IAlert {
    id: number;
    subject: string;
    message: string;
    createdTime: Date;
    isRead: boolean;
    priority:string;
}

export class HighAlert implements IAlert {
    timeSince: string;
    constructor(public id: number, public subject: string, public message: string, public createdTime: Date, public isRead: boolean, public priority:string) {
        this.timeSince = moment(this.createdTime).fromNow(true);
    }
}

export class MediumAlert implements IAlert {
    timeSince: string;
    constructor(public id: number, public subject: string, public message: string, public createdTime: Date, public isRead: boolean, public priority:string) {
        this.timeSince = moment(this.createdTime).fromNow(true);
    }
}

export class LowAlert implements IAlert {
    timeSince: string;
    constructor(public id: number, public subject: string, public message: string, public createdTime: Date, public isRead: boolean, public priority:string) {
        this.timeSince = moment(this.createdTime).fromNow(true);
    }
}