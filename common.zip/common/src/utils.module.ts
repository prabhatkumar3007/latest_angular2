import { AuthPermissionService } from './services/authPermission.service';
import { FileService } from './services/file.service';
import { HttpService } from './services/http.service';
import { NgModule } from '@angular/core';

export { HttpService } from './services/http.service';
export { FileService } from './services/file.service';
export {AuthPermissionService} from './services/authPermission.service';

@NgModule({
    imports: [],
    declarations: [],
    exports: [],
    providers: [
        FileService,
        AuthPermissionService
    ]
})
export class CommonUtilsModule { }
