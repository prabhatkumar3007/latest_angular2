import { Pipe, PipeTransform } from '@angular/core';

declare let moment: any;

@Pipe({
  name: 'datePipe'
})
export class DateFormaterPipe implements PipeTransform {
  transform(date: any): any {
    let d = date.substring(0, 10);
    return moment(d).format('MM/DD/YYYY');
  }
}