import { Pipe, PipeTransform } from '@angular/core';

declare let moment: any;

@Pipe({
  name: 'formatDate'
})
export class DatePipe implements PipeTransform {
  transform(date: any, args?: any): any {
    let d,formatedDate;
    if (date.substring) {
      let datePart = date.substring(0, date.length - 6);
      let zone = date.substring(date.length - 6, date.length);
      d = moment(datePart).utcOffset(zone)._d;
      formatedDate = args ? moment(d).format(args) : moment(d).format('MM/DD/YYYY HH:mm:ss');
      return formatedDate;
    }
    else
      d = moment(date);
    if (!d._isValid)
      d = moment(date);
    formatedDate = args ? moment(d).format(args) : moment(d).format('MM/DD/YYYY HH:mm:ss')
    return formatedDate;

  }
}