import { Component, Input } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from './auth/auth.service';
import { HttpService } from './shared/http.service';

@Component({
  moduleId: 'module.id',
  templateUrl: 'loginPage.component.html'
})
export class LoginComponent {
  constructor(private _loginService: AuthService, private routes: Router, private _http: HttpService) {

  }
  private ErrorMsg: string;
  public ErrorMessageIsVisible: boolean;

  login(userName: string, password: string) {
    var creds = "userName=" + userName + "&password=" + password;
    this._loginService.getLoginData(creds).subscribe(
      data => this.loginSucess(data),
      err => this.loginFail(err),
      () => console.log('Authentication Complete'),
    );
  }

  loginSucess(data: any) {
    var msg: string = "Login Failed"
    this.routes.navigate(['home']);
    this._loginService.getUserData().subscribe(
      data => this.userPresent(data),
      err => this.loginFail(err),
      () => console.log('Authentication Complete')
    )
  }

  userPresent(data: any) {
    this.routes.navigate(['home']);
    return true;
  }

  loginFail(err: any) {
    console.log(err);
  }

  hideErrorMsg() {
    this.ErrorMessageIsVisible = false;
  }
}
