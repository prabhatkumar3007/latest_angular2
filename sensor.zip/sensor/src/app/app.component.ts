import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from './auth/auth.service';
import { NavBarComponent } from './shared/navbar.component';
import { LocalStorageService } from "./shared/storage/LocalStorageEmitter";

@Component({
  selector: 'app-root',
  template: `
      <div *ngIf="_loginService.isLoggedIn">
        <navbar-new></navbar-new>
        <navbar></navbar>
      </div>
      <router-outlet></router-outlet>
      <footer-all></footer-all>
  `,
  providers: [LocalStorageService]
})
export class AppComponent {
  constructor(private _loginService: AuthService, private storageService: LocalStorageService) {
  }
  showStyle: boolean = false;
  getStyle() {
    if (this.showStyle) {
      return "yellow";
    } else {
      return "";
    }
  }
}