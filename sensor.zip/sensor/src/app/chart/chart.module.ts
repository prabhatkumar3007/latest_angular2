import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { HttpModule } from '@angular/http';
import "d3";
import "nvd3"
import { nvD3 } from 'ng2-nvd3'
import { LineChartComponent } from './lineChart.component';



@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule,
    HttpModule

  ],
  declarations: [
      LineChartComponent,
      nvD3
  ],
  exports: [
      LineChartComponent,
      nvD3
  ],
  providers: [
  ]
})
export class ChartModule { 
}