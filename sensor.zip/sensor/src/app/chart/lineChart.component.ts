import { Component, AfterViewInit, Input } from '@angular/core';
import { ProcessRateData } from '../chart/chart-data';
declare let d3: any;

@Component({
  selector: 'line-chart',
  templateUrl: 'lineChart.component.html'
})
export class LineChartComponent {
  chartData: any = [];
  @Input() chartDataProcess: any;
  
  options;

  ngAfterViewInit() {
    
    this.chartData.push(this.chartDataProcess);
    if(this.chartData[0].percent >= 1){
      
    }
    this.options = {
      chart: {
        type: 'lineChart',
        height: 200,
        margin: {
          top: 20,
          right: 20,
          bottom: 45,
          left: 45
        },
        y: function (d) { return d.y; },
        x: function (d, i) { return i; },
        color: d3.scale.category10().range(),
        duration: 300,
        showLegend: false,
        reduceXTicks: true,
        useInteractiveGuideline: true,
        clipVoronoi: false,
        yAxis: {
          axisLabel: "Units",
          axisLabelDistance: -20,
          tickFormat: function (d) {
            return Math.round(d);
          }
        },
      }
    }
  }
}
