import { Component, OnInit } from '@angular/core';
import { BarData } from './chart-data';
declare let d3: any;

@Component({
  selector: 'chart-componet',
  template: '<nvd3 [options]="options" [data]="data"></nvd3>'
})
export class BarChartComponent implements OnInit {
  options;
  data;
  ngOnInit() {
    this.options = {
      chart: {
        type: 'multiBarChart',
        height: 450,
        margin: {
          top: 20,
          right: 20,
          bottom: 45,
          left: 45
        },
        clipEdge: true,
        //staggerLabels: true,
        duration: 500,
        stacked: false,
        xAxis: {
          axisLabel: 'Days',
          showMaxMin: false,

        },
        yAxis: {
          axisLabel: 'Units',
          axisLabelDistance: -20,
          tickFormat: function (d) {
            return d3.format(',.1f')(d);
          }
        }
      }
    }
    this.data = BarData;
  }
}
