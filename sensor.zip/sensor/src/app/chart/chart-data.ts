export const BarData: Array<any> = [
    {
        key: "Order",
        color: "#33CAFF",
        values:
        [
            { x: "Monday", y: 90 },
            { x: "Tuesday", y: 80 },
            { x: "Wednesday", y: 40 },
            { x: "Thursday", y: 30 },
            { x: "Friday", y: 20 }
        ]
    },
    {
        key: "Order Lines",
        color: "#8033FF	",
        values:
        [
            { x: "Monday", y: 100 },
            { x: "Tuesday", y: 70 },
            { x: "Wednesday", y: 50 },
            { x: "Thursday", y: 30 },
            { x: "Friday", y: 20 }
        ]
    },
    {
        key: "Container",
        color: "#FF3336",
        values:
        [
            { x: "Monday", y: 70 },
            { x: "Tuesday", y: 60 },
            { x: "Wednesday", y: 50 },
            { x: "Thursday", y: 30 },
            { x: "Friday", y: 20 }
        ]
    }
];
export const LineData: Array<any> = [

    {
        key: "Order",
        color: "#33CAFF",
        seriesIndex: 0,
        values:
        [
            { series: 0, x: "Monday", y: 70, y1: 70 },
            { series: 0, x: "Tuesday", y: 60, y1: 60 },
            { series: 0, x: "Wednesday", y: 40, y1: 40 },
            { series: 0, x: "Thrusday", y: 30, y1: 30 },
            { series: 0, x: "Friday", y: 10, y1: 10 }
        ]
    },
    {
        key: "Order Lines",
        color: "#8033FF",
        seriesIndex: 0,
        values:
        [
            { series: 0, x: "Monday", y: 90, y1: 90 },
            { series: 0, x: "Monday", y: 70, y1: 70 },
            { series: 0, x: "Monday", y: 40, y1: 40 },
            { series: 0, x: "Monday", y: 70, y1: 70 },
            { series: 0, x: "Monday", y: 30, y1: 30 }
        ]
    },
    {
        key: "Container",
        color: "#FF3336",
        seriesIndex: 0,
        values:
        [
            { series: 0, x: "Monday", y: 80, y1: 80 },
            { series: 0, x: "Monday", y: 60, y1: 60 },
            { series: 0, x: "Monday", y: 50, y1: 50 },
            { series: 0, x: "Monday", y: 20, y1: 20 },
            { series: 0, x: "Monday", y: 10, y1: 10 }
        ]
    }
];
export class ProcessRateData {

    key: string;
    seriesIndex: number;
    values: any;
    target:number;
    actual:number;
    percent:number;
    percent_up:boolean;

    constructor(key, series) {
        this.key = key;
        this.seriesIndex = series;
    }
    calculatePer(){
        this.percent = Math.round((this.actual - this.target) / this.target * 100);
        this.percent_up = (this.percent >= 0)? true : false;
        this.percent = Math.abs(this.percent);

    }
}


export const LineProcessData: Array<any> = [

    {
        key: "Order",
        color: "#33CAFF",
        seriesIndex: 0,
        values:
        [
            { series: 0, x: "Monday", y: 70, y1: 70 },
            { series: 0, x: "Tuesday", y: 60, y1: 60 },
            { series: 0, x: "Wednesday", y: 40, y1: 40 },
            { series: 0, x: "Thrusday", y: 30, y1: 30 },
            { series: 0, x: "Friday", y: 10, y1: 10 }
        ]
    }
];
export const DonutData: Array<any> = [
    {
        key: "One",
        y: 98
    },
    {
        key: "Two",
        y: 2
    }
];
export const PieData: Array<any> = [
    {
        key: "One",
        y: 98
    },
    {
        key: "Two",
        y: 2
    }
];
export const SparklineData: Array<any> = [
    {
        x: "One",
        y: 98
    },
    {
        x: "Two",
        y: 12
    },
    {
        x: "One",
        y: 20
    },
    {
        x: "Two",
        y: 22
    },
    {
        x: "One",
        y: 45
    },
    {
        x: "Two",
        y: 2
    },
    {
        x: "One",
        y: 89
    },
    {
        x: "Two",
        y: 7
    },
    {
        x: "One",
        y: 57
    },
    {
        x: "Two",
        y: 2
    },
    {
        x: "One",
        y: 42
    },
    {
        x: "Two",
        y: 2
    },
    {
        x: "One",
        y: 35
    },
    {
        x: "Two",
        y: 2
    }
];