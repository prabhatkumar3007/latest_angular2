import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

import { MessagesService }  from './messages.service';
import { MessagesComponent } from './messages.component';
import { LoginComponent } from '../login.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule
  ],
  declarations: [
    MessagesComponent
  ],
  exports: [
    MessagesComponent
  ],
  providers: [
    MessagesService,
    LoginComponent
  ]
})
export class MessagesModule {
  
}