import { RouterModule  } from '@angular/router';

import {MessagesComponent} from './messages.component';
import { AuthGuard } from '../auth/auth-guard.service';

export const messageRouting = RouterModule.forChild([
  { path: 'home/messages', component: MessagesComponent, canActivate: [ AuthGuard ] },
]);