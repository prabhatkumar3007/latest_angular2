import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { HttpModule } from '@angular/http';
import { ModalModule } from 'ng2-bootstrap/modal';



import { UserFormComponent } from './userForm.component';
import { UsersComponent } from './users.component';
import { UserService } from './user.service';
import { PreventUnsavedChangesGuard } from '../../shared/prevent-unsaved-changes-guard.service';
import { HttpService } from '../../shared/http.service';
import { ControlsModule } from '../../controls/controls.module';
//import { UserModelComponent } from './../users.component'


@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule,
    HttpModule,
    ControlsModule,
    ModalModule.forRoot()
  ],
  declarations: [
    UserFormComponent, 
    UsersComponent,
    //UserModelComponent
  ],
  exports: [
    UserFormComponent, 
    UsersComponent,
    //UserModelComponent
  ],
  providers: [
    UserService,
    PreventUnsavedChangesGuard,
    HttpService
  ]
})
export class UsersModule { 
}