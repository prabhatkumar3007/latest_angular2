import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import { HttpService } from '../../shared/http.service';

@Injectable()
export class UserService {

  constructor(private _http:HttpService){
  }

  getUsers(){
    return this._http.get(this._http.getBaseUrl() + "/app/users/list", { withCredentials: true } )
      .map(res => res.json());
  }
  
  getUser(userId){
    return this._http.get(this._http.getBaseUrl() + "/app/users/" + userId, { withCredentials: true } )
      .map(res => res.json());
  }
  
  addUser(user){
    var data = JSON.stringify(user);
    return this._http.post(this._http.getBaseUrl() + "/app/users/create", data)
    .map(res => res.json());
  }
  
  updateUser(user){
    var data = JSON.stringify(user);
    return this._http.put(this._http.getBaseUrl() + "/app/users/" + user.userId, data, {withCredentials: true})
    .map(res => res.json());
  }
  
  deleteUser(userId){
    return this._http.delete(this._http.getBaseUrl() + "/app/users/" + userId, {withCredentials: true})
    .map(res => res);
  }
}