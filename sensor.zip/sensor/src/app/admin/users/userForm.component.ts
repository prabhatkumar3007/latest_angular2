import { Component, Input, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { BasicValidators } from '../../shared/basicValidators';
import { UserService } from './user.service';
import { User } from './user';

@Component({
  selector: 'user-modal',
  templateUrl: 'userForm.component.html'
})
export class UserFormComponent {
  form: FormGroup;
  title: string;
  user: User = new User();
  isEditMode: boolean = false;


  constructor(
    private fb: FormBuilder,
    private cdr: ChangeDetectorRef,
    private _userService: UserService) {
    this.createForm();
  }

  createForm() {
    this.form = this.fb.group({
      userLogin: [null, Validators.required],
      firstName: [null, Validators.required],
      lname: [null, Validators.required],
      email: [null, BasicValidators.email],
      status: [1]
    });
  }

  setUserInfo(userObj) {
    if (userObj) {  // in edit mode
      this.createForm();
      this.user = new User();
      this.cdr.detectChanges();// this is done to reset the form and resolve error of blank data on clicking edit on same row.
      
      this.isEditMode = true;
      this.form.controls['userLogin'].disable({ emitEvent: false });
      this.form.controls['status'].enable({ emitEvent: false });

      this.user = Object.assign({}, userObj);
      this.cdr.detectChanges();
    }
    else {// in new
      this.form.controls['userLogin'].enable({ emitEvent: false });
      this.form.controls['status'].disable({ emitEvent: false });
      this.createForm();
      this.user = new User();
    }
  }

  save() {
    var result;

    if (this.user.userId) {
      // console.log("user-form.userId::::: " + this.user.userId)
      result = this._userService.updateUser(this.user);
    } else {
      var data = JSON.stringify(this.user);
      result = this._userService.addUser(this.user)
    }
    return result;
  }
}