import { Component, OnInit, ViewChild } from '@angular/core';
import { ModalDirective } from 'ng2-bootstrap';

import { UserService } from './user.service';
import { HttpService } from '../../shared/http.service';
import { User } from './user';

import { UserFormComponent } from './userForm.component'

@Component({
  templateUrl: 'users.component.html'
})
export class UsersComponent implements OnInit {
  users: any[];
  angular: any;
  user: any;
  modelTitle: String;
  submitText: String;
  @ViewChild(UserFormComponent) userForm: UserFormComponent;
  @ViewChild('userModal') public userModal: ModalDirective;

  constructor(private _service: UserService, private _http: HttpService) {
  }

  ngOnInit() {
    this.getAllUsers();
  }
  onOpenUserModal(userObject) {
    this.modelTitle = (userObject === undefined) ? "CREATE NEW USER" : "EDIT USER";
    this.submitText = (userObject === undefined) ? "Create" : "Save"
    this.userForm.setUserInfo(userObject);
    this.userModal.show();
  }

  deleteUser(user) {
    if (user.userId === 1) {
      alert(" You can not delete this User.");
    } else {
      if (confirm("Are you sure you want to delete " + user.firstName + "?")) {
        var index = this.users.indexOf(user)
        this._service.deleteUser(user.userId)
          .subscribe(res => {
            this.getAllUsers();
          },
          err => {
            alert("Could not delete the user.");
          });
      }
    }

  }
  getAllUsers() {
    this._service.getUsers().subscribe(users => this.users = users);
  }
  onSaveUser() {
    this.userForm.save().subscribe(
      res => {

        this.userModal.hide();
        this.getAllUsers();
      });
  }
}