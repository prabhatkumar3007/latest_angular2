

export class User {
    userId: number;
    name: string;
    status: number = 1;
    userLogin: string;
    password: any = "5f4dcc3b5aa765d61d8327deb882cf99";
    firstName: string;
    lastName: string;
    middleInitial: string;
    title: string;
    email: string;
    phone: string;
    fax: string;
    jobTitle: string
    cellPhone: string;
    country: string;
    language: string;
    variant: string;
    dateFormat: string;
    timeZone: string;
    // address = new Address();
}