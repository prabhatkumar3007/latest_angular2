import { RouterModule } from '@angular/router';

import { UserFormComponent } from './userForm.component';
import { UsersComponent } from './users.component';
import { PreventUnsavedChangesGuard } from '../../shared/prevent-unsaved-changes-guard.service';
import { AuthGuard } from '../../auth/auth-guard.service';

export const usersRouting = RouterModule.forChild([
  {
    path: 'users/:id',
    component: UserFormComponent,
    canActivate: [AuthGuard],
    canDeactivate: [PreventUnsavedChangesGuard]
  },
  {
    path: 'users/new',
    component: UserFormComponent,
    canActivate: [AuthGuard],
    canDeactivate: [PreventUnsavedChangesGuard]
  },
  { path: 'users', component: UsersComponent, canActivate: [AuthGuard] },
]);