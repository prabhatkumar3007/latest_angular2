import { Component, Input } from '@angular/core';
import { ProcessData } from './progressBar.data'

@Component({
    selector: 'process-bar',
    templateUrl: 'progressBar.component.html'
})

export class ProgressBarComponent {

    @Input() processData: ProcessData;

    applyBgColor(index) {
        let colors = ['color_bg_green', 'color_bg_blue', 'color_bg_yellow', 'color_bg_light_red'];
        return colors[index];
    }
}