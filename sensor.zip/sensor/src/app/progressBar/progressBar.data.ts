export class ProcessSection {
    Label: string
    Value: number
    PercentageWidth: string

    constructor(label, value) {
        this.Label = label;
        this.Value = value;
    }
}

export class ProcessData {
    TotalProcess: number
    AverageProcessTime: string
    ProcessSections: ProcessSection[] = []
    constructor(averageProcessTime) {
        this.AverageProcessTime = averageProcessTime;
        this.TotalProcess = 0;
    }

    addProcessValues(objProcessSection) {
        this.ProcessSections.push(objProcessSection);
        this.TotalProcess += objProcessSection.Value;
    }

    calculatePercentageWidths() {
        this.ProcessSections.forEach((section) => {
            section.PercentageWidth = (section.Value / this.TotalProcess * 100) + '%';
        });
    }

}

