import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { HttpModule } from '@angular/http';

import { DashboardComponent } from './dashboard.component';
import { DashboardService } from './dashboard.service';
import { ProcessRateService } from './processRate.service';
import { TopRankingService } from './topRanking.service';


import { ChartModule } from '../chart/chart.module';
import { PaginationModule } from 'ng2-bootstrap/ng2-bootstrap';

import { TabsModule } from 'ng2-bootstrap';
import { Ng2TableModule } from 'ng2-table/ng2-table';
import { TooltipModule } from 'ng2-bootstrap/tooltip';
import { AccordionModule } from 'ng2-bootstrap/accordion';

import { ProgressBarComponent } from '../progressBar/progressBar.component';
import { PopoverHtmlComponent } from '../popover/popover.component';

import { ControlsModule } from '../controls/controls.module'

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule,
    HttpModule,
    ChartModule,
    Ng2TableModule,
    TooltipModule.forRoot(),
    AccordionModule.forRoot(),
    PaginationModule,
    TabsModule,
    ControlsModule
  ],
  declarations: [
    DashboardComponent,
    ProgressBarComponent,
    PopoverHtmlComponent
  ],
  exports: [
    DashboardComponent,
    ProgressBarComponent,
    PopoverHtmlComponent
  ],
  providers: [
    DashboardService,
    ProcessRateService,
    TopRankingService
  ]
})
export class DashboardModule {
}