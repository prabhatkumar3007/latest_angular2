export class WaveData {
  no: number;
  waveId: number;
  agedTime: any;
  quantity: number;
  priority: number;
  constructor(no, waveId, agedTime, quantity, priority) {
    this.no = no;
    this.waveId = waveId;
    this.agedTime = agedTime;
    this.quantity = quantity;
    this.priority = priority;
  }
}
export class OrderData {

  no: number;
  orderId: number;
  agedTime: any;
  quantity: number;
  priority: number;
  status: string;
  constructor(no, orderId, agedTime, quantity, priority, status) {
    this.no = no;
    this.orderId = orderId;
    this.agedTime = agedTime;
    this.quantity = quantity;
    this.priority = priority;
    this.status = status;
  }
}
export class BatchData {
  no: number;
  batchId: number;
  agedTime: any;
  priority: number;
  qtyPicked: number;
  qtyPending: number;
  constructor(no, batchId, agedTime, priority,qtyPicked, qtyPending) {
    this.no = no;
    this.batchId = batchId;
    this.agedTime = agedTime;
    this.priority = priority;
    this.qtyPicked = qtyPicked;
    this.qtyPending = qtyPending;
  }
}