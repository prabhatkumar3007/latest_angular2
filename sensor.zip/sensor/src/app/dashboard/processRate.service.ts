import { Injectable } from '@angular/core'
import { ProcessRateData } from '../chart/chart-data'


@Injectable()
export class ProcessRateService {

    getOrderProgressRateData() {
        let orderData = new ProcessRateData("Order", 0);
        orderData.values = [
            { series: 0, x: "Monday", y: 70, y1: 70 },
            { series: 0, x: "Tuesday", y: 60, y1: 60 },
            { series: 0, x: "Wednesday", y: 40, y1: 40 },
            { series: 0, x: "Thrusday", y: 30, y1: 30 },
            { series: 0, x: "Friday", y: 10, y1: 10 }
        ];
        orderData.target = 2400;
        orderData.actual = 2760;
        orderData.calculatePer();
        orderData.percent;

        return orderData;
    }
    getOrderLineProgressRateData() {
        let orderData = new ProcessRateData("Order", 0);
        orderData.values = [
            { series: 0, x: "Monday", y: 90, y1: 90 },
            { series: 0, x: "Tuesday", y: 70, y1: 7 },
            { series: 0, x: "Wednesday", y: 40, y1: 40 },
            { series: 0, x: "Thrusday", y: 60, y1: 60 },
            { series: 0, x: "Friday", y: 10, y1: 10 }
        ];
        orderData.target = 2000;
        orderData.actual = 1920;
        orderData.calculatePer();
        orderData.percent;
        return orderData;
    }
    getOrderLineUnitData() {
        let orderData = new ProcessRateData("Order", 0);
        orderData.values = [
            { series: 0, x: "Monday", y: 90, y1: 90 },
            { series: 0, x: "Tuesday", y: 30, y1: 30 },
            { series: 0, x: "Wednesday", y: 70, y1: 70 },
            { series: 0, x: "Thrusday", y: 10, y1: 10 },
            { series: 0, x: "Friday", y: 60, y1: 60 }
        ];
        orderData.target = 2800;
        orderData.actual = 2080;
        orderData.calculatePer();
        orderData.percent;
        return orderData;
    }
    getOrderLineContainerData() {
        let orderData = new ProcessRateData("Order", 0);
        orderData.values = [
            { series: 0, x: "Monday", y: 80, y1: 80 },
            { series: 0, x: "Tuesday", y: 30, y1: 30 },
            { series: 0, x: "Wednesday", y: 90, y1: 90 },
            { series: 0, x: "Thrusday", y: 10, y1: 10 },
            { series: 0, x: "Friday", y: 90, y1: 90 }
        ];
        orderData.target = 120;
        orderData.actual = 208;
        orderData.calculatePer();
        orderData.percent;
        return orderData;
    }
}