import { Component, OnInit } from '@angular/core';
import { DashboardService } from './dashboard.service';
import { ProcessRateService } from './processRate.service';
import { TopRankingService } from './topRanking.service';
import { WaveData, OrderData, BatchData } from './topRankingTable-data';




declare let d3: any;

@Component({
  templateUrl: 'dashboard.component.html'

})
export class DashboardComponent implements OnInit {


  isWorkQueue: boolean = false;
  isProcessRate: boolean = false;
  isBarClicked: boolean = true;
  isDonutClicked = true;
  orderProcessData: any;
  orderLinesProcessData: any;
  unitProcessData: any;
  containersProcessData: any;
  processRateOrderData: any;
  processRateOrderlineData: any;
  processRateUnitData: any;
  processRateContainerData: any;
  datepickerConfig: any;
  shiftContents = ["Morning", "Regular", "Night"];
  AreaContents = ["Area 1", "Area 2", "Area 3"];
  topRrankingWave:any;
  topRrankingOrder:any;
  topRrankingBatch:any;

  constructor(private dashboardService: DashboardService, private processDataService: ProcessRateService,private _RankDataService:TopRankingService) {
    this.orderProcessData = this.dashboardService.getOrderProgressBarData();
    this.orderLinesProcessData = this.dashboardService.getOrderLinesProgressBarData();
    this.unitProcessData = this.dashboardService.getUnitProgressBarData();
    this.containersProcessData = this.dashboardService.getContainerProgressBarData();

    this.processRateOrderData = this.processDataService.getOrderProgressRateData();
    this.processRateOrderlineData = this.processDataService.getOrderLineProgressRateData();
    this.processRateUnitData = this.processDataService.getOrderLineUnitData();
    this.processRateContainerData = this.processDataService.getOrderLineContainerData();
    this.topRrankingWave = this._RankDataService.getRankWavesData();
    this.topRrankingOrder = this._RankDataService.getRankOrderData();
    this.topRrankingBatch = this._RankDataService.getRankBatchData();
  }

  chartCallback(date) {
    console.log(date); // TODO: Remove once we get method to call from server.
  }

  ngOnInit() {

  }
  barClick() {
    this.isBarClicked = true;
  }
  lineClick() {
    this.isBarClicked = false;
  }
  pieClick() {
    this.isDonutClicked = true;
  }
  donutClick() {
    this.isDonutClicked = false;
  }

}
