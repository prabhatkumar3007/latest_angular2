import { Injectable } from '@angular/core'
import { ProcessData, ProcessSection } from '../progressBar/progressBar.data'

@Injectable()
export class DashboardService {
    getOrderProgressBarData(): ProcessData {
        let orderProcessData = new ProcessData("12:13:14");
        orderProcessData.addProcessValues(new ProcessSection("Complete", this.getRandomNumber()));
        orderProcessData.addProcessValues(new ProcessSection("In Progress", this.getRandomNumber()));
        orderProcessData.addProcessValues(new ProcessSection("Pending", this.getRandomNumber()));
        orderProcessData.addProcessValues(new ProcessSection("Exception", this.getRandomNumber()));
        orderProcessData.calculatePercentageWidths();
        return orderProcessData;
    }
    getOrderLinesProgressBarData(): ProcessData {
        let orderProcessData = new ProcessData("12:13:14");
        orderProcessData.addProcessValues(new ProcessSection("Complete", this.getRandomNumber()));
        orderProcessData.addProcessValues(new ProcessSection("In Progress", this.getRandomNumber()));
        orderProcessData.addProcessValues(new ProcessSection("Pending", this.getRandomNumber()));
        orderProcessData.addProcessValues(new ProcessSection("Exception", this.getRandomNumber()));
        orderProcessData.calculatePercentageWidths();
        return orderProcessData;
    }
    getUnitProgressBarData(): ProcessData {
        let orderProcessData = new ProcessData("12:13:14");
        orderProcessData.addProcessValues(new ProcessSection("Complete", this.getRandomNumber()));
        orderProcessData.addProcessValues(new ProcessSection("In Progress", this.getRandomNumber()));
        orderProcessData.addProcessValues(new ProcessSection("Pending", this.getRandomNumber()));
        orderProcessData.addProcessValues(new ProcessSection("Exception", this.getRandomNumber()));
        orderProcessData.calculatePercentageWidths();
        return orderProcessData;
    }
    getContainerProgressBarData(): ProcessData {
        let orderProcessData = new ProcessData("12:13:14");
        orderProcessData.addProcessValues(new ProcessSection("Complete", this.getRandomNumber()));
        orderProcessData.addProcessValues(new ProcessSection("In Progress", this.getRandomNumber()));
        orderProcessData.addProcessValues(new ProcessSection("Pending", this.getRandomNumber()));
        orderProcessData.addProcessValues(new ProcessSection("Exception", this.getRandomNumber()));
        orderProcessData.calculatePercentageWidths();
        return orderProcessData;
    }

    getRandomNumber(): number {
        return Math.floor(Math.random() * 1000) + 1;
    }
}