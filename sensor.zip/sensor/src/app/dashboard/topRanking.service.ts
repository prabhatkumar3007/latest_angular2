import { Injectable } from '@angular/core';
import { WaveData, OrderData, BatchData } from './topRankingTable-data';

@Injectable()
export class TopRankingService {
    getRankWavesData() {
        //let waveData = new WaveData(1, 401305, '1 Day', 120, 1);
        let waveData = [{
            no: 1,
            waveId: 401305,
            agedTime: '1 Day',
            quantity: 120,
            priority: 1,
        },{
            no: 1,
            waveId: 401305,
            agedTime: '1 Day',
            quantity: 120,
            priority: 1,
        },{
            no: 1,
            waveId: 401305,
            agedTime: '1 Day',
            quantity: 120,
            priority: 1,
        }
        ];

        return waveData;
    }
    getRankOrderData() {
        // let orderData = new OrderData();
         let orderData = [{
            no: 1,
            orderId: 401305,
            agedTime: '1 Day',
            quantity: 120,
            priority: 1,
            status:'completed'
        },{
            no: 1,
            orderId: 401305,
            agedTime: '1 Day',
            quantity: 120,
            priority: 1,
            status:'Pending'
        },{
            no: 1,
            orderId: 401305,
            agedTime: '1 Day',
            quantity: 120,
            priority: 1,
             status:'In Progress'
        }
        ];
        return orderData;
    }
    getRankBatchData() {
        // let batchData = new BatchData();
        let batchData = [{
            no: 1,
            batchId: 401305,
            agedTime: '1 Day',
            priority: 1,
            qtyPicked: 500,
            qtyPending:120
        },{
            no: 1,
            batchId: 401305,
            agedTime: '1 Day',
            priority: 1,
            qtyPicked: 500,
            qtyPending:120
        },{
            no: 1,
            batchId: 401305,
            agedTime: '1 Day',
            priority: 1,
            qtyPicked: 500,
            qtyPending:120
        }
        ];
        return batchData;
    }

    constructor() { }
}