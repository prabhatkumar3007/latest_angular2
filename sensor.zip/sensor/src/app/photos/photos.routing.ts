import { Router, RouterModule } from '@angular/router';

import { PhotosComponent } from './photos.component';
import { PhotoDetailsComponent } from './photo-details.component';
import { AuthGuard } from '../auth/auth-guard.service';

export const photosRouting = RouterModule.forChild([
  { path: 'photos/:id', component: PhotoDetailsComponent, canActivate: [ AuthGuard ] },
  { path: 'photos', component: PhotosComponent, canActivate: [ AuthGuard ] }
]);