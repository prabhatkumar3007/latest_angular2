import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { HttpModule } from '@angular/http';

import { PaginationComponent } from './pagination.component';
import { SpinnerComponent } from './spinner.component';
import { NavBarComponent } from './navbar.component';
import { NavComponent } from './nav.component';
import { FooterComponent } from './footer.component';
import { HttpService } from '../shared/http.service'

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    RouterModule,
    HttpModule
  ],
  declarations: [
    PaginationComponent,
    SpinnerComponent,
    NavBarComponent,
    NavComponent,
    FooterComponent

  ],
  exports: [
    PaginationComponent,
    SpinnerComponent,
    NavBarComponent,
    NavComponent,
    FooterComponent
  ]
})
export class SharedModule {
}