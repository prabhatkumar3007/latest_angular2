import { Component } from '@angular/core';
import { AuthService } from '../auth/auth.service';

@Component({
  selector: 'navbar',
  templateUrl: 'navbar.component.html'
})
export class NavBarComponent {
  isHidden: number = 1;
  constructor(private _loginService: AuthService) {
  }

  logout() {
    this._loginService.logout().subscribe(
      data => { },
      err => this.logoutFail(err)
    )
  }

  logoutFail(err: any) {
    console.log(err);
  }
}