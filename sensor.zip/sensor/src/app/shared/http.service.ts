import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptionsArgs } from "@angular/http";

@Injectable()
export class HttpService {
  constructor(private _http: Http) { }

  private baseUrl: string = "http://172.27.27.56:8080/iot";

  createHeader(headers: Headers) {
    headers.append('Content-Type', 'application/json');
  }

  get(url: string, options?: RequestOptionsArgs) {
    let headers = new Headers();
    this.createHeader(headers);
    return this._http.get(url, {
      headers: headers
    });
  }

  post(url, data, options?: RequestOptionsArgs) {
    let headers = new Headers();
    this.createHeader(headers);
    return this._http.post(url, data, {
      headers: headers
    });
  }

  put(url, data, options?: RequestOptionsArgs) {
    let headers = new Headers();
    this.createHeader(headers);
    return this._http.put(url, data, {
      headers: headers
    });
  }

  delete(url: string, options?: RequestOptionsArgs) {
    let headers = new Headers();
    this.createHeader(headers);
    return this._http.delete(url, {
      headers: headers
    });
  }

  setBaseUrl(url) {
    this.baseUrl = url;
  }

  getBaseUrl() {
    return this.baseUrl;
  }
}