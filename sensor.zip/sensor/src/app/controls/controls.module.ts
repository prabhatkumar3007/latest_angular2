import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DatePickerComponent } from './datepicker/datepicker.component'
import { DataTableDirective } from './datatable/angular-datatables.directive'

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [
    DatePickerComponent,
    DataTableDirective
  ],
  exports: [
    DatePickerComponent,
    DataTableDirective
  ],
  providers: [
  ]
})
export class ControlsModule {
}