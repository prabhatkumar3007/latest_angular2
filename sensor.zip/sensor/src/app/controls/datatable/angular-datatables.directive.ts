import { Directive, ElementRef, Inject, Input, ChangeDetectorRef } from '@angular/core';
declare var $: any;

@Directive({
  selector: '[datatable]'
})
export class DataTableDirective {
  /**
   * The DataTable option you pass to configure your table.
   */
  @Input()
  dtOptions: any = {
    "paging": false,
    "ordering": false,
    "info": false,
    "searching": false,
    "scrollY": '50vh',
    "scrollCollapse": true,
    "sDom": 'r'
  };
  @Input() datatable: any;
  table: any;

  dtInstance: Promise<any>;

  constructor( @Inject(ElementRef) private el: ElementRef, private cdr: ChangeDetectorRef) {
    this.dtOptions = $.extend(true, this.dtOptions, $.fn.DataTable.defaults);
  }
  ngOnChanges(changes) {
    if (changes.datatable.currentValue) {
      this.initializeGrid();
    }
  }

  initializeGrid() {
    this.dtInstance = new Promise((resolve, reject) => {
      Promise.resolve(this.dtOptions).then(dtOptions => {
        $.fn.dataTable.ext.errMode = "none";
        // if (this.table)
        //   this.table.destroy();
        if (!this.table)
          this.table = $(this.el.nativeElement).DataTable(dtOptions);
        this.cdr.detectChanges();
        resolve(this.table);
      });
    });
  }
}
