import { Component, Input, AfterViewInit, ElementRef, Output, EventEmitter } from '@angular/core';
declare var $: any
declare var moment: any
@Component({
    selector: 'date-picker',
    templateUrl: 'datepicker.component.html'
})

export class DatePickerComponent {
    isDay: boolean = true;
    isWeek: boolean = false;
    datepickerObj: any;
    config: any;
    inSelectionProcess: boolean = false;

    @Input() showDayWeekOptions: boolean = true;
    @Input() datepickerConfig: any;
    @Output() onDateChanged: EventEmitter<any> = new EventEmitter();

    constructor(private elementRef: ElementRef) {
    }

    setDatePickerConfig(isWeek: boolean) {
        this.config = {
            language: 'en',
            dateFormat: 'dd/mm/yyyy',
            position: "bottom right",
            firstDay: 1
        }
        if (this.datepickerConfig)
            this.config = Object.assign(this.config, this.datepickerConfig);
        if (!isWeek) {
            this.config.onSelect = ((formattedDate, date, inst) => {
                this.dateChange(inst.selectedDates); // callback event
            });
        }
        else {
            this.config.range = true;
            this.config.multipleDatesSeparator = ' - ';
            // this.config.multipleDates = true;
            this.config.onSelect = ((formattedDate, date, inst) => {
                if (this.inSelectionProcess === false) {
                    this.inSelectionProcess = true;
                    let firstDate = moment(date[0], "MM-DD-YYYY").day(1);
                    let lastDate = moment(date[0], "MM-DD-YYYY").day(7);
                    inst.clear();
                    inst.selectDate([firstDate._d, lastDate._d]);
                    this.dateChange(inst.selectedDates); // callback event
                    this.inSelectionProcess = false;
                }
            });
        }
    }

    ngAfterViewInit() {
        this.setDatePickerConfig(this.isWeek);
        this.initialiseDatePicker();
    }

    initialiseDatePicker() {
        if (this.datepickerObj)
            this.datepickerObj.destroy();
        $(this.elementRef.nativeElement).find(".date-text").datepicker(this.config)
        this.datepickerObj = $(this.elementRef.nativeElement).find(".date-text").data('datepicker');

        //adding event to open calendar when clicking on the icon
        $(this.elementRef.nativeElement).find(".fa-calendar").off("click").on("click", e => {
            e.stopPropagation();
            this.datepickerObj.show();
        });

        this.setDate(this.isDay);
    }

    setDate(isDay: boolean) {
        if (isDay) {
            this.datepickerObj.date = new Date();
            this.datepickerObj.selectDate(new Date());
        }
        else {
            let firstDate = moment(new Date(), "MM-DD-YYYY").day(0);
            let lastDate = moment(new Date, "MM-DD-YYYY").day(6);
            this.datepickerObj.selectDate([firstDate._d, lastDate._d]);
        }
    }

    toggleWeek(flag: boolean) {
        if (flag) {
            this.isDay = false;
            this.isWeek = true;
        }
        else {
            this.isDay = true;
            this.isWeek = false;
        }
        this.setDatePickerConfig(this.isWeek);
        this.initialiseDatePicker();
    }

    dateChange(date) {
        this.onDateChanged.emit([date]);
    }
}   