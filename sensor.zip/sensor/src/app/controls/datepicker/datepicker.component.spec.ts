import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { DatePickerComponent } from './datepicker.component';

describe('DatePicker Component', () => {

    let comp: DatePickerComponent;
    let fixture: ComponentFixture<DatePickerComponent>;
    let de: DebugElement;
    let el: HTMLElement;

    beforeEach(() => {
        TestBed.configureTestingModule({
            declarations: [DatePickerComponent], // declare the test component
        });

        fixture = TestBed.createComponent(DatePickerComponent);

        comp = fixture.componentInstance; // DatePickerComponent test instance

        // query for the title <h1> by CSS element selector
        de = fixture.debugElement.query(By.css('ul'));
        el = de.nativeElement;
    });


    describe("When the date pickter initializes ", () => {
        it('should call setDatePickerConfig and initialiseDatePicker methods', () => {
            spyOn(comp, "setDatePickerConfig").and.callThrough();
            spyOn(comp, "initialiseDatePicker").and.callThrough();
            fixture.detectChanges();
            expect(comp.setDatePickerConfig).toHaveBeenCalled();
            expect(comp.initialiseDatePicker).toHaveBeenCalled();
        })

        it('should set the initial config for datepicker', () => {
            fixture.detectChanges();
            expect(comp.config).toBeDefined();
            expect(comp.config.language).toBe("en");
            expect(comp.config.dateFormat).toBe("dd/mm/yyyy");
            expect(comp.config.position).toBe("bottom right");
            expect(comp.config.onSelect).toBeDefined();
        });
    })

    describe("When I call setDate method ", () => {
        it('should set the date on the datepicker when day is true', () => {
            fixture.detectChanges();
            // comp.datepickerObj.selectDate = function () { };
            spyOn(comp.datepickerObj, "selectDate");
            comp.setDate(true);
            expect(comp.datepickerObj.selectDate).toHaveBeenCalled();
        });

        it('should set date range on the datepicker when day is false', () => {
            fixture.detectChanges();
            // comp.datepickerObj.selectDate = function () { };
            spyOn(comp.datepickerObj, "selectDate");
            comp.setDate(false);
            expect(comp.datepickerObj.selectDate).toHaveBeenCalled();
        });
    });


    describe('When I call toggleWeek method ', () => {
        it('should toggle the datepicker to week mode when flag is true', () => {
            spyOn(comp, "setDatePickerConfig");
            spyOn(comp, "initialiseDatePicker");
            fixture.detectChanges();
            comp.toggleWeek(true);
            expect(comp.isDay).toBe(false);
            expect(comp.isWeek).toBe(true);
            expect(comp.setDatePickerConfig).toHaveBeenCalled();
            expect(comp.initialiseDatePicker).toHaveBeenCalled();
        });
        
       it('should toggle the datepicker to week mode when flag is false', () => {
            spyOn(comp, "setDatePickerConfig");
            spyOn(comp, "initialiseDatePicker");
            fixture.detectChanges();
            comp.toggleWeek(false);
            expect(comp.isDay).toBe(true);
            expect(comp.isWeek).toBe(false);
            expect(comp.setDatePickerConfig).toHaveBeenCalled();
            expect(comp.initialiseDatePicker).toHaveBeenCalled();
        });
            
    });

});
