import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';

import { AuthService } from './auth.service';

@Injectable()
export class AuthGuard implements CanActivate {
  constructor( private _router: Router,private authService:AuthService) {
  }

  canActivate() {
    console.log("authService.isLoggedIn: "+this.authService.isLoggedIn);
    if (this.authService.isLoggedIn) {
      return true;
    }

    //TODO: Might have to invalidate the session before taking the user back to login page..
    this._router.navigate(['login']);
    return false;
  }
}