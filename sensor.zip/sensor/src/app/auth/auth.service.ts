import { Injectable } from '@angular/core';
import { Http, Headers } from '@angular/http';

import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

import { HttpService } from '../shared/http.service';

import { SessionStorage } from "../shared/storage/WebStorage";

@Injectable()
export class AuthService {
  // isLoggedIn: boolean = false;
  @SessionStorage() public isLoggedIn: boolean;

  constructor(public http: Http, public _httpService: HttpService) {
    //If not loggedIn, check for valid session.
    //TODO: Since this call is asychronous, need to re-visit this
    if (!this.isLoggedIn) {
      this.hasValidSession().subscribe(
        data => {
          this.isLoggedIn = true;

        },
        (err) => {
          this.isLoggedIn = false;
        }
      );
    }
  }

  getLoginData(creds: string): Observable<any> {
    //this.isLoggedIn = true;
    var headers = new Headers();
    headers.append('Content-Type', 'application/x-www-form-urlencoded');
    return this.http.post(this._httpService.getBaseUrl() + "/app/auth/login", creds, { headers: headers, withCredentials: true })
      .map(res => {
        //Login Success
        if (res.status == 200) {
          this.isLoggedIn = true;
          return res.json();
        }
        //Login Failure
        else {
          throw new Error('Login failed: Status - ' + res.status);
        }
      })
  }

  getUserData(): Observable<any> {
    return this._httpService.get(this._httpService.getBaseUrl() + "/app/auth/currentUser", { withCredentials: true })
      .map(res => res.json());
  }

  logout(): Observable<any> {
    this.isLoggedIn = false;
    return this._httpService.get(this._httpService.getBaseUrl() + "/app/auth/logout", { withCredentials: true })
      .map(res => {
        //Logout Success
        if (res.status == 200) {
          return res;
        }
        //Logout Failure
        else {
          throw new Error('Logout failed: Status - ' + res.status);
        }
      })
  }

  hasValidSession(): Observable<any> {
    //Check for valid session
    return this._httpService.get(this._httpService.getBaseUrl() + "/app/auth/session")
      .map(res => {
        //Has a valid session
        if (res.status == 200) {
          return res;
        } else {
          //Not a valid session
          throw new Error('No valid Session');
        }
      });
  }
}
