import { Component, Input } from '@angular/core';

@Component({
  selector: 'popover-html',
  templateUrl: 'popover.component.html'
})
export class PopoverHtmlComponent {
  @Input() dropDownTitle: String;
  @Input() dropDownList: any;

} 