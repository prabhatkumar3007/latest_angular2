import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { LoginComponent } from './login.component';
import { HomeComponent } from './homePage.component';
//import { NavBarComponent } from './navbar.component';
//import { FooterComponent } from './footer.component';
import { NotFoundComponent } from './shared/not-found.component';

import { MessagesModule } from './messages/messages.module';
import { OtherModule } from './other/other.module';
import { SharedModule } from './shared/shared.module';
import { UsersModule } from './admin/users/users.module';
import { DashboardModule } from './dashboard/dashboard.module';

import { usersRouting } from './admin/users/users.routing';
import { messageRouting } from './messages/message.routing';
import { otherRouting } from './other/other.routing';
import { routing } from './app.routing';

import { AuthService } from './auth/auth.service';
import { AuthGuard } from './auth/auth-guard.service';
import { HttpService } from './shared/http.service';
import { PreventUnsavedChangesGuard } from './shared/prevent-unsaved-changes-guard.service';


@NgModule({
  imports: [
    BrowserModule,
    FormsModule,
    SharedModule,
    UsersModule,
    MessagesModule,
    OtherModule,
    DashboardModule,
    usersRouting,
    messageRouting,
    otherRouting,
    routing
  ],
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    NotFoundComponent
  ],
  providers: [AuthService, AuthGuard, PreventUnsavedChangesGuard, HttpService],
  bootstrap: [AppComponent]
})
export class AppModule { }