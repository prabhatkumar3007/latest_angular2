import { Observable } from 'rxjs/Observable';
export class MockShiftService {
    getAllShift() {
        return Observable.of([{}]).toPromise();
    }
}