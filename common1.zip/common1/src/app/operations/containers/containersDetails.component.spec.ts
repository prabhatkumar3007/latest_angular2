import { ComponentFixture, TestBed, async, tick, fakeAsync } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement, Directive } from '@angular/core';

import { ContainersDetailsComponent } from './containersDetails.component';
import { OperationsModule } from '../operations.module'
import { ContainersService } from '../services/containers.service'
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { RouterStub } from '../../../test/routerStub';
import { MockActivatedRouteById } from '../../../test/mockActivateRoute';

class MockUserService {
  getContainerDetailsData(): Observable<any> {
    return Observable.of({ content: [{}], totalElements: 0 });
  }
  getTopContainerDetailsData(): Observable<any> {
    return Observable.of({ });
  }
  getSortDestination(): Observable<any> {
    return Observable.of({});
  }
  getLocationHistory(): Observable<any> {
    return Observable.of({});
  }
}

describe('Pick Container DETAILS:... Component', () => {

    let comp: ContainersDetailsComponent;
    let fixture: ComponentFixture<ContainersDetailsComponent>;
    let de: DebugElement;
    let el: HTMLElement;
    let service;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [OperationsModule],
            providers: [{ provide: ContainersService, useClass: MockUserService },
            { provide: Router, useClass: RouterStub },
            { provide: ActivatedRoute, useClass: MockActivatedRouteById }]
        })
        // https://angular-2-training-book.rangle.io/handout/testing/components/injecting-dependencies.html
        fixture = TestBed.overrideComponent(ContainersDetailsComponent, {
            set: {
                template: '<span>{{message}}</span>'
            }
        })
            .createComponent(ContainersDetailsComponent);
        comp = fixture.componentInstance;
        service = fixture.debugElement.injector.get(ContainersService);
    }));
    it('should have a defined component', () => {
        expect(comp).toBeDefined();
    });
    describe('When we call getAllPickDetailsContainer', () => {
    it('should get all pickContainer details data', () => {
      spyOn(service, 'getContainerDetailsData').and.callThrough();
      spyOn(comp, 'setPagerConfig');
      comp.getAllPickDetailsContainer(1, '','',2);
      expect(comp.setPagerConfig).toHaveBeenCalled();
      expect(comp.containersDetailsData.length).toBe(1);
      expect(comp.isLoading).toBe(false)
    })
  });
  describe('When we call setPagerConfig', () => {
    it(' should set the pager config', () => {
      comp.setPagerConfig(10, 1, 5);
      expect(comp.pagerConfig.totalItems).toBe(10);
      expect(comp.pagerConfig.currentPage).toBe(1);
      expect(comp.pagerConfig.itemsPerPage).toBe(5);
    })
  });
  describe('When we call checkActivatedRoute', () => {
    it(' should set the state', () => {
      comp.checkActivatedRoute();
      expect(comp.id).toBe(1);
    })
  });
  describe('When we call getPickTopDetailsContainer', () => {
    it('should get all PickTopDetails details data', () => {
      spyOn(service, 'getTopContainerDetailsData').and.returnValue(Observable.of([{}, {}] ));
      comp.getPickTopDetailsContainer(1);
      expect(comp.containersTopData.length).toBe(1);
    })
  });
  describe('When we call getPickSortDestination', () => {
    it('should get all pickContainer details data', () => {
      spyOn(service, 'getSortDestination').and.returnValue(Observable.of([{}, {}] ));
      comp.getPickSortDestination(1);
      expect(comp.containersSortDestinationData.length).toBe(2);
    })
  });
  describe('When we call getPickLocationData', () => {
    it('should get all LocationData details data', () => {
      spyOn(service, 'getLocationHistory').and.returnValue(Observable.of([{}, {}] ));
      comp.getPickLocationData(1);
      expect(comp.containersLocationHistoryData.length).toBe(2);
    })
  });
});