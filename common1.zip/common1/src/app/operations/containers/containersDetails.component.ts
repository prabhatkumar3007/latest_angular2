import { Component, Input, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';

import { ContainersService } from '../services/containers.service';
import { FormComponent } from '../../shared/services/prevent-unsaved-changes-guard.service';
import { ActivatedRoute } from '@angular/router';

import { FormControl } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/throttleTime';
import 'rxjs/add/observable/fromEvent';
import { FilterParams, ActionButtons } from 'sensorthink-commoncontrols/src/components/advancedFilter/advancedFilter.data';
import { NotyService } from "sensorthink-commoncontrols/src/services/noty.service";


@Component({
  selector: 'messages',
  templateUrl: 'containersDetails.component.html'

})
export class ContainersDetailsComponent {
  containersDetailsData: any;
  containersTopData = [];
  containersSortDestinationData: any;
  containersLocationHistoryData: any;
  pagerConfig: any;
  sortArgs: string;
  isLoading: boolean = false;
  onCheckBoxChecked: any;
  id: any;
  private sub: any;
  isFirstLoad: boolean = false;
  sideBarVisible: boolean;
  searchTxt = '';
  searchTxtControl = new FormControl();
  public filterConfig: FilterParams;
  private eligibleForceBatchClose: boolean;
  satgingLoacation: any;

  constructor(private _service: ContainersService, private _cdr: ChangeDetectorRef, private route: ActivatedRoute, private noty: NotyService) {
    this.sortArgs = "containerId,asc";

    this.pagerConfig = {
      totalItems: 64,
      currentPage: 1,
      smallnumPages: 0,
    }
  }
  setPagerConfig(totalItems, currentPage, itemsPerPage?) {
    this.pagerConfig = {
      totalItems: totalItems,
      currentPage: currentPage || 1,
      itemsPerPage: itemsPerPage || 10,
      smallnumPages: 0
    }
  }
  ngOnInit() {
    this.searchTypeResult();
    this.setPagerConfig(0, 0);
    this.checkActivatedRoute();
    this.getAllPickDetailsContainer(1, this.sortArgs, this.searchTxt, this.id);
    this.getPickTopDetailsContainer(this.id);
    this.getPickSortDestination(this.id);
    this.getPickLocationData(this.id);
    this.filterConfig = this.createFilterParams();
  }
  searchTypeResult() {
    this.searchTxtControl.valueChanges
      .debounceTime(1000)
      .subscribe(newValue => {
        this.searchTxt = newValue.trim();
        if (((this.searchTxt.length >= 1 || this.searchTxt.length === 0) && this.searchTxt !== "") || this.isFirstLoad) {
          this.isFirstLoad = (this.searchTxt.length === 0) ? false : true;
          this.getAllPickDetailsContainer(this.pagerConfig.currentPage, this.sortArgs, this.searchTxt, this.id);
        }
      });
  }
  checkActivatedRoute() {
    this.sub = this.route.params.subscribe(params => {
      this.id = params['id']; // (+) converts string 'id' to a number

      // In a real app: dispatch action to load the details here.
    });
  }
  getAllPickDetailsContainer(pageNumber: number, sortArgs: string, searchTxt?: string, id?: any) {
    this.isLoading = true;
    this._service.getContainerDetailsData(pageNumber, this.pagerConfig.itemsPerPage, sortArgs, this.id, searchTxt).subscribe((data) => {
      // this.setPagerConfig(data.totalElements, data.totalPages, data.size)
      if (data) {
        this.setPagerConfig(data.totalElements, this.pagerConfig.currentPage, this.pagerConfig.itemsPerPage);
        this.containersDetailsData = data.content;
      } else {
        this.containersDetailsData = [];
        this.setPagerConfig(0, this.pagerConfig.currentPage, this.pagerConfig.itemsPerPage)
      }

      this.isLoading = false;
      this._cdr.detectChanges();
    });
  }
  getPickTopDetailsContainer(id: any) {
    this._service.getTopContainerDetailsData(id).subscribe((data) => {
      if (data == null) {
        this.containersTopData = [];
        this.eligibleForceBatchClose = false;
      } else {
        this.eligibleForceBatchClose = data.eligibleForceBatchClose;
        if (data.stagingLocation) {
          data.locationAlias = data.stagingLocation.locationAlias;
          this.satgingLoacation = data.locationAlias
        }
        this.containersTopData.push(data);
      }
      this._cdr.detectChanges();
    })

  }
  getPickSortDestination(id: any) {
    this._service.getSortDestination(id).subscribe((data) => {
      this.containersSortDestinationData = (data == null) ? [] : data;
      this._cdr.detectChanges();
    })
  }
  getPickLocationData(id: any) {
    this._service.getLocationHistory(id).subscribe((data) => {
      this.containersLocationHistoryData = (data == null) ? [] : data;

      this._cdr.detectChanges();
    })
  }
  onPageSizeChanged(pageSize) {
    this.pagerConfig.itemsPerPage = pageSize;
    this.getAllPickDetailsContainer(1, this.sortArgs, this.searchTxt);
    this._cdr.detectChanges();

  }
  onPageChanged(pager) {
    this.pagerConfig.currentPage = pager.page;
    this.getAllPickDetailsContainer(pager.page, this.sortArgs, this.searchTxt);
  }
  onSortChanged(sortArgs) {
    this.sortArgs = sortArgs[0] + "," + sortArgs[1];
    this.getAllPickDetailsContainer(this.pagerConfig.currentPage, this.sortArgs, this.searchTxt);
  }

  onBatchForceApply(event) {
    let id = this.id;
    this._service.getForceBatchContainerCloseData(id).subscribe((data) => {
      this.noty.success("Container force completed successfully.");
    })
    this.noty.confirm("Are you sure", 'You want to force complete chute ' + this.satgingLoacation + ' ?', null, true, null, null, 'Yes, force complete!').then(() => {
      this._service.getForceBatchContainerCloseData(id).subscribe((res) => {
        this.noty.success("Container force completed successfully.");
      },
        err => {
          this.noty.error("Error occurred.Could not force complete container.");
        });
    }, err => {
    })
  }
  createFilterParams(): FilterParams {
    let params = new FilterParams(); // initialises to default on object creation
    params.state.isVisible = false;
    params.site.isVisible = false;
    params.baseMetric.isVisible = false;
    params.otherMetric.isVisible = false;
    if (this.eligibleForceBatchClose == true)
      params.actionButtons.push(new ActionButtons("Force Batch Container Close", true, this.onBatchForceApply.bind(this), false));
    else
      params.actionButtons.push(new ActionButtons("Force Batch Container Close", true, this.onBatchForceApply.bind(this), true, 'This chute is not eligible for this action.'));
    params.actionSubSection.isChangeState = false;
    params.actionSubSection.isExportTo = false;
    params.actionSubSection.isTransaction = false;
    return params;
  }

}