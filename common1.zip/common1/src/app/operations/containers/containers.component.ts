import { ActivatedRoute, Params } from '@angular/router';
import { ChangeDetectorRef, Component, Input, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { FormControl } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/throttleTime';
import 'rxjs/add/observable/fromEvent';
import { ContainersService } from '../services/containers.service';
import { FormComponent } from '../../shared/services/prevent-unsaved-changes-guard.service';
import { ShiftService } from './../../shared/services/shift.service';
import { FilterParams, ActionButtons } from 'sensorthink-commoncontrols/src/controls.module';
import { ShareDataService } from "sensorthink-commoncontrols/src/services/shareDataService";
import { AuthPermissionService } from 'sensorthink-commoncontrols/src/utils.module';
import { NotyService } from "sensorthink-commoncontrols/src/services/noty.service";
import { AdvanceFilterService } from "./../../shared/services/advanceFilter.service";
import { AdvancedFilterComponent } from "sensorthink-commoncontrols/src/components/advancedFilter/advancedFilter.component";
declare var moment: any;
@Component({
  selector: 'messages',
  templateUrl: 'containers.component.html'

})
export class ContainersComponent {
  filterConfig: FilterParams;
  appliedFilterData: FilterParams;
  pagerConfig: any;
  sortArgs: string;
  isLoading: boolean = false;
  containersData: any;
  isFirstLoad: boolean = false;
  searchTxt = '';
  searchTxtControl = new FormControl();
  public sideBarVisible: boolean;
  public state: string;
  public loadSavedFilters: any;
  containerType: any;
  parentModule: any;
  callBack = this.onCheckBoxChecked.bind(this);
  allShift: any;
  processType: string = '';
  containerServiceObject = { processType: null, parentModule: null, groupBy: null, containerType: null, batchId: null };
  containerTypeList: any = [{ name: 'All', containerType: 'All' }, { name: 'Pick', containerType: 'Pick' }, { name: 'Pack', containerType: 'Pack' }, { name: 'Ship', containerType: 'Ship' }]
  showForceCompleteButton: boolean = false;
  @ViewChild(AdvancedFilterComponent) advanceFilter: AdvancedFilterComponent;

  constructor(private _service: ContainersService, private _cdr: ChangeDetectorRef, private allShiftService: ShiftService, private activatedRoute: ActivatedRoute, private sharedService: ShareDataService, private _authPermissionService: AuthPermissionService, private noty: NotyService, private filterService: AdvanceFilterService) {
    this.sortArgs = "containerId,asc";
    this.filterConfig = this.createFilterParams();
    this.pagerConfig = {
      totalItems: 64,
      currentPage: 1,
      smallnumPages: 0,
    }
    this._service.selectedRoute =[];
  }

  ngOnInit() {
    this.searchTypeResult();
    this.setPagerConfig(0, 0);
    this.getSavedFilterDataList();
    this.allShiftService.getAllShift().then((res) => {
      this.allShift = res;
      this.filterConfig.shift.options = this.allShift;
      if (this.filterConfig.shift.options) {
        this.filterConfig.shift.selectedValue = this.filterConfig.shift.options[0].name;
      }
      if (this.sharedService.objectStore.shiftValue)
        this.filterConfig.shift.selectedValue = this.sharedService.objectStore.shiftValue;
      this.filterConfig.dateRange.from = (this.sharedService.objectStore.fromDate) ? this.sharedService.objectStore.fromDate : moment(new Date()).format("YYYY-MM-DDT00:00:00");
      this.filterConfig.dateRange.to = (this.sharedService.objectStore.toDate) ? this.sharedService.objectStore.toDate : moment(new Date()).format("YYYY-MM-DDT23:59:59");
      if (this.filterConfig.dateRange.from)
        this.setFilterDates(this.filterConfig.dateRange.from, this.filterConfig.dateRange.to);
      this.checkActivatedRoute();
    })
    let permission = this._authPermissionService.getWESPermissionByModule("container");
    if (permission && permission.length > 0) {
      //this.showForceCompleteButton = this._authPermissionService.canManage(permission);
    }
  }
  getSavedFilterDataList() {
    this.filterService.getAllLoadSaveFilterData('CONTAINERS').then((res) => {
      this.loadSavedFilters = this.filterService.createFilterObjectFormat(res)
      if (this.loadSavedFilters) {
        this.filterConfig.saveLoadFilter.options = this.loadSavedFilters;
      }
      this.isLoading = false;
    })
  }
  searchTypeResult() {
    this.searchTxtControl.valueChanges
      .debounceTime(1000)
      .subscribe(newValue => {
        this.searchTxt = newValue.trim();
        if (((this.searchTxt.length >= 1 || this.searchTxt.length === 0) && this.searchTxt !== "") || this.isFirstLoad) {
          this.isFirstLoad = (this.searchTxt.length === 0) ? false : true;
          if (this.appliedFilterData) {
            this.getAllContainer(this.pagerConfig.currentPage, this.sortArgs, this.appliedFilterData, this.searchTxt, this.containerServiceObject);
          } else {
            this.getAllContainer(this.pagerConfig.currentPage, this.sortArgs, this.appliedFilterData, this.searchTxt, this.containerServiceObject);
          }
        }
      });
  }
  filterApliedMethodCall() {
    let fltr: FilterParams = JSON.parse(JSON.stringify(this.filterConfig));
    fltr.aging.from = null;
    fltr.aging.to = null;
    fltr.aging.fromSeconds = null;
    fltr.aging.toSeconds = null;
    fltr.priority.from = null;
    fltr.priority.to = null;
    this.filterApplied(fltr);
  }

  checkActivatedRoute() {
    this.activatedRoute.queryParams.subscribe((params) => {
      this.state = params['status'];

      this.containerServiceObject.processType = params['processType'];
      if (params['processType'] === 'Dashboard') {
        this.filterConfig.containerTypes.selectedStates[0].checked = true;
      } else if (params['processType'] === 'Picking') {
        this.filterConfig.containerTypes.selectedStates[1].checked = true;
      } else if (params['processType'] === 'Packing' && this.state !== "pending") {
        this.filterConfig.containerTypes.selectedStates[2].checked = true;
      } else if (params['processType'] === 'Shipping' && this.state !== "pending") {
        this.filterConfig.containerTypes.selectedStates[3].checked = true;
      }


      if (params['parentModule']) {
        this.containerServiceObject.parentModule = params['parentModule'];
        this.containerServiceObject.groupBy = 'parentModule';
      } else {
        this.containerServiceObject.groupBy = params['groupBy'];
      }
      if (params['batchId']) {
        this.containerServiceObject.batchId = params['batchId'];
      }
      if (this.state === "exception") {
        this.filterConfig.state.selectedStates[6].checked = true;
        this.filterApliedMethodCall();
      }
      if (this.state === "pending") {
        if (this.containerServiceObject.processType === 'Shipping') {
          this.filterConfig.state.selectedStates[0].checked = true;
          this.filterConfig.state.selectedStates[1].checked = true;
          this.filterConfig.state.selectedStates[2].checked = true;
          this.filterConfig.containerTypes.selectedStates[1].checked = true;
          this.filterConfig.containerTypes.selectedStates[2].checked = true;
        }
        else if (this.containerServiceObject.processType === 'Packing') {
          this.filterConfig.state.selectedStates[0].checked = true;
          this.filterConfig.state.selectedStates[1].checked = true;
          this.filterConfig.containerTypes.selectedStates[1].checked = true;
          this.filterConfig.containerTypes.selectedStates[3].checked = true;
        } else {
          this.filterConfig.state.selectedStates[0].checked = true;
        }
        this.filterApliedMethodCall();
      }
      if (this.state === "complete") {
        if (this.containerServiceObject.processType === 'Picking')
          this.filterConfig.state.selectedStates[2].checked = true;
        else if (this.containerServiceObject.processType === 'Packing')
          this.filterConfig.state.selectedStates[3].checked = true;
        else if (this.containerServiceObject.processType === 'Shipping') {
          this.filterConfig.state.selectedStates[4].checked = true;
        } else
          this.filterConfig.state.selectedStates[5].checked = true;
        this.filterApliedMethodCall();
      }
      if (this.state === "in process") {
        if (this.containerServiceObject.processType === 'Picking')
          this.filterConfig.state.selectedStates[1].checked = true;
        else if (this.containerServiceObject.processType === 'Packing') {
          this.filterConfig.state.selectedStates[2].checked = true;
        }
        else if (this.containerServiceObject.processType === 'Shipping') {
          this.filterConfig.state.selectedStates[3].checked = true;
        }
        else {
          this.filterConfig.state.selectedStates[1].checked = true;
          this.filterConfig.state.selectedStates[2].checked = true;
          this.filterConfig.state.selectedStates[3].checked = true;
          this.filterConfig.state.selectedStates[4].checked = true;
        }
        this.filterApliedMethodCall();
      }
      if (!this.state) {
        this.appliedFilterData = null;
        this.filterConfig.containerTypes.selectedStates[0].checked = true;
        this.getAllContainer(1, this.sortArgs, this.appliedFilterData, this.searchTxt, this.containerServiceObject);
      }
    });
  }

  getAllContainer(pageNumber: number, sortArgs: string, filterObj, searchTxt?: string, containerServiceObject?: any) {
    this.isLoading = true;
    this._service.getContainerData(pageNumber, this.pagerConfig.itemsPerPage, sortArgs, filterObj, this.state, searchTxt, containerServiceObject).subscribe((data) => {
      if (data) {
        this.setPagerConfig(data.totalElements, this.pagerConfig.currentPage, data.size)
        this.containersData = data.content;
      } else {
        this.setPagerConfig(0, this.pagerConfig.currentPage, this.pagerConfig.itemsPerPage)
        this.containersData = [];
      }
      this.isLoading = false;
    }, (err) => {

    });
  }
  setPagerConfig(totalItems, currentPage, itemsPerPage?) {
    this.pagerConfig = {
      totalItems: totalItems,
      currentPage: currentPage || 1,
      itemsPerPage: itemsPerPage || 10,
      smallnumPages: 0
    }
  }

  onPageSizeChanged(pageSize) {
    this.pagerConfig.itemsPerPage = pageSize;
    if (this.appliedFilterData) {
      this.getAllContainer(1, this.sortArgs, this.appliedFilterData, this.searchTxt, this.containerServiceObject);
    } else {
      this.getAllContainer(1, this.sortArgs, this.appliedFilterData, this.searchTxt, this.containerServiceObject);
    }
    this._cdr.detectChanges();
  }
  onPageChanged(pager) {
    this.pagerConfig.currentPage = pager.page;
    if (this.appliedFilterData) {
      this.getAllContainer(pager.page, this.sortArgs, this.appliedFilterData, this.searchTxt, this.containerServiceObject);
    } else {
      this.getAllContainer(pager.page, this.sortArgs, this.appliedFilterData, this.searchTxt, this.containerServiceObject);
    }
    this._cdr.detectChanges();
  }
  onSortChanged(sortArgs) {
    this.sortArgs = sortArgs[0] + "," + sortArgs[1];
    if (this.appliedFilterData) {
      this.getAllContainer(this.pagerConfig.currentPage, this.sortArgs, this.appliedFilterData, this.searchTxt, this.containerServiceObject);
    } else {
      this.getAllContainer(this.pagerConfig.currentPage, this.sortArgs, this.appliedFilterData, this.searchTxt, this.containerServiceObject);
    }
    this._cdr.detectChanges();
  }
  createFilterParams(): FilterParams {
    let params = new FilterParams(); // initialises to default on object creation
    params.state.selectedStates = [
      { text: "Active Pending", value: "ActivePending", checked: false },
      { text: "Picking Active", value: "PickingActive", checked: false },
      { text: "Picking Complete", value: "PickingComplete", checked: false },
      { text: "Packing Complete", value: "PackingComplete", checked: false },
      { text: "Ship Sort Complete", value: "ShipSortComplete", checked: false },
      { text: "Complete", value: "Complete", checked: false },
      { text: "Exception", value: "Exception", checked: false }
    ]
    params.containerTypes.selectedStates = [
      { text: "All", value: "All", checked: false },
      { text: "Pick", value: "Pick", checked: false },
      { text: "Pack", value: "Pack", checked: false },
      { text: "Ship", value: "Ship", checked: false }
    ]
    params.site.isVisible = false;
    params.actionSubSection.isChangeState = false;
    params.actionSubSection.isExportTo = false;
    params.baseMetric.isVisible = false;
    params.otherMetric.isVisible = false;
    return params;
  }
  onCheckBoxChecked(containerData, e) {
    if (e.target.checked == true) {
      this._service.selectedRoute.push(containerData)
    }
    else {
      this._service.selectedRoute.splice(this._service.selectedRoute.indexOf(containerData), 1);
    }
  }
  
  filterApplied(filterObj: FilterParams) {
    this.appliedFilterData = JSON.parse(JSON.stringify(filterObj));
    //todo: used from --- http://stackoverflow.com/questions/728360/how-do-i-correctly-clone-a-javascript-object    
    this.getAllContainer(this.pagerConfig.currentPage, this.sortArgs, filterObj, this.searchTxt, this.containerServiceObject);
  }
  clearFilters() {
    this.appliedFilterData = null;
    this.reSetFilterObject(this.filterConfig);
    this.getAllContainer(this.pagerConfig.currentPage, this.sortArgs, this.appliedFilterData, this.searchTxt, this.containerServiceObject);
  }
  onRemoveFilter(filterObj: FilterParams) {
    this.getAllContainer(this.pagerConfig.currentPage, this.sortArgs, filterObj, this.searchTxt, this.containerServiceObject);
  }

  applyFormatting(columns) {
    this.getAllContainer(this.pagerConfig.currentPage, this.sortArgs, this.appliedFilterData, this.searchTxt, this.containerServiceObject);
  }
  onSaveFilterClick(saveFilterObject: FilterParams) {
    if (this.appliedFilterData) {
      this.isLoading = true;
      if (saveFilterObject.saveFilterName.selectedValue && saveFilterObject.saveFilterName.selectedValue !== '') {
        if (saveFilterObject.filterId) {
          this.filterService.updateFilters('CONTAINERS', this.appliedFilterData).subscribe((res) => {
            this.noty.success(saveFilterObject.saveFilterName.selectedValue + " filter is updated successfully.");
            this.getSavedFilterDataList();
            this.resetDropDownOptions(saveFilterObject);
          }, err => {
            this.isLoading = false;
            this.noty.error(err);
          });
        } else {
          //new filter 
          this.filterService.saveNewFilters('CONTAINERS', this.appliedFilterData, saveFilterObject.saveFilterName.selectedValue).subscribe((res) => {
            this.noty.success(saveFilterObject.saveFilterName.selectedValue + " filter is saved successfully.");
            this.getSavedFilterDataList();
            this.resetDropDownOptions(saveFilterObject);
          }, err => {
            this.isLoading = false;
            if (err.status === 409)
              this.noty.error('Filter name is already exist');
            else
              this.noty.error(err);
          });
        }

      } else {
        this.noty.error("Please enter filter name.");
        this.isLoading = false;
      }
    } else
      this.noty.error("Please click on apply button to apply filters.");
  }
  onLoadFilterCall(loadFilterObj: FilterParams) {
    if (loadFilterObj.saveLoadFilter.selectedValue && loadFilterObj.saveLoadFilter.selectedValue !== '') {
      this.filterService.getLoadSaveFilterData('CONTAINERS', loadFilterObj.saveLoadFilter.selectedValue).then((res) => {
        if (res) {
          let result: FilterParams;
          result = JSON.parse(res.value)
          this.resetDropDownOptions(result);
          this.filterConfig = this.filterService.resetFilterObject(result);
          this.filterConfig.saveLoadFilter.options = this.loadSavedFilters;
          this.filterConfig.saveLoadFilter.selectedValue = loadFilterObj.saveLoadFilter.selectedValue;
          this.filterConfig.saveFilterName.selectedValue = loadFilterObj.saveLoadFilter.selectedValue;
          this.filterConfig.filterId = res.id;
          this.filterApplied(result);
          if (result.dateRange.from)
            this.setFilterDates(result.dateRange.from, result.dateRange.to);
        }
      }, err => {
        this.noty.error(err);
      });
    } else {
      this.clearFilters();
    }
  }

  resetDropDownOptions(saveFilterObject) {
    this.filterConfig = saveFilterObject;
    this.filterConfig.shift.options = this.allShift;
    this.filterConfig.shift.selectedValue = saveFilterObject.shift.selectedValue;
  }
  setFilterDates(fromDate, todate) {
    let dates: any = this.filterService.setDateForFilter(fromDate, todate);
    if (this.advanceFilter && this.advanceFilter.fromDatePicker && this.advanceFilter.fromDatePicker.datepickerObj) {
      this.advanceFilter.fromDatePicker.datepickerObj.selectDate([dates[0]]);
    }
    if (this.advanceFilter && this.advanceFilter.toDatePicker && this.advanceFilter.toDatePicker.datepickerObj) {
      this.advanceFilter.toDatePicker.datepickerObj.selectDate([dates[1]]);
    }
  }
  reSetFilterObject(filterObj) {
    for (var i = 0; i < filterObj.state.selectedStates; i++) {
      filterObj.state.selectedStates[i].checked = false;
    }
    for (var i = 0; i < filterObj.containerTypes; i++) {
      filterObj.state.containerTypes[i].checked = false;
    }
    if (filterObj.dateRange.from)
      this.setFilterDates(moment(new Date()).format("YYYY-MM-DDT00:00:00"), moment(new Date()).format("YYYY-MM-DDT23:59:59"));
    if (this.loadSavedFilters) {
      filterObj.saveLoadFilter.options = this.loadSavedFilters;
    }
    filterObj.shift.options = this.allShift;
    filterObj.containerTypes.selectedStates[0].checked = true;
    if (filterObj.shift.options) {
      filterObj.shift.selectedValue = this.filterConfig.shift.options[0].name;
    }
    filterObj.aging.from = 1;
    filterObj.aging.to = 30;
    filterObj.priority.from = 1;
    filterObj.priority.to = 100;
  }
}