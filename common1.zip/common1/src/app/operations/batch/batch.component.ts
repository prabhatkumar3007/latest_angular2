import { ActivatedRoute, Params } from '@angular/router';
import { ChangeDetectorRef, Component, Input, ViewChild } from '@angular/core';
import { FilterParams, ActionButtons } from 'sensorthink-commoncontrols/src/controls.module';
import { FormBuilder, FormGroup } from '@angular/forms';
import { FormComponent } from '../../shared/services/prevent-unsaved-changes-guard.service';
import { FormControl } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import { BatchService } from '../services/batch.service';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/throttleTime';
import 'rxjs/add/observable/fromEvent';
import { ShiftService } from './../../shared/services/shift.service';
import { ShareDataService } from "sensorthink-commoncontrols/src/services/shareDataService";
import { NotyService } from "sensorthink-commoncontrols/src/services/noty.service";
import { AdvanceFilterService } from "./../../shared/services/advanceFilter.service";
import { AdvancedFilterComponent } from "sensorthink-commoncontrols/src/components/advancedFilter/advancedFilter.component";
declare var moment: any;
@Component({
  templateUrl: 'batch.component.html'
})
export class BatchComponent {
  filterConfig: FilterParams;
  appliedFilterData: FilterParams;
  pagerConfig: any;
  sortArgs: string;
  isLoading: boolean = false;
  batchData: any;
  isFirstLoad: boolean = false;
  searchTxt = '';
  searchTxtControl = new FormControl();
  public sideBarVisible: boolean;
  public state: string;
  containerType: any;
  allShift: any;
  batchServiceObject = { processType: null, parentModule: null, groupBy: null };
  loadSavedFilters: any;
  @ViewChild(AdvancedFilterComponent) advanceFilter: AdvancedFilterComponent;

  constructor(private _service: BatchService, private _cdr: ChangeDetectorRef, private allShiftService: ShiftService, private activatedRoute: ActivatedRoute, private sharedService: ShareDataService, private noty: NotyService, private filterService: AdvanceFilterService) {
    this.sortArgs = "externalBatchId,asc";
    this.filterConfig = this.createFilterParams();
    this.pagerConfig = {
      totalItems: 64,
      currentPage: 1,
      smallnumPages: 0,
    }
  }

  ngOnInit() {
    this.searchTypeResult();
    this.setPagerConfig(0, 0);
    this.getSavedFilterDataList();
    this.allShiftService.getAllShift().then((res) => {
      this.allShift = res;
      this.filterConfig.shift.options = this.allShift;
      if (this.filterConfig.shift.options) {
        this.filterConfig.shift.selectedValue = this.filterConfig.shift.options[0].name;
      }
      this.checkActivatedRoute();
    })
  }
  getSavedFilterDataList() {
    this.filterService.getAllLoadSaveFilterData('BATCHES').then((res) => {
      this.loadSavedFilters = this.filterService.createFilterObjectFormat(res)
      if (this.loadSavedFilters) {
        this.filterConfig.saveLoadFilter.options = this.loadSavedFilters;
      }
      this.isLoading = false;
    })
  }
  searchTypeResult() {
    this.searchTxtControl.valueChanges
      .debounceTime(1000)
      .subscribe(newValue => {
        this.searchTxt = newValue.trim();
        if (((this.searchTxt.length >= 1 || this.searchTxt.length === 0) && this.searchTxt !== "") || this.isFirstLoad) {
          this.isFirstLoad = (this.searchTxt.length === 0) ? false : true;
          if (this.appliedFilterData) {
            this.getAllBatchData(this.pagerConfig.currentPage, this.sortArgs, this.appliedFilterData, this.searchTxt);
          } else {
            this.getAllBatchData(this.pagerConfig.currentPage, this.sortArgs, this.appliedFilterData, this.searchTxt);
          }
        }
      });
  }
  filterApliedMethodCall() {
    let fltr: FilterParams = JSON.parse(JSON.stringify(this.filterConfig));
    fltr.aging.from = null;
    fltr.aging.to = null;
    fltr.aging.fromSeconds = null;
    fltr.aging.toSeconds = null;
    fltr.priority.from = null;
    fltr.priority.to = null;
    this.filterApplied(fltr);
  }

  checkActivatedRoute() {
    this.activatedRoute.queryParams.subscribe((params) => {
      this.state = params['status'];
      this.batchServiceObject.processType = params['processType'];
      if (params['parentModule']) {
        this.batchServiceObject.parentModule = params['parentModule'];
        this.batchServiceObject.groupBy = 'parentModule';
      }

      if (!this.state) {
        this.getAllBatchData(1, this.sortArgs, this.appliedFilterData, this.searchTxt);
      }
    });
  }
  /**
   * Get call for All Batch Data.
   * @param pageNumber 
   * @param sortArgs 
   * @param filterObj filter object data containg required filter
   * @param searchTxt search input text
   */
  getAllBatchData(pageNumber: number, sortArgs: string, filterObj, searchTxt?: string) {
    this.isLoading = true;
    this._service.getBatchData(pageNumber, this.pagerConfig.itemsPerPage, sortArgs, filterObj, this.state, searchTxt).subscribe((data) => {
      if (data) {
        this.setPagerConfig(data.totalElements, this.pagerConfig.currentPage, data.size)
        this.batchData = data.content;
      } else {
        this.setPagerConfig(0, this.pagerConfig.currentPage, this.pagerConfig.itemsPerPage)
        this.batchData = [];
      }
      this.isLoading = false;
    }, (err) => {

    });
  }
  setPagerConfig(totalItems, currentPage, itemsPerPage?) {
    this.pagerConfig = {
      totalItems: totalItems,
      currentPage: currentPage || 1,
      itemsPerPage: itemsPerPage || 10,
      smallnumPages: 0
    }
  }

  onPageSizeChanged(pageSize) {
    this.pagerConfig.itemsPerPage = pageSize;
    if (this.appliedFilterData) {
      this.getAllBatchData(1, this.sortArgs, this.appliedFilterData, this.searchTxt);
    } else {
      this.getAllBatchData(1, this.sortArgs, this.appliedFilterData, this.searchTxt);
    }
    //this._cdr.detectChanges();
  }
  onPageChanged(pager) {
    this.pagerConfig.currentPage = pager.page;
    if (this.appliedFilterData) {
      this.getAllBatchData(pager.page, this.sortArgs, this.appliedFilterData, this.searchTxt);
    } else {
      this.getAllBatchData(pager.page, this.sortArgs, this.appliedFilterData, this.searchTxt);
    }
    //this._cdr.detectChanges();
  }
  onSortChanged(sortArgs) {
    this.sortArgs = sortArgs[0] + "," + sortArgs[1];
    if (this.appliedFilterData) {
      this.getAllBatchData(this.pagerConfig.currentPage, this.sortArgs, this.appliedFilterData, this.searchTxt);
    } else {
      this.getAllBatchData(this.pagerConfig.currentPage, this.sortArgs, this.appliedFilterData, this.searchTxt);
    }
    // this._cdr.detectChanges();
  }
  createFilterParams(): FilterParams {
    let params = new FilterParams(); // initialises to default on object creation
     params.state.selectedStates = [
      { text: "Active", value: "Active", checked: false },
      { text: "Picking Complete", value: "PickingComplete", checked: false },
      { text: "Complete", value: "Complete", checked: false }
    ]
    params.aging.isVisible = false;
    params.priority.isVisible = false;
    params.site.isVisible = false;
    params.baseMetric.isVisible = false;
    params.otherMetric.isVisible = false;
    params.shift.options = this.allShift;
    if (params.shift.options) {
      params.shift.selectedValue = params.shift.options[0].name;
    }
    params.dateRange.from = (this.sharedService.objectStore.fromDate) ? this.sharedService.objectStore.fromDate : moment(new Date()).format("YYYY-MM-DDT00:00:00");
    params.dateRange.to = (this.sharedService.objectStore.toDate) ? this.sharedService.objectStore.toDate : moment(new Date()).format("YYYY-MM-DDT23:59:59");
    if (this.loadSavedFilters) {
      params.saveLoadFilter.options = this.loadSavedFilters;
    }
    if (this.sharedService.objectStore.shiftValue)
      params.shift.selectedValue = this.sharedService.objectStore.shiftValue;
    return params;
  }
  filterApplied(filterObj: FilterParams) {
    this.appliedFilterData = JSON.parse(JSON.stringify(filterObj));
    //todo: used from --- http://stackoverflow.com/questions/728360/how-do-i-correctly-clone-a-javascript-object    
    this.getAllBatchData(this.pagerConfig.currentPage, this.sortArgs, filterObj, this.searchTxt);
  }
  clearFilters() {
    let dates:any;
    this.appliedFilterData = null;
    this.filterConfig = this.createFilterParams();
    if (this.filterConfig.dateRange.from)
      dates = this.filterService.setDateForFilter(this.filterConfig.dateRange.from, this.filterConfig.dateRange.to);
    if (this.advanceFilter && this.advanceFilter.fromDatePicker && this.advanceFilter.fromDatePicker.datepickerObj) {
      this.advanceFilter.fromDatePicker.datepickerObj.selectDate([dates[0]]);
    }
    if (this.advanceFilter && this.advanceFilter.toDatePicker && this.advanceFilter.toDatePicker.datepickerObj) {
      this.advanceFilter.toDatePicker.datepickerObj.selectDate([dates[1]]);
    }
    this.getAllBatchData(this.pagerConfig.currentPage, this.sortArgs, this.appliedFilterData, this.searchTxt);
  }
  onRemoveFilter(filterObj: FilterParams) {
    this.getAllBatchData(this.pagerConfig.currentPage, this.sortArgs, filterObj, this.searchTxt);
  }

  applyFormatting(columns) {
    this.getAllBatchData(this.pagerConfig.currentPage, this.sortArgs, this.appliedFilterData, this.searchTxt);
  }
  onSaveFilterClick(saveFilterObject: FilterParams) {
    if (this.appliedFilterData) {
      this.isLoading = true;
      if (saveFilterObject.saveFilterName.selectedValue && saveFilterObject.saveFilterName.selectedValue !== '') {
        if (saveFilterObject.filterId) {
          this.filterService.updateFilters('BATCHES', this.appliedFilterData).subscribe((res) => {
            this.noty.success(saveFilterObject.saveFilterName.selectedValue + " filter is updated successfully.");
            this.getSavedFilterDataList();
            this.resetDropDownOptions(saveFilterObject);
          }, err => {
            this.isLoading = false;
            this.noty.error(err);
          });
        } else {
          //new filter 
          this.filterService.saveNewFilters('BATCHES', this.appliedFilterData, saveFilterObject.saveFilterName.selectedValue).subscribe((res) => {
            this.noty.success(saveFilterObject.saveFilterName.selectedValue + " filter is saved successfully.");
            this.getSavedFilterDataList();
            this.resetDropDownOptions(saveFilterObject);
          }, err => {
            this.isLoading = false;
            if (err.status === 409)
              this.noty.error('Filter name is already exist');
            else
              this.noty.error(err);
          });
        }

      } else {
        this.noty.error("Please enter filter name.");
        this.isLoading = false;
      }
    } else
      this.noty.error("Please click on apply button to apply filters.");
  }
  onLoadFilterCall(loadFilterObj: FilterParams) {
    if (loadFilterObj.saveLoadFilter.selectedValue && loadFilterObj.saveLoadFilter.selectedValue !== '') {
      this.filterService.getLoadSaveFilterData('BATCHES', loadFilterObj.saveLoadFilter.selectedValue).then((res) => {
        if (res) {
          let result: FilterParams, dates:any;
          result = JSON.parse(res.value)
          this.resetDropDownOptions(result);
          this.filterConfig = this.filterService.resetFilterObject(result);
          this.filterConfig.saveLoadFilter.options = this.loadSavedFilters;
          this.filterConfig.saveLoadFilter.selectedValue = loadFilterObj.saveLoadFilter.selectedValue;
          this.filterConfig.saveFilterName.selectedValue = loadFilterObj.saveLoadFilter.selectedValue;
          this.filterConfig.filterId = res.id;
          this.filterApplied(result);
          if (result.dateRange.from)
            dates = this.filterService.setDateForFilter(result.dateRange.from, result.dateRange.to);
          if (this.advanceFilter && this.advanceFilter.fromDatePicker && this.advanceFilter.fromDatePicker.datepickerObj) {
            this.advanceFilter.fromDatePicker.datepickerObj.selectDate([dates[0]]);
          }
          if (this.advanceFilter && this.advanceFilter.toDatePicker && this.advanceFilter.toDatePicker.datepickerObj) {            
              this.advanceFilter.toDatePicker.datepickerObj.selectDate([dates[1]]);
          }
        }
      }, err => {
        this.noty.error(err);
      });
    } else {
      this.clearFilters();
    }
  }
   resetDropDownOptions(saveFilterObject) {
    this.filterConfig = saveFilterObject;
    this.filterConfig.shift.options = this.allShift;
    this.filterConfig.shift.selectedValue = saveFilterObject.shift.selectedValue;
  }
}