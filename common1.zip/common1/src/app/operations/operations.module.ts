import { CommonModule } from '@angular/common';
import { ControlsModule } from '../controls/controls.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { LoginComponent } from '../login.component';
import { NgModule } from '@angular/core';
import { OrderDetailsComponent } from './orders/orderDetails.component';
import { OrdersComponent } from './orders/orders.component';
import { BatchComponent } from './batch/batch.component';
import { TaskComponent } from './tasks/task.component';
import { OrdersService } from './services/orders.service';
import { BatchService } from './services/batch.service';
import { TaskService } from './services/task.service';
import { ContainersComponent } from './containers/containers.component';
import { ContainersDetailsComponent } from './containers/containersDetails.component';

import { ContainersService } from './services/containers.service';
import { RouterModule } from '@angular/router';
import { SharedModule } from '../shared/shared.module';

import { TitleFormatter } from '../shared/components/titleFormatter.pipe';
import { WavesComponent } from './waves/waves.component';
import { WavesService } from './services/waves.service';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule,
    ControlsModule,
    SharedModule
  ],
  declarations: [
    ContainersComponent,
    ContainersDetailsComponent,  
    BatchComponent, 
    TaskComponent, 
    OrdersComponent,
    OrderDetailsComponent,
    WavesComponent,
    TitleFormatter
  ],
  exports: [
    ContainersComponent,
    ContainersDetailsComponent,
    BatchComponent,
    TaskComponent,
    OrdersComponent,
    OrderDetailsComponent,
    WavesComponent,
    TitleFormatter
  ],
  providers: [
    ContainersService,
    OrdersService,
    WavesService,
    BatchService,
    TaskService,
    LoginComponent
  ]
})
export class OperationsModule {

}