import { ActivatedRoute, Params } from '@angular/router';
import { ChangeDetectorRef, Component, Input, ViewChild } from '@angular/core';
import { FilterParams, ActionButtons } from 'sensorthink-commoncontrols/src/controls.module';
import { FormBuilder, FormGroup } from '@angular/forms';
import { FormComponent } from '../../shared/services/prevent-unsaved-changes-guard.service';
import { FormControl } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import { TaskService } from '../services/task.service';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/throttleTime';
import 'rxjs/add/observable/fromEvent';
import { ShiftService } from './../../shared/services/shift.service';
import { AdvanceFilterService } from './../../shared/services/advanceFilter.service';
import { ShareDataService } from "sensorthink-commoncontrols/src/services/shareDataService";
import { NotyService } from "sensorthink-commoncontrols/src/services/noty.service";
import { AdvancedFilterComponent } from "sensorthink-commoncontrols/src/components/advancedFilter/advancedFilter.component";
declare var moment: any;
@Component({
  templateUrl: 'task.component.html'
})
export class TaskComponent {
  filterConfig: FilterParams;
  appliedFilterData: FilterParams;
  pagerConfig: any;
  sortArgs: string;
  isLoading: boolean = false;
  taskData: any;
  isFirstLoad: boolean = false;
  searchTxt = '';
  searchTxtControl = new FormControl();
  public sideBarVisible: boolean;
  public state: string;
  loadSavedFilters: any;
  containerType: any;
  allShift: any;
  allBatches: any;
  allContainers: any;
  allVirtualContainers: any;
  taskServiceObject = {
    "processType": null,
    "groupBy": null,
    "batchId": null
  };
  containerTypeList: any = [{ name: 'All', containerType: 'All' }, { name: 'Pick', containerType: 'Pick' }, { name: 'Pack', containerType: 'Pack' }, { name: 'Ship', containerType: 'Ship' }]
  taskTypeList: any = [{ name: 'All', taskType: 'All' }, { name: 'DISCRETE_PICK', taskType: 'DISCRETE_PICK' }, { name: 'BATCH_PICK', taskType: 'BATCH_PICK' }, { name: 'BATCH_PUT', taskType: 'BATCH_PUT' }]
  @ViewChild(AdvancedFilterComponent) advanceFilter: AdvancedFilterComponent;

  constructor(private _service: TaskService, private _cdr: ChangeDetectorRef, private allShiftService: ShiftService, private allFilterService: AdvanceFilterService, private activatedRoute: ActivatedRoute, private sharedService: ShareDataService, private noty: NotyService, private filterService: AdvanceFilterService) {
    this.sortArgs = "externalBatchId, asc";
    this.containerType = this.containerTypeList[0].name;
    this.filterConfig = this.createFilterParams();
    this.pagerConfig = {
      totalItems: 64,
      currentPage: 1,
      smallnumPages: 0,
    }
  }

  ngOnInit() {
    this.searchTypeResult();
    this.setPagerConfig(0, 0);
    this.getSavedFilterDataList();
    this._service.getAllFilterExternalBatchIds().then((res) => {
      this.allBatches = this.objectMapping(res);
      this.filterConfig.extBatchContainer.options = this.allBatches;
    })
    this._service.getAllFilterContainerIds().then((res) => {
      this.allContainers = this.objectMapping(res);
      this.filterConfig.containerIds.options = this.allContainers;
    })
    this._service.getAllFilterVirtualContainerIds().then((res) => {
      this.allVirtualContainers = this.objectMapping(res);
      this.filterConfig.virtualContainetIds.options = this.allVirtualContainers;
    })
    this.allShiftService.getAllShift().then((res) => {
      this.allShift = res;
      this.filterConfig.shift.options = this.allShift;
      if (this.filterConfig.shift.options) {
        this.filterConfig.shift.selectedValue = this.filterConfig.shift.options[0].name;
      }
      this.checkActivatedRoute();
    })
  }
  getSavedFilterDataList() {
    this.filterService.getAllLoadSaveFilterData('TASKS').then((res) => {
      this.loadSavedFilters = this.filterService.createFilterObjectFormat(res)
      if (this.loadSavedFilters) {
        this.filterConfig.saveLoadFilter.options = this.loadSavedFilters;
      }
      this.isLoading = false;
    })
  }
  objectMapping(array) {
    let a = [];
    if (array) {
      for (var i = 0; i < array.length; i++) {
        a.push({ name: array[i], type: array[i] })
      }
    }
    return a;
  }
  searchTypeResult() {
    this.searchTxtControl.valueChanges
      .debounceTime(1000)
      .subscribe(newValue => {
        this.searchTxt = newValue.trim();
        if (((this.searchTxt.length >= 1 || this.searchTxt.length === 0) && this.searchTxt !== "") || this.isFirstLoad) {
          this.isFirstLoad = (this.searchTxt.length === 0) ? false : true;
          if (this.appliedFilterData) {
            this.getAllTaskData(this.pagerConfig.currentPage, this.sortArgs, this.appliedFilterData, this.searchTxt, this.taskServiceObject);
          } else {
            this.getAllTaskData(this.pagerConfig.currentPage, this.sortArgs, this.appliedFilterData, this.searchTxt, this.taskServiceObject);
          }
        }
      });
  }
  filterApliedMethodCall() {
    let fltr: FilterParams = JSON.parse(JSON.stringify(this.filterConfig));
    fltr.aging.from = null;
    fltr.aging.to = null;
    fltr.aging.fromSeconds = null;
    fltr.aging.toSeconds = null;
    fltr.priority.from = null;
    fltr.priority.to = null;
    this.filterApplied(fltr);
  }

  checkActivatedRoute() {
    this.activatedRoute.queryParams.subscribe((params) => {
      this.state = params['status'];
      this.taskServiceObject.processType = params['processType'];
      this.taskServiceObject.groupBy = params['groupBy'];
      this.taskServiceObject.batchId = params['batchId'];
      if (params['batchId']) {
        this.filterConfig.extBatchContainer.selectedValue = params['batchId'];
        this.filterApliedMethodCall();
      }
      if (!this.state) {
        this.getAllTaskData(1, this.sortArgs, this.appliedFilterData, this.searchTxt, this.taskServiceObject);
      }
    });
  }
  getAllTaskData(pageNumber: number, sortArgs: string, filterObj, searchTxt?: string, taskServiceObject?: any) {
    this.isLoading = true;
    this._service.getTaskData(pageNumber, this.pagerConfig.itemsPerPage, sortArgs, filterObj, this.state, searchTxt, taskServiceObject).subscribe((data) => {
      if (data) {
        this.setPagerConfig(data.totalElements, this.pagerConfig.currentPage, data.size)
        this.taskData = data.content;
      } else {
        this.setPagerConfig(0, this.pagerConfig.currentPage, this.pagerConfig.itemsPerPage)
        this.taskData = [];
      }
      this.isLoading = false;
    }, (err) => {

    });
  }
  setPagerConfig(totalItems, currentPage, itemsPerPage?) {
    this.pagerConfig = {
      totalItems: totalItems,
      currentPage: currentPage || 1,
      itemsPerPage: itemsPerPage || 10,
      smallnumPages: 0
    }
  }

  onPageSizeChanged(pageSize) {
    this.pagerConfig.itemsPerPage = pageSize;
    if (this.appliedFilterData) {
      this.getAllTaskData(1, this.sortArgs, this.appliedFilterData, this.searchTxt, this.taskServiceObject);
    } else {
      this.getAllTaskData(1, this.sortArgs, this.appliedFilterData, this.searchTxt, this.taskServiceObject);
    }
    // this._cdr.detectChanges();
  }
  onPageChanged(pager) {
    this.pagerConfig.currentPage = pager.page;
    if (this.appliedFilterData) {
      this.getAllTaskData(pager.page, this.sortArgs, this.appliedFilterData, this.searchTxt, this.taskServiceObject);
    } else {
      this.getAllTaskData(pager.page, this.sortArgs, this.appliedFilterData, this.searchTxt, this.taskServiceObject);
    }
    //this._cdr.detectChanges();
  }
  onSortChanged(sortArgs) {
    this.sortArgs = sortArgs[0] + "," + sortArgs[1];
    if (this.appliedFilterData) {
      this.getAllTaskData(this.pagerConfig.currentPage, this.sortArgs, this.appliedFilterData, this.searchTxt, this.taskServiceObject);
    } else {
      this.getAllTaskData(this.pagerConfig.currentPage, this.sortArgs, this.appliedFilterData, this.searchTxt, this.taskServiceObject);
    }
    // this._cdr.detectChanges();
  }
  createFilterParams(): FilterParams {
    let params = new FilterParams(); // initialises to default on object creation
    params.state.selectedStates = [
      { text: "Created", value: "created", checked: false },
      { text: "Sent", value: "sent", checked: false },
      { text: "Active", value: "Active", checked: false },
      { text: "Complete", value: "Complete", checked: false }
    ]
    params.site.isVisible = false;
    params.baseMetric.isVisible = false;
    params.priority.isVisible = false;
    params.otherMetric.isVisible = false;
    params.user.isVisible = true;
    params.extBatchContainer.isVisible = true;
    params.containerIds.isVisible = true;
    params.virtualContainetIds.isVisible = true;
    params.taskType.isVisible = true;
    params.taskType.options = this.taskTypeList;
    if (params.taskType.options) {
      params.taskType.selectedValue = params.taskType.options[0].name;
    }
    params.shift.options = this.allShift;
    params.extBatchContainer.options = this.allBatches;
    params.containerIds.options = this.allContainers;
    params.virtualContainetIds.options = this.allVirtualContainers;
    if (params.shift.options) {
      params.shift.selectedValue = params.shift.options[0].name;
    }
    params.dateRange.from = (this.sharedService.objectStore.fromDate) ? this.sharedService.objectStore.fromDate : moment(new Date()).format("YYYY-MM-DDT00:00:00");
    params.dateRange.to = (this.sharedService.objectStore.toDate) ? this.sharedService.objectStore.toDate : moment(new Date()).format("YYYY-MM-DDT23:59:59");
    if (this.loadSavedFilters) {
      params.saveLoadFilter.options = this.loadSavedFilters;
    }
    if (this.sharedService.objectStore.shiftValue)
      params.shift.selectedValue = this.sharedService.objectStore.shiftValue;

    return params;
  }
  filterApplied(filterObj: FilterParams) {
    this.appliedFilterData = JSON.parse(JSON.stringify(filterObj));
    //todo: used from --- http://stackoverflow.com/questions/728360/how-do-i-correctly-clone-a-javascript-object    
    this.getAllTaskData(this.pagerConfig.currentPage, this.sortArgs, filterObj, this.searchTxt, this.taskServiceObject);
  }
  clearFilters() {
    let dates:any;
    this.appliedFilterData = null;
    this.filterConfig = this.createFilterParams();
    if (this.filterConfig.dateRange.from)
      dates = this.filterService.setDateForFilter(this.filterConfig.dateRange.from, this.filterConfig.dateRange.to);
    if (this.advanceFilter && this.advanceFilter.fromDatePicker && this.advanceFilter.fromDatePicker.datepickerObj) {
      this.advanceFilter.fromDatePicker.datepickerObj.selectDate([dates[0]]);
    }
    if (this.advanceFilter && this.advanceFilter.toDatePicker && this.advanceFilter.toDatePicker.datepickerObj) {
      this.advanceFilter.toDatePicker.datepickerObj.selectDate([dates[1]]);
    }
    this.getAllTaskData(this.pagerConfig.currentPage, this.sortArgs, this.appliedFilterData, this.searchTxt, this.taskServiceObject);
  }
  onRemoveFilter(filterObj: FilterParams) {
    this.getAllTaskData(this.pagerConfig.currentPage, this.sortArgs, filterObj, this.searchTxt, this.taskServiceObject);
  }

  applyFormatting(columns) {
    this.getAllTaskData(this.pagerConfig.currentPage, this.sortArgs, this.appliedFilterData, this.searchTxt, this.taskServiceObject);
  }
  onSaveFilterClick(saveFilterObject: FilterParams) {
    if (this.appliedFilterData) {
      this.isLoading = true;
      if (saveFilterObject.saveFilterName.selectedValue && saveFilterObject.saveFilterName.selectedValue !== '') {
        if (saveFilterObject.filterId) {
          this.filterService.updateFilters('TASKS', this.appliedFilterData).subscribe((res) => {
            this.noty.success(saveFilterObject.saveFilterName.selectedValue + " filter is updated successfully.");
            this.getSavedFilterDataList();
            this.resetDropDownOptions(saveFilterObject);
          }, err => {
            this.isLoading = false;
            this.noty.error(err);
          });
        } else {
          //new filter 
          this.filterService.saveNewFilters('TASKS', this.appliedFilterData, saveFilterObject.saveFilterName.selectedValue).subscribe((res) => {
            this.noty.success(saveFilterObject.saveFilterName.selectedValue + " filter is saved successfully.");
            this.getSavedFilterDataList();
            this.resetDropDownOptions(saveFilterObject);
          }, err => {
            this.isLoading = false;
            if (err.status === 409)
              this.noty.error('Filter name is already exist');
            else
              this.noty.error(err);
          });
        }

      } else {
        this.noty.error("Please enter filter name.");
        this.isLoading = false;
      }
    } else
      this.noty.error("Please click on apply button to apply filters.");
  }
  onLoadFilterCall(loadFilterObj: FilterParams) {
    if (loadFilterObj.saveLoadFilter.selectedValue && loadFilterObj.saveLoadFilter.selectedValue !== '') {
      this.filterService.getLoadSaveFilterData('TASKS', loadFilterObj.saveLoadFilter.selectedValue).then((res) => {
        if (res) {
          let result: FilterParams, dates: any;
          result = JSON.parse(res.value)
          this.resetDropDownOptions(result);
          this.filterConfig = this.filterService.resetFilterObject(result);
          this.filterConfig.saveLoadFilter.options = this.loadSavedFilters;
          this.filterConfig.saveLoadFilter.selectedValue = loadFilterObj.saveLoadFilter.selectedValue;
          this.filterConfig.saveFilterName.selectedValue = loadFilterObj.saveLoadFilter.selectedValue;
          this.filterConfig.filterId = res.id;
          this.filterApplied(result);
          if (result.dateRange.from)
            dates = this.filterService.setDateForFilter(result.dateRange.from, result.dateRange.to);
          if (this.advanceFilter && this.advanceFilter.fromDatePicker && this.advanceFilter.fromDatePicker.datepickerObj) {
            this.advanceFilter.fromDatePicker.datepickerObj.selectDate([dates[0]]);
          }
          if (this.advanceFilter && this.advanceFilter.toDatePicker && this.advanceFilter.toDatePicker.datepickerObj) {
            this.advanceFilter.toDatePicker.datepickerObj.selectDate([dates[1]]);
          }
        }
      }, err => {
        this.noty.error(err);
      });
    } else {
      this.clearFilters();
    }
  }
  resetDropDownOptions(saveFilterObject) {
    this.filterConfig = saveFilterObject;
    this.filterConfig.shift.options = this.allShift;
    this.filterConfig.shift.selectedValue = saveFilterObject.shift.selectedValue;
    this.filterConfig.extBatchContainer.options = this.allBatches;
    this.filterConfig.extBatchContainer.selectedValue = saveFilterObject.extBatchContainer.selectedValue;
    this.filterConfig.containerIds.options = this.allContainers;
    this.filterConfig.containerIds.selectedValue = saveFilterObject.containerIds.selectedValue;
    this.filterConfig.taskType.options = this.taskTypeList;
    this.filterConfig.taskType.selectedValue = saveFilterObject.taskType.selectedValue;
  }
}