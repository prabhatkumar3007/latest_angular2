import { ComponentFixture, TestBed, async, tick, fakeAsync } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';
import { Component } from '@angular/core';
import { WavesComponent } from './waves.component';
import { OperationsModule } from '../operations.module'
import { WavesService } from '../services/waves.service';
import { Observable } from 'rxjs/Observable';
import { Router } from '@angular/router';
import { FormControl } from '@angular/forms';
import { FilterParams } from "sensorthink-commoncontrols/src/controls.module";

class FakeOrdersService {
  getWaveData(): Observable<any> {
    return Observable.of({ content: [{}], totalElements: 0 });
  }
}
class RouterStub {
  navigateByUrl(url: string) { return url; }
}
describe('Waves Component', () => {
  let comp: WavesComponent;
  let fixture: ComponentFixture<WavesComponent>;
  let de: DebugElement;
  let el: HTMLElement;
  let _service;
  let filterObj = new FilterParams();

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [OperationsModule],
      providers: [{ provide: WavesService, useClass: FakeOrdersService },
      { provide: Router, useClass: RouterStub }
      ]
    })

    fixture = TestBed.overrideComponent(WavesComponent, {
      set: {
        template: '<span>{{message}}</span>'
      }
    }).createComponent(WavesComponent);
    comp = fixture.componentInstance;
    _service = fixture.debugElement.injector.get(WavesService);
  });
  it('Should have defined component', () => {
    expect(comp).toBeDefined();
  });
  describe('When we call getAllWaves', () => {
    it('should get all orders data', () => {
      spyOn(_service, 'getWaveData').and.callThrough();
      spyOn(comp, 'setPagerConfig');
      comp.getAllWaves(1, '', {});
      expect(comp.setPagerConfig).toHaveBeenCalled();
      expect(comp.waveData.length).toBe(1);
      expect(comp.isLoading).toBe(false)
    })
  });
  describe('When we call setPagerConfig', () => {
    it(' should set the pager config', () => {
      comp.setPagerConfig(10, 1, 5);
      expect(comp.pagerConfig.totalItems).toBe(10);
      expect(comp.pagerConfig.currentPage).toBe(1);
      expect(comp.pagerConfig.itemsPerPage).toBe(5);
    })
  });
  describe('search box spec', () => {
    let input, isFirstLoad = true, date1, date2;
    beforeEach(function () {
      input = comp.searchTxt;
      comp.setPagerConfig(10, 1, 1);
    });
    it(' should set to a valid search text', fakeAsync(() => {
      spyOn(comp, 'getAllWaves');
      comp.searchTypeResult()
      expect(comp.searchTxt).toBe(input);
      tick(1000);
      fixture.detectChanges();
      expect(comp.getAllWaves).toHaveBeenCalled();
    }))
    it(' should be first load', () => {
      comp.searchTypeResult()
      expect(comp.isFirstLoad).toBeFalsy();
    })
  });
  describe('When we call onPageSizeChanged, onPageChanged, onSortChanged', () => {
    beforeEach(() => {
      comp.setPagerConfig(10, 1, 1);
    })
    it(' should change the size of page with more orders data', () => {
      spyOn(comp, 'getAllWaves');
      comp.onPageSizeChanged(10);
      expect(comp.pagerConfig.itemsPerPage).toBe(10);
      expect(comp.getAllWaves).toHaveBeenCalled();
    })
    it(' should change the page with next orders data', () => {
      let pager = { page: 2 }
      spyOn(comp, 'getAllWaves');
      comp.onPageChanged(pager);
      expect(comp.pagerConfig.currentPage).toBe(2);
      expect(comp.getAllWaves).toHaveBeenCalled();

    })
    it(' should get sorted orders data', () => {
      let args = ['firstName', 'asc']
      spyOn(comp, 'getAllWaves');
      comp.onSortChanged(args);
      expect(comp.sortArgs).toBe('firstName,asc');
      expect(comp.getAllWaves).toHaveBeenCalled();
    })
  });
  describe('When we call filterApplied,onRemoveFilter,clearFilters', () => {
    beforeEach(() => {
      comp.setPagerConfig(10, 1, 1);
      spyOn(comp, 'getAllWaves');
    })
    it(' should check for applied filter data', () => {
      let item = { currentPage: 1, sortArgs: '', filterObj: filterObj }
      comp.filterApplied(filterObj);
      expect(comp.getAllWaves).toHaveBeenCalled();
    })
    it(' should remove selected applied filter data', () => {
      let item = { currentPage: 1, sortArgs: '', filterObj: filterObj }
      comp.onRemoveFilter(filterObj);
      expect(comp.getAllWaves).toHaveBeenCalled();
    })
    it(' should clear selected applied filter data', () => {
      let item = { currentPage: 1, sortArgs: '', filterObj: filterObj }
      filterObj = null;
      comp.clearFilters();
      expect(comp.getAllWaves).toHaveBeenCalled();
    })
  });
});