import { ActivatedRoute } from '@angular/router';
import 'rxjs/add/operator/debounceTime';
import { WavesService } from '../services/waves.service';
import { ChangeDetectorRef, Component, OnInit, ViewChild } from '@angular/core';
import { FormControl } from '@angular/forms';
import { FilterParams } from 'sensorthink-commoncontrols/src/controls.module';
import { NotyService } from 'sensorthink-commoncontrols/src/services/noty.service';
import { AdvanceFilterService } from '../../shared/services/advanceFilter.service';
import { DatePickerComponent } from "sensorthink-commoncontrols/src/components/datepicker/datepicker.component";
import { AdvancedFilterComponent } from "sensorthink-commoncontrols/src/components/advancedFilter/advancedFilter.component";
declare var moment: any;
@Component({
  selector: 'messages',
  templateUrl: 'waves.component.html'
})
export class WavesComponent implements OnInit {
  public filterConfig: FilterParams;
  public appliedFilterData: FilterParams;
  public pagerConfig: any;
  public sortArgs: string;
  public isLoading: boolean = false;
  public waveData: any;
  public onCheckBoxChecked: any;
  public sideBarVisible: boolean;
  public loadSavedFilters: any;
  @ViewChild(AdvancedFilterComponent) advanceFilter: AdvancedFilterComponent;

  isFirstLoad: boolean = false;
  searchTxt = '';
  searchTxtControl = new FormControl();
  constructor(private _service: WavesService, private _cdr: ChangeDetectorRef, private route: ActivatedRoute, private noty: NotyService, private filterService: AdvanceFilterService) {
    this.sortArgs = "waveId,asc";
    this.filterConfig = this.createFilterParams();

    this.pagerConfig = {
      totalItems: 64,
      currentPage: 1,
      smallnumPages: 0,
    }
  }
  setPagerConfig(totalItems, currentPage, itemsPerPage?) {
    this.pagerConfig = {
      totalItems: totalItems,
      currentPage: currentPage || 1,
      itemsPerPage: itemsPerPage || 10,
      smallnumPages: 0
    }
  }
  ngOnInit() {
    this.searchTypeResult();
    this.setPagerConfig(0, 0);
    this.getSavedFilterDataList();
    this.route.queryParams.subscribe(params => {
      if (params['waveId']) {
        this.searchTxt = params['waveId']
        this.getAllWaves(1, this.sortArgs, this.appliedFilterData, this.searchTxt);
      }
      else
        this.getAllWaves(1, this.sortArgs, this.appliedFilterData);
    }, err => {
      this.noty.error(err);
    });
  }
  getSavedFilterDataList() {
    this.filterService.getAllLoadSaveFilterData('WAVES').then((res) => {
      this.loadSavedFilters = this.filterService.createFilterObjectFormat(res)
      if (this.loadSavedFilters) {
        this.filterConfig.saveLoadFilter.options = this.loadSavedFilters;
      }
      this.isLoading = false;
    })
  }
  searchTypeResult() {
    this.searchTxtControl.valueChanges
      .debounceTime(1000)
      .subscribe(newValue => {
        this.searchTxt = newValue.trim();
        if (((this.searchTxt.length >= 1 || this.searchTxt.length === 0) && this.searchTxt !== "") || this.isFirstLoad) {
          this.isFirstLoad = (this.searchTxt.length === 0) ? false : true;
          if (this.appliedFilterData) {
            this.getAllWaves(this.pagerConfig.currentPage, this.sortArgs, this.appliedFilterData, this.searchTxt);
          } else {
            this.getAllWaves(this.pagerConfig.currentPage, this.sortArgs, this.appliedFilterData, this.searchTxt);
          }
        }
      }, err => {
        this.noty.error(err);
      });
  }
  getAllWaves(pageNumber: number, sortArgs: string, filterObj, searchTxt?: string) {
    this.isLoading = true;
    this._service.getWaveData(pageNumber, this.pagerConfig.itemsPerPage, sortArgs, filterObj, searchTxt).subscribe((waves) => {
      if (waves) {
        this.setPagerConfig(waves.totalElements, waves.totalPages, waves.size)
        this.waveData = waves.content;
      } else {
        this.setPagerConfig(0, this.pagerConfig.currentPage, this.pagerConfig.itemsPerPage)
        this.waveData = [];
      }
      this.isLoading = false;
    }, err => {
      this.noty.error(err);
      this.isLoading = false;
    });
  }
  onPageSizeChanged(pageSize) {
    this.pagerConfig.itemsPerPage = pageSize;

    if (this.appliedFilterData) {
      this.getAllWaves(1, this.sortArgs, this.appliedFilterData);
    } else {
      this.getAllWaves(1, this.sortArgs, this.appliedFilterData);
    }
    this._cdr.detectChanges();
  }
  onPageChanged(pager) {
    this.pagerConfig.currentPage = pager.page;
    if (this.appliedFilterData) {
      this.getAllWaves(pager.page, this.sortArgs, this.appliedFilterData);
    } else {
      this.getAllWaves(pager.page, this.sortArgs, this.appliedFilterData);
    }
  }
  onSortChanged(sortArgs) {
    this.sortArgs = sortArgs[0] + "," + sortArgs[1];
    if (this.appliedFilterData) {
      this.getAllWaves(this.pagerConfig.currentPage, this.sortArgs, this.appliedFilterData, this.searchTxt);
    } else {
      this.getAllWaves(this.pagerConfig.currentPage, this.sortArgs, this.appliedFilterData, this.searchTxt);
    }
  }
  createFilterParams(): FilterParams {
    let params = new FilterParams();
    params.state.selectedStates = [
      { text: "Active Pending", value: "ActivePending", checked: false },
      { text: "Active", value: "Active", checked: false },
      { text: "Complete", value: "Complete", checked: false }
    ]
    params.columns = ['waveId', 'priority', 'state', 'status', 'orderQuantity', 'agedTime', 'createdTime',]
    params.site.isVisible = false;
    params.baseMetric.isVisible = false;
    params.otherMetric.isVisible = false;
    params.shift.isVisible = false;
    params.dateRange.from = moment(new Date()).format("YYYY-MM-DDT00:00:00");
    params.dateRange.to = moment(new Date()).format("YYYY-MM-DDT23:59:59");
    if (this.loadSavedFilters) {
      params.saveLoadFilter.options = this.loadSavedFilters;
    }
    return params;
  }
  filterApplied(filterObj: FilterParams) {
    this.appliedFilterData = JSON.parse(JSON.stringify(filterObj));
    //todo: used from --- http://stackoverflow.com/questions/728360/how-do-i-correctly-clone-a-javascript-object    
    this.getAllWaves(this.pagerConfig.currentPage, this.sortArgs, filterObj, this.searchTxt);
  }
  onSaveFilterClick(saveFilterObject: FilterParams) {
    if (this.appliedFilterData) {
      this.isLoading = true;
      if (saveFilterObject.saveFilterName.selectedValue && saveFilterObject.saveFilterName.selectedValue !== '') {
        if (saveFilterObject.filterId) {
          this.filterService.updateFilters('WAVES', this.appliedFilterData).subscribe((res) => {
            this.noty.success(saveFilterObject.saveFilterName.selectedValue + " filter is updated successfully.");
            this.getSavedFilterDataList();
            this.filterConfig = saveFilterObject;
          }, err => {
            this.isLoading = false;
            this.noty.error(err);
          });
        } else {
          //new filter 
          this.filterService.saveNewFilters('WAVES', this.appliedFilterData, saveFilterObject.saveFilterName.selectedValue).subscribe((res) => {
            this.noty.success(saveFilterObject.saveFilterName.selectedValue + " filter is saved successfully.");
            this.getSavedFilterDataList();
            this.filterConfig = saveFilterObject;
          }, err => {
            this.isLoading = false;
            if (err.status === 409)
              this.noty.error('Filter name is already exist');
            else
              this.noty.error(err);
          });
        }
      } else {
        this.noty.error("Please enter filter name.");
        this.isLoading = false;
      }
    } else
      this.noty.error("Please click on apply button to apply filters.");
  }
  onLoadFilterCall(loadFilterObj: FilterParams) {
    if (loadFilterObj.saveLoadFilter.selectedValue && loadFilterObj.saveLoadFilter.selectedValue !== '') {
      this.filterService.getLoadSaveFilterData('WAVES', loadFilterObj.saveLoadFilter.selectedValue).then((res) => {
        if (res) {
          let dates: any, result: FilterParams;
          result = JSON.parse(res.value);
          this.filterConfig = this.filterService.resetFilterObject(result);
          this.filterConfig.saveLoadFilter.options = this.loadSavedFilters;
          this.filterConfig.saveLoadFilter.selectedValue = loadFilterObj.saveLoadFilter.selectedValue;
          this.filterConfig.saveFilterName.selectedValue = loadFilterObj.saveLoadFilter.selectedValue;
          this.filterConfig.filterId = res.id;
          this.filterApplied(result);
          if (result.dateRange.from)
            dates = this.filterService.setDateForFilter(result.dateRange.from, result.dateRange.to);
          if (this.advanceFilter && this.advanceFilter.fromDatePicker && this.advanceFilter.fromDatePicker.datepickerObj) {
            this.advanceFilter.fromDatePicker.datepickerObj.selectDate([dates[0]]);
          }
          if (this.advanceFilter && this.advanceFilter.toDatePicker && this.advanceFilter.toDatePicker.datepickerObj) {
            this.advanceFilter.toDatePicker.datepickerObj.selectDate([dates[1]]);
          }
        }
      }, err => {
        this.noty.error(err);
      });
    } else {
      this.clearFilters();
    }
  }

  clearFilters() {
    let dates:any;
    this.appliedFilterData = null;
    this.filterConfig = this.createFilterParams();
    if (this.filterConfig.dateRange.from)
      dates = this.filterService.setDateForFilter(this.filterConfig.dateRange.from, this.filterConfig.dateRange.to);
    if (this.advanceFilter && this.advanceFilter.fromDatePicker && this.advanceFilter.fromDatePicker.datepickerObj) {
      this.advanceFilter.fromDatePicker.datepickerObj.selectDate([dates[0]]);
    }
    if (this.advanceFilter && this.advanceFilter.toDatePicker && this.advanceFilter.toDatePicker.datepickerObj) {
      this.advanceFilter.toDatePicker.datepickerObj.selectDate([dates[1]]);
    }
    this.getAllWaves(this.pagerConfig.currentPage, this.sortArgs, this.appliedFilterData, this.searchTxt);
  }
  onRemoveFilter(filterObj: FilterParams) {
    this.getAllWaves(this.pagerConfig.currentPage, this.sortArgs, filterObj, this.searchTxt);
  }

  sideBarToggle(state) {
    if (state) {
      setTimeout(() => {
        let waveData = JSON.parse(JSON.stringify(this.waveData));
        this.waveData = [];
        this.waveData = waveData;
      }, 450);
    }
  }

  applyFormatting(columns) {
    this.getAllWaves(this.pagerConfig.currentPage, this.sortArgs, this.appliedFilterData, this.searchTxt);
  }
}