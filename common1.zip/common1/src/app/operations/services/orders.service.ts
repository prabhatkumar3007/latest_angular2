import { Injectable } from '@angular/core';
import { HttpService } from 'sensorthink-commoncontrols/src/common.module';
import { UtilService } from 'sensorthink-commoncontrols/src/services/util.service';

@Injectable()
export class OrdersService {
  isException:boolean;
  constructor(private $http: HttpService, private utilService: UtilService) { }

  getOrderData(pageNumber?: number, pageSize?: number, sortArgs?: string, filterObj?: any, state?: string, searchText: string = "", orderServiceObject?: any) {
    //get data of orders
    let sortArg = sortArgs.split(",");
    let order: any;
    this.isException = false;

    if (!filterObj) {
      order = {
        "startDate": null,
        "endDate": null,
        "state": (this.isException) ? ['*'] : [],
        "status": (this.isException) ? ['*'] : [],
        "agingFrom": '',
        "agingTo": '',
        "priorityFrom": '',
        "priorityTo": '',
        "pageNumber": pageNumber,
        "pageSize": pageSize,
        "shift": "All Shifts",
        "processType": orderServiceObject.processType || null,
        "parentModule": orderServiceObject.parentModule || null,
        "groupBy": orderServiceObject.groupBy || null,
        "orderBy": [{
          "sortBy": sortArg[0], "direction": sortArg[1],

        }], "searchText": searchText
      }
    } else {
      order = {
        "startDate": filterObj.dateRange.from || null,
        "endDate": filterObj.dateRange.to || null,
        "state": this.parseStates(filterObj.state.selectedStates),
        "status": (this.isException) ? ['*'] : [],
        "agingFrom": filterObj.aging.fromSeconds || null,
        "agingTo": filterObj.aging.toSeconds || null,
        "priorityFrom": filterObj.priority.from || null,
        "priorityTo": filterObj.priority.to || null,
        "pageNumber": pageNumber,
        "pageSize": pageSize,
        "shift": filterObj.shift.selectedValue || "All Shifts",
        "processType": orderServiceObject.processType || null,
        "parentModule": orderServiceObject.parentModule || null,
        "groupBy": orderServiceObject.groupBy || null,
        "orderBy": [{
          "sortBy": sortArg[0], "direction": sortArg[1]

        }], "searchText": searchText,
      }
    }

    var data = JSON.stringify(order);
    return this.$http.wesContext.url("/api/orders/search").post(data).map(res => {
      if (!res.text())
        return null;
      let obj = res.json()
      this.utilService.setTimeZone(obj.content, ["createdTime", "modifiedTime"]);
      return obj;
    });
  }

  parseStates(states) {
    let statesArray: Array<string> = new Array<string>();
    states.forEach(element => {
      if (element.checked) {
        if (element.value === 'Exception') {
          statesArray.push('*');
          this.isException = true;
        }
        else
          statesArray.push(element.value);
      }
    });
    return statesArray;
  }

  getOrderDetailListData(pageNumber?: number, pageSize?: number, sortArgs?: string, id?: any, searchText: string = "") {
    //get list data
    let sortArg = sortArgs.split(",");
    let orderLine = {
      "startDate": null,
      "endDate": null,
      "status": [],
      "agingFrom": '',
      "agingTo": '',
      "priorityFrom": '',
      "priorityTo": '',
      "pageNumber": pageNumber,
      "pageSize": pageSize,
      "orderBy": [{
        "sortBy": sortArg[0],
        "direction": sortArg[1]
      }],
      "orderId": id,
      "searchText": searchText
    }
    var data = JSON.stringify(orderLine);
    return this.$http.wesContext.url("/api/orderlines/search").post(data).map(res => {
      if (!res.text())
        return null;
      return res.json()
    });
  }
  getOrderRecordDetailData(id?: any) {
    //get single record
    return this.$http.wesContext.url("/api/orders" + "/" + id).get().map(res => res.json());
  }
}