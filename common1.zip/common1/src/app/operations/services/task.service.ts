import { Injectable } from '@angular/core';
import { HttpService } from 'sensorthink-commoncontrols/src/common.module';
import { UtilService } from 'sensorthink-commoncontrols/src/services/util.service';

@Injectable()

export class TaskService {
    constructor(private $http: HttpService,private _utilService:UtilService) { }
    stateMapping = {
        'pending': 'ActivePending',
        'exception': 'Exception'
    }
    //  Containers
    getTaskData(pageNumber?: number, pageSize?: number, sortArgs?: string, filterObj?: any, state?: string, searchText?: string, taskServiceObject?: any) {
        let sortArg = sortArgs.split(",");
        let task: any;
        if (!filterObj) {
            task = {
                "state": state === "exception" ? ['*'] : (state ? [this.stateMapping[state]] : []),
                "status": state === "exception" ? ["*"] : [],
                "taskType": 'All',
                "externalBatchId": taskServiceObject.batchId || null,
                "user": "",
                "containerId": "",
                "virtualContainerId": "",
                "pageNumber": pageNumber,
                "pageSize": pageSize,
                "startDate": null,
                "endDate": null,
                "shift": "All Shifts",
                "processType": taskServiceObject.processType || null,
                "groupBy": taskServiceObject.groupBy || null,
                "orderBy": [{
                    "sortBy": sortArg[0], "direction": sortArg[1]

                }], "searchText": searchText,
                "agingFrom": '',
                "agingTo": ''
            }
        } else {
            task = {
                "state": state === "exception" ? ['*'] : this.parseStates(filterObj.state.selectedStates),
                "status": state === "exception" ? ["*"] : [],
                "taskType": filterObj.taskType.selectedValue || 'All',
                "externalBatchId": filterObj.extBatchContainer.selectedValue || '',
                "user": filterObj.user.selectedValue || '',
                "containerId": filterObj.containerIds.selectedValue || '',
                "virtualContainerId": filterObj.virtualContainetIds.selectedValue || '',
                "pageNumber": pageNumber,
                "pageSize": pageSize,
                "startDate": filterObj.dateRange.from || null,
                "endDate": filterObj.dateRange.to || null,
                "shift": filterObj.shift.selectedValue || "All Shifts",
                "processType": taskServiceObject.processType || null,
                "groupBy": taskServiceObject.groupBy || null,
                "orderBy": [{
                    "sortBy": sortArg[0], "direction": sortArg[1]

                }], "searchText": searchText,
                "agingFrom": filterObj.aging.fromSeconds || null,
                "agingTo": filterObj.aging.toSeconds || null
            }
        }

        var data = JSON.stringify(task);
        return this.$http.wesContext.url("/api/task").post(data).map(res => {
            if (!res.text())
                return null;
            let obj = res.json();
            if (obj)
                this._utilService.setTimeZone(obj.content, ["createdTime", "modifiedTime"]);
            return obj;
        });
    }
    parseStates(states) {
        let statesArray: Array<string> = new Array<string>();
        states.forEach(element => {
            if (element.checked)
                statesArray.push(element.value);
        });
        return statesArray;
    }

    getAllFilterExternalBatchIds() {
        return this.$http.wesContext.url("/api/task/batchid").get()
            .map(res => res.json()).toPromise();
    }
    getAllFilterContainerIds() {
        return this.$http.wesContext.url("/api/task/containerid").get()
            .map(res => res.json()).toPromise();
    }
    getAllFilterVirtualContainerIds() {
        return this.$http.wesContext.url("/api/task/virtualcontainerid").get()
            .map(res => res.json()).toPromise();
    }
}
