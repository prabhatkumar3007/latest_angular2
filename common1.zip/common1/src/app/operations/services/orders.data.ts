export class OrdersData {
  orderId: number;
  waveId: number;
  orderPriority: number;
  orderType: number;
  cartonUnits: number;
  pickTicketVolume: number;
  countryCode: string;
  isHazmat: string;
  shipVia: string;
  
  constructor(orderId, waveId, orderPriority, orderType, cartonUnits,pickTicketVolume,countryCode,isHazmat,shipVia) {
    this.orderId = orderId;
    this.waveId = waveId;
    this.orderPriority = orderPriority;
    this.orderType = orderType;
    this.cartonUnits = cartonUnits;
    this.pickTicketVolume = pickTicketVolume;
    this.countryCode = countryCode;
    this.isHazmat = isHazmat;
    this.shipVia = shipVia;
  }
}
export class OrderDetailTopData {
  orderId: number;
  waveId: number;
  orderPriority: number;
  orderType: number;
  cartonUnits: number;
  pickTicketVolume: number;
  countryCode: string;
  isHazmat: string;
  shipVia: string;
  
  constructor(orderId, waveId, orderPriority, orderType, cartonUnits,pickTicketVolume,countryCode,isHazmat,shipVia) {
    this.orderId = orderId;
    this.waveId = waveId;
    this.orderPriority = orderPriority;
    this.orderType = orderType;
    this.cartonUnits = cartonUnits;
    this.pickTicketVolume = pickTicketVolume;
    this.countryCode = countryCode;
    this.isHazmat = isHazmat;
    this.shipVia = shipVia;
  }
}

export class OrdersDetailsData {
  orderId: number;
  waveId: number;
  lineItemId:number;
  fulfillmentTybe:string;
  pickLocation:string;
  SKU:string;
  SKUDiscription:string;
  prefix:string;
  cartonNumber:number;
  quantity:number;
  zone:string;
  SKKUBatchNumber:string;
  SKKUInCarton:number;
  toteId: string;
  splitFlag: string;
  
  constructor(orderId, waveId, lineItemId, fulfillmentTybe, pickLocation,SKU,SKUDiscription,prefix,cartonNumber,quantity,zone,SKKUBatchNumber,SKKUInCarton,toteId,splitFlag) {
    this.orderId = orderId;
    this.waveId = waveId;
    this.lineItemId = lineItemId;
    this.fulfillmentTybe = fulfillmentTybe;
    this.pickLocation = pickLocation;
    this.SKU = SKU;
    this.SKUDiscription = SKUDiscription;
    this.prefix = prefix;
    this.cartonNumber = cartonNumber;
    this.quantity = quantity;
    this.zone = zone;
    this.SKKUBatchNumber = SKKUBatchNumber;
    this.SKKUInCarton = SKKUInCarton;
    this.toteId = toteId;
    this.splitFlag = splitFlag;
  }
}