import { Injectable } from '@angular/core';
import { HttpService } from 'sensorthink-commoncontrols/src/common.module';
import { UtilService } from 'sensorthink-commoncontrols/src/services/util.service';

@Injectable()

export class ContainersService {
    public selectedRoute = [];
    constructor(private $http: HttpService, private _utilService: UtilService) { }
    isException: boolean;
    //  Containers
    getContainerData(pageNumber?: number, pageSize?: number, sortArgs?: string, filterObj?: any, state?: string, searchText?: string, containerServiceObject?: any) {
        let sortArg = sortArgs.split(",");
        let container: any;
        this.isException = false;
        if (!filterObj) {
            container = {
                "startDate": null,
                "endDate": null,
                "state": (this.isException) ? ['*'] : [],
                "status": (this.isException) ? ['*'] : [],
                "agingFrom": '',
                "agingTo": '',
                "priorityFrom": '',
                "priorityTo": '',
                "pageNumber": pageNumber,
                "pageSize": pageSize,
                "shift": "All Shifts",
                "processType": containerServiceObject.processType || null,
                "parentModule": containerServiceObject.parentModule || null,
                "groupBy": containerServiceObject.groupBy || null,
                "orderBy": [{
                    "sortBy": sortArg[0], "direction": sortArg[1],

                }], "searchText": searchText,
                containerType: ["All"],
                "batchId": containerServiceObject.batchId || '',
            }
        } else {
            container = {
                "startDate": filterObj.dateRange.from || null,
                "endDate": filterObj.dateRange.to || null,
                "state": this.parseStates(filterObj.state.selectedStates),
                "status": (this.isException) ? ['*'] : [],
                "agingFrom": filterObj.aging.fromSeconds || null,
                "agingTo": filterObj.aging.toSeconds || null,
                "priorityFrom": filterObj.priority.from || null,
                "priorityTo": filterObj.priority.to || null,
                "pageNumber": pageNumber,
                "pageSize": pageSize,
                "shift": filterObj.shift.selectedValue || "All Shifts",
                "processType": containerServiceObject.processType || null,
                "parentModule": containerServiceObject.parentModule || null,
                "groupBy": containerServiceObject.groupBy || null,
                "orderBy": [{
                    "sortBy": sortArg[0], "direction": sortArg[1]

                }], "searchText": searchText,
                containerType: this.parseStates(filterObj.containerTypes.selectedStates),
                "batchId": filterObj.extBatchContainer.selectedValue || '',
            }
        }

        var data = JSON.stringify(container);
        return this.$http.wesContext.url("/api/containers/search").post(data).map(res => {
            if (!res.text())
                return null;
            let obj = res.json();
            if (obj)
                this._utilService.setTimeZone(obj.content, ["createdTime", "modifiedTime"]);
            return obj;
        });
    }
    parseStates(states) {
        let statesArray: Array<string> = new Array<string>();
        states.forEach(element => {
            if (element.checked) {
                if (element.value === 'Exception') {
                    statesArray.push('*');
                    this.isException = true;
                }
                else
                    statesArray.push(element.value);
            }
        });
        return statesArray;
    }

    //Container Details
    getContainerDetailsData(pageNumber?: number, pageSize?: number, sortArgs?: string, id?: any, searchText: string = "") {
        let container: any;
        let sortArg = sortArgs.split(",");
        container = {
            "containerId": id,
            "sortBy": sortArg[0],
            "sortDirection": sortArg[1],
            "pageNumber": pageNumber,
            "pageSize": pageSize,
            "searchText": searchText,
        }
        var data = JSON.stringify(container);
        return this.$http.wesContext.url("/api/containers/contents").post(data).map(res => {
            if (!res.text())
                return null;
            return res.json()
        });
    }
    getTopContainerDetailsData(id?: any) {
        return this.$http.wesContext.url("/api/containers" + "/" + id).get().map(res => res.json());
    }
    getSortDestination(id?: any) {
        return this.$http.wesContext.url("/api/containers/sortdestination").addParam("containerId", id).get().map(res => res.json());
    }
    getLocationHistory(id?: any) {
        return this.$http.wesContext.url("/api/containers/locationhistory").addParam("containerId", id).get().map(res => {
            let obj = res.json();
            if (obj)
                this._utilService.setTimeZone(obj, ["timestamp"]);
            return obj
        });
    }
    getForceBatchContainerCloseData(containerId?: any) {
        let http = this.$http.wesContext.url("/api/containers/" + containerId + "/forcebatchtasksclose")
        return http.put().map(res => res.json());
    }
    updateContainerStatus(containerId) {
        let http = this.$http.wesContext.url("/api/containers/" + containerId + "/forcebatchtasksclose")
        return http.put().map(res => res.json());
    }
}
