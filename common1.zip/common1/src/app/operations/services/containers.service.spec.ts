import { JwtHelper } from 'sensorthink-commoncontrols/src/services/jwtHelper.service';
import { UtilService } from 'sensorthink-commoncontrols/src/services/util.service';
import { MockHttpService } from '../../../test/mockHttp.service';
import { SharedModule } from '../../shared/shared.module';
import { ContainersService } from './containers.service';
import { inject, TestBed } from '@angular/core/testing';
import { HttpModule, Response, ResponseOptions, XHRBackend } from '@angular/http';
import { MockBackend } from '@angular/http/testing';
import { HttpService } from 'sensorthink-commoncontrols/src/common.module';

describe('Service: ContainersService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [HttpModule, SharedModule],
            providers: [ContainersService, { provide: HttpService, useClass: MockHttpService },
                { provide: XHRBackend, useClass: MockBackend },UtilService]
        }).compileComponents();
    })
    it('can instantiate service when inject service',
        inject([ContainersService], (service: ContainersService) => {
            expect(service instanceof ContainersService).toBe(true);
        }));

    it('can provide the mockBackend as XHRBackend',
        inject([XHRBackend], (backend: MockBackend) => {
            expect(backend).not.toBeNull('backend should be provided');
        }));
    describe('When get all container data', () => {
        let backend: MockBackend;
        let service: ContainersService;
        let util=new UtilService(new JwtHelper());
        let response: Response;
        const mockResponse = [{ containerId: '864515', orderId: '5698027001', waveId: '101201700023776', state: 'ActivePending', virtualContainerId: '9018645151864' },
        { containerId: '864515', orderId: '5698027001', waveId: '101201700023776', state: 'ActivePending', virtualContainerId: '9018645151864' }
        ];
        beforeEach(inject([HttpService, XHRBackend], (httpService: HttpService, be: MockBackend) => {
            backend = be;
            service = new ContainersService(httpService,null);
            let options = new ResponseOptions({ status: 200, body: { data: [] } });
            response = new Response(options);
        }));
        it(' should get order data',
            inject([], () => {
                backend.connections.subscribe((connection) => {
                    connection.mockRespond(new Response(new ResponseOptions({ body: JSON.stringify(mockResponse) })));
                });
                service.getContainerData(1, 10, "ContainerId,asc", '').subscribe((res) => {
                    expect(res.length).toBe(mockResponse.length);
                }, (err) => {
                    console.log(err);
                })
            }));
    });
    describe('When ', () => {
        let backend: MockBackend;
        let service: ContainersService;
        let response: Response;
        let util=new UtilService(new JwtHelper());
        let pickContainer = { pickContainerId: 2 };
        const mockResponse = { action: 'Create', orderId: '2', priority: '1', state: 'PickingActive' };

        beforeEach(inject([HttpService, XHRBackend], (httpService: HttpService, be: MockBackend) => {
            backend = be;
            service = new ContainersService(httpService,util);
            let options = new ResponseOptions({ status: 200, body: { data: [] } });
            response = new Response(options);
        }));
        it('get details of content data by id',
            inject([], () => {
                backend.connections.subscribe((connection) => {
                    connection.mockRespond(new Response(new ResponseOptions({ body: JSON.stringify(mockResponse) })));
                });
                service.getContainerDetailsData(1, 10, 'containerId,asc', 2, '').subscribe((res) => {
                    expect(res.orderId).toBe(mockResponse.orderId);
                }, (err) => {
                    console.log(err);
                })
            }));

        it('get details of containers by id',
            inject([], () => {
                backend.connections.subscribe((connection) => {
                    connection.mockRespond(new Response(new ResponseOptions({ body: JSON.stringify(mockResponse) })));
                });
                service.getTopContainerDetailsData(pickContainer.pickContainerId).subscribe((res) => {
                    expect(res.orderId).toBe(mockResponse.orderId);
                }, (err) => {
                    console.log(err);
                })
            }));
        it('get details of sortDestination by id',
            inject([], () => {
                backend.connections.subscribe((connection) => {
                    connection.mockRespond(new Response(new ResponseOptions({ body: JSON.stringify(mockResponse) })));
                });
                service.getSortDestination(pickContainer.pickContainerId).subscribe((res) => {
                    expect(res.orderId).toBe(mockResponse.orderId);
                }, (err) => {
                    console.log(err);
                })
            }));
        it('get details of LocationHistory by id',
            inject([], () => {
                backend.connections.subscribe((connection) => {
                    connection.mockRespond(new Response(new ResponseOptions({ body: JSON.stringify(mockResponse) })));
                });
                service.getLocationHistory(pickContainer.pickContainerId).subscribe((res) => {
                    expect(res.orderId).toBe(mockResponse.orderId);
                }, (err) => {
                    console.log(err);
                })
            }));
    });
});