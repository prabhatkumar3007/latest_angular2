import { UtilService } from 'sensorthink-commoncontrols/src/services/util.service';
import { Injectable } from '@angular/core';
import { HttpService } from 'sensorthink-commoncontrols/src/common.module';

@Injectable()

export class WavesService {
  constructor(private $http: HttpService, private utilService: UtilService) { }

  parseStates(states) {
    let statesArray: Array<string> = new Array<string>();
    states.forEach(element => {
      if (element.checked)
        statesArray.push(element.value);
    });
    return statesArray;
  }
  getWaveData(pageNumber?: number, pageSize?: number, sortArgs?: string, filterObj?: any, searchText: string = "") {
    let sortArg = sortArgs.split(",");
    let wave: any;

    if (!filterObj) {
      wave = {
        startDate: null,
        endDate: null,
        state: [],
        agingFrom: '',
        agingTo: '',
        priorityFrom: '',
        priorityTo: '',
        pageNumber: pageNumber,
        pageSize: pageSize,
        orderBy: [{
          sortBy: sortArg[0], direction: sortArg[1]
        }], searchText: searchText
      }
    } else {
      wave = {
        "startDate": filterObj.dateRange.from || null,
        "endDate": filterObj.dateRange.to || null,
        "state": this.parseStates(filterObj.state.selectedStates),
        "agingFrom": filterObj.aging.fromSeconds || null,
        "agingTo": filterObj.aging.toSeconds || null,
        "priorityFrom": filterObj.priority.from || null,
        "priorityTo": filterObj.priority.to || null,
        "pageNumber": pageNumber,
        "pageSize": pageSize,
        "orderBy": [{
          "sortBy": sortArg[0], "direction": sortArg[1]
        }], searchText: searchText
      }
    }
    var data = JSON.stringify(wave);
    let http = this.$http.wesContext.url("/api/waves/search")
    return http.post(data).map((res) => {
      let obj = res.json();
      if(obj)
        this.utilService.setTimeZone(obj.content, ["createdTime", "modifiedTime"]);
      return obj;
    });
  }
}