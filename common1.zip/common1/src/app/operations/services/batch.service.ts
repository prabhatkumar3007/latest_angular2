import { Injectable } from '@angular/core';
import { HttpService } from 'sensorthink-commoncontrols/src/common.module';
import { UtilService } from 'sensorthink-commoncontrols/src/services/util.service';

@Injectable()

export class BatchService {
    constructor(private $http: HttpService,private _utilService:UtilService) { }
    parseStates(states) {
            let statesArray: Array<string> = new Array<string>();
            states.forEach(element => {
                if (element.checked)
                    statesArray.push(element.value);
            });
            return statesArray;
        }
    //  Containers
    getBatchData(pageNumber?: number, pageSize?: number, sortArgs?: string, filterObj?: any, state?: string, searchText?: string) {
        let sortArg = sortArgs.split(",");
        let batch: any;
        if (!filterObj) {
            batch = {
                "pageNumber": pageNumber,
                "pageSize": pageSize,
                "state": [],
                "shift": "All Shifts",
                "startDate": null,
                "endDate": null,
                "orderBy": [{
                    "sortBy": sortArg[0], "direction": sortArg[1]
                }], "searchText": searchText,
            }
        } else {
            batch = {
                "pageNumber": pageNumber,
                "pageSize": pageSize,
                "state": this.parseStates(filterObj.state.selectedStates),
                "shift": filterObj.shift.selectedValue || "All Shifts",
                "startDate": filterObj.dateRange.from || null,
                "endDate": filterObj.dateRange.to || null,
                "orderBy": [{
                    "sortBy": sortArg[0], "direction": sortArg[1]
                }], "searchText": searchText,
            }
        }
       
        var data = JSON.stringify(batch);
        return this.$http.wesContext.url("/api/batch").post(data).map(res => {
            if (!res.text())
                return null;
            let obj = res.json();
            if (obj)
                this._utilService.setTimeZone(obj.content, ["createdTime", "modifiedTime"]);
            return obj;
        });
    }
}
