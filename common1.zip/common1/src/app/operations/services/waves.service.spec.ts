import { JwtHelper } from 'sensorthink-commoncontrols/src/services/jwtHelper.service';
import { UtilService } from 'sensorthink-commoncontrols/src/services/util.service';
import { MockHttpService } from '../../../test/mockHttp.service';
import { SharedModule } from '../../shared/shared.module';
import { WavesService } from './waves.service';
import { inject, TestBed } from '@angular/core/testing';
import { HttpModule, Response, ResponseOptions, XHRBackend } from '@angular/http';
import { MockBackend } from '@angular/http/testing';
import { HttpService } from 'sensorthink-commoncontrols/src/common.module';

describe('Service: WaveService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [HttpModule, SharedModule],
            providers: [WavesService, { provide: HttpService, useClass: MockHttpService },
                { provide: XHRBackend, useClass: MockBackend }]
        }).compileComponents();
    })
    it('can instantiate service when inject service',
        inject([WavesService], (service: WavesService) => {
            expect(service instanceof WavesService).toBe(true);
        }));

    it('can provide the mockBackend as XHRBackend',
        inject([XHRBackend], (backend: MockBackend) => {
            expect(backend).not.toBeNull('backend should be provided');
        }));

    describe('When get all waves data', () => {
        let backend: MockBackend;
        let service: WavesService;
        let response: Response;
        const mockResponse = [{ waveId: '5597754001', state: 'Complete', priority: '1', orderQuantity: '502' },
        { waveId: '5597754001', state: 'Complete', priority: '1', orderQuantity: '502' }
        ];
        beforeEach(inject([HttpService, XHRBackend], (httpService: HttpService, be: MockBackend) => {
            backend = be;
            service = new WavesService(httpService, new UtilService(new JwtHelper()));
            let options = new ResponseOptions({ status: 200, body: { data: [] } });
            response = new Response(options);
        }));
        it(' should get wave data',
            inject([], () => {
                backend.connections.subscribe((connection) => {
                    connection.mockRespond(new Response(new ResponseOptions({ body: JSON.stringify(mockResponse) })));
                });
                service.getWaveData(1, 10, "waveId,asc", '').subscribe((res) => {
                    expect(res.length).toBe(mockResponse.length);
                }, (err) => {
                    console.log(err);
                })
            }));
    });
});