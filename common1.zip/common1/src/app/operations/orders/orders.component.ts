import 'rxjs/add/operator/debounceTime';
import { OrdersService } from '../services/orders.service';
import { ShiftService } from './../../shared/services/shift.service';
import { ChangeDetectorRef, Component, ViewChild } from '@angular/core';
import { FormControl } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { FilterParams } from 'sensorthink-commoncontrols/src/controls.module';
import { ShareDataService } from 'sensorthink-commoncontrols/src/services/shareDataService';
import { NotyService } from "sensorthink-commoncontrols/src/services/noty.service";
import { AdvanceFilterService } from "./../../shared/services/advanceFilter.service";
import { AdvancedFilterComponent } from "sensorthink-commoncontrols/src/components/advancedFilter/advancedFilter.component";
declare var moment: any;
@Component({
  templateUrl: 'orders.component.html'
})
export class OrdersComponent {
  public pagerConfig: any;
  public sortArgs: string;
  public isLoading: boolean = false;
  public orderData: any;
  public filterConfig: FilterParams;
  public appliedFilterData: FilterParams;
  public isFirstLoad: boolean = false;
  public searchTxt = '';
  public searchTxtControl = new FormControl();
  public sideBarVisible: boolean;
  public state: string;
  public parentModule: string;
  public isDrilldown: boolean = false;
  public loadSavedFilters: any;
  orderServiceObject = { processType: null, parentModule: null, groupBy: null };
  allShift: any;
  workQueueDates: any;
  @ViewChild(AdvancedFilterComponent) advanceFilter: AdvancedFilterComponent;

  constructor(private _service: OrdersService, private _cdr: ChangeDetectorRef, private allShiftService: ShiftService, private activatedRoute: ActivatedRoute, private sharedService: ShareDataService, private noty: NotyService, private filterService: AdvanceFilterService) {
    this.sortArgs = "orderId,asc";
    if (this.sharedService.objectStore.workQueueSummaryDates)
      this.workQueueDates = this.sharedService.objectStore.workQueueSummaryDates;
    this.filterConfig = this.createFilterParams();
    this.pagerConfig = {
      totalItems: 64,
      currentPage: 1,
      smallnumPages: 0,
      itemsPerPage: 10
    }

  }

  ngOnInit() {
    this.searchTypeResult();
    this.setPagerConfig(0, 0);
    this.getSavedFilterDataList();
    this.allShiftService.getAllShift().then((res) => {
      this.allShift = res;
      this.filterConfig.shift.options = this.allShift;
      if (this.filterConfig.shift.options) {
        this.filterConfig.shift.selectedValue = this.filterConfig.shift.options[0].name;
      }
      if (this.sharedService.objectStore.shiftValue)
        this.filterConfig.shift.selectedValue = this.sharedService.objectStore.shiftValue;
      this.filterConfig.dateRange.from = (this.sharedService.objectStore.fromDate) ? this.sharedService.objectStore.fromDate : moment(new Date()).format("YYYY-MM-DDT00:00:00");
      this.filterConfig.dateRange.to = (this.sharedService.objectStore.toDate) ? this.sharedService.objectStore.toDate : moment(new Date()).format("YYYY-MM-DDT23:59:59");
      if (this.filterConfig.dateRange.from)
        this.setFilterDates(this.filterConfig.dateRange.from, this.filterConfig.dateRange.to);
      this.checkActivatedRoute();
    })
  }
  getSavedFilterDataList() {
    this.filterService.getAllLoadSaveFilterData('ORDERS').then((res) => {
      this.loadSavedFilters = this.filterService.createFilterObjectFormat(res)
      if (this.loadSavedFilters) {
        this.filterConfig.saveLoadFilter.options = this.loadSavedFilters;
      }
      this.isLoading = false;
    })
  }

  searchTypeResult() {
    this.searchTxtControl.valueChanges
      .debounceTime(1000)
      .subscribe(newValue => {
        this.searchTxt = newValue.trim();
        if (((this.searchTxt.length >= 1 || this.searchTxt.length === 0) && this.searchTxt !== "") || this.isFirstLoad) {
          this.isFirstLoad = (this.searchTxt.length === 0) ? false : true;
          if (this.appliedFilterData) {
            this.getAllOrders(this.pagerConfig.currentPage, this.sortArgs, this.appliedFilterData, this.searchTxt, this.orderServiceObject);
          } else {
            this.getAllOrders(this.pagerConfig.currentPage, this.sortArgs, this.appliedFilterData, this.searchTxt, this.orderServiceObject);
          }
        }
      });
  }
  filterApliedMethodCall() {
    let fltr: FilterParams = JSON.parse(JSON.stringify(this.filterConfig));
    fltr.aging.from = null;
    fltr.aging.to = null;
    fltr.aging.fromSeconds = null;
    fltr.aging.toSeconds = null;
    fltr.priority.from = null;
    fltr.priority.to = null;
    this.filterApplied(fltr);
  }
  checkActivatedRoute() {
    this.activatedRoute.queryParams.subscribe((params) => {
      this.state = params['status'];
      this.orderServiceObject.processType = params['processType'];
      if (params['parentModule']) {
        this.orderServiceObject.parentModule = params['parentModule'];
        this.orderServiceObject.groupBy = 'parentModule';
      }
      if (this.state === "exception") {
        this.filterConfig.state.selectedStates[6].checked = true;
        this.filterApliedMethodCall();
      }
      if (this.state === "pending") {
        if (this.orderServiceObject.processType === 'Shipping') {
          this.filterConfig.state.selectedStates[0].checked = true;
          this.filterConfig.state.selectedStates[1].checked = true;
          this.filterConfig.state.selectedStates[2].checked = true;
        }
        else if (this.orderServiceObject.processType === 'Packing') {
          this.filterConfig.state.selectedStates[0].checked = true;
          this.filterConfig.state.selectedStates[1].checked = true;
        }
        else
          this.filterConfig.state.selectedStates[0].checked = true;
        this.filterApliedMethodCall();
      }
      if (this.state === "complete") {
        if (this.orderServiceObject.processType === 'Picking')
          this.filterConfig.state.selectedStates[2].checked = true;
        else if (this.orderServiceObject.processType === 'Packing')
          this.filterConfig.state.selectedStates[3].checked = true;
        else if (this.orderServiceObject.processType === 'Shipping') {
          this.filterConfig.state.selectedStates[4].checked = true;
        } else
          this.filterConfig.state.selectedStates[5].checked = true;
        this.filterApliedMethodCall();
      }
      if (this.state === "in process") {
        if (this.orderServiceObject.processType === 'Picking')
          this.filterConfig.state.selectedStates[1].checked = true;
        else if (this.orderServiceObject.processType === 'Packing') {
          this.filterConfig.state.selectedStates[2].checked = true;
        }
        else if (this.orderServiceObject.processType === 'Shipping') {
          this.filterConfig.state.selectedStates[3].checked = true;
        }
        else {
          this.filterConfig.state.selectedStates[1].checked = true;
          this.filterConfig.state.selectedStates[2].checked = true;
          this.filterConfig.state.selectedStates[3].checked = true;
          this.filterConfig.state.selectedStates[4].checked = true;
        }

        this.filterApliedMethodCall();
      }
      if (!this.state) {
        this.appliedFilterData = null;
        this.getAllOrders(1, this.sortArgs, this.appliedFilterData, '', this.orderServiceObject);
      }
    });
  }

  getAllOrders(pageNumber: number, sortArgs: string, filterObj, searchTxt?: string, orderServiceObject?: any) {
    this.isLoading = true;
    this._service.getOrderData(pageNumber, this.pagerConfig.itemsPerPage, sortArgs, filterObj, this.state, searchTxt, orderServiceObject).subscribe((orders) => {
      if (orders) {
        this.setPagerConfig(orders.totalElements, this.pagerConfig.currentPage, this.pagerConfig.itemsPerPage);
        this.orderData = orders.content;
      } else {
        this.setPagerConfig(0, this.pagerConfig.currentPage, this.pagerConfig.itemsPerPage)
        this.orderData = [];
      }
      this.isLoading = false;
    });
  }

  setPagerConfig(totalItems, currentPage, itemsPerPage?) {
    this.pagerConfig = {
      totalItems: totalItems,
      currentPage: currentPage || 1,
      itemsPerPage: itemsPerPage || 10,
      smallnumPages: 0
    }
  }

  onPageSizeChanged(pageSize) {
    this.pagerConfig.itemsPerPage = pageSize;
    if (this.appliedFilterData) {
      this.getAllOrders(1, this.sortArgs, this.appliedFilterData, this.searchTxt, this.orderServiceObject);
    } else {
      this.getAllOrders(1, this.sortArgs, this.appliedFilterData, this.searchTxt, this.orderServiceObject);
    }
    this._cdr.detectChanges();
  }

  onPageChanged(pager) {
    this.pagerConfig.currentPage = pager.page;
    if (this.appliedFilterData) {
      this.getAllOrders(pager.page, this.sortArgs, this.appliedFilterData, this.searchTxt, this.orderServiceObject);
    } else {
      this.getAllOrders(pager.page, this.sortArgs, this.appliedFilterData, this.searchTxt, this.orderServiceObject);
    }
    this._cdr.detectChanges();
  }

  filterApplied(filterObj: FilterParams) {
    //used from --- http://stackoverflow.com/questions/728360/how-do-i-correctly-clone-a-javascript-object    
    this.appliedFilterData = JSON.parse(JSON.stringify(filterObj));
    this.getAllOrders(this.pagerConfig.currentPage, this.sortArgs, filterObj, this.searchTxt, this.orderServiceObject);
  }

  onRemoveFilter(filterObj: FilterParams) {
    this.appliedFilterData = filterObj;
    this.getAllOrders(this.pagerConfig.currentPage, this.sortArgs, filterObj, this.searchTxt, this.orderServiceObject);
  }

  clearFilters() {
    this.appliedFilterData = null;
    this.reSetFilterObject(this.filterConfig);
    this.getAllOrders(this.pagerConfig.currentPage, this.sortArgs, this.appliedFilterData, this.searchTxt, this.orderServiceObject);
  }

  onSortChanged(sortArgs) {
    this.sortArgs = sortArgs[0] + "," + sortArgs[1];
    if (this.appliedFilterData) {
      this.getAllOrders(this.pagerConfig.currentPage, this.sortArgs, this.appliedFilterData, this.searchTxt, this.orderServiceObject);
    } else {
      this.getAllOrders(this.pagerConfig.currentPage, this.sortArgs, this.appliedFilterData, this.searchTxt, this.orderServiceObject);
    }
    this._cdr.detectChanges();
  }

  createFilterParams(): FilterParams {
    let params = new FilterParams(); // initialises to default on object creation
    params.state.selectedStates = [
      { text: "Active Pending", value: "ActivePending", checked: false },
      { text: "Picking Active", value: "PickingActive", checked: false },
      { text: "Picking Complete", value: "PickingComplete", checked: false },
      { text: "Packing Complete", value: "PackingComplete", checked: false },
      { text: "Ship Sort Complete", value: "ShipSortComplete", checked: false },
      { text: "Complete", value: "Complete", checked: false },
      { text: "Exception", value: "Exception", checked: false }
    ]
    params.site.isVisible = false;
    params.shift.options = this.allShift;
    params.baseMetric.isVisible = false;
    params.otherMetric.isVisible = false;
    return params;
  }

  applyFormatting(columns) {
    this.getAllOrders(this.pagerConfig.currentPage, this.sortArgs, this.appliedFilterData, this.searchTxt, this.orderServiceObject);
  }

  onSaveFilterClick(saveFilterObject: FilterParams) {
    if (this.appliedFilterData) {
      this.isLoading = true;
      if (saveFilterObject.saveFilterName.selectedValue && saveFilterObject.saveFilterName.selectedValue !== '') {
        if (saveFilterObject.filterId) {
          this.filterService.updateFilters('ORDERS', this.appliedFilterData).subscribe((res) => {
            this.noty.success(saveFilterObject.saveFilterName.selectedValue + " filter is updated successfully.");
            this.getSavedFilterDataList();
            this.resetDropDownOptions(saveFilterObject);
          }, err => {
            this.isLoading = false;
            this.noty.error(err);
          });
        } else {
          //new filter 
          this.filterService.saveNewFilters('ORDERS', this.appliedFilterData, saveFilterObject.saveFilterName.selectedValue).subscribe((res) => {
            this.noty.success(saveFilterObject.saveFilterName.selectedValue + " filter is saved successfully.");
            this.getSavedFilterDataList()
            this.resetDropDownOptions(saveFilterObject);
          }, err => {
            this.isLoading = false;
            if (err.status === 409)
              this.noty.error('Filter name is already exist');
            else
              this.noty.error(err);
          });
        }
      } else {
        this.noty.error("Please enter filter name.");
        this.isLoading = false;
      }
    } else
      this.noty.error("Please click on apply button to apply filters.");
  }
  onLoadFilterCall(loadFilterObj: FilterParams) {
    if (loadFilterObj.saveLoadFilter.selectedValue && loadFilterObj.saveLoadFilter.selectedValue !== '') {
      this.filterService.getLoadSaveFilterData('ORDERS', loadFilterObj.saveLoadFilter.selectedValue).then((res) => {
        if (res) {
          let result: FilterParams;
          result = JSON.parse(res.value)
          this.resetDropDownOptions(result);
          this.filterConfig = this.filterService.resetFilterObject(result);
          this.filterConfig.saveLoadFilter.options = this.loadSavedFilters;
          this.filterConfig.saveLoadFilter.selectedValue = loadFilterObj.saveLoadFilter.selectedValue;
          this.filterConfig.saveFilterName.selectedValue = loadFilterObj.saveLoadFilter.selectedValue;
          this.filterConfig.filterId = res.id;
          this.filterApplied(result);
          if (result.dateRange.from)
            this.setFilterDates(result.dateRange.from, result.dateRange.to);
        }
      }, err => {
        this.noty.error(err);
      });
    } else {
      this.clearFilters();
    }
  }
  resetDropDownOptions(saveFilterObject) {
    this.filterConfig = saveFilterObject;
    this.filterConfig.shift.options = this.allShift;
    this.filterConfig.shift.selectedValue = saveFilterObject.shift.selectedValue;
  }
  setFilterDates(fromDate, todate) {
    let dates: any = this.filterService.setDateForFilter(fromDate, todate);
    if (this.advanceFilter && this.advanceFilter.fromDatePicker && this.advanceFilter.fromDatePicker.datepickerObj) {
      this.advanceFilter.fromDatePicker.datepickerObj.selectDate([dates[0]]);
    }
    if (this.advanceFilter && this.advanceFilter.toDatePicker && this.advanceFilter.toDatePicker.datepickerObj) {
      this.advanceFilter.toDatePicker.datepickerObj.selectDate([dates[1]]);
    }
  }
  reSetFilterObject(filterObj) {
    for (var i = 0; i < filterObj.state.selectedStates; i++) {
      filterObj.state.selectedStates[i].checked = false;
    }
    if (filterObj.dateRange.from)
      this.setFilterDates(moment(new Date()).format("YYYY-MM-DDT00:00:00"), moment(new Date()).format("YYYY-MM-DDT23:59:59"));
    if (this.loadSavedFilters) {
      filterObj.saveLoadFilter.options = this.loadSavedFilters;
    }
    filterObj.shift.options = this.allShift;
    if (filterObj.shift.options) {
      filterObj.shift.selectedValue = this.filterConfig.shift.options[0].name;
    }
    filterObj.aging.from = 1;
    filterObj.aging.to = 30;
    filterObj.priority.from = 1;
    filterObj.priority.to = 100;
  }
}