import { ComponentFixture, TestBed, async, tick, fakeAsync } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement, Directive } from '@angular/core';

import { OrderDetailsComponent } from './orderDetails.component';
import { OperationsModule } from '../operations.module'
import { OrdersService } from '../services/orders.service'
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { RouterStub } from '../../../test/routerStub';
import { MockActivatedRouteById } from '../../../test/mockActivateRoute'

class MockUserService {
  getOrderDetailListData(): Observable<any> {
    return Observable.of({ content: [{}], totalElements: 0 });
  }
  getOrderRecordDetailData(): Observable<any> {
    return Observable.of({});
  }
}
describe('ORDER DETAILS:... Component', () => {

    let comp: OrderDetailsComponent;
    let fixture: ComponentFixture<OrderDetailsComponent>;
    let de: DebugElement;
    let el: HTMLElement;
    let service;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [OperationsModule],
            providers: [{ provide: OrdersService, useClass: MockUserService },
            { provide: Router, useClass: RouterStub },
            { provide: ActivatedRoute, useClass: MockActivatedRouteById }]
        })
        // https://angular-2-training-book.rangle.io/handout/testing/components/injecting-dependencies.html
        fixture = TestBed.overrideComponent(OrderDetailsComponent, {
            set: {
                template: '<span>{{message}}</span>'
            }
        })
            .createComponent(OrderDetailsComponent);
        comp = fixture.componentInstance;
        service = fixture.debugElement.injector.get(OrdersService);
    }));
    it('should have a defined component', () => {
        expect(comp).toBeDefined();
    });
    describe('When we call getAllOrderDetailList', () => {
    it('should get all orders details data', () => {
      spyOn(service, 'getOrderDetailListData').and.callThrough();
      spyOn(comp, 'setPagerConfig');
      comp.getAllOrderDetailList(1, '',2);
      expect(comp.setPagerConfig).toHaveBeenCalled();
      expect(comp.orderDetailsData.length).toBe(1);
      expect(comp.isDetailDataLoading).toBe(false)
    })
  });
  describe('When we call setPagerConfig', () => {
    it(' should set the pager config', () => {
      comp.setPagerConfig(10, 1, 5);
      expect(comp.pagerConfig.totalItems).toBe(10);
      expect(comp.pagerConfig.currentPage).toBe(1);
      expect(comp.pagerConfig.itemsPerPage).toBe(5);
    })
  });
  describe('When we call checkActivatedRoute', () => {
    it(' should set the state', () => {
      comp.checkActivatedRoute();
      expect(comp.id).toBe(1);
    })
  });
  describe('When we call getRecordOrderDetail', () => {
    it('should get all orders record details data', () => {
      spyOn(service, 'getOrderRecordDetailData').and.callThrough();
      spyOn(comp, 'setPagerConfig');
      comp.getRecordOrderDetail(1);
      expect(comp.orderDetailRecord.length).toBe(1);
      expect(comp.isDetailDataLoading).toBe(false)
    })
  });
  describe('search box spec', () => {
    let input, isFirstLoad = true, date1, date2;
    beforeEach(function () {
      input = comp.searchTxt;
      comp.setPagerConfig(10, 1, 1);
    });
    it(' should set to a valid search text', fakeAsync(() => {
      spyOn(comp, 'getAllOrderDetailList');
      spyOn(service, 'getOrderRecordDetailData').and.callThrough();
      comp.searchTypeResult()
      expect(comp.searchTxt).toBe(input);
      tick(1000);
      fixture.detectChanges();
      expect(comp.getAllOrderDetailList).toHaveBeenCalled();
    }))
    it(' should be first load', () => {
      comp.searchTypeResult()
      expect(comp.isFirstLoad).toBeFalsy();
    })
  });
  describe('When we call onPageSizeChanged, onPageChanged, onSortChanged', () => {
    beforeEach(() => {
      comp.setPagerConfig(10, 1, 1);
    })
    it(' should change the size of page with more orders details data', () => {
      spyOn(comp, 'getAllOrderDetailList');
      comp.onPageSizeChanged(10);
      expect(comp.pagerConfig.itemsPerPage).toBe(10);
      expect(comp.getAllOrderDetailList).toHaveBeenCalled();
    })
    it(' should change the page with next orders details data', () => {
      let pager = { page: 2 }
      spyOn(comp, 'getAllOrderDetailList');
      comp.onPageChanged(pager);
      expect(comp.pagerConfig.currentPage).toBe(2);
      expect(comp.getAllOrderDetailList).toHaveBeenCalled();

    })
    it(' should get sorted orders details data', () => {
      let args = ['firstName', 'asc']
      spyOn(comp, 'getAllOrderDetailList');
      comp.onSortChanged(args);
      expect(comp.sortArgs).toBe('firstName,asc');
      expect(comp.getAllOrderDetailList).toHaveBeenCalled();
    })
  });
});
