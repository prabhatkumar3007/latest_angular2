import { Component, Input, ChangeDetectorRef, OnInit } from '@angular/core';
import { OrdersService } from '../services/orders.service';
//import { OrdersDetailsData, OrderDetailTopData } from '../services/orders.data'
import { ActivatedRoute,Params } from '@angular/router';

import { FormControl } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/debounceTime';

@Component({
  templateUrl: 'orderDetails.component.html'
})
export class OrderDetailsComponent implements OnInit {
  orderDetailsData: any;
  orderDetailsTopData: any;
  orderDetailRecord = [];
  pagerConfig: any;
  public sortArgs: string;
  public isRecordLoading: boolean = false;
  public isDetailDataLoading: boolean = false;
 // @Input() ordersDetailsData: OrdersDetailsData;
  //@Input() ordersDetailTopData: OrderDetailTopData;
  id: any;
  private sub: any;
  isFirstLoad: boolean = false;
  searchTxt = '';
  searchTxtControl = new FormControl();

  constructor(private _service: OrdersService, private route: ActivatedRoute) {
    this.sortArgs = "orderId,asc";
    this.pagerConfig = {
      totalItems: 64,
      currentPage: 1,
      smallnumPages: 0,
    }
  }
  ngOnInit() {
    this.searchTypeResult();
    this.setPagerConfig(0, 0);
    this.checkActivatedRoute();
    this.getRecordOrderDetail(this.id);
    this.getAllOrderDetailList(1, this.sortArgs, this.id);

  }
  searchTypeResult() {
    this.searchTxtControl.valueChanges
      .debounceTime(1000)
      .subscribe(newValue => {
        this.searchTxt = newValue.trim();
        if (((this.searchTxt.length >= 1 || this.searchTxt.length === 0) && this.searchTxt !== "") || this.isFirstLoad) {
          this.isFirstLoad = (this.searchTxt.length === 0) ? false : true;
          this.getAllOrderDetailList(this.pagerConfig.currentPage, this.sortArgs,this.id, this.searchTxt);
        }
      });
  }
  checkActivatedRoute() {
    this.route.params.subscribe(params => {
      this.id = params['id']; // (+) converts string 'id' to a number

      // In a real app: dispatch action to load the details here.
    });
  }
  getRecordOrderDetail(id: any) {
    //Get Single record data
    this.isRecordLoading = true;
    this._service.getOrderRecordDetailData(id).subscribe((record) => {
      this.orderDetailRecord.push(record);
      this.isRecordLoading = false;
    });
  }
  getAllOrderDetailList(pageNumber: number, sortArgs: string, id: any, searchTxt?: string) {
    //get ordered list data
    this.isDetailDataLoading = true;
    this._service.getOrderDetailListData(pageNumber, this.pagerConfig.itemsPerPage, sortArgs, id,searchTxt).subscribe((dataList) => {
      if(dataList){
        this.setPagerConfig(dataList.totalElements, this.pagerConfig.currentPage, this.pagerConfig.itemsPerPage);
        this.orderDetailsData = dataList.content;
      }else{
        this.orderDetailsData = [];
        this.setPagerConfig(0, this.pagerConfig.currentPage, this.pagerConfig.itemsPerPage)
      }
      
      this.isDetailDataLoading = false;
    });
  }
  setPagerConfig(totalItems, currentPage, itemsPerPage?) {
    this.pagerConfig = {
      totalItems: totalItems,
      currentPage: currentPage || 1,
      itemsPerPage: itemsPerPage || 10,
      smallnumPages: 0
    }
  }
  onPageSizeChanged(pageSize) {
    this.pagerConfig.itemsPerPage = pageSize;
    this.getAllOrderDetailList(1, this.sortArgs, this.id);

  }
  onPageChanged(pager) {
    this.pagerConfig.currentPage = pager.page;
    this.getAllOrderDetailList(pager.page, this.sortArgs, this.id);
  }
  onSortChanged(sortArgs) {
    this.sortArgs = sortArgs[0] + "," + sortArgs[1];
    this.getAllOrderDetailList(this.pagerConfig.currentPage, this.sortArgs, this.id);
  }

}