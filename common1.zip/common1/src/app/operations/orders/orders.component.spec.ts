import { ActivatedRoute, Router } from '@angular/router';
import {
  async,
  ComponentFixture,
  fakeAsync,
  TestBed,
  tick
} from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { Component } from '@angular/core';
import { DebugElement } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import { OperationsModule } from '../operations.module';
import { OrdersComponent } from './orders.component';
import { OrdersService } from '../services/orders.service';
import { MockActivatedRoute } from '../../../test/mockActivateRoute'
import { RouterStub } from '../../../test/routerStub'
import { FilterParams } from "sensorthink-commoncontrols/src/controls.module";

class FakeOrdersService {
  getOrderData(): Observable<any> {
    return Observable.of({ content: [{}], totalElements: 0 });
  }
}
describe('Orders Component', () => {
  let comp: OrdersComponent;
  let fixture: ComponentFixture<OrdersComponent>;
  let de: DebugElement;
  let el: HTMLElement;
  let _service;
  let filterObj = new FilterParams();
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [OperationsModule],
      providers: [{ provide: OrdersService, useClass: FakeOrdersService },
      { provide: ActivatedRoute, useClass: MockActivatedRoute },
      { provide: Router, useClass: RouterStub }
      ]
    })
    fixture = TestBed.overrideComponent(OrdersComponent, {
      set: {
        template: '<span>{{message}}</span>'
      }
    }).createComponent(OrdersComponent);
    comp = fixture.componentInstance;
    _service = fixture.debugElement.injector.get(OrdersService);
  });
  it('Should have defined component', () => {
    expect(comp).toBeDefined();
  });
  describe('When we call getAllOrders', () => {
    it('should get all orders data', () => {
      spyOn(_service, 'getOrderData').and.callThrough();
      spyOn(comp, 'setPagerConfig');
      comp.getAllOrders(1, '', {});
      expect(comp.setPagerConfig).toHaveBeenCalled();
      expect(comp.orderData.length).toBe(1);
      expect(comp.isLoading).toBe(false)
    })
  });
  describe('When we call setPagerConfig', () => {
    it(' should set the pager config', () => {
      comp.setPagerConfig(10, 1, 5);
      expect(comp.pagerConfig.totalItems).toBe(10);
      expect(comp.pagerConfig.currentPage).toBe(1);
      expect(comp.pagerConfig.itemsPerPage).toBe(5);
    })
  });
  describe('When we call checkActivatedRoute', () => {
    it(' should set the state', () => {
      comp.checkActivatedRoute();
      expect(comp.state).toBe("exception");
    })
  });

  describe('search box spec', () => {
    let input, isFirstLoad = true, date1, date2;
    beforeEach(function () {
      input = comp.searchTxt;
      comp.setPagerConfig(10, 1, 1);
    });
    it(' should set to a valid search text', fakeAsync(() => {
      spyOn(comp, 'getAllOrders');
      comp.searchTypeResult()
      expect(comp.searchTxt).toBe(input);
      tick(1000);
      fixture.detectChanges();
      expect(comp.getAllOrders).toHaveBeenCalled();
    }))
    it(' should be first load', () => {
      comp.searchTypeResult()
      expect(comp.isFirstLoad).toBeFalsy();
    })
  });
  describe('When we call onPageSizeChanged, onPageChanged, onSortChanged', () => {
    beforeEach(() => {
      comp.setPagerConfig(10, 1, 1);
    })
    it(' should change the size of page with more orders data', () => {
      spyOn(comp, 'getAllOrders');
      comp.onPageSizeChanged(10);
      expect(comp.pagerConfig.itemsPerPage).toBe(10);
      expect(comp.getAllOrders).toHaveBeenCalled();
    })
    it(' should change the page with next orders data', () => {
      let pager = { page: 2 }
      spyOn(comp, 'getAllOrders');
      comp.onPageChanged(pager);
      expect(comp.pagerConfig.currentPage).toBe(2);
      expect(comp.getAllOrders).toHaveBeenCalled();

    })
    it(' should get sorted orders data', () => {
      let args = ['firstName', 'asc']
      spyOn(comp, 'getAllOrders');
      comp.onSortChanged(args);
      expect(comp.sortArgs).toBe('firstName,asc');
      expect(comp.getAllOrders).toHaveBeenCalled();
    })
  });
  describe('When we call filterApplied,onRemoveFilter,clearFilters', () => {
    beforeEach(() => {
      comp.setPagerConfig(10, 1, 1);
      spyOn(comp, 'getAllOrders');
    })
    it(' should check for applied filter data', () => {
      let item = { currentPage: 1, sortArgs: '', filterObj: filterObj }
      comp.filterApplied(filterObj);
      expect(comp.getAllOrders).toHaveBeenCalled();
    })
    it(' should remove selected applied filter data', () => {
      let item = { currentPage: 1, sortArgs: '', filterObj: filterObj }
      comp.onRemoveFilter(filterObj);
      expect(comp.getAllOrders).toHaveBeenCalled();
    })
    it(' should clear selected applied filter data', () => {
      let item = { currentPage: 1, sortArgs: '', filterObj: filterObj }
      filterObj = null;
      comp.clearFilters();
      expect(comp.getAllOrders).toHaveBeenCalled();
    })
  });
});