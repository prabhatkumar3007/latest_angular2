import { RouterModule } from '@angular/router';

import { WavesComponent } from './waves/waves.component';
import { OrdersComponent } from './orders/orders.component';
import { BatchComponent } from './batch/batch.component';
import { TaskComponent } from './tasks/task.component';
import { OrderDetailsComponent } from './orders/orderDetails.component';
import { PreventUnsavedChangesGuard } from '../shared/services/prevent-unsaved-changes-guard.service';

import { ContainersComponent } from './containers/containers.component';
import { ContainersDetailsComponent } from './containers/containersDetails.component';





import { AuthGuard } from '../auth/auth-guard.service';

export const operationsRouting = RouterModule.forChild([

  { path: 'waves', component: WavesComponent, canActivate: [AuthGuard], data: { permission: ['all','any pages'] } },
  { path: 'orders', component: OrdersComponent, canActivate: [AuthGuard], data: { permission: ['all','any pages'] } },
  { path: 'batches', component: BatchComponent, canActivate: [AuthGuard], data: { permission: ['all','any pages'] } },
  { path: 'tasks', component: TaskComponent, canActivate: [AuthGuard], data: { permission: ['all','any pages'] } },
  { path: 'orders/:id', component: OrderDetailsComponent, canActivate: [AuthGuard], data: { permission: ['all','any pages'] } },
  { path: 'containers', component: ContainersComponent, canActivate: [AuthGuard], data: { permission: ['all','any pages'] } },
  { path: 'containers/:id', component: ContainersDetailsComponent, canActivate: [AuthGuard], data: { permission: ['all','any pages'] } },

]);