import { AppComponent } from './app.component';
import { routing } from './app.routing';
import { AuthGuard } from './auth/auth-guard.service';
import { AuthService } from './auth/auth.service';
import { ConfigureModule } from './configure/configure.module';
import { configureRouting } from './configure/configure.routing';
import { DashboardModule } from './dashboard/dashboard.module';
import { HomeComponent } from './homePage.component';
import { LoginComponent } from './login.component';
import { OperationsModule } from './operations/operations.module';
import { operationsRouting } from './operations/operations.routing';
import { ProcessModule } from './process/process.module';
import { processRouting } from './process/process.routing';
import { NotFoundComponent } from './shared/components/not-found.component';
import { Globals } from './shared/services/globals.service';
import { PreventUnsavedChangesGuard } from './shared/services/prevent-unsaved-changes-guard.service';
import { SharedModule } from './shared/shared.module';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Http } from '@angular/http';
import { BrowserModule } from '@angular/platform-browser';
import { LocalStorageService, WebStorageModule } from 'sensorthink-commoncontrols/lib/webStore.module';
import { HttpService } from 'sensorthink-commoncontrols/src/common.module';
import { AuthPermissionService } from 'sensorthink-commoncontrols/src/utils.module';

export function httpServiceFactory(http: Http): HttpService {
  return new HttpService(http, new Globals());
}

export let HttpServiceProvider =
  {
    provide: HttpService,
    useFactory: httpServiceFactory,
    deps: [Http]
  };

@NgModule({
  imports: [
    BrowserModule,
    FormsModule,
    SharedModule,
    OperationsModule,
    ConfigureModule,
    ProcessModule,
    processRouting,
    DashboardModule,
    operationsRouting,
    configureRouting,
    processRouting,
    routing,
    WebStorageModule,
  ],
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    NotFoundComponent,
  ],
  providers: [HttpServiceProvider, AuthService, AuthGuard, PreventUnsavedChangesGuard, LocalStorageService,AuthPermissionService],
  bootstrap: [AppComponent]
})
export class AppModule { }