import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { ControlsModule } from '../controls/controls.module';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { SharedModule } from '../shared/shared.module';

import { ProgerssBarService } from '../dashboard/workQueueSummary/services/progressBar.service';
import { PickingService } from './picking/services/picking.service';
import { PackingService } from './packing/services/packing.service';

import { PickingDetailService } from './picking/services/pickingDetail.service';
import { PackingDetailService } from './packing/services/packingDetail.service';
import { ShippingDetailService } from './shipping/services/shippingDetail.service';
import { ShippingService } from './shipping/services/shipping.service';
import { SortingService } from './sorting/services/sorting.service';

import { PickingComponent } from './picking/picking.component';
import { PackingComponent } from './packing/packing.component';
import { PickingModuleDetailComponent } from './picking/pickingModuleDetail.component';
import { PackingModuleDetailComponent } from './packing/packingModuleDetail.component';

import { ShippingComponent } from './shipping/shipping.component';
import { shippingModuleDetailComponent } from './shipping/shippingModuleDetail.component';
import { SortingComponent } from './sorting/sorting.component';

@NgModule({
  imports: [
    RouterModule,
    ControlsModule,
    CommonModule,
    SharedModule,FormsModule
  ],
  declarations: [
    PickingComponent,
    PackingComponent,
    SortingComponent,
    ShippingComponent,
    PickingModuleDetailComponent,
    PackingModuleDetailComponent,
    shippingModuleDetailComponent
  ],
  exports: [
    PickingComponent,
    PackingComponent,
    SortingComponent,
    ShippingComponent,
    PickingModuleDetailComponent,
    PackingModuleDetailComponent,
    shippingModuleDetailComponent
  ],
  providers: [
    ProgerssBarService,
    PickingService,
    PackingService,
    PickingDetailService,
    PackingDetailService,
    ShippingService,
    ShippingDetailService,
    SortingService
  ]
})
export class ProcessModule {
}