import { NotyService } from 'sensorthink-commoncontrols/src/services/noty.service';
import { ActivatedRoute } from '@angular/router';
import { Component } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { ShippingDetailService } from './services/shippingDetail.service';
import { ShiftService } from './../../shared/services/shift.service';

declare var moment: any;
@Component({
  templateUrl: 'shippingModuleDetail.component.html'

})
export class shippingModuleDetailComponent {
  public AreaContents = ["All Areas"];
  public datePickerConfig: any;
  public shippingSummaryData: any;
  public shippingLineSummaryData: any
  public shippingSectionData: any
  public shippingTop5Aging: any;
  public isShippingLoading: boolean = false;
  public isLoading: boolean = false;
  public shift: any;
  public xAxisFormat: string;
  public isXAxisDateType: boolean = true;
  public isWeek: boolean = true;
  public dates: any;
  public isOrder: boolean = false;
  public isOrderLine: boolean = false;
  public isUnits: boolean = false;
  public isContainers: boolean = false;
  public isShow: boolean = false;
  public shippingId: string;
  public shipppingType: string;
  allShift: any;

  constructor(private service: ShippingDetailService, private route: ActivatedRoute, private allShiftService: ShiftService, private notyService: NotyService) {
    this.datePickerConfig = {
      maxDate: new Date(),
      minDate: moment(new Date()).subtract(1, 'M')._d
    };
    if (route.url)
      route.url.subscribe((url: any) => {
        this.shipppingType = url[1].path;
      });
  }

  ngOnInit() {
    this.route.params.subscribe(params => {
      if (params['id']) {
        this.shippingId = params['id'];
      }
    });
    if (this.service.dates)
      this.dates = this.service.dates;
    if (this.service.shift)
      this.shift = this.service.shift.name;
  }

  loadShippingDetailData(fromDate, toDate, isWeek, shift) {
    let calls = [
      this.service.getshippingSummaryData(this.shippingId, this.shipppingType, fromDate, toDate, shift),
      this.service.getShippingProcessRateSummaryData(this.shippingId, this.shipppingType, fromDate, toDate, isWeek, shift),
      this.service.getShippingData(this.shippingId, this.shipppingType, fromDate, toDate, shift),
      this.service.getShippingSectionProcessRate(this.shippingId, this.shipppingType, fromDate, toDate, isWeek, shift)
    ];
    this.isShippingLoading = true;
    Observable.forkJoin(calls).subscribe(
      data => {
        if (data[0] && data[0][0]) { this.shippingSummaryData = data[0][0].pickingData; }
        else { this.shippingSummaryData = null; }
        if (data[1])
          this.shippingLineSummaryData = data[1][0] || null;
        if (data[2] && data[3])
          this.shippingSectionData = this.parseProcessDataToSection(data[2], data[3]);
        else
          this.shippingSectionData = null;
        this.isShippingLoading = false;
      },
      err => {
        this.notyService.error(err)
      }
    )
  }

  loadTop5Aging(pickingFrom, toDate, limit, fromDate, shift) {
    if (pickingFrom === "orderLines" || pickingFrom === "units") {
      this.isShow = true
    }
    this.isLoading = true;
    this.service.getTop5Aging(pickingFrom, toDate, 5, fromDate, shift).subscribe((data) => {
      this.showTabs(pickingFrom);
      this.shippingTop5Aging = data;
      this.isLoading = false;
    });
  }

  showTabs(value) {
    this.isOrder = this.isOrderLine = this.isUnits = this.isContainers = this.isShow = false;
    switch (value) {
      case "orders":
        this.isOrder = true;
        break;
      case "orderlines":
        this.isOrderLine = true;
        break;
      case "units":
        this.isUnits = true;
        break;
      case "containers":
        this.isContainers = true;
        break;
      default:
        break;
    }
  }

  parseProcessDataToSection(sectionList, processData) {
    let sectionData: any = sectionList;
    sectionData.forEach(element => {
      let processRate: any = processData;
      let tmp = processRate.filter((f) => {
        if (f.processRateType === element.groupName)
          return f;
      })
      element.processRate = tmp[0];
    });
    return sectionData;
  }

  dateChangeCallback(date) {
    this.dates = date;
    if (date.isWeek === true) {
      this.xAxisFormat = "ddd"
      this.isWeek = true;
    }
    else {
      this.xAxisFormat = "HH:mm";
      this.isWeek = false;
    }
    this.allShiftService.getAllShift().then((res) => {
      this.allShift = res;
      this.loadShippingDetailData(date.formattedDates[0], date.formattedDates[1], date.isWeek, this.shift);
      this.loadTop5Aging(this.shipppingType, this.dates.formattedDates[1], 5, this.dates.formattedDates[0], this.shift);
    })

  }
  shiftChangeCallback(shift) {
    this.shift = shift.name;
    this.loadShippingDetailData(this.dates.formattedDates[0], this.dates.formattedDates[1], this.dates.isWeek, this.shift);
    this.loadTop5Aging(this.shipppingType, this.dates.formattedDates[1], 5, this.dates.formattedDates[0], this.shift);
  }
}
