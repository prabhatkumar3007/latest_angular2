import { UtilService } from 'sensorthink-commoncontrols/src/services/util.service';
import { ProcessRateData, ProcessRateDataPoint } from '../../../dashboard/processRate/services/processRate.data';
import { ShippingTab } from './shipping.data';
import { Injectable } from '@angular/core';
import { ProcessData, ProcessSection } from 'sensorthink-commoncontrols/src/chart.module';
import { HttpService } from 'sensorthink-commoncontrols/src/common.module';
declare let moment: any;

@Injectable()
export class ShippingService {
    constructor(private $http: HttpService, private utilService: UtilService) { }
    avg: number;

    getShippingSummary(shippingFrom, fromDate, toDate, shift) {
        return this.$http.wesContext.url("/api/workqueue/" + shippingFrom).addParam("processType", "Shipping").addParam("fromDate", fromDate)
            .addParam("toDate", toDate).addParam("shift", shift).get().map((res) => {
                if (!res.text())
                    return null;
                let obj = res.json();
                let shippingData = new ProcessData(obj[0].processTime);
                obj[0].dataPoints.forEach(element => {
                    shippingData.addProcessValues(new ProcessSection(element.key, element.value));
                });
                shippingData.calculatePercentageWidths();
                return shippingData;
            });
    }

    getShippingData(shippingFrom, fromDate, toDate, shift) {
        return this.$http.wesContext.url("/api/workqueue/" + shippingFrom).addParam("processType", "Shipping").addParam("groupBy", "parentModule")
            .addParam("fromDate", fromDate).addParam("toDate", toDate).addParam("shift", shift).get().map((res) => {
                if (!res.text())
                    return null;
                let obj = res.json();
                let orderPickings: Array<ShippingTab> = new Array<ShippingTab>();
                obj.forEach(el => {
                    let shippingData = new ProcessData(el.processTime);
                    el.dataPoints.forEach(dataPoint => {
                        shippingData.addProcessValues(new ProcessSection(dataPoint.key, dataPoint.value));
                    });
                    shippingData.calculatePercentageWidths();
                    if (el.group)
                        orderPickings.push(new ShippingTab(el.group, shippingData));
                });
                return orderPickings;
            });
    }


    getShippingProcessRateSummary(shippingFrom, fromDate, toDate, isWeek, shift) {
        return this.$http.wesContext.url("/api/processrate/" + shippingFrom).addParam("processType", "Shipping").addParam("fromDate", fromDate)
            .addParam("toDate", toDate).addParam("shift", shift).get().map((res) => {
                if (!res.text())
                    return null;
                let obj = res.json();
                if (!obj[0].dataPoints[0].xAxis)
                    return null;
                this.utilService.setTimeZone(obj[0].dataPoints, ["xAxis"]);
                let summaryProcessRate = this.parseProcessRate(obj[0], isWeek, fromDate, toDate)
                return summaryProcessRate;
            });
    }



    getShippingSectionProcessRate(shippingFrom, fromDate, toDate, isWeek, shift) {
        return this.$http.wesContext.url("/api/processrate/" + shippingFrom).addParam("processType", "Shipping").addParam("groupBy", "parentModule")
            .addParam("fromDate", fromDate).addParam("toDate", toDate).addParam("shift", shift).get().map((res) => {
                if (!res.text())
                    return null;
                let obj = res.json();
                obj.forEach(el => {
                    this.utilService.setTimeZone(el.dataPoints, ["xAxis"])
                });
                let processRates: Array<ProcessRateData> = new Array<ProcessRateData>();
                obj.forEach(el => {
                    processRates.push(this.parseProcessRate(el, isWeek, fromDate, toDate));
                });
                return processRates;
            });
    }
    getTop5Aging(pickingFrom, toDate, limit, fromDate, shift) {

        return this.$http.wesContext.url("/api/" + pickingFrom + "/top").addParam("limit", limit).addParam("processType", "Shipping").addParam("fromDate", fromDate)
            .addParam("toDate", toDate).addParam("shift", shift).get().map((res) => {
                if (!res.text())
                    return null;
                let obj = res.json();
                let endDates = this.setDate(toDate);
                let endDate = endDates.substr(0, endDates.indexOf(' '));
                for (var i = 0; i < obj.length; i++) {
                    obj[i].toDate = endDate;
                }
                return obj;
            });
    }
    private parseProcessRate(obj, isWeek, minTime, maxTime): ProcessRateData {
        let orderData;
        let data = [];
        let isZero: boolean;
        if (obj.dataPoints) {
            if (isWeek) {
                this.parseDataForWeek(obj.dataPoints).forEach(dataPoint => {
                    data.push(dataPoint);
                });
            }
            else {
                obj.dataPoints.forEach(element => {
                    data.push(new ProcessRateDataPoint(moment(this.parseDate(element.xAxis)), element.yAxis));
                });

                if (moment(data[0].x) > minTime)
                    data.splice(0, 0, new ProcessRateDataPoint(moment(minTime), 0));

                if (moment(data[data.length - 1].x) < maxTime)
                    data.push(new ProcessRateDataPoint(moment(maxTime), 0));
            }

            orderData = new ProcessRateData(obj.processRateType, obj.percentageChange, obj.actualRate, obj.targetRate, data);
            orderData.targetRate = obj.targetRate;
            orderData.actualRate = obj.actualRate;
            orderData.projectedTime = (moment(obj.projectedTime).isValid()) ? this.utilService.convertToCompanyTimeZone(obj.projectedTime, 'MM/DD/YYYY HH:mm:ss') : obj.projectedTime;
            orderData.targetTime = (moment(obj.targetTime).isValid()) ? this.utilService.convertToCompanyTimeZone(obj.targetTime, 'MM/DD/YYYY HH:mm:ss') : obj.targetTime;
            this.truncate(obj.avgProcessRate, 3)
            orderData.avgProcessRate = this.avg;

        }
        return orderData;
    }
    truncate(num, places) {
        return this.avg = Math.trunc(num * Math.pow(10, places)) / Math.pow(10, places);
    }

    private parseDataForWeek(dataPoints) {
        let tempParseObject: any = {};
        dataPoints.forEach(data => {
            let parsedDate = moment(this.parseDate(data.xAxis)).format("MMDDYYYY");
            if (tempParseObject[parsedDate] === undefined) {
                tempParseObject[parsedDate] = new ProcessRateDataPoint(moment(this.parseDate(data.xAxis.split(" ")[0])).day() - 1, data.yAxis);
            }
            else {
                tempParseObject[parsedDate].y += data.yAxis;
            }
        });
        let tmpArray = [];
        for (var property in tempParseObject) {
            if (tempParseObject.hasOwnProperty(property)) {
                tmpArray.push(tempParseObject[property])
            }
        }
        return tmpArray;
    }
    private parseDate(date) {
        let datePart = date.substring(0, date.length - 6);
        let zone = date.substring(date.length - 6, date.length);
        let d = moment(datePart).utcOffset(zone);
        return d._d;
    }
    setDate(date) {
        if (date) {
            return date = date.substr(0, 2) + '/' + date.substr(2, 2) + '/' + date.substr(4, date.length);
        }
    }

}