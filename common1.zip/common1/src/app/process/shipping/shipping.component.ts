import { ShareDataService } from 'sensorthink-commoncontrols/src/services/shareDataService';
import { NotyService } from 'sensorthink-commoncontrols/src/services/noty.service';
import { Component, ChangeDetectorRef } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { ShippingService } from './services/shipping.service';
import { ShippingDetailService } from './services/shippingDetail.service';
import { Router } from '@angular/router';
import { ShiftService } from './../../shared/services/shift.service';

declare let moment: any;
@Component({
  templateUrl: 'shipping.component.html'

})
export class ShippingComponent {
  public AreaContents = ['All Areas'];
  public summaryData: any;
  public summaryProcessRateData: any;

  public shippingOrderData: any
  public shippingOrderProcessData: any
  public shippingOrderLinesData: any
  public shippingUnitsData: any
  public shippingContainersData: any
  public shippingTop5Aging: any;
  public shippingTop5ExceptionSKU: any;

  public isShippingSummaryLoading: boolean = false;
  public isLoading: boolean = false;

  public isShippingTabLoading: boolean = false;
  public datePickerConfig: any;
  public shift: any = "All Shifts";
  public sideBarVisible: boolean;
  public dates: any;

  private selectedTab: string;
  xAxisFormat: string;
  isXAxisDateType: boolean = true;
  isWeek: boolean = true;
  isOrder: boolean = false;
  isOrderLine: boolean = false;
  isUnits: boolean = false;
  isContainers: boolean = false;
  isShow: boolean = false;
  allShift: any;

  constructor(private service: ShippingService, private ShippingDetailService: ShippingDetailService, private sharedService: ShareDataService, private allShiftService: ShiftService, private router: Router, private noty: NotyService) {
    this.datePickerConfig = {
      maxDate: new Date(),
      minDate: moment(new Date()).subtract(1, 'M')._d
    };
  }
  ngOnInit() {
    if (this.ShippingDetailService.dates)
      this.dates = this.ShippingDetailService.dates;
    if (this.ShippingDetailService.shift)
      this.shift = this.ShippingDetailService.shift.name;
    if (this.sharedService.objectStore.shippingSelectedTab) {
      this.selectedTab = this.sharedService.objectStore.shippingSelectedTab;
    } else {
      this.selectedTab = "orders";
      this.showTabs(this.selectedTab);
    }
  }
  loadSummarySection(shippingType, fromDate, toDate, isWeek, shift) {
    this.sharedService.objectStore.fromDate = fromDate;
    this.sharedService.objectStore.toDate = toDate;
    this.sharedService.objectStore.shiftValue = this.shift;
    this.sharedService.objectStore.containerTypeValue = 'Ship'; //provide value for advance filter after selecting drill down
    let calls = [
      this.service.getShippingSummary(shippingType, fromDate, toDate, shift),
      this.service.getShippingProcessRateSummary(shippingType, fromDate, toDate, isWeek, shift)
    ]
    this.isShippingSummaryLoading = true;
    Observable.forkJoin(calls).subscribe(
      data => {
        this.summaryData = data[0];
        this.summaryProcessRateData = data[1];
        this.isShippingSummaryLoading = false;
      },
      err => {
        this.summaryData = null;
        this.summaryProcessRateData = null;
        this.isShippingSummaryLoading = false;
      });
  }
  loadShippingModuleSection(shippingType, fromDate, toDate, isWeek, shift, sectionDataKey, processSectionKey) {
    let calls = [
      this.service.getShippingData(shippingType, fromDate, toDate, shift),
      this.service.getShippingSectionProcessRate(shippingType, fromDate, toDate, isWeek, shift)
    ]
    this.isShippingTabLoading = true;
    Observable.forkJoin(calls).subscribe(
      (data: any) => {
        if (data[0]) {
          data[0].forEach((element, idx) => {
            if (data[1]) {
              element.processRate = data[1][idx];
            }
            else {
              element.processRate = null
            }
          });
        }
        this[sectionDataKey] = data[0] || [];
        this.isShippingTabLoading = false;
      },
      (err) => {
        this.noty.error(err)
        this.isShippingTabLoading = false;
      });
  }
  loadShippingOrders(fromDate, toDate, isWeek, shift) {
    this.loadSummarySection("orders", fromDate, toDate, isWeek, shift)
    this.loadShippingModuleSection("orders", fromDate, toDate, isWeek, shift, "shippingOrderData", "shippingOrderProcessData")
  }

  loadShippingOrdersLines(fromDate, toDate, isWeek, shift) {
    this.loadSummarySection("orderlines", fromDate, toDate, isWeek, shift)
    this.loadShippingModuleSection("orderlines", fromDate, toDate, isWeek, shift, "shippingOrderLinesData", "shippingOrderProcessData")
  }

  loadShippingUnits(fromDate, toDate, isWeek, shift) {
    this.loadSummarySection("units", fromDate, toDate, isWeek, shift);
    this.loadShippingModuleSection("units", fromDate, toDate, isWeek, shift, "shippingUnitsData", "shippingOrderProcessData");
  }
  loadShippingContainers(fromDate, toDate, isWeek, shift) {
    this.loadSummarySection("containers", fromDate, toDate, isWeek, shift)
    this.loadShippingModuleSection("containers", fromDate, toDate, isWeek, shift, "shippingContainersData", "shippingOrderProcessData")
  }
  loadTop5Aging(pickingFrom, toDate, limit, fromDate, shift) {
    if (pickingFrom === "orderlines" || pickingFrom === "units") {
      this.isShow = true
    }
    this.isLoading = true;
    this.service.getTop5Aging(pickingFrom, toDate, 5, fromDate, shift).subscribe((data) => {
      this.showTabs(pickingFrom);
      this.shippingTop5Aging = data;
      this.isLoading = false;
    });
  }
  showTabs(value) {
    this.isOrder = this.isOrderLine = this.isUnits = this.isContainers = this.isShow = false;
    switch (value) {
      case "orders":
        this.isOrder = true;
        break;
      case "orderLines":
        this.isOrderLine = true;
        break;
      case "units":
        this.isUnits = true;
        break;
      case "containers":
        this.isContainers = true;
        break;
      default:
        break;
    }
  }

  dateChangeCallback(date) {
    this.dates = date;
    this.ShippingDetailService.dates = date;
    if (date.isWeek === true) {
      this.xAxisFormat = "ddd"
      this.isWeek = true;
    }
    else {
      this.xAxisFormat = "HH:mm";
      this.isWeek = false;
    }
    this.allShiftService.getAllShift().then((res) => {
      this.allShift = res;
      this.tabChanged(this.selectedTab);
    })

  }
  shiftChangeCallback(shift) {
    this.shift = shift.name;
    this.ShippingDetailService.shift = shift;
    this.tabChanged(this.selectedTab);
  }
  tabChanged(tabId) {
    this.selectedTab = tabId;
    this.sharedService.objectStore.shippingSelectedTab = tabId;
    switch (tabId) {
      case "orders":
        this.loadShippingOrders(this.dates.formattedDates[0], this.dates.formattedDates[1], this.dates.isWeek, this.shift);
        this.loadTop5Aging("orders", this.dates.formattedDates[1], 5, this.dates.formattedDates[0], this.shift);
        break;
      case "orderLines":
        this.loadShippingOrdersLines(this.dates.formattedDates[0], this.dates.formattedDates[1], this.dates.isWeek, this.shift);
        // this.loadTop5Aging("orderlines", this.dates.formattedDates[1], 5, this.dates.formattedDates[0], this.shift);//todo if data comes in future
        break;
      case "units":
        this.loadShippingUnits(this.dates.formattedDates[0], this.dates.formattedDates[1], this.dates.isWeek, this.shift);
        // this.loadTop5Aging("units", this.dates.formattedDates[1], 5, this.dates.formattedDates[0], this.shift);//todo if data comes in future
        break;
      case "containers":
        this.loadShippingContainers(this.dates.formattedDates[0], this.dates.formattedDates[1], this.dates.isWeek, this.shift);
        this.loadTop5Aging("containers", this.dates.formattedDates[1], 5, this.dates.formattedDates[0], this.shift);
        break;
      default:
        break;
    }
  }
  onWorkQueueSectionSelect(data, parentModule) {
    if (this.selectedTab === "orders")
      this.router.navigate(['/orders'], { queryParams: { status: data.toLowerCase(), processType: 'Shipping', parentModule: parentModule } });
    if (this.selectedTab === "containers")
      this.router.navigate(['/containers'], { queryParams: { status: data.toLowerCase(), processType: 'Shipping', parentModule: parentModule } });
  }
}