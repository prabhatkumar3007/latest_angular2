import { NotyService } from 'sensorthink-commoncontrols/src/services/noty.service';
import { ComponentFixture, TestBed, async, inject } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement, Directive } from '@angular/core';
import { ShippingComponent } from './shipping.component';
import { ShippingService } from './services/shipping.service';
import { ShippingDetailService } from './services/shippingDetail.service';
import { ProcessModule } from '../process.module';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { RouterStub } from '../../../test/routerStub';

class MockShipService {
    getShippingSummary(): Observable<any> { return Observable.of({}); };
    getShippingProcessRateSummary(): Observable<any> { return Observable.of({}); };
    getTop5Aging(): Observable<any> { return Observable.of({}); };
    getShippingData(): Observable<any> { return Observable.of({}); };
    getShippingSectionProcessRate(): Observable<any> { return Observable.of({}); };
    //getTop5ExceptionSKU(): Observable<any> { return Observable.of({}); };
}
class MockShipDetailService {
}
describe('SHIP:... Component', () => {

    let component: ShippingComponent;
    let fixture: ComponentFixture<ShippingComponent>;
    let de: DebugElement;
    let el: HTMLElement;
    let service;
    let noty;
    let router

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [ProcessModule],
            providers: [{ provide: ShippingService, useClass: MockShipService }, { provide: ShippingDetailService, useClass: MockShipDetailService },
            { provide: Router, useClass: RouterStub }, NotyService]
        })
        fixture = TestBed.createComponent(ShippingComponent);
        component = fixture.componentInstance;
        service = fixture.debugElement.injector.get(ShippingService);
        router = fixture.debugElement.injector.get(Router);
        noty = fixture.debugElement.injector.get(NotyService);
    }));

    it('should have a defined component', () => {
        expect(component).toBeDefined();
    });

    describe('When we call ', () => {
        let fromDate, toDate, isWeek, shift;
        beforeEach(() => {
            fromDate = "03232017 00:00:00";
            toDate = "03232017 23:59:59";
            isWeek = false;
            shift = 'Morning'
        })
        it(' loadSummarySection should get all Shipping Summary and summaryProcessRateData', () => {
            spyOn(service, 'getShippingSummary').and.returnValue(Observable.of([{}, {}]));
            spyOn(service, 'getShippingProcessRateSummary').and.returnValue(Observable.of([{}, {}]));
            component.loadSummarySection("orders", fromDate, toDate, isWeek, shift);
            expect(component.summaryData.length).toBe(2);
            expect(component.summaryProcessRateData.length).toBe(2);
        })
        it(' loadShippingModuleSection should get all getShippingData and getPickingSectionProcessRate', () => {
            spyOn(service, 'getShippingData').and.returnValue(Observable.of([{}, {}]));
            spyOn(service, 'getShippingProcessRateSummary').and.returnValue(Observable.of([{}, {}]));
            component.loadShippingModuleSection("orders", fromDate, toDate, isWeek, shift, 'shippingOrderData', '');
            expect(component['shippingOrderData'].length).toBe(2);
        })
    });

    describe('When we call', () => {
        let fromDate, toDate, isWeek, shift;
        beforeEach(() => {
            fromDate = "03232017 00:00:00";
            toDate = "03232017 23:59:59";
            isWeek = false;
            shift = 'Morning'
        })
        it(' loadShippingOrders should set the order Tab', () => {
            spyOn(component, 'loadSummarySection');
            spyOn(component, 'loadShippingModuleSection');
            component.loadShippingOrders(fromDate, toDate, isWeek, shift);
            expect(component.loadSummarySection).toHaveBeenCalled();
            expect(component.loadShippingModuleSection).toHaveBeenCalled();
        })
        it(' loadShippingOrdersLines should set the orderLines Tab', () => {
            spyOn(component, 'loadSummarySection');
            spyOn(component, 'loadShippingModuleSection');
            component.loadShippingOrdersLines(fromDate, toDate, isWeek, shift);
            expect(component.loadSummarySection).toHaveBeenCalled();
            expect(component.loadShippingModuleSection).toHaveBeenCalled();
        })
        it(' loadShippingUnits should set the pager config', () => {
            spyOn(component, 'loadSummarySection');
            spyOn(component, 'loadShippingModuleSection');
            component.loadShippingUnits(fromDate, toDate, isWeek, shift);
            expect(component.loadSummarySection).toHaveBeenCalled();
            expect(component.loadShippingModuleSection).toHaveBeenCalled();
        })
        it(' loadShippingContainers should set the pager config', () => {
            spyOn(component, 'loadSummarySection');
            spyOn(component, 'loadShippingModuleSection');
            component.loadShippingContainers(fromDate, toDate, isWeek, shift);
            expect(component.loadSummarySection).toHaveBeenCalled();
            expect(component.loadShippingModuleSection).toHaveBeenCalled();
        })

    });

    describe('When we call loadTop5Aging', () => {
        let fromDate, toDate, isWeek, shift;
        beforeEach(() => {
            fromDate = "03232017 00:00:00";
            toDate = "03232017 23:59:59";
            isWeek = false;
            shift = 'Morning'
        })
        it(' should get the top 5 data', () => {
            spyOn(service, "getTop5Aging").and.returnValue(Observable.of({}));
            spyOn(component, 'loadTop5Aging');
            component.loadTop5Aging('orders', toDate, 5, fromDate, shift);
            expect(component.loadTop5Aging).toHaveBeenCalled();
        })
    });

    describe("When we call", function () {
        var fixture2expectation = ["orders", "orderLines", "units", "containers"];
        var isCheck = true;
        let fromDate, toDate, isWeek, shift;
        beforeEach(() => {
            fromDate = "03232017 00:00:00";
            toDate = "03232017 23:59:59";
            isWeek = false;
            shift = 'Morning';
            component.dates = { dates: [new Date()], isWeek: false, formattedDates: ["04102017 00:00:00", "04102017 23:59:59"] };
            spyOn(component, 'loadTop5Aging');
            spyOn(component, 'loadShippingOrders');
            spyOn(component, 'loadShippingOrdersLines');
            spyOn(component, 'loadShippingUnits');
            spyOn(component, 'loadShippingContainers');

        })
        it("it activates the tab", function () {
            for (var fixtureString in fixture2expectation) {
                component.showTabs(fixtureString);
                expect(isCheck).not.toBeFalsy();
            }
        });
        it("it activates the order tab", function () {
            component.tabChanged(fixture2expectation[0]);
            expect(component.loadTop5Aging).toHaveBeenCalled();
            expect(component.loadShippingOrders).toHaveBeenCalled();
        });
        it("it activates the orderLines tab", function () {
            component.tabChanged(fixture2expectation[1]);
            expect(component.loadShippingOrdersLines).toHaveBeenCalled();
        });
        it("it activates the units tab", function () {
            component.tabChanged(fixture2expectation[2]);
            expect(component.loadShippingUnits).toHaveBeenCalled();
        });
        it("it activates the containers tab", function () {
            component.tabChanged(fixture2expectation[3]);
            expect(component.loadTop5Aging).toHaveBeenCalled();
            expect(component.loadShippingContainers).toHaveBeenCalled();
        });
    });

    describe('When we call ', () => {
        let date;
        beforeEach(() => {
            date = { dates: [new Date()], isWeek: false, formattedDates: ["04102017 00:00:00", "04102017 23:59:59"] };
            spyOn(service, 'getShippingData').and.returnValue(Observable.of([{}, {}]));
            spyOn(service, 'getShippingSectionProcessRate').and.returnValue(Observable.of([{}, {}]));
            spyOn(component, 'tabChanged');
        })
        it(' dateChangeCallback and isWeek is true then it should set the x-axis as days', () => {
            date.isWeek = true;
            component.dateChangeCallback(date);
            expect(component.xAxisFormat).toBe('ddd');
            expect(component.isWeek).toBe(true);
            expect(component.tabChanged).toHaveBeenCalled();
        })
        it(' dateChangeCallback and isWeek is false then it should set the x-axis as hr', () => {
            component.dateChangeCallback(date);
            expect(component.xAxisFormat).toBe('HH:mm');
            expect(component.isWeek).toBe(false);
            expect(component.tabChanged).toHaveBeenCalled();
        })
        it(' shiftChangeCallback should set the shift', () => {
            component.shiftChangeCallback({ text: 'Morning' });
            expect(component.shift).toBe('Morning');
            expect(component.tabChanged).toHaveBeenCalled();
        })
    });

    describe('When we call onWorkQueueSectionSelect', () => {
        it(' should go order', async(() => {
            spyOn(router, 'navigate');
            component.onWorkQueueSectionSelect('orders', 1)
            expect(router.navigate).toHaveBeenCalledWith(['/orders'], { queryParams: { status: 'orders', processType: 'Shipping', parentModule:'' } });
        }));
    });
});
