import { ActivatedRoute, Router } from '@angular/router';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MockActivatedRouteById } from '../../../test/mockActivateRoute';
import { NotyService } from 'sensorthink-commoncontrols/src/services/noty.service';
import { Observable } from 'rxjs/Observable';
import { ProcessModule } from '../process.module';
import { RouterStub } from '../../../test/routerStub';
import { ShippingDetailService } from './services/shippingDetail.service';
import { shippingModuleDetailComponent } from './shippingModuleDetail.component';

class MockPickingDetailService {
    getshippingSummaryData(): Observable<any> { return Observable.of({}); };
    getShippingProcessRateSummaryData(): Observable<any> { return Observable.of({}); };
    getShippingData(): Observable<any> { return Observable.of({}); };
    getShippingSectionProcessRate(): Observable<any> { return Observable.of({}); };
    getTop5Aging(): Observable<any> { return Observable.of({}); };
}
describe('SHIP CONTAINER DETAILS:... Component', () => {

    let component: shippingModuleDetailComponent;
    let fixture: ComponentFixture<shippingModuleDetailComponent>;
    let service;
    let router;
    let noty;
    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [ProcessModule],
            providers: [{ provide: ShippingDetailService, useClass: MockPickingDetailService },
            { provide: Router, useClass: RouterStub },
            { provide: ActivatedRoute, useClass: MockActivatedRouteById }, NotyService]
        })
        // https://angular-2-training-book.rangle.io/handout/testing/components/injecting-dependencies.html
        fixture = TestBed.overrideComponent(shippingModuleDetailComponent, {
            set: {
                template: '<span>{{message}}</span>'
            }
        })
            .createComponent(shippingModuleDetailComponent);
        component = fixture.componentInstance;
        service = fixture.debugElement.injector.get(ShippingDetailService);
        router = fixture.debugElement.injector.get(ActivatedRoute);
        noty = fixture.debugElement.injector.get(NotyService);
    });
    it('should have a defined component', () => {
        spyOn(router, "url").and.returnValue(Observable.of({}));
        expect(component).toBeDefined();
    });
    describe('When we call loadShippingDetailData', () => {
        let fromDate, toDate, isWeek, shift;
        beforeEach(() => {
            fromDate = "03232017 00:00:00";
            toDate = "03232017 23:59:59";
            isWeek = false;
            shift = 'Morning';
            component.dates = { dates: [new Date()], isWeek: false, formattedDates: ["04102017 00:00:00", "04102017 23:59:59"] };

        })
        it('should get all pickContainer details data', () => {
            spyOn(service, 'getshippingSummaryData').and.returnValue(Observable.of({}));
            spyOn(service, 'getShippingProcessRateSummaryData').and.returnValue(Observable.of({}));
            spyOn(service, 'getShippingData').and.returnValue(Observable.of([{}, {}]));
            spyOn(service, 'getShippingSectionProcessRate').and.returnValue(Observable.of([{}, {}]));
            component.loadShippingDetailData(fromDate, toDate, isWeek, shift);
            expect(component.shippingSummaryData).toBeNull();
            expect(component.shippingLineSummaryData).toBeNull();;
            expect(component.shippingSectionData.length).toBe(2);
            expect(component.isShippingLoading).toBe(false)
        })
    });
    describe('When we call showTabs', () => {
        var fixture2expectation = ["orders", "orderLines", "units", "containers"];
        var isCheck = true;
        it("it activates the tab", function () {
            for (var fixtureString in fixture2expectation) {
                component.showTabs(fixtureString);
                expect(isCheck).not.toBeFalsy();
            }
        });
    });
    describe('When we call loadTop5Aging', () => {
        let fromDate, toDate, isWeek, shift;
        beforeEach(() => {
            fromDate = "03232017 00:00:00";
            toDate = "03232017 23:59:59";
            isWeek = false;
            shift = 'Morning'
        })
        it(' should get the top 5 data', () => {
            spyOn(service, "getTop5Aging").and.returnValue(Observable.of({}));
            spyOn(component, 'loadTop5Aging');
            component.loadTop5Aging('orders', toDate, 5, fromDate, shift);
            expect(component.loadTop5Aging).toHaveBeenCalled();
        })
    });
    describe('When we call ', () => {
        let date;
        beforeEach(() => {
            component.dates = { dates: [new Date()], isWeek: false, formattedDates: ["04102017 00:00:00", "04102017 23:59:59"] };
            date = { dates: [new Date()], isWeek: false, formattedDates: ["04102017 00:00:00", "04102017 23:59:59"] };
            spyOn(component, 'loadShippingDetailData');
            spyOn(component, 'loadTop5Aging');
        })
        it(' dateChangeCallback and isWeek is true then it should set the x-axis as days', () => {
            date.isWeek = true;
            component.dateChangeCallback(date);
            expect(component.xAxisFormat).toBe('ddd');
            expect(component.isWeek).toBe(true);
        })
        it(' dateChangeCallback and isWeek is false then it should set the x-axis as hr', () => {
            component.dateChangeCallback(date);
            expect(component.xAxisFormat).toBe('HH:mm');
            expect(component.isWeek).toBe(false);
        })
        it(' shiftChangeCallback should set the shift', () => {
            component.shiftChangeCallback({ text: 'Morning' });
            expect(component.shift).toBe('Morning');
        })
    });
});