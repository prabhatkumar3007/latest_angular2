import { Component } from '@angular/core';
import { DatePipe } from 'sensorthink-commoncontrols/src/pipes/dateFormater.pipe';
import { NotyService } from 'sensorthink-commoncontrols/src/services/noty.service';
import { Router } from '@angular/router';
import { SortingService } from './services/sorting.service';

@Component({
  templateUrl: 'sorting.component.html'
})
export class SortingComponent {
  selectedSortPlan: any;
  selectedTab: string = "routeView";
  isNewPlan: boolean = true;
  isEditMode: boolean = false;
  isSortPlanLoading: boolean = false;
  isSaveAs: boolean = false

  showRouteData = [];
  showDestinationData = [];
  routeArray = [];

  masterData: any = {};
  sortingModel: any = {};
  newSortPlanName: string = '';
  sortPlanName: string;
  lastModifiedBy: string;
  lastModifiedTime: string;

  constructor(private service: SortingService, private noty: NotyService) {
    this.initializeData();
  }

  initializeData() {
    this.service.getSorters().subscribe(res => {
      this.masterData.sorterTypes = res;
      this.sortingModel.sorterType = res[0]
    });
    this.masterData.priorityOptions = this.service.priorityOption;
  }

  loadDestinations(sorterType: any) {
    //mapped to physicalLocations in API
    this.service.getDestinations(sorterType.text).subscribe(res => {
      this.masterData.destinations = res;
    });
  }


  loadRoutes(sorterType: any) {
    return this.service.getRoutes(sorterType.text).then(res => {
      this.masterData.routes = res;
    });
  }

  getSortPlans(sorterType) {
    this.onPlanCancel();
    this.resetScreen();
    this.loadRoutes(sorterType);
    this.loadDestinations(sorterType);
    return this.service.getSortPlans(sorterType.text).then(res => {
      this.masterData.sortPlans = res;
      this.sortingModel.sortPlan = res[0];
    })
  }

  tabChanged(tabId) {
    this.selectedTab = tabId;
    switch (tabId) {
      case "routeView":
        setTimeout(() => {
          this.showRouteData = JSON.parse(JSON.stringify(this.showRouteData))
        }, 200);
      case "destinationView":
        setTimeout(() => {
          this.showDestinationData = this.service.parsePlanForDestinationView(this.showRouteData);
        }, 175);
        break;
      default:
        break;
    }
  }

  loadSortPlan(isSaveAs: boolean = false) {
    if (this.sortingModel.sortPlan.text === "--Select--") {
      this.onPlanCancel();
      return;
    }
    if (!isSaveAs)
      this.isSaveAs = false;
    this.isSortPlanLoading = true;
    this.newSortPlanName = this.sortPlanName = this.sortingModel.sortPlan.text;
    return this.service.getSortPlan(this.sortingModel.sortPlan.text, this.sortingModel.sorterType.text).then(res => {
      this.selectedSortPlan = res;
      this.lastModifiedBy = res.modifiedBy.firstName + " " + res.modifiedBy.lastName;
      this.lastModifiedTime = new DatePipe().transform(res.modifiedTime, "MM/DD/YYYY,hh:mm:00");
      let plans = this.service.parsePlanForEdit(res.sortPlanRoutes, this.masterData).subscribe((res) => {
        let data;
        data = Object.assign([], res);
        this.isNewPlan = false;
        this.routeArray = data.edit;
        this.showRouteData = data.view;
        this.showDestinationData = this.service.parsePlanForDestinationView(data.view);
      }, (err) => {
        this.noty.error('Error occured while loading plan.');
        this.isSortPlanLoading = false;
      });
      this.isEditMode = true;
      this.isSortPlanLoading = false;
    });
  }

  saveAs($event, target) {
    this.isSaveAs = true;
    this.loadSortPlan(true).then(() => {
      this.isEditMode = false;
    });
  }

  onPlanCreate() {
    this.isNewPlan = false;
    this.isEditMode = false;
    this.addRouteSection()
  }

  onPlanCancel() {
    this.newSortPlanName = '';
    this.sortingModel.sortPlan = "--Select--"
    this.resetScreen();
  }

  addRouteSection() {
    this.routeArray.push(this.createRouteObject());
  }

  copyRouteSection(routeItem) {
    let dup = JSON.parse(JSON.stringify(routeItem));
    dup.route = this.masterData.routes.find(f => f.sortDestination == dup.route.sortDestination);
    for (let i = 0; i < dup.destinations.length; i++) {
      dup.destinations[i].destination = this.masterData.destinations.find(f => f.locationAlias == dup.destinations[i].destination.locationAlias);
    }
    // delete dup.route.id;
    dup.destinations.forEach(d => {
      delete d.id;
    });
    this.routeArray.push(dup);
  }

  addDestination(_arr) {
    _arr.push({
      destination: this.masterData.destinations[0],
      priority: this.masterData.priorityOptions[0]
    })
    return _arr;
  }

  removeRouteSection(routeToRemove) {
    if (this.routeArray.length > 0) {
      var index = this.routeArray.indexOf(routeToRemove);
      this.routeArray.splice(index, 1);
    }
  }

  removeDestinationSection(_arr, destinationToRemove) {
    if (_arr.length > 1) {
      var index = _arr.indexOf(destinationToRemove);
      _arr.splice(index, 1);
    }
    return _arr;
  }

  onAddClick(resultData) {
    let res = this.service.parseNewPlan(resultData)
    if (!this.checkUniqueRouteDestination(res)) {
      this.noty.error("Duplicate Route and Destination combinations found.")
      return;
    }
    this.sortPlanName = this.newSortPlanName;
    this.service.createSortPlan(this.newSortPlanName, res, this.sortingModel.sorterType.val).subscribe(res => {
      let tmp = this.newSortPlanName;
      this.getSortPlans(this.sortingModel.sorterType).then(res => {
        this.sortingModel.sortPlan = this.masterData.sortPlans.find(s => s.text === tmp);
        this.loadSortPlan();
      });
      if (this.isSaveAs) {
        this.noty.success("Plan saved as '" + this.newSortPlanName + "'.");
        this.isSaveAs = false;
      }
      else
        this.noty.success("New plan created successfully.");
    }, (err) => {
      if (err.status === 409)
        this.noty.error("Plan name already exists.");
      else
        this.noty.error(err);
    });
  }

  onUpdateClick(resultData) {
    let res = this.service.parseNewPlan(resultData)
    if (!this.checkUniqueRouteDestination(res)) {
      this.noty.error("Duplicate Route and Destination combinations found.")
      return;
    }
    // this.showRouteData = res;
    // this.showDestinationData = res;
    this.service.updateSortPlan(res, this.selectedSortPlan).subscribe(res => {
      this.noty.success("Plan updated successfully.");
      this.loadSortPlan();
      this.tabChanged("routeView");
    });
  }

  deleteSortPlan() {
    this.noty.confirm().then(() => {
      this.service.deleteSortPlan(this.selectedSortPlan.id).subscribe(res => {
        this.resetScreen();
        this.getSortPlans(this.sortingModel.sorterType);
        this.newSortPlanName = '';
        this.noty.success("Sort plan deleted successfully.");
      })
    }, () => {
      //Back method for cancel callback
    })
  }

  onLoadDisplayPlanClick(){
    this.noty.confirm(null,"You want to load Plan",null,true,null,null,"Yes, Load it!").then(()=>{
      this.service.loadSortPlan(this.selectedSortPlan.id).subscribe(res=>{
          this.noty.success("Sort plan loaded successfully!")
      },error=>{
        this.noty.error("Sort plan loaded successfully.")
      });
    })
  }

  resetScreen() {
    this.showRouteData = [];
    this.showDestinationData = [];
    this.routeArray = [];
    this.isNewPlan = true;
    this.isEditMode = false;
    this.sortPlanName = undefined;
    this.isSaveAs = false;

  }

  private checkUniqueRouteDestination(data) {
    let result = true;
    let dataMap = {};
    let prevRouteId: number;
    data.forEach(el => {
      if (!dataMap[el.route.id] && el.route.id !== undefined) {
        prevRouteId = el.route.id;
        dataMap[el.route.id] = [];
        dataMap[el.route.id].push(el.destination.id);
      }
      else {
        // if (dataMap[prevRouteId].indexOf(el.destination.id))
        let res = dataMap[prevRouteId].filter(f => {
          if (f === el.destination.id)
            return f;
        })
        if (res.length > 0)
          result = false;
        else
          dataMap[prevRouteId].push(el.destination.id);
      }
    });
    return result;
  }

  private createRouteObject() {
    let route = {
      route: this.masterData.routes,
      destinations: [
        {
          destination: this.masterData.destinations[0],
          priority: this.masterData.priorityOptions[0]
        }
      ]
    };

    return route
  }
}