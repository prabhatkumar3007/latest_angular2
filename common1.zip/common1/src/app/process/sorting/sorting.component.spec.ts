import { Observable } from 'rxjs/Rx';
import { NotyService } from 'sensorthink-commoncontrols/src/services/noty.service';
import { SortingService } from './services/sorting.service';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { SortingComponent } from './sorting.component';
import { ProcessModule } from '../process.module';

class MockSortingService {
    getDestinations(sorterType) { return Observable.of([{}]) }
    getRoutes(sorterType) { return Observable.of([{}]).toPromise() }
    getSorters() { return Observable.of([{ text: 'ShipSorter' }]) }
    getSortPlans(sorterType) { return Observable.of([{ text: 'Plan2' }]).toPromise() }
    getSortPlan(planName) {
        return Observable.of({
            modifiedBy: { firstname: "A", lastName: "J" },
            modifiedTime: new Date(),
            sortPlanRoutes: [],
        }).toPromise()
    }
    parsePlanForEdit(a, b) { return Observable.of([{ edit: [], view: {} }]) }
    parsePlanForDestinationView(obj) { }
}

describe('SORTING :... Component', () => {

    let component: SortingComponent;
    let fixture: ComponentFixture<SortingComponent>;
    let service: SortingService;
    let router;
    let noty;
    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [ProcessModule],
            providers: [{ provide: SortingService, useClass: MockSortingService }, NotyService]
        })
        // https://angular-2-training-book.rangle.io/handout/testing/components/injecting-dependencies.html
        fixture = TestBed.overrideComponent(SortingComponent, {
            set: {
                template: '<span>{{message}}</span>'
            }
        })
            .createComponent(SortingComponent);
        component = fixture.componentInstance;

    });
    it('should have a defined component', () => {
        expect(component).toBeDefined();
        expect(component.masterData.sorterTypes.length).toBe(1);
        expect(component.sortingModel.sorterType).toBe("ShipSorter");

    });

    describe('When we call tabChanged', () => {
        var fixture2expectation = ["routeView", "destinationView"];
        var isCheck = true;
        it("it activates the tab", function () {
            for (var fixtureString in fixture2expectation) {
                component.tabChanged(fixtureString);
                expect(isCheck).not.toBeFalsy();
            }
        });
    });
    describe('When we call', () => {
        it(' onPlanCreate should create new plan', () => {
            spyOn(component, 'addRouteSection');
            component.onPlanCreate();
            expect(component.isNewPlan).toBeFalsy();
            expect(component.addRouteSection).toHaveBeenCalled();
        })
    });

    describe('When we call loadDestinations', () => {
        it(' should load the physical destination', () => {
            component.loadDestinations("ShipSorter");
            expect(component.masterData.destinations.length).toBe(1);
        })
    });

    describe('When we call loadRoutes', () => {
        it(' should load the routes', () => {
            component.loadRoutes("ShipSorter").then(() => {
                expect(component.masterData.routes.length).toBe(1);
            })
        })
    });

    describe('When we call getSortPlans', () => {
        it(' should load the sortplans', () => {
            spyOn(component, "resetScreen");
            spyOn(component, "loadRoutes");
            spyOn(component, "loadDestinations");
            component.getSortPlans("ShipSorter").then(() => {
                expect(component.masterData.sortPlans.length).toBe(1);
                expect(component.sortingModel.sortPlan).toBe("Plan2")

            })
            expect(component.resetScreen).toHaveBeenCalled();
            expect(component.loadRoutes).toHaveBeenCalled();
            expect(component.loadDestinations).toHaveBeenCalled();
        })
    });

    describe('When we call loadSortPlan', () => {
        it(' should load the select sort plan', () => {
            component.sortingModel.sortPlan = "Plan2"
            component.loadSortPlan().then(() => {
                expect(component.isNewPlan).toBe(false);
            })
        })
    });

});