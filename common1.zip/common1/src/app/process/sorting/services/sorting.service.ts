import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { HttpService } from 'sensorthink-commoncontrols/src/common.module';

declare let moment: any;

@Injectable()
export class SortingService {
    sortingDropDownData = { Sorter: [], SortPlans: [], routeSortOption: [], destSortOption: [], };
    priorityOption: Array<string> = [];
    constructor(private $http: HttpService) {
        for (let i = 1; i <= 99; i++) {
            this.priorityOption.push(i < 10 ? ("0" + i) : (i + ""))
        }
    }

    getSorters() {
        let sorterTypes = [];
        return this.$http.wesContext.url("/api/sortplan/sorters").get().map((res) => {
            let data = res.json()
            sorterTypes.push({ id: -1, "text": "--Select--" });
            if (data) {
                data.forEach((d, i) => {
                    let obj = {
                        id: i,
                        "text": d.locationAlias,
                        val: d
                    }
                    sorterTypes.push(obj);
                });
            }

            return sorterTypes;
        });
    }

    getSortPlans(sorterType: string) {
        let sortPlans = [];
        return this.$http.wesContext.url("/api/sortplan/plannames").addParam("sorter", sorterType).get().map((res) => {
            let data = res.json()
            sortPlans.push({ text: "--Select--", value: "-1" });
            if (data)
                data.forEach((d, i) => {
                    let obj = {
                        id: i,
                        "text": d,
                    }
                    sortPlans.push(obj);
                });

            return sortPlans;
        }).toPromise();
    }

    getRoutes(sorterType: string) {
        let sortPlans = [];
        return this.$http.wesContext.url("/api/sortplan/sortdestinations").addParam("sorter", sorterType).get().map((res) => res.json()).toPromise();;
    }

    getDestinations(sorterType: string) {
        let sortPlans = [];
        return this.$http.wesContext.url("/api/sortplan/physicallocations").addParam("sorter", sorterType).get().map((res) => res.json());
    }


    getSortPlan(planName: string, sorter: string) {
        return this.$http.wesContext.url("/api/sortplan").addParam("planName", planName).addParam("sorter", sorter).get()
            .map(res => res.json()).toPromise();
    }

    parseNewPlan(resultData) {
        let plans = [];
        for (var i = 0; i < resultData.length; i++) {
            let plan = { id: undefined, route: '', destination: '', priority: '' };
            plan.id = resultData[i].destinations[0].id
            plan.route = resultData[i].route;
            plan.destination = resultData[i].destinations[0].destination;
            plan.priority = resultData[i].destinations[0].priority;
            plans.push(plan);
            if (resultData[i].destinations.length > 1) {
                for (var j = 1; j < resultData[i].destinations.length; j++) {
                    let dest = { id: undefined, route: {}, destination: {}, priority: {} };
                    dest.id = resultData[i].destinations[j].id
                    dest.destination = resultData[i].destinations[j].destination;
                    dest.priority = resultData[i].destinations[j].priority;
                    plans.push(dest);
                }
            }
        }
        return plans;
    }

    parsePlanForEdit(data, masterData): Observable<object> {
        let plans = [];
        let prevRouteName = "";
        try {
            for (var i = 0; i < data.length; i++) {
                let route;
                let alreadyAddedRoute = plans.find(p => p.route.sortDestination == data[i].sortDestination.sortDestination)
                if (alreadyAddedRoute)
                    route = alreadyAddedRoute;
                if (!alreadyAddedRoute && (prevRouteName === "" || prevRouteName != data[i].sortDestination.sortDestination) || !alreadyAddedRoute) {
                    prevRouteName = data[i].sortDestination.sortDestination;
                    route = {
                        route: masterData.routes.find(f => data[i].sortDestination.sortDestination == f.sortDestination),
                        destinations: [
                            {
                                id: data[i].id,
                                destination: masterData.destinations.find(f => data[i].physicalLocation.id == f.id),
                                priority: this.priorityOption.find(p => p == data[i].priority)
                            }
                        ]
                    };
                    plans.push(route);
                }
                else {
                    route.destinations.push({
                        id: data[i].id,
                        destination: masterData.destinations.find(f => data[i].physicalLocation.id == f.id),
                        priority: this.priorityOption.find(p => p == data[i].priority)
                    })
                }
            }
            let viewData = this.parseNewPlan(plans);
            return Observable.of({ view: viewData, edit: plans });
        } catch (error) {
            return Observable.throw({});
        }
    }

    parsePlanForDestinationView(routeView) {
        let destinations = []; let routes = []; let route: any = {}; let destinationView = [];
        routeView.forEach(r => {
            if (r.route.id) {
                route = JSON.parse(JSON.stringify(r.route));
                route.destinations = [];
                routes.push(route);
            }
            let destExist = destinations.find(d => d.locationAlias === r.destination.locationAlias)
            if (!destExist) {
                r.destination[route.sortDestination + "_priority"] = r.priority;
                destinations.push(JSON.parse(JSON.stringify(r.destination)));
            }
            else
                r.destination[route.sortDestination + "_priority"] = r.priority;

            route.destinations.push(JSON.parse(JSON.stringify(r.destination)))
        });

        destinations.forEach(d => {
            let route = routes.filter(r => {
                let dest = r.destinations.find(dest => dest.locationAlias == d.locationAlias)
                if (dest)
                    return r.sortDestination;
            });
            route.forEach((r, i) => {
                let view = {
                    destinationName: i === 0 ? d.locationAlias : "",
                    routeName: r.sortDestination,
                    priority: d[r.sortDestination + "_priority"]
                }
                destinationView.push(view);
            })
        })

        return destinationView;
    }

    createSortPlan(newPlanName, routes, sorterType) {
        let prevRoute: any;
        let newPlan = {
            "planName": newPlanName,
            "sortPlanRoutes": [],
            "sorter": sorterType
        };
        routes.forEach(r => {
            if (r.route.companyId)
                prevRoute = r.route;
            let sortPlanRoute = {
                sortDestination: prevRoute,
                physicalLocation: r.destination,
                priority: parseInt(r.priority)
            }

            newPlan.sortPlanRoutes.push(sortPlanRoute);
        });
        //newPlan = JSON.parse('{"companyId": 2,"parentCompanyId": 1,"planName": "Plan400","sortPlanRoutes": [{"sortDestination":{ "id": 4, "companyId": 2, "parentCompanyId": 1, "parentModule": "ShipSorter", "sortDestination": "FDXG" },"physicalLocation":{ "id": "1", "companyId": 2, "parentCompanyId": 1, "physicalLocation": "Chute1", "locationAlias": "Phys_Loc_01" },"priority": 1},{"sortDestination":{ "id": 4, "companyId": 2, "parentCompanyId": 1, "parentModule": "ShipSorter", "sortDestination": "FDXG" },"physicalLocation":{ "id": "8", "companyId": 2, "parentCompanyId": 1, "physicalLocation": "ShipSorter", "locationAlias": "ScanM1L22" },"priority": 1},{"sortDestination":{ "id": 8, "companyId": 2, "parentCompanyId": 1, "parentModule": "PickModule1", "sortDestination": "111" },"physicalLocation":{ "id": "12", "companyId": 2, "parentCompanyId": 1, "physicalLocation": "PickModule1", "locationAlias": "ScanM2L12" },"priority": 1}]}')
        return this.$http.wesContext.url("/api/sortplan").post(JSON.stringify(newPlan)).map(res => res.json());
    }

    updateSortPlan(routes, selectedPlan) {
        let prevRoute: any;
        let plan = selectedPlan;
        plan.sortPlanRoutes = [];
        routes.forEach(r => {
            if (r.route.companyId)
                prevRoute = r.route;
            let sortPlanRoute = {
                id: r.id,
                sortDestination: prevRoute,
                physicalLocation: r.destination,
                priority: parseInt(r.priority)
            }

            plan.sortPlanRoutes.push(sortPlanRoute);
        });
        plan.createdBy = plan.createdBy.userId;
        plan.modifiedBy = plan.modifiedBy.userId;
        return this.$http.wesContext.url("/api/sortplan/" + selectedPlan.id).put(JSON.stringify(plan)).map(res => res.json());
    }

    deleteSortPlan(sortPlanId) {
        return this.$http.wesContext.url("/api/sortplan/" + sortPlanId).delete().map(res => null);
    }

    loadSortPlan(sortPlanId) {
        return this.$http.wesContext.url("/api/sortplan/" + sortPlanId + "/activate").put().map(res => null);
    }
}
