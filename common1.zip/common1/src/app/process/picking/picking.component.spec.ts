import { async, ComponentFixture, inject, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement, Directive } from '@angular/core';
import { NotyService } from 'sensorthink-commoncontrols/src/services/noty.service';
import { Observable } from 'rxjs/Observable';
import { PickingComponent } from './picking.component';
import { PickingDetailService } from './services/pickingDetail.service';
import { PickingService } from './services/picking.service';
import { ProcessModule } from '../process.module';
import { Router } from '@angular/router';
import { RouterStub } from '../../../test/routerStub';

class MockPickService {
    getPickingSummary(): Observable<any> { return Observable.of({}); };
    getPickingProcessRateSummary(): Observable<any> { return Observable.of({}); };
    getTop5Aging(): Observable<any> { return Observable.of({}); };
    getPickingData(): Observable<any> { return Observable.of({}); };
    getPickingSectionProcessRate(): Observable<any> { return Observable.of({}); };
    getTop5ExceptionSKU(): Observable<any> { return Observable.of({}); };
}
class MockPickDetailService {
}
describe('PICK:... Component', () => {

    let component: PickingComponent;
    let fixture: ComponentFixture<PickingComponent>;
    let de: DebugElement;
    let el: HTMLElement;
    let service;
    let noty;
    let router

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [ProcessModule],
            providers: [{ provide: PickingService, useClass: MockPickService }, { provide: PickingDetailService, useClass: MockPickDetailService },
            { provide: Router, useClass: RouterStub }, NotyService]
        })
        fixture = TestBed.overrideComponent(PickingComponent, {
            set: {
                template: '<span>{{message}}</span>'
            }
        }).createComponent(PickingComponent);
        component = fixture.componentInstance;
        service = fixture.debugElement.injector.get(PickingService);
        router = fixture.debugElement.injector.get(Router);
        noty = fixture.debugElement.injector.get(NotyService);
    }));

    it('should have a defined component', () => {
        expect(component).toBeDefined();
    });

    describe('When we call ', () => {
        let fromDate, toDate, isWeek, shift;
        beforeEach(() => {
            fromDate = "03232017 00:00:00";
            toDate = "03232017 23:59:59";
            isWeek = false;
            shift = 'Morning'
        })
        it(' loadSummarySection should get all summaryData and summaryProcessRateData', () => {
            spyOn(service, 'getPickingSummary').and.returnValue(Observable.of([{}, {}]));
            spyOn(service, 'getPickingProcessRateSummary').and.returnValue(Observable.of([{}, {}]));
            component.loadSummarySection("orders", fromDate, toDate, isWeek, shift);
            expect(component.summaryData.length).toBe(2);
            expect(component.summaryProcessRateData.length).toBe(2);
        })
        it(' loadPickingModuleSection should get all getPickingData and getPickingSectionProcessRate', () => {
            spyOn(service, 'getPickingData').and.returnValue(Observable.of([{}, {}]));
            spyOn(service, 'getPickingSectionProcessRate').and.returnValue(Observable.of([{}, {}]));
            component.loadPickingModuleSection("orders", fromDate, toDate, isWeek, shift, 'pick', '');
            expect(component['pick'].length).toBe(2);
        })
    });

    describe('When we call', () => {
        let fromDate, toDate, isWeek, shift;
        beforeEach(() => {
            fromDate = "03232017 00:00:00";
            toDate = "03232017 23:59:59";
            isWeek = false;
            shift = 'Morning'
        })
        it(' loadPickingOrders should set the order Tab', () => {
            spyOn(component, 'loadSummarySection');
            spyOn(component, 'loadPickingModuleSection');
            component.loadPickingOrders(fromDate, toDate, isWeek, shift);
            expect(component.loadSummarySection).toHaveBeenCalled();
            expect(component.loadPickingModuleSection).toHaveBeenCalled();
        })
        it(' loadPickingOrdersLines should set the orderLines Tab', () => {
            spyOn(component, 'loadSummarySection');
            spyOn(component, 'loadPickingModuleSection');
            component.loadPickingOrders(fromDate, toDate, isWeek, shift);
            expect(component.loadSummarySection).toHaveBeenCalled();
            expect(component.loadPickingModuleSection).toHaveBeenCalled();
        })
        it(' loadPickingUnits should set the pager config', () => {
            spyOn(component, 'loadSummarySection');
            spyOn(component, 'loadPickingModuleSection');
            component.loadPickingOrders(fromDate, toDate, isWeek, shift);
            expect(component.loadSummarySection).toHaveBeenCalled();
            expect(component.loadPickingModuleSection).toHaveBeenCalled();
        })
        it(' loadPickingContainers should set the pager config', () => {
            spyOn(component, 'loadSummarySection');
            spyOn(component, 'loadPickingModuleSection');
            component.loadPickingOrders(fromDate, toDate, isWeek, shift);
            expect(component.loadSummarySection).toHaveBeenCalled();
            expect(component.loadPickingModuleSection).toHaveBeenCalled();
        })

    });

    describe('When we call loadTop5Aging', () => {
        let fromDate, toDate, isWeek, shift;
        beforeEach(() => {
            fromDate = "03232017 00:00:00";
            toDate = "03232017 23:59:59";
            isWeek = false;
            shift = 'Morning'
        })
        it(' should get the top 5 data', () => {
            spyOn(service, "getTop5Aging").and.returnValue(Observable.of({}));
            spyOn(component, 'loadTop5Aging');
            component.loadTop5Aging('orders', toDate, 5, fromDate, shift);
            expect(component.loadTop5Aging).toHaveBeenCalled();
        })
    });

    describe("When we call", function () {
        var fixture2expectation = ["orders", "orderLines", "units", "containers"];
        var isCheck = true;
        let fromDate, toDate, isWeek, shift;
        beforeEach(() => {
            fromDate = "03232017 00:00:00";
            toDate = "03232017 23:59:59";
            isWeek = false;
            shift = 'Morning';
            component.dates = { dates: [new Date()], isWeek: false, formattedDates: ["04102017 00:00:00", "04102017 23:59:59"] };
            spyOn(component, 'loadTop5Aging');
            spyOn(component, 'loadTop5ExceptionSKU');
            spyOn(component, 'loadPickingOrders');
            spyOn(component, 'loadPickingOrdersLines');
            spyOn(component, 'loadPickingUnits');
            spyOn(component, 'loadPickingContainers');

        })
        it("it activates the tab", function () {
            for (var fixtureString in fixture2expectation) {
                component.showTabs(fixtureString);
                expect(isCheck).not.toBeFalsy();
            }
        });
        it("it activates the order tab", function () {
            component.tabChanged(fixture2expectation[0]);
            expect(component.loadTop5Aging).toHaveBeenCalled();
            expect(component.loadTop5ExceptionSKU).toHaveBeenCalled();
            expect(component.loadPickingOrders).toHaveBeenCalled();
        });
        it("it activates the orderLines tab", function () {
            component.tabChanged(fixture2expectation[1]);
            expect(component.loadTop5Aging).toHaveBeenCalled();
            expect(component.loadTop5ExceptionSKU).toHaveBeenCalled();
            expect(component.loadPickingOrdersLines).toHaveBeenCalled();
        });
        it("it activates the units tab", function () {
            component.tabChanged(fixture2expectation[2]);
            expect(component.loadTop5Aging).toHaveBeenCalled();
            expect(component.loadTop5ExceptionSKU).toHaveBeenCalled();
            expect(component.loadPickingUnits).toHaveBeenCalled();
        });
        it("it activates the containers tab", function () {
            component.tabChanged(fixture2expectation[3]);
            expect(component.loadTop5Aging).toHaveBeenCalled();
            expect(component.loadTop5ExceptionSKU).toHaveBeenCalled();
            expect(component.loadPickingContainers).toHaveBeenCalled();
        });
    });

    describe('When we call ', () => {
        let date;
        beforeEach(() => {
            date = { dates: [new Date()], isWeek: false, formattedDates: ["04102017 00:00:00", "04102017 23:59:59"] };
            spyOn(service, 'getPickingData').and.returnValue(Observable.of([{}, {}]));
            spyOn(service, 'getPickingSectionProcessRate').and.returnValue(Observable.of([{}, {}]));
            spyOn(component, 'tabChanged');
        })
        it(' dateChangeCallback and isWeek is true then it should set the x-axis as days', () => {
            date.isWeek = true;
            component.dateChangeCallback(date);
            expect(component.xAxisFormat).toBe('ddd');
            expect(component.isWeek).toBe(true);
            expect(component.tabChanged).toHaveBeenCalled();
        })
        it(' dateChangeCallback and isWeek is false then it should set the x-axis as hr', () => {
            component.dateChangeCallback(date);
            expect(component.xAxisFormat).toBe('HH:mm');
            expect(component.isWeek).toBe(false);
            expect(component.tabChanged).toHaveBeenCalled();
        })
        it(' shiftChangeCallback should set the shift', () => {
            component.shiftChangeCallback({ text: 'Morning' });
            expect(component.shift).toBe('Morning');
            expect(component.tabChanged).toHaveBeenCalled();
        })
    });

    describe('When we call onWorkQueueSectionSelect', () => {
        it(' should go order', async(() => {
            spyOn(router, 'navigate');
            component.onWorkQueueSectionSelect('orders', 1)
            expect(router.navigate).toHaveBeenCalledWith(['/orders'], { queryParams: { status: 'orders', processType: 'Picking', parentModule:1} });
        }));
    });
});
