import { UtilService } from 'sensorthink-commoncontrols/src/services/util.service';
import { ShareDataService } from 'sensorthink-commoncontrols/src/services/shareDataService';
import { NotyService } from 'sensorthink-commoncontrols/src/services/noty.service';
import { Component } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { PickingService } from './services/picking.service';
import { PickingDetailService } from './services/pickingDetail.service';
import { Router } from '@angular/router';
import { ShiftService } from './../../shared/services/shift.service';

declare let moment: any;

@Component({
  templateUrl: 'picking.component.html'
})

export class PickingComponent {
  public AreaContents = ['All Areas'];
  public summaryData: any;
  public summaryProcessRateData: any;

  public pickingOrderData: any;
  public pickingOrderProcessData: any;
  public pickingOrderLinesData: any;
  public pickingUnitsData: any;
  public pickingContainersData: any;
  public pickingTop5Aging: any;
  public pickingTop5ExceptionSKU: any;
  public isPickingSummaryLoading: boolean = false;
  public isPickingTabLoading: boolean = false;
  public isLoading: boolean = false;
  public datePickerConfig: any;
  public shift: any = 'All Shifts';
  public sideBarVisible: boolean;
  public dates: any;
  private selectedTab: string;
  xAxisFormat: string;
  isXAxisDateType: boolean = true;
  isWeek: boolean = true;
  isOrder: boolean = false;
  isOrderLine: boolean = false;
  isUnits: boolean = false;
  isContainers: boolean = false;
  isSection: string;
  allShift: any;

  constructor(private service: PickingService, private pickingDetailService: PickingDetailService, private sharedService: ShareDataService,
    private allShiftService: ShiftService, private router: Router, private notyService: NotyService) {
    this.datePickerConfig = {
      maxDate: new Date(),
      minDate: moment(new Date()).subtract(1, 'M')._d
    };
  }

  ngOnInit() {
    if (this.pickingDetailService.dates)
      this.dates = this.pickingDetailService.dates;
    if (this.pickingDetailService.shift)
      this.shift = this.pickingDetailService.shift.name;
    if (this.sharedService.objectStore.pickingSelectedTab) {
      this.selectedTab = this.sharedService.objectStore.pickingSelectedTab;
    } else{
      this.selectedTab = "orders";
      this.showTabs(this.selectedTab);
    }
  }
  

  loadSummarySection(pickingType, fromDate, toDate, isWeek, shift) {
    this.sharedService.objectStore.fromDate = fromDate;
    this.sharedService.objectStore.toDate = toDate;
    this.sharedService.objectStore.shiftValue = this.shift;
    this.sharedService.objectStore.containerTypeValue = 'Pick'; //provide value for advance filter after selecting drill down

    let calls = [
      this.service.getPickingSummary(pickingType, fromDate, toDate, shift),
      this.service.getPickingProcessRateSummary(pickingType, fromDate, toDate, isWeek, shift)

    ]
    this.isPickingSummaryLoading = true;
    Observable.forkJoin(calls).subscribe(
      data => {
        this.summaryData = data[0];
        this.summaryProcessRateData = data[1];
        this.isPickingSummaryLoading = false;
      },
      err => {
        this.summaryData = null;
        this.summaryProcessRateData = null;
        this.isPickingSummaryLoading = false;
      });
  }


  loadPickingModuleSection(pickingType, fromDate, toDate, isWeek, shift, sectionDataKey, processSectionKey) {
    let calls = [
      this.service.getPickingData(pickingType, fromDate, toDate, shift),
      this.service.getPickingSectionProcessRate(pickingType, fromDate, toDate, isWeek, shift)
    ]
    this.isPickingTabLoading = true;
    Observable.forkJoin(calls).subscribe(
      (data: any) => {
        if (data[0]) {
          data[0].forEach((element, idx) => {
            if (data[1]) {
              element.processRate = data[1][idx];
            }
            else {
              element.processRate = null
            }
          });
        }
        this[sectionDataKey] = data[0] || [];
        this.isPickingTabLoading = false;
      },
      (err) => {
        this.notyService.error(err)
        this.isPickingTabLoading = false;
      });
  }

  loadPickingOrders(fromDate, toDate, isWeek, shift) {
    this.loadSummarySection("orders", fromDate, toDate, isWeek, shift)
    this.loadPickingModuleSection("orders", fromDate, toDate, isWeek, shift, "pickingOrderData", "pickingOrderProcessData")
  }

  loadPickingOrdersLines(fromDate, toDate, isWeek, shift) {
    this.loadSummarySection("orderlines", fromDate, toDate, isWeek, shift)
    this.loadPickingModuleSection("orderlines", fromDate, toDate, isWeek, shift, "pickingOrderLinesData", "pickingOrderProcessData")
  }

  loadPickingUnits(fromDate, toDate, isWeek, shift) {
    this.loadSummarySection("units", fromDate, toDate, isWeek, shift);
    this.loadPickingModuleSection("units", fromDate, toDate, isWeek, shift, "pickingUnitsData", "pickingOrderProcessData");
  }

  loadPickingContainers(fromDate, toDate, isWeek, shift) {
    this.loadSummarySection("containers", fromDate, toDate, isWeek, shift)
    this.loadPickingModuleSection("containers", fromDate, toDate, isWeek, shift, "pickingContainersData", "pickingOrderProcessData")
  }
  loadTop5Aging(pickingFrom, toDate, limit, fromDate, shift) {
    this.isLoading = true;
    this.service.getTop5Aging(pickingFrom, toDate, 5, fromDate, shift).subscribe((data) => {
      this.showTabs(pickingFrom);
      this.pickingTop5Aging = data;
      this.isLoading = false;
    });
  }
  showTabs(value) {
    this.isOrder = this.isOrderLine = this.isUnits = this.isContainers = false;
    switch (value) {
      case "orders":
        this.isOrder = true;
        break;
      case "orderlines":
        this.isOrderLine = true;
        break;
      case "units":
        this.isUnits = true;
        break;
      case "containers":
        this.isContainers = true;
        break;
      default:
        break;
    }
  }
  loadTop5ExceptionSKU(pickingFrom, toDate, limit, fromDate, shift) {
    this.isLoading = true;
    this.service.getTop5ExceptionSKU(pickingFrom, toDate, 5, fromDate, shift).subscribe((data) => {
      this.pickingTop5ExceptionSKU = data;
      this.isLoading = false;
    });
  }

  dateChangeCallback(date) {
    this.dates = date;
    this.pickingDetailService.dates = date;

    if (date.isWeek === true) {
      this.xAxisFormat = "ddd"
      this.isWeek = true;
    }
    else {
      this.xAxisFormat = "HH:mm";
      this.isWeek = false;
    }
    this.allShiftService.getAllShift().then((res) => {
      this.allShift = res;
      this.tabChanged(this.selectedTab);
    })
  }

  shiftChangeCallback(shift) {
    this.shift = shift.name;
    this.pickingDetailService.shift = shift;
    this.tabChanged(this.selectedTab);
  }

  tabChanged(tabId) {
    this.selectedTab = tabId;
    this.sharedService.objectStore.pickingSelectedTab = tabId;
    switch (tabId) {
      case "orders":
        this.loadPickingOrders(this.dates.formattedDates[0], this.dates.formattedDates[1], this.dates.isWeek, this.shift);
        this.loadTop5Aging("orders", this.dates.formattedDates[1], 5, this.dates.formattedDates[0], this.shift);
        this.loadTop5ExceptionSKU("orders", this.dates.formattedDates[1], 5, this.dates.formattedDates[0], this.shift);
        break;
      case "orderLines":
        this.loadPickingOrdersLines(this.dates.formattedDates[0], this.dates.formattedDates[1], this.dates.isWeek, this.shift);
        this.loadTop5Aging("orderlines", this.dates.formattedDates[1], 5, this.dates.formattedDates[0], this.shift);
        this.loadTop5ExceptionSKU("orderlines", this.dates.formattedDates[1], 5, this.dates.formattedDates[0], this.shift);
        break;
      case "units":
        this.loadPickingUnits(this.dates.formattedDates[0], this.dates.formattedDates[1], this.dates.isWeek, this.shift);
        this.loadTop5Aging("units", this.dates.formattedDates[1], 5, this.dates.formattedDates[0], this.shift);
        this.loadTop5ExceptionSKU("units", this.dates.formattedDates[1], 5, this.dates.formattedDates[0], this.shift);
        break;
      case "containers":
        this.loadPickingContainers(this.dates.formattedDates[0], this.dates.formattedDates[1], this.dates.isWeek, this.shift);
        this.loadTop5Aging("containers", this.dates.formattedDates[1], 5, this.dates.formattedDates[0], this.shift);
        this.loadTop5ExceptionSKU("containers", this.dates.formattedDates[1], 5, this.dates.formattedDates[0], this.shift);
        break;
      default:
        break;
    }
  }
  onWorkQueueSectionSelect(data, parentModule) {
    this.sharedService.objectStore.fromPath = 'dashboardWorkQueueSummary';
    if (this.selectedTab === "orders")
      this.router.navigate(['/orders'], { queryParams: { status: data.toLowerCase(), processType: 'Picking', parentModule: parentModule } });
    if (this.selectedTab === "containers")
      this.router.navigate(['/containers'], { queryParams: { status: data.toLowerCase(), processType: 'Picking', parentModule: parentModule } });
  }
}