import { ActivatedRoute } from '@angular/router';
import { Component } from '@angular/core';
import { NotyService } from 'sensorthink-commoncontrols/src/services/noty.service';
import { Observable } from 'rxjs/Rx';
import { PickingDetailService } from './services/pickingDetail.service';
import { ShiftService } from './../../shared/services/shift.service';

declare var moment: any;
@Component({
  templateUrl: 'pickingModuleDetail.component.html'

})
export class PickingModuleDetailComponent {
  public AreaContents = ["All Areas"];
  public datePickerConfig: any;
  public pickingSummaryData: any;
  public pickingLineSummaryData: any;
  public pickingSectionData: any;
  public pickingTop5Aging: any;
  public pickingTop5ExceptionSKU: any;

  public isPickingLoading: boolean = false;
  public isLoading: boolean = false;
  public shift: any;
  public xAxisFormat: string;
  public isXAxisDateType: boolean = true;
  public isWeek: boolean = true;
  public dates: any;
  public pickingId: string;

  public pickingType: string;
  isOrder: boolean = false;
  isOrderLine: boolean = false;
  isUnits: boolean = false;
  isContainers: boolean = false;
  allShift: any;

  constructor(private service: PickingDetailService, private route: ActivatedRoute, private allShiftService: ShiftService, private notyService: NotyService) {
    this.datePickerConfig = {
      maxDate: new Date(),
      minDate: moment(new Date()).subtract(1, 'M')._d
    };
    if (route.url)
      route.url.subscribe((url: any) => {
        this.pickingType = url[1].path;
      });
  }
  ngOnInit() {
    this.route.params.subscribe(params => {
      if (params['id']) {
        this.pickingId = params['id'];
      }
    });
    if (this.service.dates)
      this.dates = this.service.dates;
    if (this.service.shift)
      this.shift = this.service.shift.name;
  }

  loadPickingDetailData(fromDate, toDate, isWeek, shift) {
    let calls = [
      this.service.getPickingSummaryData(this.pickingId, this.pickingType, fromDate, toDate, shift),
      this.service.getPickingProcessRateSummaryData(this.pickingId, this.pickingType, fromDate, toDate, isWeek, shift),
      this.service.getPickingData(this.pickingId, this.pickingType, fromDate, toDate, shift),
      this.service.getPickingSectionProcessRate(this.pickingId, this.pickingType, fromDate, toDate, isWeek, shift)
    ];
    this.isPickingLoading = true;
    Observable.forkJoin(calls).subscribe(
      data => {
        if (data[0] && data[0][0])
          this.pickingSummaryData = data[0][0].pickingData;
        else
          this.pickingSummaryData = null;

        if (data[1] && data[1][0]) {
          if (data[0] && data[0][0]) {
            let groupName = data[0][0].groupName;
            let values = [];
            values = Array(data[1]);
            for (let mod of values) {
              for (let val of mod) {
                if (val.ProcessRateType == groupName) {
                  this.pickingLineSummaryData = val;
                  break;
                }
              }
            }
          }
        } else {
          this.pickingLineSummaryData = null;
        }

        if (data[2])
          this.pickingSectionData = this.parseProcessDataToSection(data[2], data[3]);
        else
          this.pickingSectionData = null;
        this.isPickingLoading = false;
      },
      err => {
        this.notyService.error(err)
      }
    )
  }
  loadTop5Aging(pickingFrom, toDate, limit, fromDate, shift) {
    this.isLoading = true;
    this.service.getTop5Aging(pickingFrom, toDate, 5, fromDate, shift).subscribe((data) => {
      this.showTabs(pickingFrom);
      this.pickingTop5Aging = data;
      this.isLoading = false;
    });
  }
  loadTop5ExceptionSKU(pickingFrom, toDate, limit, fromDate, shift) {
    this.isLoading = true;
    this.service.getTop5ExceptionSKU(pickingFrom, toDate, 5, fromDate, shift).subscribe((data) => {
      this.pickingTop5ExceptionSKU = data;
      this.isLoading = false;
    });
  }
  showTabs(value) {
    this.isOrder = this.isOrderLine = this.isUnits = this.isContainers = false;
    switch (value) {
      case "orders":
        this.isOrder = true;
        break;
      case "orderlines":
        this.isOrderLine = true;
        break;
      case "units":
        this.isUnits = true;
        break;
      case "containers":
        this.isContainers = true;
        break;
      default:
        break;
    }
  }
  parseProcessDataToSection(sectionList, processData) {
    let sectionData: any = sectionList;
    sectionData.forEach(element => {
      let processRate: any = processData;
      if (processRate) {
        let tmp = processRate.filter((f) => {
          if (f.processRateType === element.groupName)
            return f;
        })
        element.processRate = tmp[0];
      }
    });
    return sectionData;
  }

  dateChangeCallback(date) {
    this.dates = date;
    if (date.isWeek === true) {
      this.xAxisFormat = "ddd"
      this.isWeek = true;
    }
    else {
      this.xAxisFormat = "HH:mm";
      this.isWeek = false;
    }
    this.allShiftService.getAllShift().then((res) => {
      this.allShift = res;
      this.loadPickingDetailData(date.formattedDates[0], date.formattedDates[1], date.isWeek, this.shift);
      this.loadTop5Aging(this.pickingType, this.dates.formattedDates[1], 5, this.dates.formattedDates[0], this.shift);
      this.loadTop5ExceptionSKU("orders", this.dates.formattedDates[1], 5, this.dates.formattedDates[0], this.shift);
    })
  }

  shiftChangeCallback(shift) {
    this.shift = shift.name;
    this.loadPickingDetailData(this.dates.formattedDates[0], this.dates.formattedDates[1], this.dates.isWeek, this.shift);
    this.loadTop5Aging(this.pickingType, this.dates.formattedDates[1], 5, this.dates.formattedDates[0], this.shift);
    this.loadTop5ExceptionSKU("orders", this.dates.formattedDates[1], 5, this.dates.formattedDates[0], this.shift);
  }
}