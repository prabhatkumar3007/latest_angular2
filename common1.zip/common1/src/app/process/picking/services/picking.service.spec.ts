import { JwtHelper } from 'sensorthink-commoncontrols/src/services/jwtHelper.service';
import { UtilService } from 'sensorthink-commoncontrols/src/services/util.service';
import { MockHttpService } from '../../../../test/mockHttp.service';
import { SharedModule } from '../../../shared/shared.module';
import { PickingService } from './picking.service';
import { inject, TestBed } from '@angular/core/testing';
import { HttpModule, Response, ResponseOptions, XHRBackend } from '@angular/http';
import { MockBackend } from '@angular/http/testing';
import { HttpService } from 'sensorthink-commoncontrols/src/common.module';

describe('Service: PickingService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [HttpModule, SharedModule],
            providers: [PickingService, { provide: HttpService, useClass: MockHttpService },
                { provide: XHRBackend, useClass: MockBackend }]
        }).compileComponents();
    })

    it('can instantiate service when inject service',
        inject([PickingService], (service: PickingService) => {
            expect(service instanceof PickingService).toBe(true);
        }));

    it('can provide the mockBackend as XHRBackend',
        inject([XHRBackend], (backend: MockBackend) => {
            expect(backend).not.toBeNull('backend should be provided');
        }));

    describe('When get all picking summary', () => {
        let backend: MockBackend;
        let service: PickingService;
        let response: Response;
        const mockResponse = { DataPoints: [{ key: 0, value: 1 }, { key: 1, value: 2 }, { key: 2, value: 3 }, { key: 3, value: 4 }] };
        let fromDate, toDate, isWeek, shift;
        beforeEach(inject([HttpService, XHRBackend], (httpService: HttpService, be: MockBackend) => {
            backend = be;
            service = new PickingService(httpService, new UtilService(new JwtHelper()));
            let options = new ResponseOptions({ status: 200, body: { data: [] } });
            response = new Response(options);
            fromDate = "03232017 00:00:00";
            toDate = "03232017 23:59:59";
            shift = 'Morning';
            isWeek = false;
        }));

        it(' should get picking summary data object',
            inject([], () => {
                backend.connections.subscribe((connection) => {
                    connection.mockRespond(new Response(new ResponseOptions({ body: JSON.stringify(mockResponse) })));
                });
                service.getPickingSummary('orders', fromDate, toDate, shift).subscribe((res) => {
                    expect(res.DataPoints.length).toBe(mockResponse.DataPoints.length);
                }, (err) => {
                    console.log(err);
                })
            }));

        it(' should get picking data object',
            inject([], () => {
                backend.connections.subscribe((connection) => {
                    connection.mockRespond(new Response(new ResponseOptions({ body: JSON.stringify(mockResponse) })));
                });
                service.getPickingProcessRateSummary('orders', fromDate, toDate, shift, isWeek).subscribe((res) => {
                    expect(res[0].pickingData.DataPoints.length).toBe(mockResponse.DataPoints.length);
                }, (err) => {
                    console.log(err);
                })
            }));

        it(' should get picking Section Process Rate data object',
            inject([], () => {
                backend.connections.subscribe((connection) => {
                    connection.mockRespond(new Response(new ResponseOptions({ body: JSON.stringify(mockResponse) })));
                });
                service.getPickingSectionProcessRate('orders', fromDate, toDate, shift, isWeek).subscribe((res) => {
                    expect(res).toBe(null);
                }, (err) => {
                    console.log(err);
                })
            }));
    });

    describe('When we call getpickingProcessRateSummary', () => {
        let backend: MockBackend;
        let service: PickingService;
        let response: Response;
        const mockResponse = { ProcessRateType: 'summary', Values: [{}, {}] };
        let fromDate, toDate, isWeek, shift;
        beforeEach(inject([HttpService, XHRBackend], (httpService: HttpService, be: MockBackend) => {
            backend = be;
            service = new PickingService(httpService, new UtilService(new JwtHelper()));
            let options = new ResponseOptions({ status: 200, body: { data: [] } });
            response = new Response(options);
            fromDate = "03232017 00:00:00";
            toDate = "03232017 23:59:59";
            shift = 'Morning';
            isWeek = false;
        }));

        it(' should get picking summary data object',
            inject([], () => {
                backend.connections.subscribe((connection) => {
                    connection.mockRespond(new Response(new ResponseOptions({ body: JSON.stringify(mockResponse) })));
                });
                service.getPickingData('orders', fromDate, toDate, shift).subscribe((res) => {
                    expect(res.Values.length).toBe(mockResponse.Values.length);
                }, (err) => {
                    console.log(err);
                })
            }));
    });

    describe('When we call getTop5Aging', () => {
        let backend: MockBackend;
        let service: PickingService;
        let response: Response;
        const mockResponse = [{}, {}];
        let fromDate, toDate, isWeek, shift;
        beforeEach(inject([HttpService, XHRBackend], (httpService: HttpService, be: MockBackend) => {
            backend = be;
            service = new PickingService(httpService, new UtilService(new JwtHelper()));
            let options = new ResponseOptions({ status: 200, body: { data: [] } });
            response = new Response(options);
            fromDate = "03232017 00:00:00";
            toDate = "03232017 23:59:59";
            shift = 'Morning';
            isWeek = false;
        }));

        it(' should get picking Top 5 Aging data',
            inject([], () => {
                backend.connections.subscribe((connection) => {
                    connection.mockRespond(new Response(new ResponseOptions({ body: JSON.stringify(mockResponse) })));
                });
                service.getTop5Aging('orders', toDate, 5, fromDate, shift).subscribe((res) => {
                    expect(res.length).toBe(mockResponse.length);
                }, (err) => {
                    console.log(err);
                })
            }));
    });
    describe('When we call getTop5ExceptionSKU', () => {
        let backend: MockBackend;
        let service: PickingService;
        let response: Response;
        const mockResponse = [{}, {}];
        let fromDate, toDate, isWeek, shift;
        beforeEach(inject([HttpService, XHRBackend], (httpService: HttpService, be: MockBackend) => {
            backend = be;
            service = new PickingService(httpService, new UtilService(new JwtHelper()));
            let options = new ResponseOptions({ status: 200, body: { data: [] } });
            response = new Response(options);
            fromDate = "03232017 00:00:00";
            toDate = "03232017 23:59:59";
            shift = 'Morning';
            isWeek = false;
        }));

        it(' should get picking Top 5 Aging data',
            inject([], () => {
                backend.connections.subscribe((connection) => {
                    connection.mockRespond(new Response(new ResponseOptions({ body: JSON.stringify(mockResponse) })));
                });
                service.getTop5ExceptionSKU('orders', toDate, 5, fromDate, shift).subscribe((res) => {
                    expect(res.length).toBe(mockResponse.length);
                }, (err) => {
                    console.log(err);
                })
            }));
    });
});