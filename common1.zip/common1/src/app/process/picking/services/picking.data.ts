import { ProcessData } from 'sensorthink-commoncontrols/src/chart.module';
import { ProcessRateData } from '../../../dashboard/processRate/services/processRate.data'

export class PickingTab {
    public groupName: string;
    public pickingData: ProcessData;
    public processRate: ProcessRateData;

    constructor(groupName: string, processData: ProcessData) {
        this.groupName = groupName;
        this.pickingData = processData;
    }
}

