import { Router, RouterModule } from '@angular/router';

import { PickingComponent } from './picking/picking.component';
import { PackingComponent } from './packing/packing.component';
import { PickingModuleDetailComponent } from './picking/pickingModuleDetail.component'
import { PackingModuleDetailComponent } from './packing/packingModuleDetail.component';
import { SortingComponent } from './sorting/sorting.component';
import { ShippingComponent } from './shipping/shipping.component';
import { shippingModuleDetailComponent } from './shipping/shippingModuleDetail.component';
import { AuthGuard } from '../auth/auth-guard.service';

export const processRouting = RouterModule.forChild([
  { path: 'picking', component: PickingComponent, canActivate: [AuthGuard], data: { permission: ['all','Any pages'] } },
  { path: 'packing', component: PackingComponent, canActivate: [AuthGuard], data: { permission: ['all','Any pages'] } },
  { path: 'packing/orders/:id', component: PackingModuleDetailComponent },
  { path: 'packing/containers/:id', component: PackingModuleDetailComponent },
  { path: 'picking/orders/:id', component: PickingModuleDetailComponent },
  { path: 'picking/orderlines/:id', component: PickingModuleDetailComponent },
  { path: 'picking/units/:id', component: PickingModuleDetailComponent },
  { path: 'picking/containers/:id', component: PickingModuleDetailComponent },
  { path: 'shipping', component: ShippingComponent, canActivate: [AuthGuard], data: { permission: ['all','Any pages'] } },
  { path: 'shipping/orders/:id', component: shippingModuleDetailComponent },
  { path: 'shipping/containers/:id', component: shippingModuleDetailComponent },
  { path: 'sorting', component: SortingComponent, canActivate: [AuthGuard], data: { permission: ['all','Any pages'] } }

]);