import { ShareDataService } from 'sensorthink-commoncontrols/src/services/shareDataService';
import { ShiftService } from './../../shared/services/shift.service';
import { PackingService } from './services/packing.service';
import { PackingDetailService } from './services/packingDetail.service';
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Rx';
import { NotyService } from 'sensorthink-commoncontrols/src/services/noty.service';

declare let moment: any;

@Component({
  templateUrl: 'packing.component.html'
})

export class PackingComponent {
  public AreaContents = ['All Areas'];
  public summaryData: any;
  public summaryProcessRateData: any;

  public packingOrderData: any;
  public packingOrderProcessData: any;
  public packingContainersData: any;
  public packingTop5Aging: any;
  public packingTop5ExceptionSKU: any;
  public isPackingSummaryLoading: boolean = false;
  public isPackingTabLoading: boolean = false;
  public isLoading: boolean = false;
  public datePickerConfig: any;
  public shift: any = "All Shifts";
  public dates: any;
  private selectedTab: string;
  xAxisFormat: string;
  isXAxisDateType: boolean = true;
  isWeek: boolean = true;
  isOrder: boolean = false;
  isOrderLine: boolean = false;
  isUnits: boolean = false;
  isContainers: boolean = false;
  sideBarVisible: boolean;
  isSection: string;
  allShift: any;

  constructor(private service: PackingService, private packingDetailService: PackingDetailService, private sharedService: ShareDataService, private allShiftService: ShiftService, private router: Router, private notyService: NotyService) {
    this.datePickerConfig = {
      maxDate: new Date(),
      minDate: moment(new Date()).subtract(1, 'M')._d
    };
  }

  ngOnInit() {
    if (this.packingDetailService.dates)
      this.dates = this.packingDetailService.dates;
    if (this.packingDetailService.shift)
      this.shift = this.packingDetailService.shift.name;
    if (this.sharedService.objectStore.packingSelectedTab) {
      this.selectedTab = this.sharedService.objectStore.packingSelectedTab;
    } else {
      this.selectedTab = "orders";
      this.showTabs(this.selectedTab);
    }
  }

  loadSummarySection(packingType, fromDate, toDate, isWeek, shift) {
    this.sharedService.objectStore.fromDate = fromDate;
    this.sharedService.objectStore.toDate = toDate;
    this.sharedService.objectStore.shiftValue = this.shift;
    this.sharedService.objectStore.containerTypeValue = 'Pack'; //provide value for advance filter after selecting drill down
    let calls = [
      this.service.getPackingSummary(packingType, fromDate, toDate, shift),
      this.service.getPackingProcessRateSummary(packingType, fromDate, toDate, isWeek, shift)
    ]
    this.isPackingSummaryLoading = true;
    Observable.forkJoin(calls).subscribe(
      data => {
        this.summaryData = data[0];
        this.summaryProcessRateData = data[1];
        this.isPackingSummaryLoading = false;
      },
      err => {
        this.summaryData = null;
        this.summaryProcessRateData = null;
        this.isPackingSummaryLoading = false;
      });
  }


  loadPackingModuleSection(packingType, fromDate, toDate, isWeek, shift, sectionDataKey, processSectionKey) {
    let calls = [
      this.service.getPackingData(packingType, fromDate, toDate, shift),
      this.service.getPackingSectionProcessRate(packingType, fromDate, toDate, isWeek, shift)
    ]
    this.isPackingTabLoading = true;
    Observable.forkJoin(calls).subscribe(
      (data: any) => {
        if (data[0]) {
          data[0].forEach((element, idx) => {
            if (data[1]) {
              element.processRate = data[1][idx];
            }
            else {
              element.processRate = null
            }
          });
        }
        this[sectionDataKey] = data[0] || [];
        this.isPackingTabLoading = false;
      },
      (err) => {
        this.notyService.error(err)
        this.isPackingTabLoading = false;
      });
  }

  loadPackingOrders(fromDate, toDate, isWeek, shift) {
    this.loadSummarySection("orders", fromDate, toDate, isWeek, shift)
    this.loadPackingModuleSection("orders", fromDate, toDate, isWeek, shift, "packingOrderData", "packingOrderProcessData")
  }
  loadPackingContainers(fromDate, toDate, isWeek, shift) {
    this.loadSummarySection("containers", fromDate, toDate, isWeek, shift)
    this.loadPackingModuleSection("containers", fromDate, toDate, isWeek, shift, "packingContainersData", "packingOrderProcessData")
  }
  loadTop5Aging(packingFrom, toDate, limit, fromDate, shift) {
    this.isLoading = true;
    this.service.getTop5Aging(packingFrom, toDate, 5, fromDate, shift).subscribe((data) => {
      this.showTabs(packingFrom);
      this.packingTop5Aging = data;
      this.isLoading = false;
    });
  }
  showTabs(value) {
    this.isOrder = this.isOrderLine = this.isUnits = this.isContainers = false;
    switch (value) {
      case "orders":
        this.isOrder = true;
        break;
      case "containers":
        this.isContainers = true;
        break;
      default:
        break;
    }
  }
  loadTop5ExceptionSKU(packingFrom, toDate, limit, fromDate, shift) {
    this.isLoading = true;
    this.service.getTop5ExceptionSKU(packingFrom, toDate, 5, fromDate, shift).subscribe((data) => {
      this.packingTop5ExceptionSKU = data;
      this.isLoading = false;
    });
  }

  dateChangeCallback(date) {
    this.dates = date;
    this.packingDetailService.dates = date;

    if (date.isWeek === true) {
      this.xAxisFormat = "ddd"
      this.isWeek = true;
    }
    else {
      this.xAxisFormat = "HH:mm";
      this.isWeek = false;
    }
    this.allShiftService.getAllShift().then((res) => {
      this.allShift = res;
      this.tabChanged(this.selectedTab);
    })
  }

  shiftChangeCallback(shift) {
    this.shift = shift.name;
    this.packingDetailService.shift = shift;
    this.tabChanged(this.selectedTab);
  }

  tabChanged(tabId) {
    this.selectedTab = tabId;
    this.sharedService.objectStore.packingSelectedTab = tabId;
    switch (tabId) {
      case "orders":
        this.loadPackingOrders(this.dates.formattedDates[0], this.dates.formattedDates[1], this.dates.isWeek, this.shift);
        this.loadTop5Aging("orders", this.dates.formattedDates[1], 5, this.dates.formattedDates[0], this.shift);
        //this.loadTop5ExceptionSKU("orders", this.dates.formattedDates[1], 5, this.dates.formattedDates[0], this.shift);
        break;
      case "containers":
        this.loadPackingContainers(this.dates.formattedDates[0], this.dates.formattedDates[1], this.dates.isWeek, this.shift);
        this.loadTop5Aging("containers", this.dates.formattedDates[1], 5, this.dates.formattedDates[0], this.shift);
        //this.loadTop5ExceptionSKU("containers", this.dates.formattedDates[1], 5, this.dates.formattedDates[0], this.shift);
        break;
      default:
        break;
    }
  }
  onWorkQueueSectionSelect(data, parentModule) {
    if (this.selectedTab === "orders")
      this.router.navigate(['/orders'], { queryParams: { status: data.toLowerCase(), processType: 'Packing', parentModule: parentModule } });
    if (this.selectedTab === "containers")
      this.router.navigate(['/containers'], { queryParams: { status: data.toLowerCase(), processType: 'Packing', parentModule: parentModule } });
  }
}