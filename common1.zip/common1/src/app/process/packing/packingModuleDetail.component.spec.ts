import { NotyService } from 'sensorthink-commoncontrols/src/services/noty.service';
import { ComponentFixture, TestBed, async, tick, fakeAsync } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement, Directive } from '@angular/core';
import { PackingModuleDetailComponent } from './packingModuleDetail.component';
import { ProcessModule } from '../process.module';
import { PackingDetailService } from './services/packingDetail.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { RouterStub } from '../../../test/routerStub';
import { MockActivatedRouteById } from '../../../test/mockActivateRoute';

class MockPackingDetailService {
    getPackingSummaryData(): Observable<any> { return Observable.of({}); };
    getPackingProcessRateSummaryData(): Observable<any> { return Observable.of({}); };
    getPackingData(): Observable<any> { return Observable.of({}); };
    getPackingSectionProcessRate(): Observable<any> { return Observable.of({}); };
    getTop5Aging(): Observable<any> { return Observable.of({}); };
}
xdescribe('PACK CONTAINER DETAILS:... Component', () => {

    let component: PackingModuleDetailComponent;
    let fixture: ComponentFixture<PackingModuleDetailComponent>;
    let de: DebugElement;
    let el: HTMLElement;
    let service;
    let noty;
    let router;
    //let mockParams;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            // mockParams = Observable.of<>({foo: '3'});
            imports: [ProcessModule],
            providers: [{ provide: PackingDetailService, useClass: MockPackingDetailService },
            { provide: Router, useClass: RouterStub },
            { provide: ActivatedRoute, useClass: MockActivatedRouteById }, NotyService]
        })
        // https://angular-2-training-book.rangle.io/handout/testing/components/injecting-dependencies.html
        fixture = TestBed.overrideComponent(PackingModuleDetailComponent, {
            set: {
                template: '<span>{{message}}</span>'
            }
        })
        .createComponent(PackingModuleDetailComponent);
        component = fixture.componentInstance;
        service = fixture.debugElement.injector.get(PackingDetailService);
        router = fixture.debugElement.injector.get(ActivatedRoute);
        noty = fixture.debugElement.injector.get(NotyService);
    }));
    it('should have a defined component', () => {
        expect(component).toBeDefined();
    });
    describe('When we call loadPickingDetailData', () => {
        let fromDate, toDate, isWeek, shift;
        beforeEach(() => {
            fromDate = "03232017 00:00:00";
            toDate = "03232017 23:59:59";
            isWeek = false;
            shift = 'Morning';
            component.dates = { dates: [new Date()], isWeek: false, formattedDates: ["04102017 00:00:00", "04102017 23:59:59"] };

        })
        it('should get all pickContainer details data', () => {
            spyOn(service, 'getPackingSummaryData').and.returnValue(Observable.of({}));
            spyOn(service, 'getPackingProcessRateSummaryData').and.returnValue(Observable.of({}));
            spyOn(service, 'getPackingData').and.returnValue(Observable.of([{}, {}]));
            spyOn(service, 'getPackingSectionProcessRate').and.returnValue(Observable.of([{}, {}]));
            component.loadPackingDetailData(fromDate, toDate, isWeek, shift); 
            expect(component.packingSummaryData).toBeNull();           
            expect(component.packingLineSummaryData).toBeNull();;
            expect(component.packingSectionData.length).toBe(2); 
            expect(component.isPickingLoading).toBe(false)
        })
    });
    describe('When we call showTabs', () => {
        var fixture2expectation = ["orders", "orderLines", "units", "containers"]; 
         var isCheck = true;   
         it("it activates the tab", function () {
            for (var fixtureString in fixture2expectation) {
                component.showTabs(fixtureString);
                expect(isCheck).not.toBeFalsy();
            }
        });
    });
    describe('When we call loadTop5Aging', () => {
        let fromDate, toDate, isWeek, shift;
        beforeEach(() => {
            fromDate = "03232017 00:00:00";
            toDate = "03232017 23:59:59";
            isWeek = false;
            shift = 'Morning'
        })
        it(' should get the top 5 data', () => {
            spyOn(service, "getTop5Aging").and.returnValue(Observable.of({}));
            spyOn(component, 'loadTop5Aging');
            component.loadTop5Aging('orders', toDate, 5, fromDate, shift);
            expect(component.loadTop5Aging).toHaveBeenCalled();
        })
    });
    describe('When we call ', () => {
        let date;
        beforeEach(() => {
            component.dates = { dates: [new Date()], isWeek: false, formattedDates: ["04102017 00:00:00", "04102017 23:59:59"] };
            date = { dates: [new Date()], isWeek: false, formattedDates: ["04102017 00:00:00", "04102017 23:59:59"] };
            spyOn(component, 'loadPackingDetailData');
            spyOn(component, 'loadTop5Aging');
        })
        it(' dateChangeCallback and isWeek is true then it should set the x-axis as days', () => {
            date.isWeek = true;
            component.dateChangeCallback(date);
            expect(component.xAxisFormat).toBe('ddd');
            expect(component.isWeek).toBe(true);
        })
        it(' dateChangeCallback and isWeek is false then it should set the x-axis as hr', () => {
            component.dateChangeCallback(date);
            expect(component.xAxisFormat).toBe('HH:mm');
            expect(component.isWeek).toBe(false);
        })
        it(' shiftChangeCallback should set the shift', () => {
            component.shiftChangeCallback({ text: 'Morning' });
            expect(component.shift).toBe('Morning');
        })
    });    
});