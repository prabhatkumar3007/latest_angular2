import { ShiftService } from './../../shared/services/shift.service';
import { PackingDetailService } from './services/packingDetail.service';
import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Rx';
import { NotyService } from 'sensorthink-commoncontrols/src/services/noty.service';

declare var moment: any;
@Component({
  templateUrl: 'packingModuleDetail.component.html'

})
export class PackingModuleDetailComponent {
  public AreaContents = ["All Areas"];
  public datePickerConfig: any;
  public packingSummaryData: any;
  public packingLineSummaryData: any;
  public packingSectionData: any;
  public packingTop5Aging: any;
  public packingTop5ExceptionSKU: any;

  public isPickingLoading: boolean = false;
  public isLoading: boolean = false;
  public shift: any;
  public xAxisFormat: string;
  public isXAxisDateType: boolean = true;
  public isWeek: boolean = true;
  public dates: any;
  public packingId: string;

  public packingType: string;
  isOrder: boolean = false;
  isOrderLine: boolean = false;
  isUnits: boolean = false;
  isContainers: boolean = false;
  allShift: any;

  constructor(private service: PackingDetailService, private route: ActivatedRoute, private allShiftService: ShiftService, private notyService: NotyService) {
    this.datePickerConfig = {
      maxDate: new Date(),
      minDate: moment(new Date()).subtract(1, 'M')._d
    };
    if (route.url)
      route.url.subscribe((url: any) => {
        this.packingType = url[1].path;
      });
  }
  ngOnInit() {
    this.route.params.subscribe(params => {
      if (params['id']) {
        this.packingId = params['id'];
      }
    });
    if (this.service.dates)
      this.dates = this.service.dates;
    if (this.service.shift)
      this.shift = this.service.shift.name;
  }

  loadPackingDetailData(fromDate, toDate, isWeek, shift) {
    let calls = [
      this.service.getPackingSummaryData(this.packingId, this.packingType, fromDate, toDate, shift),
      this.service.getPackingProcessRateSummaryData(this.packingId, this.packingType, fromDate, toDate, isWeek, shift),
      this.service.getPackingData(this.packingId, this.packingType, fromDate, toDate, shift),
      this.service.getPackingSectionProcessRate(this.packingId, this.packingType, fromDate, toDate, isWeek, shift)
    ];
    this.isPickingLoading = true;
    Observable.forkJoin(calls).subscribe(
      data => {
        if (data[0] && data[0][0])
          this.packingSummaryData = data[0][0].packingData;
        else
          this.packingSummaryData = null;
        if (data[1] && data[1][0])
          this.packingLineSummaryData = data[1][0];
        else
          this.packingLineSummaryData = null;
        if (data[2])
          this.packingSectionData = this.parseProcessDataToSection(data[2], data[3]);
        else
          this.packingSectionData = null;
        this.isPickingLoading = false;
      },
      err => {
        this.notyService.error(err)
      }
    )
  }
  loadTop5Aging(packingFrom, toDate, limit, fromDate, shift) {
    this.isLoading = true;
    this.service.getTop5Aging(packingFrom, toDate, 5, fromDate, shift).subscribe((data) => {
      this.showTabs(packingFrom);
      this.packingTop5Aging = data;
      this.isLoading = false;
    });
  }
  loadTop5ExceptionSKU(packingFrom, toDate, limit, fromDate, shift) {
    this.isLoading = true;
    this.service.getTop5ExceptionSKU(packingFrom, toDate, 5, fromDate, shift).subscribe((data) => {
      this.packingTop5ExceptionSKU = data;
      this.isLoading = false;
    });
  }
  showTabs(value) {
    this.isOrder = this.isOrderLine = this.isUnits = this.isContainers = false;
    switch (value) {
      case "orders":
        this.isOrder = true;
        break;
      case "containers":
        this.isContainers = true;
        break;
      default:
        break;
    }
  }
  parseProcessDataToSection(sectionList, processData) {
    let sectionData: any = sectionList;
    sectionData.forEach(element => {
      let processRate: any = processData;
      if (processRate) {
        let tmp = processRate.filter((f) => {
          if (f.processRateType === element.groupName)
            return f;
        })
        element.processRate = tmp[0];
      }
    });
    return sectionData;
  }

  dateChangeCallback(date) {
    this.dates = date;
    if (date.isWeek === true) {
      this.xAxisFormat = "ddd"
      this.isWeek = true;
    }
    else {
      this.xAxisFormat = "HH:mm";
      this.isWeek = false;
    }
    this.allShiftService.getAllShift().then((res) => {
      this.allShift = res;
      this.loadPackingDetailData(date.formattedDates[0], date.formattedDates[1], date.isWeek, this.shift);
      this.loadTop5Aging(this.packingType, this.dates.formattedDates[1], 5, this.dates.formattedDates[0], this.shift);
      //this.loadTop5ExceptionSKU("orders", this.dates.formattedDates[1], 5, this.dates.formattedDates[0], this.shift);
    })

  }

  shiftChangeCallback(shift) {
    this.shift = shift.name;
    this.loadPackingDetailData(this.dates.formattedDates[0], this.dates.formattedDates[1], this.dates.isWeek, this.shift);
    this.loadTop5Aging(this.packingType, this.dates.formattedDates[1], 5, this.dates.formattedDates[0], this.shift);
    //this.loadTop5ExceptionSKU("orders", this.dates.formattedDates[1], 5, this.dates.formattedDates[0], this.shift);
  }
}