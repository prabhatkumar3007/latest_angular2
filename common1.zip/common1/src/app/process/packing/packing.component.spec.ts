import { async, ComponentFixture, inject, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement, Directive } from '@angular/core';
import { NotyService } from 'sensorthink-commoncontrols/src/services/noty.service';
import { Observable } from 'rxjs/Observable';
import { PackingComponent } from './packing.component';
import { PackingDetailService } from './services/packingDetail.service';
import { PackingService } from './services/packing.service';
import { ProcessModule } from '../process.module';
import { Router } from '@angular/router';
import { RouterStub } from '../../../test/routerStub';

class MockPackService {
    getPackingSummary(): Observable<any> { return Observable.of({}); };
    getPackingProcessRateSummary(): Observable<any> { return Observable.of({}); };
    getTop5Aging(): Observable<any> { return Observable.of({}); };
    getPackingData(): Observable<any> { return Observable.of({}); };
    getPackingSectionProcessRate(): Observable<any> { return Observable.of({}); };
}
class MockPackDetailService {
}
describe('PACK:... Component', () => {

    let component: PackingComponent;
    let fixture: ComponentFixture<PackingComponent>;
    let de: DebugElement;
    let el: HTMLElement;
    let service;
    let noty;
    let router

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [ProcessModule],
            providers: [{ provide: PackingService, useClass: MockPackService }, { provide: PackingDetailService, useClass: MockPackDetailService },
            { provide: Router, useClass: RouterStub }, NotyService]
        })
        fixture = TestBed.overrideComponent(PackingComponent, {
            set: {
                template: '<span>{{message}}</span>'
            }
        }).createComponent(PackingComponent);
        component = fixture.componentInstance;
        service = fixture.debugElement.injector.get(PackingService);
        router = fixture.debugElement.injector.get(Router);
        noty = fixture.debugElement.injector.get(NotyService);
    }));

    it('should have a defined component', () => {
        expect(component).toBeDefined();
    });

    describe('When we call ', () => {
        let fromDate, toDate, isWeek, shift;
        beforeEach(() => {
            fromDate = "03232017 00:00:00";
            toDate = "03232017 23:59:59";
            isWeek = false;
            shift = 'Morning'
        })
        it(' loadSummarySection should get all summaryData and summaryProcessRateData', () => {
            spyOn(service, 'getPackingSummary').and.returnValue(Observable.of([{}, {}]));
            spyOn(service, 'getPackingProcessRateSummary').and.returnValue(Observable.of([{}, {}]));
            component.loadSummarySection("orders", fromDate, toDate, isWeek, shift);
            expect(component.summaryData.length).toBe(2);
            expect(component.summaryProcessRateData.length).toBe(2);
        })
        it(' loadPackingModuleSection should get all getPackingData and getPackingSectionProcessRate', () => {
            spyOn(service, 'getPackingData').and.returnValue(Observable.of([{}, {}]));
            spyOn(service, 'getPackingSectionProcessRate').and.returnValue(Observable.of([{}, {}]));
            component.loadPackingModuleSection("orders", fromDate, toDate, isWeek, shift, 'pack', '');
            expect(component['pack'].length).toBe(2);
        })
    });

    describe('When we call', () => {
        let fromDate, toDate, isWeek, shift;
        beforeEach(() => {
            fromDate = "03232017 00:00:00";
            toDate = "03232017 23:59:59";
            isWeek = false;
            shift = 'Morning'
        })
        it(' loadPackingOrders should set the order Tab', () => {
            spyOn(component, 'loadSummarySection');
            spyOn(component, 'loadPackingModuleSection');
            component.loadPackingOrders(fromDate, toDate, isWeek, shift);
            expect(component.loadSummarySection).toHaveBeenCalled();
            expect(component.loadPackingModuleSection).toHaveBeenCalled();
        })
        it(' loadPackingOrdersLines should set the orderLines Tab', () => {
            spyOn(component, 'loadSummarySection');
            spyOn(component, 'loadPackingModuleSection');
            component.loadPackingOrders(fromDate, toDate, isWeek, shift);
            expect(component.loadSummarySection).toHaveBeenCalled();
            expect(component.loadPackingModuleSection).toHaveBeenCalled();
        })
        it(' loadPackingUnits should set the pager config', () => {
            spyOn(component, 'loadSummarySection');
            spyOn(component, 'loadPackingModuleSection');
            component.loadPackingOrders(fromDate, toDate, isWeek, shift);
            expect(component.loadSummarySection).toHaveBeenCalled();
            expect(component.loadPackingModuleSection).toHaveBeenCalled();
        })
        it(' loadPackingContainers should set the pager config', () => {
            spyOn(component, 'loadSummarySection');
            spyOn(component, 'loadPackingModuleSection');
            component.loadPackingOrders(fromDate, toDate, isWeek, shift);
            expect(component.loadSummarySection).toHaveBeenCalled();
            expect(component.loadPackingModuleSection).toHaveBeenCalled();
        })

    });

    describe('When we call loadTop5Aging', () => {
        let fromDate, toDate, isWeek, shift;
        beforeEach(() => {
            fromDate = "03232017 00:00:00";
            toDate = "03232017 23:59:59";
            isWeek = false;
            shift = 'Morning'
        })
        it(' should get the top 5 data', () => {
            spyOn(service, "getTop5Aging").and.returnValue(Observable.of({}));
            spyOn(component, 'loadTop5Aging');
            component.loadTop5Aging('orders', toDate, 5, fromDate, shift);
            expect(component.loadTop5Aging).toHaveBeenCalled();
        })
    });

    describe("When we call", function () {
        var fixture2expectation = ["orders", "orderLines", "units", "containers"];
        var isCheck = true;
        let fromDate, toDate, isWeek, shift;
        beforeEach(() => {
            fromDate = "03232017 00:00:00";
            toDate = "03232017 23:59:59";
            isWeek = false;
            shift = 'Morning';
            component.dates = { dates: [new Date()], isWeek: false, formattedDates: ["04102017 00:00:00", "04102017 23:59:59"] };
            spyOn(component, 'loadTop5Aging');
            spyOn(component, 'loadPackingOrders');
            spyOn(component, 'loadPackingContainers');

        })
        it("it activates the tab", function () {
            for (var fixtureString in fixture2expectation) {
                component.showTabs(fixtureString);
                expect(isCheck).not.toBeFalsy();
            }
        });
        it("it activates the order tab", function () {
            component.tabChanged(fixture2expectation[0]);
            expect(component.loadTop5Aging).toHaveBeenCalled();
            expect(component.loadPackingOrders).toHaveBeenCalled();
        });
        it("it activates the containers tab", function () {
            component.tabChanged(fixture2expectation[3]);
            expect(component.loadTop5Aging).toHaveBeenCalled();
            expect(component.loadPackingContainers).toHaveBeenCalled();
        });
    });

    describe('When we call ', () => {
        let date;
        beforeEach(() => {
            date = { dates: [new Date()], isWeek: false, formattedDates: ["04102017 00:00:00", "04102017 23:59:59"] };
            spyOn(service, 'getPackingData').and.returnValue(Observable.of([{}, {}]));
            spyOn(service, 'getPackingSectionProcessRate').and.returnValue(Observable.of([{}, {}]));
            spyOn(component, 'tabChanged');
        })
        it(' dateChangeCallback and isWeek is true then it should set the x-axis as days', () => {
            date.isWeek = true;
            component.dateChangeCallback(date);
            expect(component.xAxisFormat).toBe('ddd');
            expect(component.isWeek).toBe(true);
            expect(component.tabChanged).toHaveBeenCalled();
        })
        it(' dateChangeCallback and isWeek is false then it should set the x-axis as hr', () => {
            component.dateChangeCallback(date);
            expect(component.xAxisFormat).toBe('HH:mm');
            expect(component.isWeek).toBe(false);
            expect(component.tabChanged).toHaveBeenCalled();
        })
        it(' shiftChangeCallback should set the shift', () => {
            component.shiftChangeCallback({ text: 'Morning' });
            expect(component.shift).toBe('Morning');
            expect(component.tabChanged).toHaveBeenCalled();
        })
    });

    describe('When we call onWorkQueueSectionSelect', () => {
        it(' should go order', async(() => {
            spyOn(router, 'navigate');
            component.onWorkQueueSectionSelect('orders', 1)
            expect(router.navigate).toHaveBeenCalledWith(['/orders'], { queryParams: { status: 'orders' , processType: 'Packing', parentModule:''} });
        }));
    });
});
