import { ProcessRateData } from '../../../dashboard/processRate/services/processRate.data';
import { ProcessData } from 'sensorthink-commoncontrols/src/chart.module';

export class PickingTab {
    public groupName: string;
    public packingData: ProcessData;
    public processRate: ProcessRateData;

    constructor(groupName: string, processData: ProcessData) {
        this.groupName = groupName;
        this.packingData = processData;
    }
}

