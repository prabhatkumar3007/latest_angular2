import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { NvD3Module } from 'angular2-nvd3';
import { PaginationModule } from 'ng2-bootstrap/pagination';
import { PopoverModule } from 'ng2-bootstrap/popover';
import { TabsModule } from 'ng2-bootstrap/tabs';
import { TooltipModule } from 'ng2-bootstrap/tooltip';
import { DragulaModule } from 'ng2-dragula';
import { ChartModule } from 'sensorthink-commoncontrols/src/chart.module';
import { CommonUtilsModule } from 'sensorthink-commoncontrols/src/common.module';
import { SensorThinkControlsModule } from 'sensorthink-commoncontrols/src/controls.module';
import { PermissionDirective } from './../shared/directives/permission.directive';

@NgModule({
  imports: [
    FormsModule,
    CommonModule,
    PopoverModule.forRoot(),
    PaginationModule.forRoot(),
    TooltipModule.forRoot(),
    TabsModule.forRoot(),
    NvD3Module
  ],
  declarations: [PermissionDirective],
  exports: [
    DragulaModule,
    ChartModule,
    SensorThinkControlsModule,
    CommonUtilsModule,
    PermissionDirective
  ]
})
export class ControlsModule { }