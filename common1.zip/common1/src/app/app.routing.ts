import { RouterModule } from '@angular/router';
import { AuthGuard } from './auth/auth-guard.service';
import { DashboardComponent } from './dashboard/dashboard.component';
import { LoginComponent } from './login.component';
import { NotFoundComponent } from './shared/components/not-found.component';
import { NoAccessComponent } from './shared/components/no-access.component';

export const routing = RouterModule.forRoot([
  { path: '', component: DashboardComponent, canActivate: [AuthGuard], data: { permission: ['all','any pages'] } },
  { path: 'login', component: LoginComponent },
  { path: 'home', component: DashboardComponent, canActivate: [AuthGuard], data: { permission: ['all','any pages'] } },
  { path: 'not-found', component: NotFoundComponent },
  { path: 'no-access', component: NoAccessComponent },
  { path: '**', redirectTo: 'not-found' }
], { useHash: true });