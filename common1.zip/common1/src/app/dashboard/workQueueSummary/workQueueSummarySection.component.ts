import { Subject } from 'rxjs/Rx';
import { ShiftService } from './../../shared/services/shift.service';
import { ProgerssBarService } from './services/progressBar.service';
import { Component, Input } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { ProcessData } from 'sensorthink-commoncontrols/src/chart.module';
import { NotyService } from 'sensorthink-commoncontrols/src/services/noty.service';
import { ShareDataService } from 'sensorthink-commoncontrols/src/services/shareDataService';
declare var moment: any

@Component({
    selector: 'work-queue-summary-section',
    templateUrl: 'workQueueSummarySection.template.html'
})

export class WorkQueueSummarySection {
    @Input() datePickerConfig: any;
    @Input() dateChange: Subject<any>;
    dates: any = {};
    workQueueSummaryShift: string;
    isWorkQueueSummaryLoading: boolean = false;
    isWorkQueue:boolean;
    orderProcessData: ProcessData;
    orderLinesProcessData: ProcessData;
    unitProcessData: ProcessData;
    containersProcessData: ProcessData;
    allShift: any;

    constructor(private progerssBarService: ProgerssBarService, private sharedService: ShareDataService, private allShiftService: ShiftService, private noty: NotyService, private router: Router) {
    }

    ngOnInit() {
        this.dateChange
            .subscribe(model => {
                this.workQueueSummaryCallback(model);
            });
    }

    workQueueSummaryCallback(filterObj) {
        let dateObj = filterObj.dates;
        let fromDate;
        let toDate;
        fromDate = dateObj.formattedDates[0];
        toDate = dateObj.formattedDates[1];
        this.dates.workQueueSummaryDates = dateObj;
        if (filterObj.shift != undefined)
            this.workQueueSummaryShift = filterObj.shift;
        this.loadWorkQueueSummarySection(fromDate, toDate);
    }


    loadWorkQueueSummarySection(fromDate?, toDate?) {
        if (this.workQueueSummaryShift === undefined) {
            this.workQueueSummaryShift = "All Shifts"
        }
        let calls = [
            this.progerssBarService.getOrderProgressBarData(fromDate, toDate, this.workQueueSummaryShift),
            this.progerssBarService.getOrderLinesProgressBarData(fromDate, toDate, this.workQueueSummaryShift),
            this.progerssBarService.getUnitProgressBarData(fromDate, toDate, this.workQueueSummaryShift),
            this.progerssBarService.getContainerProgressBarData(fromDate, toDate, this.workQueueSummaryShift)
        ];

        this.isWorkQueueSummaryLoading = true;

        Observable.forkJoin(calls).subscribe((response) => {
            this.orderProcessData = null;
            this.orderProcessData = response[0];

            this.orderLinesProcessData = null;
            this.orderLinesProcessData = response[1];

            this.unitProcessData = null;
            this.unitProcessData = response[2]

            this.containersProcessData = null;
            this.containersProcessData = response[3];
            this.isWorkQueueSummaryLoading = false;
        }, (err) => {
            this.noty.error(err);
        })
    }

    shiftChangeCallback(shift) {
        this.workQueueSummaryShift = shift.name;
        this.sharedService.objectStore.workQueueSummaryShift = shift;
        this.workQueueSummaryCallback(this.dates.workQueueSummaryDates)
    }

    onWorkQueueSectionSelect(data, selectedTabName) {
        if (selectedTabName === 'orders')
            this.router.navigate(['/orders'], { queryParams: { status: data.toLowerCase(), processType: 'Dashboard' } });
        else
            this.router.navigate(['/containers'], { queryParams: { status: data.toLowerCase(), processType: 'Dashboard' } });
    }
}