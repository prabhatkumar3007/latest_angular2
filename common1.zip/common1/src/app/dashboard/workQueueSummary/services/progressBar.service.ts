import { Injectable } from '@angular/core';
import { Response } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import { ProcessData, ProcessSection } from 'sensorthink-commoncontrols/src/chart.module';
import { HttpService } from 'sensorthink-commoncontrols/src/common.module';

@Injectable()
export class ProgerssBarService {

    constructor(private $http: HttpService) { }

    getOrderProgressBarData(fromDate, toDate, shift?): Observable<ProcessData> {
        return this.$http.wesContext.url("/api/workqueue/orders").addParam("fromDate", fromDate).addParam("toDate", toDate).addParam("shift", shift)
            .get().map((res: Response) => {
                if (!res.text())
                    return null;
                let obj = res.json();
                let orderProcessData = new ProcessData(obj[0].processTime);
                obj[0].dataPoints.forEach(element => {
                    orderProcessData.addProcessValues(new ProcessSection(element.key, element.value));
                });
                orderProcessData.calculatePercentageWidths();
                return orderProcessData;
            });
    }
    getOrderLinesProgressBarData(fromDate, toDate, shift?): Observable<ProcessData> {
        return this.$http.wesContext.url("/api/workqueue/orderlines").addParam("fromDate", fromDate).addParam("toDate", toDate).addParam("shift", shift).get().map((res: Response) => {
            if (!res.text())
                return null;
            let obj = res.json();
            let orderProcessData = new ProcessData(obj[0].processTime);
            obj[0].dataPoints.forEach(element => {
                orderProcessData.addProcessValues(new ProcessSection(element.key, element.value));
            });
            orderProcessData.calculatePercentageWidths();
            return orderProcessData;
        });
    }
    getUnitProgressBarData(fromDate, toDate, shift?): Observable<ProcessData> {
        return this.$http.wesContext.url("/api/workqueue/units").addParam("fromDate", fromDate).addParam("toDate", toDate).addParam("shift", shift).get().map((res: Response) => {
            if (!res.text())
                return null;
            let obj = res.json();
            let orderProcessData = new ProcessData(obj[0].processTime);
            obj[0].dataPoints.forEach(element => {
                orderProcessData.addProcessValues(new ProcessSection(element.key, element.value));
            });
            orderProcessData.calculatePercentageWidths();
            return orderProcessData;
        });
    }
    getContainerProgressBarData(fromDate, toDate, shift?): Observable<ProcessData> {
        return this.$http.wesContext.url("/api/workqueue/containers").addParam("fromDate", fromDate).addParam("toDate", toDate).addParam("shift", shift).get().map((res: Response) => {
            if (!res.text())
                return null;
            let obj = res.json();
            let orderProcessData = new ProcessData(obj[0].processTime);
            obj[0].dataPoints.forEach(element => {
                orderProcessData.addProcessValues(new ProcessSection(element.key, element.value));
            });
            orderProcessData.calculatePercentageWidths();
            return orderProcessData;
        });
    }
    getRandomNumber(): number {
        return Math.floor(Math.random() * 1000) + 1;
    }
}