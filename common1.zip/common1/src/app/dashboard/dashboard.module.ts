import { PopoverTopRankingHtmlComponent } from './topTenRankingComponent/topRankingSelector.component';
import { DashboardService } from './dashboard.service';
import { OrdersPickedShippedSection } from './ordersPickedShipped/ordersPickedShipped.component';
import { AccordionModule } from 'ng2-bootstrap/accordion';
import { CommonModule } from '@angular/common';
import { ControlsModule } from '../controls/controls.module';
import { DashboardComponent } from './dashboard.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { KeysPipe } from '../shared/components/objectKeyFilter.pipe';
import { NgModule } from '@angular/core';
import { OrderPickedService } from './ordersPickedShipped/services/orderPicked.service';
import { PaginationModule } from 'ng2-bootstrap/ng2-bootstrap';
import { PopoverModule } from 'ng2-bootstrap/popover';
import { ProcessRateComponent } from './processRate/processRate.component';
import { ProcessRateService } from './processRate/services/processRate.service';
import { ProgerssBarService } from './workQueueSummary/services/progressBar.service';
import { RouterModule } from '@angular/router';
import { SharedModule } from '../shared/shared.module';
import { TabsModule } from 'ng2-bootstrap';
import { TitleCase } from '../shared/components/camelCaseFilter.pipe';
import { TopTenRakingComponent } from './topTenRankingComponent/topTenRanking.component';
import { TopTenRankingService } from './topTenRankingComponent/services/topTenRanking.service';
import { WorkQueueSummarySection } from './workQueueSummary/workQueueSummarySection.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule,
    HttpModule,
    AccordionModule.forRoot(),
    PaginationModule,
    TabsModule,
    ControlsModule,
    PopoverModule,
    SharedModule
  ],
  declarations: [
    DashboardComponent,
    PopoverTopRankingHtmlComponent,
    TopTenRakingComponent,
    ProcessRateComponent,
    KeysPipe,
    TitleCase,
    WorkQueueSummarySection,
    OrdersPickedShippedSection
  ],
  exports: [
    DashboardComponent,
    PopoverTopRankingHtmlComponent,
    TopTenRakingComponent,
    ProcessRateComponent,
    KeysPipe,
    TitleCase,
    WorkQueueSummarySection,
    OrdersPickedShippedSection
  ],
  providers: [
    ProgerssBarService,
    ProcessRateService,
    OrderPickedService,
    TopTenRankingService,
    DashboardService
  ]
})
export class DashboardModule {
}