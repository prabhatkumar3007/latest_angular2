import { ShiftService } from './../../shared/services/shift.service';
import { WaveData } from './services/topTenRanking.data';
import { TopTenRankingService } from './services/topTenRanking.service';
import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Observable, Subject } from 'rxjs/Rx';
import { NotyService } from 'sensorthink-commoncontrols/src/services/noty.service';
import { ShareDataService } from 'sensorthink-commoncontrols/src/services/shareDataService';

declare var moment: any;

@Component({
    selector: 'top-ten-rank-table',
    templateUrl: 'topTenRanking.component.html'
})

export class TopTenRakingComponent {
    filterObj: any;
    @Output() tableRemoveEvent = new EventEmitter();
    @Input() topTenRankingData: WaveData;
    @Input() datePickerConfig: any;
    @Input() dateChange: Subject<any>;
    public addedTopTableRanking: any;

    private fromDate: string;
    private toDate: string;

    selectedTopTenTables: Array<any> = new Array<any>();
    isRankingTableCountOdd: boolean = true;
    isTop10RankingLoading: boolean = false;
    isTopRanking:boolean;
    dates: any;
    shift: string;

    constructor(private service: TopTenRankingService, private allShiftService: ShiftService, private noty: NotyService, private sharedService: ShareDataService) { }

    ngOnInit() {
        if (this.dateChange)
            this.dateChange
                .subscribe(model => {
                    this.topTenRankDatePickerCallback(model);
                });
    }

    topTenRankDatePickerCallback(filterObj) {
        this.filterObj = filterObj;
        let dateObj = filterObj.dates;
        this.shift = filterObj.shift;
        this.dates = dateObj;
        this.sharedService.objectStore.topTenRankingDates = dateObj;
        let fromDate;
        let toDate;
        fromDate = dateObj.formattedDates[0];
        toDate = dateObj.formattedDates[1];
        this.fromDate = fromDate;
        this.toDate = toDate;
        this.reloadSelectedTablesData(this.service.getAllTables(), this.shift);
    }

    reloadSelectedTablesData(selectedTables, shift) {
        let calls = [];
        selectedTables = selectedTables.filter((tbl) => {
            if (tbl.isChecked === true)
                return tbl;
        });
        selectedTables.forEach(tbl => {
            calls.push(tbl.callFn([this.fromDate, this.toDate], tbl.sortBy, shift));
        });
        this.isTop10RankingLoading = true;
        Observable.forkJoin(calls).subscribe((res) => {
            this.isRankingTableCountOdd = selectedTables.length % 2 === 0 ? false : true;
            selectedTables.forEach((tbl, idx) => {
                tbl.rankData = res[idx];
            });
            this.selectedTopTenTables = selectedTables;
            this.isTop10RankingLoading = false;
        }, (err) => {
            this.noty.error(err);
            this.isTop10RankingLoading = false;
        })
    }

    removeRankingTable(data) {
        if (this.selectedTopTenTables.length > 1) {
            data.isChecked = false;
            this.reloadSelectedTablesData(this.service.getAllTables(), this.shift);
        }
        else
            this.noty.error("At least 1 table should be selected.")
    }

    addTopRankingTable(selectedTables) {
        this.reloadSelectedTablesData(this.service.getAllTables(), this.shift);
    }
}