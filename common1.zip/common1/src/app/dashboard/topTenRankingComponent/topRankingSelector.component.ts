import { TopTenRankingService } from './services/topTenRanking.service';
import { Component, Input, Output, EventEmitter, SimpleChanges } from '@angular/core';
import { NotyService } from "sensorthink-commoncontrols/src/services/noty.service";

declare var $: any;

@Component({
  selector: 'top-ranking-selector',
  templateUrl: 'topRankingSelector.component.html'
})
export class PopoverTopRankingHtmlComponent {
  @Output() onApplyChanges: EventEmitter<Array<any>> = new EventEmitter<any>();
  @Input() dropDownTitle: String;
  @Input() dropDownList: any;
  @Input() selectedData: any;
  private _selectedTables: Array<any> = new Array<any>();
  model = { title: 'Age', ID: 1 };
  radioItems = [{ title: 'Age', ID: 1 },
  // { title: 'Quantity', ID: 2 },
  { title: 'Priority', ID: 3 }];
  radioBtn = this.radioItems[0].ID;
  tableList = Object.assign([], this.service.getTablesByType("Age"));

  constructor(private service: TopTenRankingService, private notyService: NotyService) { }

  onPopupShown(pop, el) {
    this.tableList = Object.assign([], this.service.getTablesByType("Age"));    
  }

  selectTable(tableId) {
    switch (tableId) {
      case 1: //Age Table
        this.tableList = Object.assign([], this.service.getTablesByType("Age"));
        break;
      case 2: // Quantity Table
        this.tableList = Object.assign([], this.service.getTablesByType("Quantity"));
        break;
      case 3: // Priority Table
        this.tableList = Object.assign([], this.service.getTablesByType("Priority"));
        break;
    }
  }

  toggleTable(chkBox, tableItem) {
    tableItem.isChecked = chkBox.checked;
    let asLeastOneSelected = false;
    this.service.getAllTables().forEach(tbl => {
      if (tbl.isChecked === true)
        asLeastOneSelected = true;
    });
    if (!asLeastOneSelected) {
      this.notyService.warning("At least 1 table should be selected.")
      tableItem.isChecked = !chkBox.checked;
      chkBox.checked = !chkBox.checked;
    }
  }

  applyTableSelection(popOver) {    
    this.onApplyChanges.emit(this.service.getAllTables());
    this.resetPopOver(popOver);
  }

  resetPopOver(popOver) {
    if (popOver)
      popOver.hide();
  }
} 