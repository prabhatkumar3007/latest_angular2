export class WaveData {
  waveId: any;
  agedTime: any;
  state: any;
  priority: any;
  constructor(waveId, agedTime, state: number, priority: number) {
    this.waveId = { title: "Wave Id", value: waveId };
    this.agedTime = { title: "Aged Time", value: agedTime };
    this.state = { title: "State", value: state };
    this.priority = { title: "Priority", value: priority };
  }
}

export class OrderData {
  orderId: any;
  agedTime: any;
  state: any;
  priority: any;
  constructor(orderId, agedTime, state, priority) {
    this.orderId = { title: "Order Id", value: orderId };
    this.agedTime = { title: "Aged Time", value: agedTime };
    this.state = { title: "State", value: state };
    this.priority = { title: "Priority", value: priority };
  }
}
export class BatchData {
  title: string;
  sortBy: string;
  no: number;
  batchId: number;
  agedTime: any;
  priority: number;
  qtyPicked: number;
  qtyPending: number;
  constructor(no, batchId, agedTime, priority, qtyPicked, qtyPending) {
    this.no = no;
    this.batchId = batchId;
    this.agedTime = agedTime;
    this.priority = priority;
    this.qtyPicked = qtyPicked;
    this.qtyPending = qtyPending;
  }
}

export class TopRankingMetadata {
  type: string;
  title: string;
  isChecked: boolean;
  sortBy: string;
  callFn: any;
  rankData: Array<any>;

  constructor(type, title, isChecked, sortBy, callFn) {
    this.type = type;
    this.title = title;
    this.isChecked = isChecked;
    this.sortBy = sortBy;
    this.callFn = callFn;
  }

}