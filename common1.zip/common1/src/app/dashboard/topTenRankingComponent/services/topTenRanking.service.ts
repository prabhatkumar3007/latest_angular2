import { OrderData, TopRankingMetadata, WaveData } from './topTenRanking.data';
import { Injectable } from '@angular/core';
import { HttpService } from 'sensorthink-commoncontrols/src/common.module';

@Injectable()
export class TopTenRankingService {
    private entityRef: any;
    private addedTopTableRanking: any = {};

    private topTenRankingTables =
    [
        new TopRankingMetadata("Age", "Wave", true, "age", this.getRankWavesData.bind(this)),
        new TopRankingMetadata("Age", "Order", false, "age", this.getRankOrderData.bind(this)),
        new TopRankingMetadata("Priority", "Wave", false, "priority", this.getRankWavesData.bind(this)),
        new TopRankingMetadata("Priority", "Order", false, "priority", this.getRankOrderData.bind(this))
    ]


    constructor(private _http: HttpService) { }


    getTablesByType(type: string) {
        return this.topTenRankingTables.filter((e) => {
            if (e.type === type)
                return e;
        })
    }

    getAllTables() {
        return this.topTenRankingTables;
    }

    getRankWavesData(dates, sortBy, shift) {
        return this._http.wesContext.url('/api/waves/top10/').addParam("fromDate", dates[0]).addParam("toDate", dates[1]).addParam("sortByColumn", sortBy).addParam("shift", shift).get().map(res => {
            let data = res.json();
            let waves = [];
            if (data)
                data.forEach(wave => {
                    waves.push(new WaveData(wave.waveId, wave.age, wave.state, wave.priority));
                });
            return waves;
        });
    }

    getRankOrderData(dates, sortBy, shift) {
        return this._http.wesContext.url('/api/orders/top10/').addParam("fromDate", dates[0]).addParam("toDate", dates[1]).addParam("sortByColumn", sortBy).addParam("shift", shift).get().map(res => {
            let data = res.json();
            let orders = [];
            if (data)
                data.forEach(order => {
                    orders.push(new OrderData(order.orderId, order.age, order.state, order.priority));
                });
            return orders;
        });
    }
}