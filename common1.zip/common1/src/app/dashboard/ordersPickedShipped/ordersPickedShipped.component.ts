import { ShiftService } from './../../shared/services/shift.service';
import { OrderPickedService } from './../ordersPickedShipped/services/orderPicked.service';
import { Component, Input } from '@angular/core';
import { Subject } from 'rxjs/Rx';
import { ChartService } from 'sensorthink-commoncontrols/src/chart.module';
import { NotyService } from 'sensorthink-commoncontrols/src/services/noty.service';
import { ShareDataService } from 'sensorthink-commoncontrols/src/services/shareDataService';
declare var moment: any

@Component({
    selector: 'orders-picked-shipped-section',
    templateUrl: 'orderesPickedShipped.template.html'
})

export class OrdersPickedShippedSection {
    filterObj: any;
    @Input() datePickerConfig: any;
    @Input() dateChange: Subject<any>;
    shift: string;
    dates: any = {};
    xAxisFormat: string;
    isXAxisDateType: boolean = true;
    isWeek: boolean = true;
    tickValues: any;
    isPickedChart: boolean = true;
    isOrdersLoading: boolean = false;
    orderPickedData: any;
    orderBarData: any;
    isBarClicked: boolean = false;
    isOrdersPicked:boolean;
    ordersDropDownList = ["ORDERS PICKED", "ORDERS SHIPPED"];
    selectedDropDown = this.ordersDropDownList[0]; // for oderpicked selected value
    allShift: any;

    constructor(private service: OrderPickedService, private sharedService: ShareDataService, private chartService: ChartService, private allShiftService: ShiftService, private noty: NotyService) {
    }

    ngOnInit() {
        if (this.dateChange)
            this.dateChange
                .subscribe(model => {
                    this.orderPickedCallback(model);
                });
    }

    orderPickedCallback(filterObj) {
        this.filterObj = filterObj;
        let dateObj = filterObj.dates;
        this.shift = filterObj.shift;
        let fromDate;
        let toDate;
        this.dates.orderPickedShippedDates = dateObj;
        fromDate = dateObj.formattedDates[0];
        toDate = dateObj.formattedDates[1];

        if (dateObj.isWeek === true) {
            this.xAxisFormat = "ddd"
            this.isWeek = true;
            this.tickValues = undefined;
        }
        else {
            this.xAxisFormat = "HH:mm";
            this.isWeek = false;
        }
        if (this.isPickedChart) {
            this.orderPickedSection(fromDate, toDate, dateObj.isWeek);
        } else {
            this.orderShippedSection(fromDate, toDate, dateObj.isWeek);
        }
    }

    orderPickedSection(fromDate, toDate, isWeek) {
        this.isOrdersLoading = true;
        this.service.getOrderData(fromDate, toDate, isWeek, false, this.shift).subscribe((res) => {
            this.tickValues = this.chartService.getTicksForChart(res[0]);
            this.orderPickedData = res[0];
            this.orderBarData = res[1];
            this.isOrdersLoading = false;
        }, err => {
            this.noty.error(err);
        })
    }

    orderShippedSection(fromDate, toDate, isWeek) {
        this.isOrdersLoading = true;
        this.service.getOrderData(fromDate, toDate, isWeek, true, this.shift).subscribe((res) => {
            this.orderPickedData = res[0];
            this.orderBarData = res[1];
            this.isOrdersLoading = false;
        })
    }

    toggleChartType() {
        this.isBarClicked = !this.isBarClicked;
    }

    onSelect(dropDownItem, index) {
        this.selectedDropDown = dropDownItem;
        this.isPickedChart = (index == 1) ? false : true;
        this.orderPickedCallback(this.filterObj);
    }
}