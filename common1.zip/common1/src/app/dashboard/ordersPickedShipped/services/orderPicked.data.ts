//Line Chart
export class OrderData {
    key: string;
    color: string;
    private Values: Array<OrderDataPoint>;

    get values(): Array<OrderDataPoint> {
        return this.Values;
    }


    constructor(key, color, dataPoints: Array<OrderDataPoint>) {
        this.key = key;
        this.color = color;
        this.Values = dataPoints || new Array<OrderDataPoint>();
    }

    addDataPoint(obj) {
        this.Values.push(obj);
    }
}

export class OrderDataPoint {
    x: string;
    y: number;
    constructor(x_axis, y_axis) {
        this.x = x_axis;
        this.y = y_axis;
    }
}

// Bar Chart
export class OrderPickedBarData {
    private Values: Array<OrderPickedBarDataPoint>;

    get values(): Array<OrderPickedBarDataPoint> {
        return this.Values;
    }


    constructor(dataPoints: Array<OrderPickedBarDataPoint>) {
        this.Values = dataPoints || new Array<OrderPickedBarDataPoint>();
    }

    addDataPoint(obj) {
        this.Values.push(obj);
    }
}

export class OrderPickedBarDataPoint {
    x: string;
    y: number;
    constructor(x_axis, y_axis) {
        this.x = x_axis;
        this.y = y_axis;
    }
}