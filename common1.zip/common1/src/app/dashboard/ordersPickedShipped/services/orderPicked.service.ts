import { OrderData, OrderDataPoint } from './orderPicked.data';
import { Injectable } from '@angular/core';
import { Response } from '@angular/http';
import { HttpService } from 'sensorthink-commoncontrols/src/common.module';
import { JwtHelper } from "sensorthink-commoncontrols/src/services/jwtHelper.service";
declare var moment: any;

@Injectable()
export class OrderPickedService {

    constructor(private _http: HttpService,private _jwtHelper:JwtHelper) { }

    getOrderData(fromDate, toDate, isWeek, isShipped, shift) {
        let labels = {
            orders: { title: "Orders", color: "#33CAFF" },
            orderlines: { title: "Order Lines", color: "#FF0000" },
            containers: { title: "Containers", color: "#9A9AD6" },
        }
        return this._http.wesContext.url("/api/processrate/consolidated").addParam("processType", !isShipped ? "picked" : "shipped").addParam("fromDate", fromDate).addParam("toDate", toDate).addParam("shift", shift)
            .get().map((res: Response) => {
                let obj = res.json();
                let lineChartData = []
                let barChartData = []
                obj.forEach(el => {
                    let data = [];
                    if (el.dataPoints) {
                        if (isWeek) {
                            this.parseDataForWeek(el.dataPoints).forEach(dataPoint => {
                                data.push(dataPoint);
                            });
                        }
                        else {
                            this.parseDataForDay(el.dataPoints).forEach(dataPoint => {
                                data.push(dataPoint);
                            });
                        }
                        let barData = new OrderData(labels[el.processRateType].title, labels[el.processRateType].color, data);
                        let cData = [];
                        let tot = 0;
                        data.forEach((el, idx) => {
                            tot += el.y;
                            let obj = {
                                x: data[idx].x,
                                y: tot
                            }
                            cData.push(obj);
                        });

                        let lineData = new OrderData(labels[el.processRateType].title, labels[el.processRateType].color, cData);
                        lineChartData.push(lineData);
                        barChartData.push(barData);
                    }
                });
                return [lineChartData, barChartData];
            });
    }

    parseDataForDay(dataPoints) {
        let minTime, maxTime;
        let tmpArray = [];
        dataPoints.forEach(element => {
            if (minTime === undefined)
                minTime = this.parseDate(element.xAxis);
            else if (this.parseDate(element.xAxis) < minTime)
                minTime = this.parseDate(element.xAxis);

            if (maxTime === undefined)
                maxTime = this.parseDate(element.xAxis);
            else if (maxTime < this.parseDate(element.xAxis))
                maxTime = this.parseDate(element.xAxis);
        })
        // tmpArray.push(new OrderDataPoint(moment(minTime).subtract({ 'minutes': 30 })._d, 0));
        dataPoints.forEach(element => {
            tmpArray.push(new OrderDataPoint(moment(this.parseDate(element.xAxis))._d, element.yAxis));
        });
        // tmpArray.push(new OrderDataPoint(moment(maxTime).add({ 'minutes': 30 })._d, 0));
        return tmpArray;
    }

    parseDataForWeek(dataPoints) {
        let tempParseObject: any = {};
        let firstDate = moment(new Date(), "MM-DD-YYYY").day(0)._d;
        [0, 1, 2, 3, 4, 5, 6].forEach(idx => {
            tempParseObject[idx] = new OrderDataPoint(idx, 0);
        });
        dataPoints.forEach(data => {
            let parsedDate = moment(this.parseDate(data.xAxis)).day() - 1;
            // if (parsedDate === 6)  // NEED TO CHECK WITH DATA ON MONDAY AND SUNDAY
            //     parsedDate = 0;
            if (tempParseObject[parsedDate] === undefined) {
                tempParseObject[parsedDate] = new OrderDataPoint(moment(this.parseDate(data.xAxis.split(" ")[0])).day(), data.yAxis);
            }
            else
                tempParseObject[parsedDate].y += data.yAxis;
        });

        let tmpArray = [];
        [0, 1, 2, 3, 4, 5, 6].forEach(idx => {
            tmpArray.push(tempParseObject[idx])
        });
        return tmpArray;
    }

    parseDate(date) {
        
        let dt = date.substring(0, 19);                
        let tz=this._jwtHelper.token.companyTimeZone;
        let d= moment(dt).utcOffset(tz)._d;  
        return d;
    }
}
