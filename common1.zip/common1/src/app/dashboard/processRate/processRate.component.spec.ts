import { ShiftService } from './../../shared/services/shift.service';
import { MockShiftService } from './../../../test/mockShiftServiceStub';
import { NotyService } from 'sensorthink-commoncontrols/src/services/noty.service';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { DashboardModule } from '../dashboard.module';
import { Observable } from 'rxjs/Rx';
import { ProcessRateComponent } from './processRate.component';
import { ProcessRateService } from './services/processRate.service';
import { ShareDataService } from "sensorthink-commoncontrols/src/services/shareDataService";


class MockProcessRateService {
    getProcessRateData() { }
}

describe('Process Rate Component', () => {
    let comp: ProcessRateComponent;
    let fixture: ComponentFixture<ProcessRateComponent>;
    let service: any;
    let sharedServiceRef: any;
    let shiftService: any;
    beforeEach(() => {
        TestBed.configureTestingModule({ 
            imports: [DashboardModule], // modules
            providers: [{ provide: ProcessRateService, useClass: MockProcessRateService },
            { provide: ShiftService, useClass: MockShiftService }, NotyService, ShareDataService]
        })
        fixture = TestBed.overrideComponent(ProcessRateComponent, {
            set: {
                template: '<span>{{message}}</span>'
            }
        }).createComponent(ProcessRateComponent);
        comp = fixture.componentInstance;
        service = fixture.debugElement.injector.get(ProcessRateService);
        sharedServiceRef = fixture.debugElement.injector.get(ShareDataService);
        shiftService = fixture.debugElement.injector.get(ShiftService);
        // });
    });

    describe('On Initialization', () => {
        it('should set the initial states', () => {
            expect(comp.isXAxisDateType).toBe(true);
            expect(comp.isProcessRateLoading).toBe(false);
        });
    });

    describe("When I change the date then ", () => {
        it(" should set the date and reload the process rate graph with date as Day", () => {
            spyOn(comp, "reloadProcessRate");
            spyOn(shiftService, "getAllShift").and.callThrough();
            comp.datePickerCallback({
                "dates": ["2017-03-22T18:30:00.000Z"], "isWeek": false,
                "formattedDates": ["03232017 00:00:00", "03232017 23:59:59"]
            })
            expect(comp.fromDate).toBe("03232017 00:00:00");
            expect(comp.toDate).toBe("03232017 23:59:59");
            expect(comp.xAxisDateFormat).toBe("HH:mm");
            expect(comp.isWeek).toBe(false);
            expect(shiftService.getAllShift).toHaveBeenCalled();
        });

        it(" should set the date and reload the process rate graph with date as Week", () => {
            spyOn(comp, "reloadProcessRate");
            spyOn(shiftService, "getAllShift").and.callThrough();
            comp.datePickerCallback({
                "dates": ["2017-03-22T18:30:00.000Z"], "isWeek": true,
                "formattedDates": ["03232017 00:00:00", "03232017 23:59:59"]
            })
            expect(comp.fromDate).toBe("03232017 00:00:00");
            expect(comp.toDate).toBe("03232017 23:59:59");
            expect(comp.xAxisDateFormat).toBe("ddd");
            expect(comp.isWeek).toBe(true);
            // expect(comp.reloadProcessRate).toHaveBeenCalled();
            expect(shiftService.getAllShift).toHaveBeenCalled();
        });
    })

    describe('When I reload Process Rate', () => {
        it(' should reload data from server and set the model', () => {
            spyOn(service, "getProcessRateData").and.returnValue(Observable.of({
                orders: [{}, {}],
                orderLines: [{}, {}, {}],
                units: [{}],
                containers: [{}, {}, {}]
            }));
            let fromDate = new Date();
            let toDate = new Date();
            comp.reloadProcessRate(new Date(), new Date(), true);
            expect(service.getProcessRateData).toHaveBeenCalled();
            expect(comp.processRateOrderData.length).toBe(2);
            expect(comp.processRateOrderlineData.length).toBe(3);
            expect(comp.processRateUnitData.length).toBe(1);
            expect(comp.processRateContainerData.length).toBe(3);
        });
    });
});