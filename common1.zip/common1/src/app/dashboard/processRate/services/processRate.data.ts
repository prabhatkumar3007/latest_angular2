export class ProcessRateData {
    private ProcessRateType: string;
    private Values: Array<ProcessRateDataPoint>;
    private IsArrowUp: boolean;
    get processRateType(): string {
        return this.ProcessRateType;
    }

    get values(): Array<ProcessRateDataPoint> {
        return this.Values;
    }

    get isArrowUp(): boolean {
        return this.IsArrowUp;
    }

    targetRate: number;
    actualRate: number;
    targetTime: string;
    projectedTime: string;
    percentageChange: number;
    isZero: boolean;
    avgProcessRate: string | number;

    constructor(processRateType, percentageChange, actualRate: number, targetRate, dataPoints?: Array<ProcessRateDataPoint>) {
        this.ProcessRateType = processRateType;
        this.Values = dataPoints || new Array<ProcessRateDataPoint>();
        //this.percentageChange = actualRate/ targetRate * 100;

        this.percentageChange = percentageChange;

        this.IsArrowUp = (this.percentageChange > 0) ? true : false;
        this.percentageChange = Math.abs(percentageChange);

    }

    addDataPoint(obj) {
        this.Values.push(obj);
    }
}

export class ProcessRateDataPoint {
    x: string;
    y: number;
    constructor(x_axis, y_axis) {
        this.x = x_axis;
        this.y = y_axis;
    }
}