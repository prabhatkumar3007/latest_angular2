import { ProcessRateData, ProcessRateDataPoint } from './processRate.data';
import { Injectable } from '@angular/core';
import { Response } from '@angular/http';
import { HttpService } from 'sensorthink-commoncontrols/src/common.module';
import { JwtHelper } from 'sensorthink-commoncontrols/src/services/jwtHelper.service';

declare let moment: any;

@Injectable()
export class ProcessRateService {
    constructor(private _http: HttpService,private _jwtHelper:JwtHelper) { }

    getProcessRateData(fromDate, toDate, isWeek, shift?) {
        return this._http.wesContext.url("/api/processrate/consolidated").addParam("fromDate", fromDate).addParam("toDate", toDate).addParam("shift", shift).get().map((res) => {
            let data = res.json();
            let minTime;
            let maxTime;
            data.forEach(obj => {
                if (obj.dataPoints)
                    obj.dataPoints.forEach(element => {
                        if (minTime === undefined)
                            minTime = this.parseDate(element.xAxis);
                        else if (this.parseDate(element.xAxis) < minTime)
                            minTime = this.parseDate(element.xAxis);

                        if (maxTime === undefined)
                            maxTime = this.parseDate(element.xAxis);
                        else if (maxTime < this.parseDate(element.xAxis))
                            maxTime = this.parseDate(element.xAxis);
                    });
            });

            return {
                orders: this.parseProcessRate(data[0], isWeek, minTime, maxTime),
                orderLines: this.parseProcessRate(data[1], isWeek, minTime, maxTime),
                units: this.parseProcessRate(data[2], isWeek, minTime, maxTime),
                containers: this.parseProcessRate(data[3], isWeek, minTime, maxTime)
            }
        });
    }


    parseProcessRate(obj, isWeek, minTime, maxTime): ProcessRateData {
        let orderData;
        let data = [];
        let isZero: boolean;
        if (obj.dataPoints) {
            if (isWeek) {
                this.parseDataForWeek(obj.dataPoints).forEach(dataPoint => {
                    data.push(dataPoint);
                });
            }
            else {
                obj.dataPoints.forEach(element => {
                    data.push(new ProcessRateDataPoint(moment(this.parseDate(element.xAxis)), element.yAxis));
                });

                if (moment(data[0].x) > minTime)
                    data.splice(0, 0, new ProcessRateDataPoint(moment(minTime), 0));

                if (moment(data[data.length - 1].x) < maxTime)
                    data.push(new ProcessRateDataPoint(moment(maxTime), 0));
            }

            orderData = new ProcessRateData(obj.processRateType, obj.percentageChange, obj.actualRate, obj.targetRate, data);
            orderData.targetRate = obj.targetRate;
            orderData.actualRate = obj.actualRate;
            orderData.projectedTime = obj.projectedTime;
            orderData.targetTime = obj.targetTime;

        }
        return orderData;
    }

    getOrderProgressRateData() {
        return this._http.wesContext.url("/api/processrate/orders").get().map((res: Response) => {
            let obj = res.json();
            let data = [];
            if (!obj[0].dataPoints)
                return null;
            obj[0].dataPoints.forEach(element => {
                data.push(new ProcessRateDataPoint(moment(this.parseDate(element.xAxis)), element.yAxis));
            });
            let orderData = new ProcessRateData(obj[0].processRateType, obj[0].percentageChange, obj[0].actualRate, obj[0].targetRate, data);
            orderData.targetRate = obj[0].targetRate;
            orderData.actualRate = obj[0].actualRate;
            orderData.projectedTime = obj[0].projectedTime;
            orderData.targetTime = obj[0].targetTime;
            return orderData;
        });
    }


    parseDataForWeek(dataPoints) {
        let tempParseObject: any = {};
        dataPoints.forEach(data => {
            let parsedDate = moment(this.parseDate(data.xAxis)).format("MMDDYYYY");
            if (tempParseObject[parsedDate] === undefined) {
                tempParseObject[parsedDate] = new ProcessRateDataPoint(moment(this.parseDate(data.xAxis.split(" ")[0])).day() - 1, data.yAxis);
            }
            else
                tempParseObject[parsedDate].y += data.yAxis;
        });

        let tmpArray = [];
        for (var property in tempParseObject) {
            if (tempParseObject.hasOwnProperty(property)) {
                tmpArray.push(tempParseObject[property])
            }
        }
        return tmpArray;
    }

    parseDate(date) {                
        let dt = date.substring(0, 19);        
        let tz=this._jwtHelper.token.companyTimeZone;
        let d= moment(dt).utcOffset(tz)._d;        
        return d;
    }
}
