import { ShiftService } from './../../shared/services/shift.service';
import { ProcessRateService } from './services/processRate.service';
import { Component, Input } from '@angular/core';
import { Subject } from 'rxjs/Rx';
import { NotyService } from 'sensorthink-commoncontrols/src/services/noty.service';
import { ShareDataService } from 'sensorthink-commoncontrols/src/services/shareDataService';

declare var moment: any;

@Component({
    selector: 'process-rate-section',
    templateUrl: 'processRate.component.html'
})
export class ProcessRateComponent {
    @Input() datePickerConfig: any;
    @Input() dateChange: Subject<any>;
    processRateOrderData: any;
    processRateOrderlineData: any;
    processRateUnitData: any;
    processRateContainerData: any;
    fromDate: any;
    toDate: any;
    isXAxisDateType: boolean = true;
    xAxisDateFormat: string;
    dates: any;
    isWeek: boolean;
    shift: string;
    isProcessRate:boolean;
    isProcessRateLoading: boolean = false;

    constructor(private processDataService: ProcessRateService, private sharedService: ShareDataService, private allShiftService: ShiftService, private noty: NotyService) { }

    ngOnInit() {
        if (this.dateChange)
            this.dateChange
                .subscribe(model => {
                    this.datePickerCallback(model);
                });
    }


    datePickerCallback(filterObj) {
        let dateObj = filterObj.dates;
        this.shift = filterObj.shift;
        this.fromDate = dateObj.formattedDates[0];
        this.toDate = dateObj.formattedDates[1];

        if (dateObj.isWeek === true) {
            this.xAxisDateFormat = "ddd"
            this.isWeek = true;
        }
        else {
            this.xAxisDateFormat = "HH:mm";
            this.isWeek = false;
        }
        this.reloadProcessRate(this.fromDate, this.toDate, dateObj.isWeek, this.shift);
    }

    reloadProcessRate(fromDate, toDate, isWeek, shift?) {
        this.isProcessRateLoading = true;
        this.processDataService.getProcessRateData(fromDate, toDate, isWeek, this.shift).subscribe(data => {
            this.processRateOrderData = data.orders;
            this.processRateOrderlineData = data.orderLines;
            this.processRateUnitData = data.units;
            this.processRateContainerData = data.containers;
            this.isProcessRateLoading = false;
        }, err => {
            this.noty.error(err);
        });
    }
}
