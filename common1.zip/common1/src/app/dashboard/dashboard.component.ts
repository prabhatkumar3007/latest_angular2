import { unescape } from 'querystring';
import { ShareDataService } from 'sensorthink-commoncontrols/src/services/shareDataService';
import { ShiftService } from './../shared/services/shift.service';
import { Subject } from 'rxjs/Rx';
import { DashboardService } from './dashboard.service';
import { ChangeDetectorRef, Component } from '@angular/core';
import { DragulaService } from 'ng2-dragula';
declare var moment: any

@Component({
  templateUrl: 'dashboard.component.html'

})
export class DashboardComponent {
  dateFilterObj: any = {
    dates: undefined,
    shift: undefined
  }
  isFirstLoad: boolean = true;
  AreaContents = ["All Areas"];
  datePickerConfig: any;
  dashBoardSettingConfig: any
  dateModelChanged: Subject<any> = new Subject<any>()
  shift: string;
  allShifts: any;

  constructor(private service: DashboardService, private dragulaService: DragulaService, private cdr: ChangeDetectorRef, private shiftService: ShiftService, private sharedService: ShareDataService) {
    this.datePickerConfig = {
      maxDate: new Date(),
      minDate: moment(new Date()).subtract(1, 'M')._d
    };
    this.checkSavedDates(this.dateFilterObj);
    this.setDnDOptions();
  }


  ngAfterViewInit() {
    this.service.getDashboardProfile().subscribe(res => {
      if (res) {
        this.sortArray(res, "order");
        this.dashBoardSettingConfig = res;
        this.shiftService.getAllShift().then((res) => {
          this.allShifts = res;
          this.isFirstLoad = false;
          this.dateModelChanged.next(this.dateFilterObj);
          this.cdr.detectChanges();
        })
      }
    }, (err) => {
      this.dashBoardSettingConfig = this.service.userSectionConfig;
    });
  }

  checkSavedDates(dateFilterObj) {
    if (this.sharedService.objectStore.dashBoardDateFilter) {
      this.dateFilterObj.dates = this.sharedService.objectStore.dashBoardDateFilter.dates;
      this.dateFilterObj.shift = this.shift = this.sharedService.objectStore.dashBoardDateFilter.shift;
    }
  }

  setDnDOptions() {
    try {
      this.dragulaService.setOptions('bag-one', {
        moves: function (el, container, handle) {
          if (handle.className.indexOf)
            return handle.className.indexOf('drag-handle') >= 0;
          return false;
        }
      });
    } catch (error) {
      // Intentionally left blank.
    }

    this.dragulaService.drop.subscribe((value) => {
      this.onDrop(value.slice(1));
    });
  }

  onDashboardFilterChange(dates, shift?) {
    this.dateModelChanged.next(this.dateFilterObj);
  }

  shiftChangeCallback(shift) {
    this.dateFilterObj.shift = shift.name;
    this.sharedService.objectStore.shiftValue=shift.name;
    if (!this.sharedService.objectStore.dashBoardDateFilter)
      this.sharedService.objectStore.dashBoardDateFilter = { shift: shift.name };
    else
      this.sharedService.objectStore.dashBoardDateFilter.shift = shift.name;
    this.onDashboardFilterChange(this.sharedService.objectStore.dashBoardDateFilter.dates, shift.name);
  }

  onDateChangedCallback(dates) {
    this.dateFilterObj.dates = dates;
    this.sharedService.objectStore.fromDate = dates.formattedDates[0];
    this.sharedService.objectStore.toDate = dates.formattedDates[1];
    if (!this.isFirstLoad) {
      if (!this.sharedService.objectStore.dashBoardDateFilter)
        this.sharedService.objectStore.dashBoardDateFilter = { dates: dates }
      else
        this.sharedService.objectStore.dashBoardDateFilter.dates = dates;

      this.onDashboardFilterChange(dates);
    }
  }

  private onDrop(args) {
    let [el, target, source] = args;
    let config = JSON.parse(JSON.stringify(this.dashBoardSettingConfig));
    var list = document.getElementsByClassName("section");
    for (var i = 0; i < list.length - 1; i++) {
      let section = config.filter((s) => {
        if (s.name === list[i].id)
          return s;
      })

      section[0].order = i + 1;
    }
    this.service.reorderSections(config);
  }

  private getElementFromCollection(el, value) {
    for (var index = 0; index < el.parentElement.children.length; index++) {
      var element = el.parentElement.children[index];
      if (element.id && value === element.id)
        return element
    }
  }

  private sortArray(arr, field) {
    arr.sort(function (a, b) {
      return parseFloat(a[field]) - parseFloat(b[field]);
    });
  }
}


