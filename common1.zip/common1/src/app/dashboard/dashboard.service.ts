import { Injectable } from '@angular/core';
import { SessionStorage } from 'sensorthink-commoncontrols/lib/webStore.module';
import { HttpService } from 'sensorthink-commoncontrols/src/common.module';

@Injectable()
export class DashboardService {
    @SessionStorage() private _userSectionConfig: any = [];
    private dashBoardProfile: any;
    get userSectionConfig(): any {
        if (this._userSectionConfig.length === 0)
            return [
                {
                    name: "work-queue-summary",
                    order: 1
                },
                {
                    name: "process-rate",
                    order: 2
                },
                {
                    name: "order-picked-shipped",
                    order: 3
                },
                {
                    name: "top-10",
                    order: 4
                }
            ];
        else
            return this._userSectionConfig;
    }

    constructor(private $http: HttpService) { }

    getDashboardProfile() {
        return this.$http.wesContext.url("/api/userpreference").addParam("attribute", "DashboardProfile").addParam("module", "WES").get().map(res => {
            let response = res.json();
            this.dashBoardProfile = response;
            if (response)
                this._userSectionConfig = JSON.parse(response.value);
            return this.userSectionConfig;
        });
    }

    updateDashboardSetting(newConfig) {
        if (this._userSectionConfig.length === 0) {
            let obj = {
                "applicationModule": "WES",
                "attribute": "DashboardProfile",
                "value": JSON.stringify(newConfig)
            }
            return this.$http.wesContext.url("/api/userpreference").post(obj).map(res => res.json()).subscribe(res => {
                this._userSectionConfig = newConfig;
            });
        }
        else {
            let obj = {
                "id": this.dashBoardProfile.id,
                "applicationModule": "WES",
                "attribute": "DashboardProfile",
                "value": JSON.stringify(newConfig)
            }

            return this.$http.wesContext.url("/api/userpreference/" + this.dashBoardProfile.id).put(obj).map(res => res.json()).subscribe(res => {
                this._userSectionConfig = newConfig;
            });
        }
    }

    reorderSections(newConfig) {
        this.updateDashboardSetting(newConfig);
    }
}