import { GlobalSearchService } from './../globalSearch/services/globalSearch.service';
import { ControlsModule } from '../controls/controls.module';
import { GlobalSearchResult } from '../globalSearch/globalSearchResult.component';
import { searchRouting } from './../globalSearch/globalSearch.routing';
import { FooterComponent } from './components/footer.component';
import { NavComponent } from './components/nav.component';
import { NavBarComponent } from './components/navbar.component';
import { PaginationComponent } from './components/pagination.component';
import { SpinnerComponent } from './components/spinner.component';
import { ClickOutside } from './directives/clickOutside.directive';
import { Globals } from './services/globals.service';
import { ShiftService } from './services/shift.service';
import { AdvanceFilterService } from './services/advanceFilter.service';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { RouterModule } from '@angular/router';
import { ModalModule } from 'ng2-bootstrap/modal';
import { PopoverModule } from 'ng2-bootstrap/popover';
import { NoAccessComponent } from './components/no-access.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    RouterModule,
    HttpModule,
    ControlsModule,
    PopoverModule.forRoot(),
    ModalModule.forRoot(),
    searchRouting,

  ],
  declarations: [
    PaginationComponent,
    SpinnerComponent,
    NavBarComponent,
    NavComponent,
    FooterComponent,
    ClickOutside,
    GlobalSearchResult,
    NoAccessComponent
  ],
  exports: [
    PaginationComponent,
    SpinnerComponent,
    NavBarComponent,
    NavComponent,
    FooterComponent,
    ClickOutside,
    NoAccessComponent
  ],
  providers: [
    Globals,
    ShiftService,
    AdvanceFilterService,
    GlobalSearchService
  ]
})
export class SharedModule { }