import { Injectable } from '@angular/core';
import { HttpService } from 'sensorthink-commoncontrols/src/common.module';

@Injectable()
export class ShiftService {

    constructor(private $http: HttpService) { }

    getAllShift() {
        return this.$http.wesContext.url("/api/shifts").get()
            .map(res => res.json()).toPromise();
    }
}