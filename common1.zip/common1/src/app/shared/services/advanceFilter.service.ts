import { Injectable } from '@angular/core';
import { HttpService } from 'sensorthink-commoncontrols/src/common.module';
declare var moment: any;
@Injectable()
export class AdvanceFilterService {

    constructor(private $http: HttpService) { }

    getAllFilterTaskTypes() {
        return this.$http.wesContext.url("/api/task").get()
            .map(res => res.json()).toPromise();
    }
    getAllFilterExternalBatchIds() {
        return this.$http.wesContext.url("/api/batchId").get()
            .map(res => res.json()).toPromise();
    }
    getAllFilterContainerIds() {
        return this.$http.wesContext.url("/api/containerId").get()
            .map(res => res.json()).toPromise();
    }
    getAllFilterVirtualContainerIds() {
        return this.$http.wesContext.url("/api/virtualcontainerId").get()
            .map(res => res.json()).toPromise();
    }

    saveNewFilters(applicationModule, filterObject, attribute) {
        //API call to save new Filter
        let saveFilterObj = { "applicationModule": applicationModule, "attribute": attribute, "value": JSON.stringify(filterObject) }
        let http = this.$http.wesContext.url("/api/userpreference")
        return http.post(saveFilterObj).map((res) => {
            let obj = res.json();
            return obj;
        });
    }
    updateFilters(moduleName, filterObject) {
        //API call to update existing Filter
        let saveFilterObj = { "applicationModule": moduleName, "attribute": filterObject.saveFilterName.selectedValue, "value": JSON.stringify(filterObject), "id": filterObject.filterId }
        let http = this.$http.wesContext.url("/api/userpreference/" + filterObject.filterId);
        return http.put(saveFilterObj).map((res) => {
            let obj = res.json();
            return obj;
        });
    }
    getLoadSaveFilterData(moduleName, attribute) {
        //API call to get data of existing Filter
        let http = this.$http.wesContext.url("/api/userpreference");
        http.addParam("module", moduleName).addParam("attribute", attribute);
        return http.get().map(res => res.json()).toPromise();
    }
    getAllLoadSaveFilterData(moduleName) {
        //API call to get list of existing Filter
        return this.$http.wesContext.url("/api/userpreference/filters?user=" + 1 + "&module=" + moduleName).get()
            .map(res => res.json()).toPromise();
    }
    setOptionsAsNull(obj) {
        obj.site.options = null;
        obj.shift.options = null;
        obj.containerIds.options = null;
        obj.virtualContainetIds.options = null;
        obj.saveLoadFilter.options = null;
        obj.extBatchContainer.options = null;
        obj.taskType.options = null;
        obj.routeName.options = null;
        obj.messageType.options = null;
        obj.baseMetric.options = null;
        obj.otherMetric.options = null;
        return obj;
    }
    resetFilterObject(filterObject) {
        if (filterObject.priority.from === null) {
            filterObject.priority.from = 1;
            filterObject.priority.to = 100;
        }
        if (filterObject.aging.from === null) {
            filterObject.aging.from = 1;
            filterObject.aging.to = 30;
        }
        if (filterObject.dateRange.from === null) {
            filterObject.dateRange = { isVisible: true };
        }
        return filterObject;
    }
    createFilterObjectFormat(savedFilteObjectArry) {
        let a = [];
        for (var i = 0; i < savedFilteObjectArry.length; i++) {
            let b = savedFilteObjectArry[i].attribute;
            a.push(b);
        }
        return a;
    }
    setDateForFilter(fromDate, toDate){
        toDate = toDate.substring(0,19);
        let dates = [moment(new Date(fromDate)).startOf('day')._d, moment(new Date(toDate)).endOf('day')._d];
        return dates;
    }
}