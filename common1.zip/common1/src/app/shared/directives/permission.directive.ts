import { element } from 'protractor';
import { Directive, ElementRef, HostListener, Input, Output, OnInit } from '@angular/core';
import { AuthPermissionService } from "sensorthink-commoncontrols/src/utils.module";
import { AuthService } from './../../auth/auth.service';
import {LocationStrategy} from '@angular/common';
@Directive({
    selector: '[permission]'
})

export class PermissionDirective {
    private _hasManageKeyWord: boolean = false;
    private _view: boolean = false;
    private _permission= [];
    private _hasMonitorKeyWord: boolean = false;
    private _modulePermission = [];
    @Input() moduleName: string | Array<string>;
    @Input() isMonitor: boolean = false;
    @Input() isMenu: boolean = false;

    constructor(private _el: ElementRef, private _authPermissionService: AuthPermissionService,private _authService: AuthService,private _url:LocationStrategy) { };

    ngOnInit() {
        if (this._authPermissionService.permissions && this._authPermissionService.permissions.length == 0) {            
            this._authPermissionService.setLoggedInUserPermissions(this._authService.userPermissons);
        }
        if (this._authPermissionService.isSuperAdmin()) {
            return true;
        }
        if (this.moduleName instanceof Array) { //Hide tab and sub menu
            for (let mod of this.moduleName) {
                this._modulePermission = this._modulePermission.concat(this._authPermissionService.getWESPermissionByModule(mod));
            }
            this._hasManageKeyWord = this._authPermissionService.canManage(this._modulePermission);
            this._view = this._authPermissionService.canView(this._modulePermission);
            this._hasMonitorKeyWord = this._authPermissionService.canMonitor(this._modulePermission);
            if (!this._hasManageKeyWord && !this._view && !this._hasMonitorKeyWord) {
                this.hide();
            } else if (this._view || this._hasManageKeyWord || this.isMonitor) {
                this.show();
            }
        } else {

            this._modulePermission = this._authPermissionService.getWESPermissionByModule(this.moduleName);
            this._hasManageKeyWord = this._authPermissionService.canManage(this._modulePermission);
            this._hasMonitorKeyWord = this._authPermissionService.canMonitor(this._modulePermission);
            this._view = this._authPermissionService.canView(this._modulePermission);
            this._permission = this._authPermissionService.userWESPermissons;

            if (this.isMenu && !this._view) {
                this.hide(); return;
            }
            if (this._hasManageKeyWord) {
                this.show(); return;
            }
            if (this._hasMonitorKeyWord && this.isMonitor) {
                this.show();return;
            }           
        }
    }
    hide() {
        this._el.nativeElement.style.display = "none";
    };
    show() {
        this._el.nativeElement.style.display = "";
    };
}
