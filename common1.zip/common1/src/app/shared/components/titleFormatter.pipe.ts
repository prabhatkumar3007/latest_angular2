import { Pipe, PipeTransform } from '@angular/core';

/*
 * Changes the case of the first letter of a given number of words in a string.
*/

@Pipe({ name: 'titleFormatter', pure: false })
export class TitleFormatter implements PipeTransform {
    transform(input: string, length: number): string {
        if (input)
            return input.length > 0 ? input.replace(/([a-z])([A-Z])/g, '$1 $2') : '';
        return input;
    }
}