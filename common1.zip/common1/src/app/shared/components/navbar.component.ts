import { AuthService } from '../../auth/auth.service';
import { Globals } from './../services/globals.service';
import { PlatformLocation } from '@angular/common';
import { Component } from '@angular/core';
import { NavigationStart, Router } from '@angular/router';
import { Subject } from 'rxjs/Rx';
import { AuthPermissionService } from 'sensorthink-commoncontrols/src/utils.module';

@Component({
  selector: 'navbar',
  templateUrl: 'navbar.component.html'
})
export class NavBarComponent {
  isHidden: number = 1;
  isExecute: boolean = false;
  imgSrc: string = "../resources/images/operationImg.png";
  isProcessTab: boolean = false;
  isOperationTab: boolean = false;
  isConfigureTab: boolean = false;
  operations: any = ['waves', 'orders', 'batches', 'tasks', 'containers']; //added routing tabs for operations
  process: any = ['picking', 'packing', 'shipping'];
  configure: any = ['iotroute', 'hubroute', 'endroute'];
  canRedirectToIOT: boolean = false;
  searchTxt: any;
  searchModelChanged: Subject<string> = new Subject<string>()

  constructor(private _loginService: AuthService, private _router: Router, pltFormLoc: PlatformLocation, private _authpermissionService: AuthPermissionService) {
    _router.events.subscribe((event) => {
      if (event instanceof NavigationStart) {
        let routeValue = (event.url.split('?'))[0].split('/');
        this.changeRoute(routeValue[1])
      }
    });
    pltFormLoc.onPopState(() => {
      if (pltFormLoc.hash === "#/home") {
        this.executeClick();
      }
    });
    this.canRedirectToIOT = _authpermissionService.hasAccessIOTWebsite();
    this.searchTypeResult();
  }

  changeRoute(routeValue) {
    if (!(this.operations.indexOf(routeValue) == -1))
      this.onTabClick('OPERATIONS');
    else if (!(this.process.indexOf(routeValue) == -1))
      this.onTabClick('PROCESS');
    else
      this.onTabClick(routeValue);
  }

  logout() {
    this._loginService.logout().subscribe(
      data => { },
      err => this.logoutFail(err)
    )
  }

  changed(text: string) {
    this.searchModelChanged.next(text);
  }

  searchTypeResult() {
    this.searchModelChanged
      .debounceTime(500) // wait 300ms after the last event before emitting last event
      .distinctUntilChanged() // only emit if value is different from previous value
      .subscribe(model => {
        if (model.length > 0)
          this._router.navigate(['search-result'], { queryParams: { searchText: model } });
      });
  }

  logoutFail(err: any) {
    console.log(err);
  }

  executeClick(): void {
    this.isExecute = false;
  }
  manageClick(): void {
    this.isExecute = false;
    window.location.href = new Globals().baseApiUrl_Iot;
  }
  onTabClick(value) {
    this.isOperationTab = false;
    this.isProcessTab = false;
    this.isConfigureTab = false;
    switch (value) {
      case "OPERATIONS":
        this.isOperationTab = true;
        break;
      case "PROCESS":
        this.isProcessTab = true;
        break;
      case "CONFIGURE":
        this.isConfigureTab = true;
        break;
      default:
        break;
    }
  }
}