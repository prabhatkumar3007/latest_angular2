import { fakeAsync } from '@angular/core/testing';

import { Injectable } from '@angular/core';
import { CanActivate, Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';

import { AuthService } from './auth.service';
import { AuthPermissionService } from 'sensorthink-commoncontrols/src/utils.module';

@Injectable()
export class AuthGuard implements CanActivate {

  public userPermission: any;
  constructor(private _router: Router, private authService: AuthService, private _authPermissionService: AuthPermissionService) {
    this.userPermission = authService.userPermissons;
  }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    if (this.authService.accessToken) {
      if (this._authPermissionService.isSuperAdmin()) {
        return true;
      }
      let roles = route.data["permission"] as Array<string>;
      let hasAccess = this.checkPermission(roles[0]);
      if (!hasAccess) {
        if (roles[1]) {
          this._router.navigate(['no-access'], { queryParams: { page: roles[1] } });
        } else {
          this._router.navigate(['no-access']);
        }
      }
      return hasAccess;
    } else {
      this._router.navigate(['login']);
      return false;
    }
  }

  checkPermission(moduleName): boolean {
    if (moduleName && moduleName != "") {
      if (this._authPermissionService.permissions && this._authPermissionService.permissions.length == 0) {
        this._authPermissionService.setLoggedInUserPermissions(this.authService.userPermissons);
      }
      if (this._authPermissionService.isSuperAdmin()) {
        return true;
      }
      let permission = this._authPermissionService.getWESPermissionByModule(moduleName);
      if (permission && permission.length > 0) {
        return true;
      }
    }
    return false;
  }

}