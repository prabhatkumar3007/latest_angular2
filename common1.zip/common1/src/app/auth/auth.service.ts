import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/map';
import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import { SessionStorage } from 'sensorthink-commoncontrols/lib/webStore.module';
import { HttpService } from 'sensorthink-commoncontrols/src/common.module';
import { AuthPermissionService } from 'sensorthink-commoncontrols/src/utils.module';

declare let moment: any;

@Injectable()
export class AuthService {
  @SessionStorage() public accessToken: any;
  @SessionStorage() public userInfo: any;

  private tokenChecker: any;

  constructor(public http: Http, public $http: HttpService, public authPermissionService: AuthPermissionService) { }

  get isTokenExpired(): boolean {
    if (!this.accessToken)
      return true;
    let jwt = this.getUserDataFromToken();
    if (jwt.exp < Date.now() / 1000) {
      return true;
    }
    return false;
  }

  getLoginData(userName: string, password: string): Observable<any> {
    let data = {
      "username": userName,
      "password": password
    }

    return this.$http.wesContext.url("/api/auth/login").post(data)
      .map(res => {
        //Login Success
        if (res.status == 200) {
          this.accessToken = res.json();
          let jwt = this.getUserDataFromToken();
          this.authPermissionService.setLoggedInUserPermissions(jwt.scopes);
          this.authPermissionService.setUserPermissionInformation();
          return res.json();
        }
        //Login Failure
        else {
          throw new Error('Login failed: Status - ' + res.status);
        }
      })
  }

  getUserData(): any {
    let jwt = this.getUserDataFromToken();
    this.userInfo = {
      displayName: jwt.firstName + " " + jwt.lastName
    }
  }

  silentAuthentication(): any {
    this.tokenChecker = Observable.interval(60 * 1000).subscribe((x) => {
      let jwt = this.getUserDataFromToken();
      if (jwt.exp <= moment(Date.now()).add({ 'minutes': 5 }) / 1000) {
        this.$http.wesContext.url("/api/auth/jwtoken/").refreshToken().map(res => res.json()).subscribe((res) => {
          let accToken = Object.assign({}, this.accessToken);
          accToken.token = res.token;
          this.accessToken = accToken;
          let jwt = this.getUserDataFromToken();
          this.authPermissionService.setLoggedInUserPermissions(jwt.scopes);
          this.authPermissionService.setUserPermissionInformation();
        });
      }
    });
  }

  resetTokens() {
    this.accessToken = null;
    this.userInfo = null;
    window.sessionStorage.removeItem("angular2ws_accessToken");
    window.sessionStorage.removeItem("angular2ws_userInfo");
  }

  logout(): Observable<any> {
    return this.$http.wesContext.url("/api/auth/logout").get()
      .map(res => {
        //Logout Success
        if (res.status == 200) {
          if (this.tokenChecker)
            this.tokenChecker.unsubscribe();
          return res;
        }
        //Logout Failure
        else {
          throw new Error('Logout failed: Status - ' + res.status);
        }
      })
  }

  getUserDataFromToken(): any {
    if (this.accessToken.token) {
      return JSON.parse(window.atob(this.accessToken.token.split('.')[1]));
    }
  }

  get userPermissons(): any {
    let jwt = this.getUserDataFromToken();
    return jwt.scopes;
  }
}
