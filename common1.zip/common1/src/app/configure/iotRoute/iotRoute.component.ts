import { Component, ViewChild, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ModalDirective } from 'ng2-bootstrap';
import { IotRouteFormComponent, } from './iotRouteForm.component';
import { IotRouteService } from '../services/iotRoute.service';

import { FormControl } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/throttleTime';
import 'rxjs/add/observable/fromEvent';
import { Iot, IotRouteEndPoint } from "app/configure/configure.data";

@Component({
  templateUrl: 'iotRoute.component.html'
})
export class IotRouteComponent implements OnInit {
  public modelTitle: String;
  public submitText: String;
  allRouteData: any;
  loadForm: boolean = false;
  isLoading:boolean = false;
  @ViewChild(IotRouteFormComponent) iotRouteForm: IotRouteFormComponent;
  @ViewChild('iotRouteModal') public iotRouteModal: ModalDirective;

  constructor(private service: IotRouteService) {

  }
  ngOnInit() {
     this.getAllRoutes();
  }
  
  onOpenIotRouteModal(iot?) {
    this.modelTitle = (iot === undefined) ? "CREATE A NEW ROUTE" : "EDIT ROUTE";
    this.submitText = (iot === undefined) ? "Create" : "Save";
    this.loadForm = true;
    //this.iotRouteForm.setIotInfo(iot, this.routeClassData, this.TransformationClassData);
    this.iotRouteModal.show();
  }
  getAllRoutes(){
    this.isLoading = true;
    this.service.getAllRoutes().subscribe((routes) => {
      this.allRouteData = routes;
      this.isLoading = false;
    });
  }
  onSaveIotForm() {
    this.iotRouteForm.save().subscribe(
      res => {
        this.iotRouteForm.iot = new Iot();
        this.iotRouteModal.hide();
        this.getAllRoutes();
      });
  }
  onCancelClick(){
    this.iotRouteModal.hide();
    this.iotRouteForm.iot = new Iot();
  }
}