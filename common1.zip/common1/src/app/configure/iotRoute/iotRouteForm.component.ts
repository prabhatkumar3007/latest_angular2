import { Component, Input, ChangeDetectorRef, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { BasicValidators } from '../../shared/services/basicValidators';
import { Iot, IotRouteEndPointConfig, ConnectionType, IotRouteEndPoint } from '../configure.data';
import { DragulaService } from "ng2-dragula";
import { IotRouteService } from '../services/iotRoute.service';
import { RequestOptions } from "@angular/http/http";

declare let $: any;

@Component({
  selector: 'iotRoute-modal',
  templateUrl: 'iotRouteForm.component.html'
})

export class IotRouteFormComponent implements OnInit {
    selectedFile: EventTarget;
  iotForm: FormGroup;
  title: string;
  isEditMode: boolean = false;
  fromEndPoint: IotRouteEndPoint;
  endPointValues: any;
  fromEndPointOptions: Array<IotRouteEndPoint> = new Array<IotRouteEndPoint>();
  toEndPointOptions: Array<IotRouteEndPoint> = new Array<IotRouteEndPoint>();
  toAddMultipleEndPoint = [{ toEndPointValue: '' }];
  count: number = 0;
  connectonF: any;
  connectonT: any;
  urlFText: any;
  urlTText: any;
  isOutbond: boolean;
  routeClassData: any;
  transformationClassData: any;
  ConnectionTypeData: any;
  myfile = {};
  transformationTypeData = [
    { name: "Delimited" },
    { name: "Fixed width" }
  ];
  iot: Iot = new Iot();

  constructor(private fb: FormBuilder, private dragulaService: DragulaService, private cdr: ChangeDetectorRef, private service: IotRouteService) {
    this.createForm();
    this.myfile = {
      name: 'Upload File'
    }
    this.setDnDOptions()
  }

  createForm() {
    this.iotForm = this.fb.group({
      transformationMapping: [null, Validators.required],
      fromEndPoint: [null, Validators.required],
      routeName: [null, Validators.required],
      connectonF: [null, Validators.required],
      urlFText: [null, Validators.required],
      urlTText: [null, Validators.required],
      connectonT: [null, Validators.required],
      endpoint: [null, Validators.required],
      transformationType: [null, Validators.required],
      name: [null, Validators.required],
      endPointValues: [null, Validators.required],
      direction: [null, Validators.required],
      enableOnStartup: [null, Validators.required],
      enableHeartbeatAck: [null, Validators.required],
      enableAck: [null, Validators.required],
      enableHubDelivery: [null, Validators.required],
      enableHeartbeat: [null, Validators.required],
      enableConnectionRetry: [null, Validators.required],
      source: [null, Validators.required],
      routeClass: [null, Validators.required],
      transformationClass: [null, Validators.required],
      persistMessage: [null, Validators.required],
      active: [null, Validators.required],
      company: [null, Validators.required],
      heartbeatInterval: [null, Validators.required],
      maxRedeliveries: [null, Validators.required],
      connectionRetryDelay: [null, Validators.required],
      redeliveryDelay: [null, Validators.required],
    });
  }

  ngOnInit() {
    this.getAllConnectionType();
    this.getAllRouteClass();
    this.getAllTransformationClass();
  }

  getAllRouteClass() {
    this.service.getRouteClass().subscribe((data) => {
      this.routeClassData = data;
    });
  }
  getAllTransformationClass() {
    this.service.getTransformationClass().subscribe((data) => {
      this.transformationClassData = data;
    });
  }
  getAllCompany() {
    this.service.getAllCompany().subscribe((data) => {

    });
  }

  getAllConnectionType() {
    this.service.getConnectionType().subscribe((data) => {
      this.ConnectionTypeData = data;
      console.log(this.ConnectionTypeData);
    });
  }

  setDnDOptions() {
    try {
      this.dragulaService.setOptions('bag-endpoint', {
        moves: function (el, container, handle) {
          if (handle.className.indexOf)
            return handle.className.indexOf('drag-handle') >= 0;
          return false;
        }
      });
    } catch (error) {
      // Intentionally left blank.
    }
    this.dragulaService.drop.subscribe((value) => {
      this.onDrop(value.slice(1));
    });
  }
  private onDrop(args) {
    let endpoints = [];
    var select = document.getElementsByClassName("toendpoint");
    for (var i = 0; i < select.length - 1; i++) {
      // endpoints.push($(select[i]).val());
    }
  }
  save() {
    var result;
    console.log(this.toAddMultipleEndPoint)
    for (var i = 0; i < this.toAddMultipleEndPoint.length; i++) {
      let temp: any;
      temp = this.toAddMultipleEndPoint[i].toEndPointValue;
      this.iot.endpoint.push(temp);
    }
    this.iot.endpoint.push(this.fromEndPoint);
    result = this.service.addRoute(this.iot)
    return result;
  }

  addToForm(connectionTypeObj: ConnectionType, endpointUrl) {
    let endPointConfig = new IotRouteEndPointConfig(5, endpointUrl, "", connectionTypeObj);
    let endPoint = new IotRouteEndPoint("from", "1", endPointConfig);
    this.fromEndPointOptions.push(endPoint);
    this.connectonF = this.urlFText = '';
  }

  addTo(connectionTypeObj: ConnectionType, endpointUrl) {
    let endPointConfig = new IotRouteEndPointConfig(5, endpointUrl, "", connectionTypeObj);
    let endPoint = new IotRouteEndPoint("to", "1", endPointConfig);
    this.toEndPointOptions.push(endPoint);
    this.connectonT = this.urlTText = '';
  }

  addMultipleToEndPoint() {
    this.toAddMultipleEndPoint.push({ toEndPointValue: '' });
    //this.count++
  }

  deleteMultipleToEndPoint(index) {
    if (this.toAddMultipleEndPoint.length == 1) {
      alert("cannot delete last")
    } else {
      setTimeout(() => {
        console.log(this.toAddMultipleEndPoint.indexOf(index));
        this.toAddMultipleEndPoint.splice(this.toAddMultipleEndPoint.indexOf(index), 1);
        this.cdr.detectChanges();
      }, 1000);
    }
  }

  onChange(event: EventTarget) {
    console.log(event);
    let eventObj: MSInputMethodContext = <MSInputMethodContext>event;
    let target: HTMLInputElement = <HTMLInputElement>eventObj.target;
    let files: FileList = target.files;
    this.myfile = files[0];
    this.selectedFile = event
  }

  upload(event: EventTarget) {
    this.readTextFile(this.selectedFile);
  }


  readTextFile(event) {
    var input = event.target;

    var reader = new FileReader();
    reader.onload = () => {
      var text = reader.result;
      this.iot.transformationMapping = text;
    };
    reader.readAsText(input.files[0]);
  }

  onchangeDirection(val) {
    if (val == "outbound") {
      this.isOutbond = true;
    } else {
      this.isOutbond = false;
    }
  }
}