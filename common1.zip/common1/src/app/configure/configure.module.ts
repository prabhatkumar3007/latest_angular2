import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { ControlsModule } from '../controls/controls.module';
import { SharedModule } from '../shared/shared.module';
import { ModalModule } from 'ng2-bootstrap/modal';
import { PopoverModule } from 'ng2-bootstrap/popover';


import { IotRouteComponent } from './iotRoute/iotRoute.component';
import { IotRouteFormComponent } from './iotRoute/iotRouteForm.component';
import { IotRouteService } from './services/iotRoute.service'



@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule,
    ControlsModule,
    SharedModule,
    ModalModule.forRoot(),
    PopoverModule.forRoot()
  ],
  declarations: [
    IotRouteComponent,
    IotRouteFormComponent
  ],
  exports: [
    IotRouteComponent,
    IotRouteFormComponent
  ],
  providers: [
    IotRouteService
  ]
})
export class ConfigureModule {

}