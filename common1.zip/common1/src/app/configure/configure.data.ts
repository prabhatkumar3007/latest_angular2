
export class Iot {
    routeName: string;
    routeClass: string;
    transformationType: string;
    transformationClass: any;
    transformationMapping: any;
    direction: string;
    persistMessage: boolean = false;
    enableOnStartup: boolean = false;
    active: boolean = false;
    healthStatus: string;
    company: Company;
    createdTime: string
    modifiedTime: string;
    createdByID: string;
    modifiedByID: string;
    enableHeartbeat: boolean = false;
    heartbeatInterval: string;
    enableAck: boolean = false;
    enableHeartbeatAck: boolean = false
    enableConnectionRetry: boolean = false;
    maxRedeliveries: number;
    redeliveryDelay: number;
    connectionRetryDelay: number;
    enableHubDelivery: boolean = false;
    source: string;
    endpoint: Array<IotRouteEndPoint> = new Array<IotRouteEndPoint>();
}

export class IotRouteEndPoint {
    direction: string;
    endpointSequence: string;
    endpointConfig: IotRouteEndPointConfig;
    constructor(direction: string, endpointSequence: string, endpointConfig: IotRouteEndPointConfig) {
        this.direction = direction;
        this.endpointSequence = endpointSequence;
        this.endpointConfig = endpointConfig;
    }

}
export class IotRouteEndPointConfig {
    endpointConfigId: number;
    endpointUrl: string;
    endpointParams: string;
    connectionType: ConnectionType;

    constructor(endpointConfigId: number, endpointUrl: string, endpointParams: string, connectionType: ConnectionType) {
        this.endpointConfigId = endpointConfigId;
        this.endpointUrl = endpointUrl;
        this.connectionType = connectionType;
        this.endpointParams = endpointParams;
    }
}
export class ConnectionType {
    connectionTypeId: number;
    name: string;
    description: string

    constructor(connectionTypeId: number, name: string, description: string) {
        this.connectionTypeId = connectionTypeId;
        this.name = name;
        this.description = description;
    }
}
export class Company {
    companyId: number;
    name: string;
    shortName: string;
    code: string;
    companyURL: string;
    type: number;
    status: number;
    createdTime: string;
    modifiedTime: string;
    country: string;
    language: string;
    variant: string;
    dateFormat: string;
    timeZone: string;
    parentCompanyId: number;
}
