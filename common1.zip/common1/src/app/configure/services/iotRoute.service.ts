import 'rxjs/add/operator/map';
import { Injectable } from '@angular/core';
import { HttpService } from 'sensorthink-commoncontrols/src/common.module';

@Injectable()
export class IotRouteService {

    constructor(private $http: HttpService) {
    }

    getConnectionType() {
        return this.$http.iotContext.url("/api/routes/connectiontype").get()
            .map(res => res.json());
    }
    getRouteClass() {
        return this.$http.iotContext.url("/api/routes/routeclass").get()
            .map(res => res.json());
    }
    getTransformationClass() {
        return this.$http.iotContext.url("/api/routes/transformationclass").get()
            .map(res => res.json());
    }
    getAllCompany() {
        return this.$http.iotContext.url("/api/routes/connectiontype").get()
            .map(res => res.json());
    }
    addRoute(iotRoute) {
        var data = JSON.stringify(iotRoute);
        return this.$http.iotContext.url("/api/routes/create").post(data)
            .map(res => res.json());
    }
    getAllRoutes() {
        return this.$http.iotContext.url("/api/routes/").get()
            .map(res =>
                res.json()
            );
    }
}
