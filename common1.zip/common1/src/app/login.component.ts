import { AuthService } from './auth/auth.service';
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { NotyService } from 'sensorthink-commoncontrols/src/services/noty.service';
import { HttpService } from 'sensorthink-commoncontrols/src/common.module';

@Component({
  moduleId: 'module.id',
  templateUrl: 'loginPage.component.html'
})
export class LoginComponent {
  private ErrorMsg: string;
  public ErrorMessageIsVisible: boolean;
  public accessToken: string;

  constructor(private service: AuthService, private routes: Router, private _http: HttpService, private noty: NotyService) { }

  login(userName: string, password: string) {
    this.noty.closeAll();
    this.service.getLoginData(userName, password).subscribe(
      data => this.loginSucess(data),
      err => this.loginFail(err),
      () => console.log('Authentication Complete'),
    );
  }

  loginSucess(data: any) {
    this.accessToken = this.service.accessToken;
    this.service.getUserData();
    this.routes.navigate(['home']);
  }

  loginFail(err: any) {
    this.noty.error("Invalid username or password.");
  }

  hideErrorMsg() {
    this.ErrorMessageIsVisible = false;
  }
}
