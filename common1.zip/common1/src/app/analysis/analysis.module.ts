import { NgModule } from '@angular/core';

import { AnalysisComponent } from './analysis.component';

@NgModule({
  declarations: [
    AnalysisComponent
  ],
  exports: [
    AnalysisComponent
  ]
})
export class AanalysisModule {
}