import { Component } from '@angular/core';
import { Router, NavigationStart } from '@angular/router';
import { AuthService } from './auth/auth.service';

declare let $: any;

@Component({
  selector: 'app-root',
  template: `
      <div *ngIf="accessToken">
        <navbar-new></navbar-new>
       
      </div>
      <router-outlet></router-outlet>
      <footer-all></footer-all>
  `
})
export class AppComponent {
  showStyle: boolean = false;
  accessToken: string;
  constructor(private service: AuthService, private router: Router) {
    this.cleanUpOnRouteChange();
    this.onBackButtonClick();
  }
  onBackButtonClick() {
    window.onhashchange = function (event) {
      if (window.location.hash === '#/login'){
        window.location.hash = "/home";
      }
    };
  }
  //clean up datepicker and tooltip elements from html.
  cleanUpOnRouteChange() {
    this.router.events.subscribe((val) => {
      if (val instanceof NavigationStart) {
        this.accessToken = this.service.accessToken;
        $("#datepickers-container").empty();
        $(".nvtooltip").remove();

        if (this.service.isTokenExpired && val.url != "/login") {
          this.service.resetTokens();
          this.router.navigate(['login']);
        }
      }
    });
  }

  getStyle() {
    if (this.showStyle) {
      return "yellow";
    } else {
      return "";
    }
  }
}