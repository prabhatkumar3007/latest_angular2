import { Injectable } from '@angular/core';
import { HttpService } from 'sensorthink-commoncontrols/src/common.module';

declare let moment: any;

@Injectable()
export class GlobalSearchService {
    linkMap: any = {
        ActiveWave: ["waves", "waveId", "?"],
        HistoryWave: ["waves", "waveId"],
        ActiveOrder: ["orders", "orderId"],
        HistoryOrder: ["orders", "orderId"],
        ActiveOrderLine: ["orders", "orderId"],
        HistoryOrderLine: ["orders", "orderId"],
        ActiveContainer: ["containers", "containerId"],
        HistoryContainer: ["containers", "containerId"]
    }

    titleMap: any = {
        ActiveWave: "waves",
        HistoryWave: "waves",
        ActiveOrder: "orders",
        HistoryOrder: "orders",
        ActiveOrderLine: "order line",
        ActiveContainer: "containers",
        HistoryContainer: "containers",
        HistoryOrderLine: "order line"
    }

    constructor(private http: HttpService) { }

    search(searchText: string, pagerConfig: any) {
        return this.http.wesContext.url("/api/search").addParam("searchText", searchText).addParam("pageNumber", pagerConfig.currentPage)
            .addParam("pageSize", pagerConfig.itemsPerPage).get().map(res => {
                let data = res.json();
                if (data)
                    data.content = this.parseResult(data.content);
                return data;
            });
    }

    parseResult(srchData) {
        let result = [];
        srchData.forEach(el => {
            let obj = {
                title: "Operations :: " + this.getTitle(el.entityType),
                link: this.getLinkPath(el),
                data: this.getParsedDetailData(el)
            }
            result.push(obj);
        });
        return result;
    }

    getTitle(entityType) {
        let res = this.titleMap[entityType]
        return res;
    }
    getLinkPath(obj) {
        let res = this.linkMap[obj.entityType]
        if (res) {
            if (res.length === 2)
                return "#/" + res[0] + "/" + obj[res[1]];
            else if (res.length === 3) {
                return "#/" + res[0] + res[2] + "waveId=" + obj[res[1]];
            }
        }
    }

    splitCamelCase(source) {
        return source.match(/([A-Z]?[^A-Z]*)/g).slice(0, -1).join(" ")
    }

    getParsedDetailData(obj) {
        let excludedProps = ["companyId", "parentCompanyId", "virtualContainerId", "modifiedSource", "id", "entityType", "action"];
        let finalStr = "";
        let val = "";
        for (let key of Object.keys(obj)) {
            if (excludedProps.indexOf(key) === -1) {
                if (typeof (obj[key]) !== 'object') {
                    if (key.indexOf("Time") >= 0)
                        val = moment(obj[key]).format("MM/DD/YYYY")
                    else
                        val = obj[key];

                    finalStr += this.splitCamelCase(key) + " " + (val == "Invalid date" ? obj[key] : val) + ", ";
                }
            }
        }

        return finalStr.substr(0, finalStr.length - 2);
    }
}