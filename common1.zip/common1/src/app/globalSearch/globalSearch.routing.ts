import { AuthGuard } from './../auth/auth-guard.service';
import { GlobalSearchResult } from './globalSearchResult.component';
import { Router, RouterModule } from '@angular/router';

export const searchRouting = RouterModule.forChild([
  { path: 'search-result', component: GlobalSearchResult, canActivate: [AuthGuard], data: { permission: ['all','any pages'] } },
]);