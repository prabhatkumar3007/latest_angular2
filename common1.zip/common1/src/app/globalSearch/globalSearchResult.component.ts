import { GlobalSearchService } from './services/globalSearch.service';
import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
@Component({
  templateUrl: 'globalSearchResult.template.html'
})

export class GlobalSearchResult {
  isLoading: boolean = false;
  searchResult: any = [];
  searchText: any;
  pagerConfig: {
    totalItems: any;
    currentPage: any;
    itemsPerPage: any;
  };

  constructor(private service: GlobalSearchService, private route: ActivatedRoute) {
    this.setPagerConfig(0, 1, 10);
  }

  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      this.searchText = params['searchText']
      this.loadResults();
    });
  }

  loadResults() {
    this.isLoading = true;
    this.service.search(this.searchText, this.pagerConfig).subscribe((res) => {
      if (res) {
        this.setPagerConfig(res.totalElements, (res.number + 1), res.size)
        this.searchResult = res.content;
      }
      else
        this.searchResult = []
      this.isLoading = false;
    }, err => {
      this.isLoading = false;
    });
  }

  setPagerConfig(totalItems, currentPage?, itemsPerPage?) {
    this.pagerConfig = JSON.parse(JSON.stringify({
      totalItems: totalItems,
      currentPage: currentPage || 1,
      itemsPerPage: itemsPerPage || 10,
    }));
  }


  onPageSizeChanged(p) {
    this.pagerConfig.itemsPerPage = p;
    this.loadResults();
  }

  onPageChanged(pageObj) {
    this.pagerConfig.currentPage = pageObj.page;
    this.loadResults();
  }

}