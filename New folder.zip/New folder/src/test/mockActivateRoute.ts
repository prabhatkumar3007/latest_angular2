import { ActivatedRoute, Router, UrlSegment } from '@angular/router';
import { Observable } from 'rxjs/Observable';
export class MockActivatedRoute extends ActivatedRoute {
  constructor() {
    super();
    this.queryParams = Observable.of({ status: "exception" });
  }
}
export class MockActivatedRouteById extends ActivatedRoute {
  constructor() {
    super();
    this.params = Observable.of({ id: 1 });
    this.url = Observable.of([new UrlSegment('api',null), new UrlSegment('orders',null)]);
  }
}