import { AppComponent } from './app.component';
import { AuthGuard } from './auth/auth-guard.service';
import { AuthService } from './auth/auth.service';
import { BrowserModule } from '@angular/platform-browser';
import { DashboardModule } from './dashboard/dashboard.module';
import { FormsModule } from '@angular/forms';
import { HomeComponent } from './homePage.component';
import { HttpService } from './shared/services/http.service';
import { LoginComponent } from './login.component';
import { NgModule } from '@angular/core';
import { NotFoundComponent } from './shared/components/not-found.component';
import { NotyService } from './shared/services/noty.service';
import { ConfigureModule } from './configure/configure.module';

import { configureRouting } from './configure/configure.routing';
import { PreventUnsavedChangesGuard } from './shared/services/prevent-unsaved-changes-guard.service';
import { routing } from './app.routing';
import { SharedModule } from './shared/shared.module';
import { WebStorageModule, LocalStorageService } from 'sensorthink-commoncontrols/lib/webStore.module';

@NgModule({
  imports: [
    BrowserModule,
    FormsModule,
    SharedModule,
    ConfigureModule,
    DashboardModule,
    configureRouting,
    routing,
    WebStorageModule,
  ],
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    NotFoundComponent,
  ],
  providers: [AuthService, AuthGuard, PreventUnsavedChangesGuard, HttpService, NotyService, LocalStorageService],
  bootstrap: [AppComponent]
})
export class AppModule { }