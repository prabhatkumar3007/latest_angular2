import { IotRouteComponent } from './configure/iotRoute/iotRoute.component';
import { EndPointComponent } from './configure/endPoint/endPoint.component'
import { Router, RouterModule } from '@angular/router';

import { LoginComponent } from './login.component';
import { HomeComponent } from './homePage.component';
import { NotFoundComponent } from './shared/components/not-found.component';
import { DashboardComponent } from './dashboard/dashboard.component';

import { AuthGuard } from './auth/auth-guard.service';
import { PreventUnsavedChangesGuard } from './shared/services/prevent-unsaved-changes-guard.service';

export const routing = RouterModule.forRoot([
  { path: '', component: DashboardComponent, canActivate: [AuthGuard] },
  { path: 'login', component: LoginComponent },
  { path: 'home', component: DashboardComponent, canActivate: [AuthGuard] },
  { path: 'iot-route', component: IotRouteComponent, canActivate: [AuthGuard] },
  { path: 'end-route', component: EndPointComponent, canActivate: [AuthGuard] },
  { path: 'not-found', component: NotFoundComponent },
  { path: '**', redirectTo: 'not-found' }
], { useHash: true });