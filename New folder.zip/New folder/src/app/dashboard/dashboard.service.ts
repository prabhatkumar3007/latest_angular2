import { Injectable } from '@angular/core'

@Injectable()
export class DashboardService {
    private _userSectionConfig: any;
    get userSectionConfig(): any {
        if (!this._userSectionConfig)
            return [
                {
                    name: "work-queue-summary",
                    order: 1
                },
                {
                    name: "process-rate",
                    order: 2
                },
                {
                    name: "order-picked-shipped",
                    order: 3
                },
                {
                    name: "top-10",
                    order: 4
                }
            ];
        else
            return this._userSectionConfig;
    }

    constructor() { }

    reorderSections(newConfig) {
        this._userSectionConfig = newConfig;
    }
}