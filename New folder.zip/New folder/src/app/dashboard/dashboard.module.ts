import { DashboardService } from './dashboard.service';
import { AccordionModule } from 'ng2-bootstrap/accordion';
import { CommonModule } from '@angular/common';
import { ControlsModule } from '../controls/controls.module';
import { DashboardComponent } from './dashboard.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { KeysPipe } from '../shared/components/objectKeyFilter.pipe';
import { NgModule } from '@angular/core';
import { PaginationModule } from 'ng2-bootstrap/ng2-bootstrap';
import { PopoverModule } from 'ng2-bootstrap/popover';
import { RouterModule } from '@angular/router';
import { SharedModule } from '../shared/shared.module';
import { TabsModule } from 'ng2-bootstrap';
import { TitleCase } from '../shared/components/camelCaseFilter.pipe';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule,
    HttpModule,
    AccordionModule.forRoot(),
    PaginationModule,
    TabsModule,
    ControlsModule,
    PopoverModule,
    SharedModule
  ],
  declarations: [
    DashboardComponent,
    KeysPipe,
    TitleCase,
  ],
  exports: [
    DashboardComponent,
    KeysPipe,
    TitleCase,
  ],
  providers: [
    DashboardService
  ]
})
export class DashboardModule {
}