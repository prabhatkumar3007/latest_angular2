import { DashboardService } from './dashboard.service';
import {
  Component,
  OnInit
} from '@angular/core';
import { DragulaService } from "ng2-dragula";
declare var moment: any

@Component({
  templateUrl: 'dashboard.component.html'

})
export class DashboardComponent {
  datePickerConfig: any;
  dashBoardSettingConfig;

  constructor(private service: DashboardService, private dragulaService: DragulaService) {
    this.datePickerConfig = {
      maxDate: new Date(),
      minDate: moment(new Date()).subtract(1, 'M')._d
    };
    this.setDnDOptions();
    this.dashBoardSettingConfig = this.service.userSectionConfig;

  }

  ngOnInit() {
    this.sortArray(this.dashBoardSettingConfig, "order");
  }

  setDnDOptions() {
    try {
      this.dragulaService.setOptions('bag-one', {
        moves: function (el, container, handle) {
          if (handle.className.indexOf)
            return handle.className.indexOf('drag-handle') >= 0;
          return false;
        }
      });
    } catch (error) {
      // Intentionally left blank.
    }

    this.dragulaService.drop.subscribe((value) => {
      this.onDrop(value.slice(1));
    });
  }

  private onDrop(args) {
    let [el, target, source] = args;
    let config = JSON.parse(JSON.stringify(this.dashBoardSettingConfig));
    var list = document.getElementsByClassName("section");
    for (var i = 0; i < list.length - 1; i++) {
      let section = config.filter((s) => {
        if (s.name === list[i].id)
          return s;
      })

      section[0].order = i + 1;
    }
    this.service.reorderSections(config);
  }

  private getElementFromCollection(el, value) {
    for (var index = 0; index < el.parentElement.children.length; index++) {
      var element = el.parentElement.children[index];
      if (element.id && value === element.id)
        return element
    }
  }

  private sortArray(arr, field) {
    arr.sort(function (a, b) {
      return parseFloat(a[field]) - parseFloat(b[field]);
    });
  }
}


