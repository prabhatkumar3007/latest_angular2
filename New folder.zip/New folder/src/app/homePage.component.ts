import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'home',
  template: `
    <h1>Home Page</h1>
  `
})
export class HomeComponent {
}