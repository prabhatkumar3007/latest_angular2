import { ChartModule } from 'sensorthink-commoncontrols/src/chart.module';
import { CommonModule } from '@angular/common';
import { DragulaModule } from 'ng2-dragula';
import { FormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { NvD3Module } from 'angular2-nvd3';
import { PaginationModule } from 'ng2-bootstrap/pagination';
import { PopoverModule } from 'ng2-bootstrap/popover';
import { SensorThinkControlsModule } from 'sensorthink-commoncontrols/src/controls.module';
import { TabsModule } from 'ng2-bootstrap/tabs';
import { TooltipModule } from 'ng2-bootstrap/tooltip';


@NgModule({
  imports: [
    FormsModule,
    CommonModule,
    PopoverModule.forRoot(),
    PaginationModule.forRoot(),
    TooltipModule.forRoot(),
    TabsModule.forRoot(),
    NvD3Module
  ],
  declarations: [],
  exports: [
    DragulaModule,
    ChartModule,
    SensorThinkControlsModule
  ]
})
export class ControlsModule {
}