import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { HttpModule } from '@angular/http';
import { PopoverModule } from 'ng2-bootstrap/popover';
import { ModalModule } from 'ng2-bootstrap/modal';

import { ControlsModule } from '../controls/controls.module';

import { PaginationComponent } from './components/pagination.component';
import { SpinnerComponent } from './components/spinner.component';
import { NavBarComponent } from './components/navbar.component';
import { NavComponent } from './components/nav.component';
import { FooterComponent } from './components/footer.component';
import { AlertService } from '../alerts/alert.service'
import { AlertDetailComponent } from '../alerts/alertDetail.component'
import { ViewAllComponent } from './components/viewAll.component';
import { DatePipe } from './components/dateFormater.pipe';
import { ShareDataService } from './services/shareDataService'
import { Globals } from './services/globals.service';
import { ClickOutside } from './directives/clickOutside.directive'

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    RouterModule,
    HttpModule,
    ControlsModule,
    PopoverModule.forRoot(),
    ModalModule.forRoot()
  ],
  declarations: [
    PaginationComponent,
    SpinnerComponent,
    NavBarComponent,
    NavComponent,
    FooterComponent,
    AlertDetailComponent,
    ViewAllComponent,
    DatePipe,
    ClickOutside
  ],
  exports: [
    PaginationComponent,
    SpinnerComponent,
    NavBarComponent,
    NavComponent,
    FooterComponent,
    AlertDetailComponent,
    ViewAllComponent,
    DatePipe,
    ClickOutside
  ],
  providers: [
    AlertService,
    ShareDataService,
    Globals
  ]
})
export class SharedModule { }