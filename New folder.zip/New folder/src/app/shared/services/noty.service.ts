import { Injectable } from '@angular/core';
declare var $: any
declare var noty: any

@Injectable()
export class NotyService {
    config: any = {
        theme: "bootstrapTheme",
        layout: "topCenter",
        animation: {
            open: "animated flipInX", // Animate.css class names
            close: "animated flipOutX", // Animate.css class names
        },
        closeWith: ["click"],
        timeout: 10000,
        killer: true
    }

    private defaultMessage: string = "Error occured, Please contact Administrator.";

    success(message: string) {
        let settings = Object.assign({}, this.config);
        settings.type = 'success'
        settings.text = '<i class="glyphicon glyphicon-ok-sign" aria-hidden="true"></i>&nbsp;&nbsp;' + message;
        this.closeAll();
        var n = noty(settings)
    }

    error(message: string | any) {
        let errMessage = Object.assign({}, this.defaultMessage);
        if (typeof (message) === "object") {
            if (message.status === 401) {
                errMessage = "Your session has expired. Please re-login.";
            }
            else if (message.status === 404) {
                errMessage = errMessage;
            }
        }
        else
            errMessage = message;
        let settings = Object.assign({}, this.config);
        settings.type = 'error'
        settings.text = '<i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;&nbsp;' + errMessage;
        this.closeAll();
        var n = noty(settings)
    }

    warning(message: string) {
        let settings = Object.assign({}, this.config);
        settings.type = 'warning'
        settings.text = '<i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;&nbsp;' + message;
        this.closeAll();
        var n = noty(settings)
    }

    closeAll() {
        $.noty.clearQueue(); // Clears the notification queue
        $.noty.closeAll(); // Close all notifications
    }
}