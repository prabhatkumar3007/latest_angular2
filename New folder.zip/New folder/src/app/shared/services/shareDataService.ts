import { Injectable } from '@angular/core'
@Injectable()
export class ShareDataService {
    fDate: string;
    tDate: string;
    objectStore: any = {}

    setDate(f, t) {
        this.fDate = f;
        this.tDate = t;
    }

    getDate() {
        let date = [];
        date.push(this.fDate, this.tDate)
        return date;
    }
}