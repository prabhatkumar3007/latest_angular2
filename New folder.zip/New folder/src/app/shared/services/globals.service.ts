import { Injectable } from '@angular/core';
import config from '../../../config.json';


Injectable()
export class Globals {
    baseApiUrl_Wes = config.baseUrl_Wes;
    baseApiUrl_Iot = config.baseUrl_Iot;
}