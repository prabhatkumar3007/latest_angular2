import { Component, ChangeDetectorRef } from '@angular/core';
import { AlertService } from '../../alerts/alert.service';
import { ShareDataService } from '../services/shareDataService';

declare var $: any
declare var moment: any

@Component({
  selector: 'view-all-modal',
  templateUrl: 'viewAll.component.html',
  styles: [`
  .dataTableLayout {
      table-layout:fixed;
    width:100%;
    }`]
})
export class ViewAllComponent {
  public alertViewAllData: any;
  public prioritySelected: string;
  public markAsReadList = [];
  public onCheckBoxChecked: any;
  public datePickerConfig: any;
  public dataTableConfig: any;
  public sortArgs: string;
  public fromDate: any;
  public toDate: any;
  public isModalShown: boolean = false;


  constructor(private alertService: AlertService, private _cdr: ChangeDetectorRef, private setDate: ShareDataService) {
    this.onCheckBoxChecked = this.onChecked.bind(this);
    this.datePickerConfig = {
      maxDate: new Date(),
      minDate: moment(new Date()).subtract(1, 'M')._d
    };

    this.dataTableConfig = {
      "createdRow": (row, data, dataIndex) => {
        if (!data["isRead"]) {
          $(row).addClass('alert-unread');
        }
      }
    }
    this.sortArgs = "createdTime,desc";
    this.prioritySelected = 'High';
  }
  ngAfterViewInit() {
    this._cdr.detectChanges();
  }

  onChecked(dataContext) {
    if (this.markAsReadList.indexOf(dataContext) > -1) {
      this.markAsReadList.splice(dataContext, 1);
    } else {
      this.markAsReadList.push(dataContext);
    }
  }

  markAsRead() {
    this.markAsReadList.forEach((alert) => {
      this.alertService.markAsRead(alert.id).subscribe((res) => {
        alert.isRead = true;
        this.viewAllData(this.prioritySelected, this.sortArgs, this.fromDate, this.toDate);
      });
    });
  }

  priorityChange(value) {
    this.viewAllData(value, this.sortArgs, this.fromDate, this.toDate);
  }
  viewAllData(section, sortArgs?: any, fromDate?: any, toDate?: any) {
    this.alertViewAllData = null;
    this.prioritySelected = section;
    switch (section) {
      case 'High':
        this.alertService.getHighAlertNotifications(sortArgs, fromDate, toDate, false).subscribe(alerts => {
          this.alertViewAllData = alerts
        });

        break;

      case 'Medium':
        this.alertService.getMediumAlertNotifications(sortArgs, fromDate, toDate, false, ).subscribe(alerts =>
          this.alertViewAllData = alerts
        );
        break;

      case 'Low':
        this.alertService.getLowAlertNotifications(sortArgs, fromDate, toDate, false).subscribe(alerts =>
          this.alertViewAllData = alerts
        );
        break;

    }
  }
  viewAllCallback(date) {
    if (date) {
      if (date && date.dates.length <= 1) {
        this.fromDate = moment(date.dates[0]).format("MMDDYYYY 00:00:00");
        this.toDate = moment(date.dates[0]).format("MMDDYYYY 23:59:59");
      }
      else {
        this.fromDate = moment(date.dates[0]).format("MMDDYYYY 00:00:00");
        this.toDate = moment(date.dates[1]).format("MMDDYYYY 23:59:59");
      }
      if (this.isModalShown) {
        this.setDate.setDate(this.fromDate, this.toDate);
        this.viewAllData(this.prioritySelected, this.sortArgs, this.fromDate, this.toDate);
      }

    }

  }

  onSortChanged(sortArgs) {
    this.sortArgs = sortArgs[0] + "," + sortArgs[1];
    this.viewAllData(this.prioritySelected, this.sortArgs, this.fromDate, this.toDate);
  }
}