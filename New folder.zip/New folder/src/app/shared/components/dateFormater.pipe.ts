import { Pipe, PipeTransform } from '@angular/core'
import * as moment from 'moment'

@Pipe({
   name: 'formatDate'
})
export class DatePipe implements PipeTransform {
   transform(date: any, args?: any): any {
     let d = new Date(date)
     let formatedDate = moment(d).format(args) || moment(d).format('MM/DD/YYYY')
     return formatedDate;

   }
}