import { Component } from '@angular/core';

@Component({
    selector: 'footer-all',
    templateUrl: 'footer.component.html'
})
export class FooterComponent {

}