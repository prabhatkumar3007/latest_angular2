import { Component, Input } from '@angular/core';

@Component({
    selector: 'spinner',
    template: `
      <div *ngIf="visible" class="overlay text_align_center"><i  class="fa fa-refresh fa-spin fa-3x fa-fw"></i></div>
    `,
    styles: [`
    .overlay {
            top: 1px;
            width: 97%;
            height: 95%;
            background: white;
            opacity: 0.6;
            position: absolute;
            left: 19px;
            margin-right: 5px;
            z-index: 1;
        }

    .overlay i {
        position: relative;
        top: 41%;
    }
  `],
})
export class SpinnerComponent {
    @Input() visible = false;
}