import { Headers, Http, URLSearchParams } from '@angular/http';
import { HttpService } from '../shared/services/http.service';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { SessionStorage } from 'sensorthink-commoncontrols/lib/webStore.module';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

declare let moment: any;

@Injectable()
export class AuthService {
  @SessionStorage() public accessToken: any;
  @SessionStorage() public userInfo: any;

  private tokenChecker: any;

  constructor(public http: Http, public $http: HttpService) { }

  get isTokenExpired(): boolean {
    if (!this.accessToken)
      return true;
    let jwt = JSON.parse(window.atob(this.accessToken.token.split('.')[1]));
    if (jwt.exp < Date.now() / 1000) {
      return true;
    }
    return false;
  }

  getLoginData(userName: string, password: string): Observable<any> {
    let data = {
      "username": userName,
      "password": password
    }

    return this.$http.wesContext.url("/api/auth/login").post(data)
      .map(res => {
        //Login Success
        if (res.status == 200) {
          this.accessToken = res.json();
          return res.json();
        }
        //Login Failure
        else {
          throw new Error('Login failed: Status - ' + res.status);
        }
      })
  }

  getUserData(): any {
    let jwt = JSON.parse(window.atob(this.accessToken.token.split('.')[1]));
    this.userInfo = {
      displayName: jwt.firstName + " " + jwt.lastName,
      userId:jwt.userId
    }
  }

  silentAuthentication(): any {
    this.tokenChecker = Observable.interval(60 * 1000).subscribe((x) => {
      let jwt = JSON.parse(window.atob(this.accessToken.token.split('.')[1]));
      if (jwt.exp <= moment(Date.now()).add({ 'minutes': 5 }) / 1000) {
        this.$http.wesContext.url("/api/auth/jwtoken/").refreshToken().map(res => res.json()).subscribe((res) => {
          let accToken = Object.assign({}, this.accessToken);
          accToken.token = res.token;
          this.accessToken = accToken;
        });
      }
    });
  }

  resetTokens() {
    this.accessToken = null;
    this.userInfo = null;
    window.sessionStorage.removeItem("angular2ws_accessToken");
    window.sessionStorage.removeItem("angular2ws_userInfo");
  }

  logout(): Observable<any> {
    return this.$http.wesContext.url("/api/auth/logout").get()
      .map(res => {
        //Logout Success
        if (res.status == 200) {
          if (this.tokenChecker)
            this.tokenChecker.unsubscribe();
          return res;
        }
        //Logout Failure
        else {
          throw new Error('Logout failed: Status - ' + res.status);
        }
      })
  }
}
