import { CommonModule } from '@angular/common';
import { ControlsModule } from '../controls/controls.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { IotRouteComponent } from './iotRoute/iotRoute.component';
import { IotRouteFormComponent } from './iotRoute/iotRouteForm.component';
import { EndPointComponent } from './endPoint/endPoint.component'
import { EndPointFormComponent } from './endPoint/endpointForm.component'
import { IotRouteService } from './services/iotRoute.service';
import { ModalModule } from 'ng2-bootstrap/modal';
import { NgModule } from '@angular/core';
import { PopoverModule } from 'ng2-bootstrap/popover';
import { RouterModule } from '@angular/router';
import { SharedModule } from '../shared/shared.module';
import { CommonUtilsModule } from 'sensorthink-commoncontrols/src/utils.module'


@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule,
    ControlsModule,
    SharedModule,
    ModalModule.forRoot(),
    PopoverModule.forRoot()
  ],
  declarations: [
    IotRouteComponent,
    IotRouteFormComponent,
    EndPointComponent,
    EndPointFormComponent
  ],
  exports: [
    CommonUtilsModule,
    IotRouteComponent,
    IotRouteFormComponent,
    EndPointComponent,
    EndPointFormComponent
  ],
  providers: [
    IotRouteService
  ]
})
export class ConfigureModule {

}