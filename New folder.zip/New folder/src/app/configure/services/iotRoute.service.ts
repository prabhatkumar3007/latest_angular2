import { BasicValidators } from '../../shared/services/basicValidators';
import { HttpService } from '../../shared/services/http.service';
import { Injectable } from '@angular/core';
import { Validators } from '@angular/forms';
import 'rxjs/add/operator/map';
import { IotRoute } from "app/configure/configure.data";

@Injectable()
export class IotRouteService {
public selectedRoute:IotRoute;
    constructor(private $http: HttpService) {

    }

    initializeFormObject(fb) {
        return fb.group({
            transformationMapping: [null, Validators.required],
            fromEndPoint: [null, Validators.required],
            routeName: [null, Validators.required],
            connectonF: [null, Validators.required],
            urlFText: [null, Validators.required],
            urlTText: [null, Validators.required],
            connectonT: [null, Validators.required],
            endpoint: [null, Validators.required],
            transformationType: [null, Validators.required],
            name: [null, Validators.required],
            endPointValues: [null, Validators.required],
            direction: [null, Validators.required],
            enableOnStartup: [null, Validators.required],
            enableHeartbeatAck: [null, Validators.required],
            enableAck: [null, Validators.required],
            enableHubDelivery: [null, Validators.required],
            enableHeartbeat: [null, Validators.required],
            enableConnectionRetry: [null, Validators.required],
            source: [null, Validators.required],
            routeClass: [null, Validators.required],
            allCompany: [null, Validators.required],
            transformationClass: [null, Validators.required],
            persistMessage: [null, Validators.required],
            active: [null, Validators.required],
            modifiedBy: [{value: '', disabled: true}],
            modifiedTime: [{value: '', disabled: true}],
            createdTime: [{value: '', disabled: true}],
            createdBy: [{value: '', disabled: true}],
            company: [null, Validators.required],
            heartbeatInterval: [null, Validators.required],
            maxRedeliveries: [null, Validators.required],
            connectionRetryDelay: [null, Validators.required],
            redeliveryDelay: [null, Validators.required],
        });
    }
    initializeEndPointFormObject(fb) {
        return fb.group({
            endPointUrlFText: [null, Validators.required],
            companyId: [null, Validators.required],
            endPointConnecton: [null, Validators.required],
            discriptionEndPoint: [null, Validators.required],
        });
    }
    getConnectionType() {
        return this.$http.iotContext.url("/api/routes/connectiontype").get()
            .map(res => res.json());
    }
    getRouteClass() {
        return this.$http.iotContext.url("/api/routes/routeclass").get()
            .map(res => res.json());
    }
    getTransformationClass() {
        return this.$http.iotContext.url("/api/routes/transformationclass").get()
            .map(res => res.json());
    }
    getAllCompany() {
        return this.$http.iotContext.url("/api/company/").addParam("userId", 2).get()
            .map(res => res.json());
    }
    addRoute(iotRoute) {
        var data = JSON.stringify(iotRoute);
        return this.$http.iotContext.url("/api/routes/create").post(data)
            .map(res => res.json());
    }
    addEndPoint(iotRoute) {
        var data = JSON.stringify(iotRoute);
        return this.$http.iotContext.url("/api/routes/create").post(data)
            .map(res => res.json());
    }
    getAllRoutes(pageNumber?: number, pageSize?: number, sortArgs?: string, searchText: string = "") {
        let sortArg = sortArgs.split(",");
        let route: any;
        route = {
            "fromDate": "",
            "endDate": "",
            "status": [],
            "agingFrom": "",
            "agingTo": "",
            "pageNumber": pageNumber,
            "pageSize": pageSize,
            "orderBy": [
                { "sortBy": sortArg[0], "direction": sortArg[1] }
            ],
            "searchText": searchText
        }
        let data = JSON.stringify(route);
        let http = this.$http.iotContext.url("/api/routes/search")
        return http.post(data).map((res) => {
            let obj = res.json();
            return obj;
        });
    }
    getAllEndPoint() {
        return this.$http.iotContext.url().get()
            .map(res =>
                res.json()
            );
    }
    deleteIotRoute(iotRouteId) {
        return this.$http.iotContext.url("/api/routes/" +  iotRouteId).delete()
            .map(res => res.json());
    }
}
