import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { FormControl } from '@angular/forms';
import { IotRoute } from 'app/configure/configure.data';
import { IotRouteService } from '../services/iotRoute.service';
import { ModalDirective } from 'ng2-bootstrap';
import { IotRouteFormComponent, } from './iotRouteForm.component';
import { FilterParams } from "sensorthink-commoncontrols/src/components/advancedFilter/advancedFilter.data";

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/throttleTime';
import 'rxjs/add/observable/fromEvent'


@Component({
  templateUrl: 'iotRoute.component.html'
})
export class IotRouteComponent implements OnInit {
  public modelTitle: String;
  public submitText: String;
  public allRouteData: any;
  public loadForm: boolean = false;
  public pagerConfig: any;
  public sortArgs: string;
  public sideBarVisible: boolean;
  public filterConfig: FilterParams;
  public appliedFilterData: FilterParams;
  callBack = this.onCheckBoxChecked.bind(this)
  iotObj: any;
  isLoading: boolean = false;
  searchTxt = '';
  searchTxtControl = new FormControl();
  selectedCheckboxCount= [];

  @ViewChild(IotRouteFormComponent) iotRouteForm: IotRouteFormComponent;
  @ViewChild('iotRouteModal') public iotRouteModal: ModalDirective;

  constructor(private service: IotRouteService) {
    let that = this;
    this.sortArgs = "routeId,desc";
    this.filterConfig = this.createFilterParams();
    this.pagerConfig = {
      totalItems: 64,
      currentPage: 1,
      smallnumPages: 0,
    }
  }
  setPagerConfig(totalItems, currentPage, itemsPerPage?) {
    this.pagerConfig = {
      totalItems: totalItems,
      currentPage: currentPage || 1,
      itemsPerPage: itemsPerPage || 10,
      smallnumPages: 0
    }
  }
  ngOnInit() {
    this.searchTypeResult();
    this.setPagerConfig(0, 0);
    this.getAllRoutes(1, this.sortArgs, );
  }
  searchTypeResult() {
    this.searchTxtControl.valueChanges
      .debounceTime(1000)
      .subscribe(newValue => {
        this.searchTxt = newValue.trim();
        if (((this.searchTxt.length >= 1 || this.searchTxt.length === 0) && this.searchTxt !== "") || this.isLoading) {
          this.isLoading = (this.searchTxt.length === 0) ? false : true;
          this.getAllRoutes(this.pagerConfig.currentPage, this.sortArgs, this.searchTxt);
        }
      });
  }

  onOpenIotRouteModal(iot) {
    this.modelTitle = (iot === undefined) ? "CREATE A NEW ROUTE" : "EDIT ROUTE";
    this.submitText = (iot === undefined) ? "Create" : "Save";
    this.loadForm = true;
    this.iotRouteModal.show();
  }
  getAllRoutes(pageNumber: number, sortArgs: string, searchTxt?: string) {
    this.isLoading = true;
    this.service.getAllRoutes(pageNumber, this.pagerConfig.itemsPerPage, sortArgs, searchTxt).subscribe((routes) => {
      this.setPagerConfig(routes.totalElements,routes.totalPages,routes.size)
      this.allRouteData = routes.content;
      this.isLoading = false;
    });
  }
  onSaveIotForm() {
    this.iotRouteForm.save().subscribe(
      res => {
        this.iotRouteForm.iotRoute = new IotRoute();
        this.iotRouteModal.hide();
        this.getAllRoutes(1, this.sortArgs, );
      },
      err => {
          alert("Something went wrong");
          this.iotRouteModal.hide();
          // this.noty.error("Could not delete the route.");
        });
  }
  onCancelClick() {
    this.iotRouteModal.hide();
    this.iotRouteForm.iotRoute = new IotRoute();
    this.loadForm = false;
  }
  filterApplied(filterObj: FilterParams) {
    //used from --- http://stackoverflow.com/questions/728360/how-do-i-correctly-clone-a-javascript-object    
    // this.appliedFilterData = JSON.parse(JSON.stringify(filterObj));
    // this.appliedFilterData.dateRange.from = this.setDate(filterObj.dateRange.from);
    // this.appliedFilterData.dateRange.to = this.setDate(filterObj.dateRange.to);
    // this.getAllOrders(this.pagerConfig.currentPage, this.sortArgs, filterObj, this.searchTxt);
  }
  clearFilters() {
    // this.appliedFilterData = null;
    // this.filterConfig = this.createFilterParams();
    // this.getAllOrders(this.pagerConfig.currentPage, this.sortArgs, this.appliedFilterData, this.searchTxt);
  }
  onSortChanged(sortArgs) {
    this.sortArgs = sortArgs[0][0] + "," + sortArgs[0][1];
    this.getAllRoutes(this.pagerConfig.currentPage, this.sortArgs);
  }
  onPageSizeChanged(pageSize) {
    this.pagerConfig.itemsPerPage = pageSize;
    this.getAllRoutes(1, this.sortArgs);
  }
  onPageChanged(pager) {
    this.pagerConfig.currentPage = pager.page;
    this.getAllRoutes(pager.page, this.sortArgs);
  }
  onCheckBoxChecked(iot, e) {
    if (e.target.checked){
      this.selectedCheckboxCount.push(1);
      this.service.selectedRoute = Object.assign({}, iot);
    }
    else{
      this.selectedCheckboxCount.pop();
      this.service.selectedRoute = undefined;
    }
  }
  onEditIotRouteModal() { //edit
    if(this.selectedCheckboxCount.length > 1 ){
      alert("Please select only one Route for Edit")
    }else if(this.selectedCheckboxCount.length == 0){
      alert("Please select one Route for Edit")
    }else{
      this.onOpenIotRouteModal(this.service.selectedRoute);
    }
  }
  onDeleteIotRouteModal() {
    if (confirm("Are you sure you want to delete " + this.service.selectedRoute.routeName + "?")) {
      this.service.deleteIotRoute(this.service.selectedRoute.routeId)
        .subscribe(res => {
          this.getAllRoutes(this.pagerConfig.currentPage, this.sortArgs);
        },
        err => {
          alert("Could not delete the route.");
          // this.noty.error("Could not delete the route.");
        });
    }
    //delete
  }
  createFilterParams(): FilterParams {
    let params = new FilterParams(); // initialises to default on object creation
    params.state.isVisible = false;
    params.site.isVisible = false;
    params.baseMetric.isVisible = false;
    params.otherMetric.isVisible = false;

    return params;
  }
  applyFormatting(columns) {
    this.getAllRoutes(this.pagerConfig.currentPage, this.sortArgs);
  }
}