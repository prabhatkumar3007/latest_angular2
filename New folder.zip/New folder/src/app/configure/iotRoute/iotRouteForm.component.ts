import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { BasicValidators } from '../../shared/services/basicValidators';
import { IotRoute, IotRouteEndPointConfig, ConnectionType, IotRouteEndPoint } from '../configure.data';
import { DragulaService } from "ng2-dragula";
import { IotRouteService } from '../services/iotRoute.service';
import { SessionStorage } from "sensorthink-commoncontrols/lib/webStore.module";
import { RequestOptions } from "@angular/http/http";
import { FileService } from "sensorthink-commoncontrols/src/utils.module";
import { Observable } from "rxjs/Observable";

declare let $: any;

@Component({
  selector: 'iotRoute-modal',
  templateUrl: 'iotRouteForm.component.html'
})

export class IotRouteFormComponent implements OnInit {
  selectedFile: EventTarget;
  iotForm: FormGroup;
  title: string;
  isEditMode: boolean = false;
  fromEndPoint: IotRouteEndPoint;
  endPointValues: any;
  fromEndPointOptions: Array<IotRouteEndPoint> = new Array<IotRouteEndPoint>();
  toEndPointOptions: Array<IotRouteEndPoint> = new Array<IotRouteEndPoint>();
  toAddMultipleEndPoint = [{ toEndPointValue: '' }];
  count: number = 0;
  connectonF: any;
  connectonT: any;
  urlFText: any;
  urlTText: any;
  isOutbond: boolean;
  routeClassData: any;
  allCompany: any;
  transformationClassData: any;
  ConnectionTypeData: any;
  transformationMappingFile = {};
  transformationTypeData = [
    { name: "Delimited", value: "DELIMITED" },
    { name: "Fixed width", value: "FIXEDWIDTH" }
  ];
  iotRoute: IotRoute = new IotRoute();
  @SessionStorage() public userInfo: any;
  constructor(private service: IotRouteService, private fb: FormBuilder, private dragulaService: DragulaService, private fileService: FileService) {
    // this.iotForm = this.service.initializeFormObject(fb);
    this.transformationMappingFile = {
      name: 'Upload File'
    }
    this.createForm();
    this.setDnDOptions();
    this.iotRoute.direction = 'Inbound'
  }
  createForm() {
    this.iotForm = this.service.initializeFormObject(this.fb);
  }

  ngOnInit() {
    this.getAllPromises();
  }
  getAllPromises() {
    let promises = [
      this.service.getConnectionType(),
      this.service.getRouteClass(),
      this.service.getTransformationClass(),
      this.service.getAllCompany()
    ]
    Observable.forkJoin(promises).subscribe((res) => {
      this.ConnectionTypeData = res[0];
      this.routeClassData = res[1];
      this.transformationClassData = res[2];
      if (res[3].constructor === Array)
        this.allCompany = res[3]
      else
        this.allCompany = [res[3]]
      if (this.service.selectedRoute)
        this.iotRoute = this.service.selectedRoute;
    })
  }

  setDnDOptions() {
    try {
      this.dragulaService.setOptions('bag-endpoint', {
        moves: function (el, container, handle) {
          if (handle.className.indexOf)
            return handle.className.indexOf('drag-handle') >= 0;
          return false;
        }
      });
    } catch (error) {
      // Intentionally left blank.
    }
    this.dragulaService.drop.subscribe((value) => {
      this.onDrop(value.slice(1));
    });
  }

  private onDrop(args) {
    let endpoints = [];
    var select = document.getElementsByClassName("toendpoint");
    for (var i = 0; i < select.length - 1; i++) {
      // endpoints.push($(select[i]).val());
    }
  }

  save() {
    var result;
    for (var i = 0; i < this.toAddMultipleEndPoint.length; i++) {
      let temp: any;
      temp = this.toAddMultipleEndPoint[i].toEndPointValue;
      this.iotRoute.endpoint.push(temp);
    }
    this.iotRoute.endpoint.push(this.fromEndPoint);
    result = this.service.addRoute(this.iotRoute)
    return result;
  }

  addToForm(connectionTypeObj: ConnectionType, endpointUrl) {
    let endPointConfig = new IotRouteEndPointConfig(5, endpointUrl, "", connectionTypeObj);
    let endPoint = new IotRouteEndPoint("from", "1", endPointConfig);
    this.fromEndPointOptions.push(endPoint);
    this.connectonF = this.urlFText = '';
  }

  addTo(connectionTypeObj: ConnectionType, endpointUrl) {
    let endPointConfig = new IotRouteEndPointConfig(5, endpointUrl, "", connectionTypeObj);
    let endPoint = new IotRouteEndPoint("to", "1", endPointConfig);
    this.toEndPointOptions.push(endPoint);
    this.connectonT = this.urlTText = '';
  }

  addMultipleToEndPoint() {
    this.toAddMultipleEndPoint.push({ toEndPointValue: '' });
    //this.count++
  }

  deleteMultipleToEndPoint(index) {
    if (this.toAddMultipleEndPoint.length == 1) {
      alert("cannot remove the last entry")
    } else {
      setTimeout(() => {
        this.toAddMultipleEndPoint.splice(this.toAddMultipleEndPoint.indexOf(index), 1);
      }, 1000);
    }
  }

  onChange(event: EventTarget) {
    let eventObj: MSInputMethodContext = <MSInputMethodContext>event;
    let target: HTMLInputElement = <HTMLInputElement>eventObj.target;
    let files: FileList = target.files;
    this.transformationMappingFile = files[0];
    this.selectedFile = event
  }

  upload(event: EventTarget) {
    this.fileService.readTextFile(this.selectedFile).subscribe(txt => {
      this.iotRoute.transformationMapping = txt;
    });
  }

  onchangeDirection(val) {
    if (val == "outbound") {
      this.isOutbond = true;
    } else {
      this.isOutbond = false;
    }
  }
}