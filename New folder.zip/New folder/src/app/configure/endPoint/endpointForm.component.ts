import { Component, Input, ChangeDetectorRef, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { BasicValidators } from '../../shared/services/basicValidators';
import { IotRoute, IotRouteEndPointConfig, ConnectionType, IotRouteEndPoint } from '../configure.data';
import { IotRouteService } from '../services/iotRoute.service';
import { RequestOptions } from "@angular/http/http";

declare let $: any;

@Component({
  selector: 'endPoint-modal',
  templateUrl: 'endPointForm.component.html'
})

export class EndPointFormComponent implements OnInit {
  endPointForm: FormGroup;
  discriptionEndPoint:any;
  ConnectionTypeData: any;
  companyIdData = [
    { id: "1" },
    {  id: "2" }
  ];
  iotRoute: IotRoute = new IotRoute();

  constructor(private service: IotRouteService, private fb: FormBuilder) {
    this.endPointForm = this.service.initializeEndPointFormObject(fb);
  }

  ngOnInit() {
    this.getAllConnectionType();
  }
  getAllCompany() {
    this.service.getAllCompany().subscribe((data) => {

    });
  }

  getAllConnectionType() {
    this.service.getConnectionType().subscribe((data) => {
      this.ConnectionTypeData = data;
      console.log(this.ConnectionTypeData);
    });
  }

  save() {
    var result;
   // result = this.service.addEndPoint(this.iotRoute)
    return result;
  }
}