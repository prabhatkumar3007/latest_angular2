import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { FormControl } from '@angular/forms';
import { IotRoute } from 'app/configure/configure.data';
import { IotRouteService } from '../services/iotRoute.service';
import { ModalDirective } from 'ng2-bootstrap';
import { EndPointFormComponent } from './endpointForm.component';

@Component({
  templateUrl: 'endPoint.component.html'
})
export class EndPointComponent implements OnInit {
  public modelTitle: String;
  public submitText: String;
  public allEndPointData: any;
  public loadForm: boolean = false;
  isLoading: boolean = false;
  pagerConfig = {
    totalItems: 64,
    currentPage: 1,
    smallnumPages: 0,
    itemsPerPage: 10
  }
  @ViewChild(EndPointFormComponent) endPointForm: EndPointFormComponent;
  @ViewChild('endPointModal') public endPointModal: ModalDirective;

  constructor(private service: IotRouteService) { }

  ngOnInit() {
    this.getAllEndPoints();
  }

  onOpenendPointModal(iot) {
     this.modelTitle = (iot === undefined) ? "ADD NEW END POINT" : "EDIT END POINT";
     this.submitText = (iot === undefined) ? "Add" : "Save";
     this.loadForm = true;
     this.endPointModal.show();
  }
  getAllEndPoints() {
     this.isLoading = true;
     this.service.getAllEndPoint().subscribe((endPoints) => {
       this.allEndPointData = endPoints;
       this.isLoading = false;
     });
  }
  onSaveIotForm() {
    this.endPointForm.save().subscribe(
      res => {
        this.endPointModal.hide();
        this.getAllEndPoints();
      });
  }
  onCancelClick() {
     this.endPointModal.hide();
  }
}