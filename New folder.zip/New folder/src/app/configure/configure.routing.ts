import { RouterModule  } from '@angular/router';

import {IotRouteComponent} from './iotRoute/iotRoute.component';




import { AuthGuard } from '../auth/auth-guard.service';

export const configureRouting = RouterModule.forChild([
  
  // { path: 'iotroute', component: IotRouteComponent, canActivate: [ AuthGuard ] }
  
]);