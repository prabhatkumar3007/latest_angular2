import { JwtHelper } from './services/jwtHelper.service';
import { AdvancedFilterComponent } from './components/advancedFilter/advancedFilter.component';
import { AdvancedFilterStore } from './components/advancedFilter/advancedFilterStore.service';
import { AppliedFilterDataComponent } from './components/advancedFilter/selectedAppliedFilter.component';
import { CommonModule } from '@angular/common';
import { DataGrid, GridColumn } from './components/datatable/datagrid.component';
import { DataGridService } from './components/datatable/datagrid.service';
import { DatePickerComponent } from './components/datepicker/datepicker.component';
import { DatePipe } from './pipes/dateFormater.pipe';
import { FormattingTab } from './components/advancedFilter/formatting.advancedFilter.component';
import { FormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { PagerComponent } from './components/datatable/pager.component';
import { PageSizeComponent } from './components/datatable/pageSize.component';
import { PaginationModule } from 'ng2-bootstrap/pagination';
import { PopoverHtmlComponent } from './components/popover/popover.component';
import { PopoverModule } from 'ng2-bootstrap/popover';
import { ShiftPopoverComponent } from './components/shiftPopover/shiftPopover.component';
import { SliderComponent } from './components/slider/slider.component';

export { DatePickerComponent } from './components/datepicker/datepicker.component'
export { SliderComponent } from './components/slider/slider.component'
export { ShiftPopoverComponent } from './components/shiftPopover/shiftPopover.component'
export { DataGrid, GridColumn } from './components/datatable/datagrid.component';
export { DataGridService } from './components/datatable/datagrid.service';
export { PagerComponent } from './components/datatable/pager.component';
export { PageSizeComponent } from './components/datatable/pageSize.component';
export { FilterParams } from './components/advancedFilter/advancedFilter.data';

@NgModule({
    imports: [
        FormsModule,
        CommonModule,
        PopoverModule.forRoot(),
        PaginationModule.forRoot(),
    ],
    declarations: [
        DatePipe,
        DatePickerComponent,
        SliderComponent,
        ShiftPopoverComponent,
        DataGrid,
        GridColumn,
        PagerComponent,
        PageSizeComponent,
        PopoverHtmlComponent,
        AdvancedFilterComponent,
        FormattingTab,
        AppliedFilterDataComponent,
    ],
    exports: [
        DatePipe,
        DatePickerComponent,
        SliderComponent,
        ShiftPopoverComponent,
        DataGrid,
        GridColumn,
        PagerComponent,
        PageSizeComponent,
        PopoverHtmlComponent,
        AdvancedFilterComponent,
        FormattingTab,
        AppliedFilterDataComponent
    ],
    providers: [
        DataGridService,
        AdvancedFilterStore,
        JwtHelper
    ]
})
export class SensorThinkControlsModule { }
