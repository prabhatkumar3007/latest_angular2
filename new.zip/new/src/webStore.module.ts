// import { CommonModule } from '@angular/common';
// import { LocalStorageService, WebStorageModule, LocalStorage } from './storage';
// import { ModuleWithProviders, NgModule } from '@angular/core';

// export { LocalStorageService, WebStorageModule, LocalStorage, SessionStorage } from './storage';

// @NgModule({
//   imports: [
//     CommonModule,
//     WebStorageModule
//   ],
//   declarations: [],
//   exports: [],
//   providers: [LocalStorageService]
// })
// export class WebStoreModule {
//   static forRoot(): ModuleWithProviders {
//     return {
//       ngModule: WebStoreModule
//     }
//   }
// }

export * from './storage'