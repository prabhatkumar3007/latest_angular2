import { Injectable } from '@angular/core'
import { Observable } from "rxjs/Observable";

@Injectable()
export class FileService {

    readTextFile(event) {
        var input = event.target;
        var reader = new FileReader();
        return Observable.create(observer => {
            reader.onload = () => {
                var text = reader.result;
                observer.next(text);
                observer.complete();
            };
            reader.readAsText(input.files[0]);
        });
    }
}   