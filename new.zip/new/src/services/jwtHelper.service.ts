import { Injectable } from '@angular/core'
import { Observable } from "rxjs/Observable";
import { BehaviorSubject } from 'rxjs/BehaviorSubject'
import { SessionStorage } from "../webStore.module";

@Injectable()
export class JwtHelper {
    // use this property for property binding
    @SessionStorage() private accessToken: any;

    get token(): any {
        let jwt = JSON.parse(window.atob(this.accessToken.token.split('.')[1]));
        return jwt;
    }
}