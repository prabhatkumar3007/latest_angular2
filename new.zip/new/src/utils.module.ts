import { FileService } from './services/file.service';
import { NgModule } from '@angular/core';

export { FileService } from './services/file.service';

@NgModule({
    imports: [],
    declarations: [],
    exports: [],
    providers: [
        FileService
    ]
})
export class CommonUtilsModule { }
