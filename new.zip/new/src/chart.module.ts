import { NvD3Module } from 'angular2-nvd3';
import { BarChartComponent } from './components/chart/barChart.component';
import { ChartService } from './components/chart/chart.service';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { LineBarChartComponent } from './components/chart/lineBarChart.component';
import { LineChartComponent } from './components/chart/lineChart.component';
import { ModuleWithProviders, NgModule } from '@angular/core';
import { OrdersPickedComponent } from './components/chart/ordersPickedChart.component';
import { PickingLineChartComponent } from './components/chart/processPickingLineChart/pickingLineChart.component';
import { PickingLineChartInfoComponent } from './components/chart/processPickingLineChart/pickingLineChartInfo.component';
import { PickingLineChartStatusInfoComponent } from './components/chart/processPickingLineChart/pickingLineChartStatusInfo.component';
import { PickingLineChartTableComponent } from './components/chart/processPickingLineChart/pickingLineChartTable.component';
import { ProcessData, ProcessSection } from './components/chart/progessBar/services/progressBar.data';
import { ProcessRateInfoComponent } from './components/chart/processRateChart/processRateInfo.component';
import { ProcessRateLineChartComponent } from './components/chart/processRateChart/processRateLineChart.component';
import { ProgressBarComponent } from './components/chart/progessBar/progressBar.component';

export { ChartService } from './components/chart/chart.service';
export { OrdersPickedComponent } from './components/chart/ordersPickedChart.component';
export { BarChartComponent } from './components/chart/barChart.component';
export { LineChartComponent } from './components/chart/lineChart.component';
export { PickingLineChartComponent } from './components/chart/processPickingLineChart/pickingLineChart.component';
export { PickingLineChartInfoComponent } from './components/chart/processPickingLineChart/pickingLineChartInfo.component';
export { PickingLineChartStatusInfoComponent } from './components/chart/processPickingLineChart/pickingLineChartStatusInfo.component';
export { PickingLineChartTableComponent } from './components/chart/processPickingLineChart/pickingLineChartTable.component';
export { ProcessRateInfoComponent } from './components/chart/processRateChart/processRateInfo.component';
export { ProcessRateLineChartComponent } from './components/chart/processRateChart/processRateLineChart.component';
export { LineBarChartComponent } from './components/chart/lineBarChart.component';
export { ProcessData, ProcessSection } from './components/chart/progessBar/services/progressBar.data';
import { TooltipModule } from 'ng2-bootstrap/tooltip';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    NvD3Module,
    TooltipModule.forRoot()
  ],
  declarations: [
    LineChartComponent,
    OrdersPickedComponent,
    BarChartComponent,
    PickingLineChartInfoComponent,
    ProcessRateLineChartComponent,
    ProcessRateInfoComponent,
    PickingLineChartComponent,
    PickingLineChartStatusInfoComponent,
    PickingLineChartTableComponent,
    LineBarChartComponent,
    ProgressBarComponent
  ],
  exports: [
    LineChartComponent,
    OrdersPickedComponent,
    BarChartComponent,
    PickingLineChartInfoComponent,
    ProcessRateLineChartComponent,
    PickingLineChartComponent,
    ProcessRateInfoComponent,
    PickingLineChartStatusInfoComponent,
    PickingLineChartTableComponent,
    LineBarChartComponent,
    ProgressBarComponent
  ],
  providers: [
    ChartService
  ]
})
export class ChartModule {
  static forRoot(): ModuleWithProviders {
    return {
      ngModule: ChartModule
    }
  }
}