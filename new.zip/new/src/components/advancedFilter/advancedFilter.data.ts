export class Status {
    selectedStates: any = [];
    isVisible: boolean = true;
}

export class FromTo {
    from: any | Date;
    to: any | Date;
    isVisible: boolean = true;
}

export class Type extends FromTo {
    pick: boolean;
    pack: boolean;
    ship: boolean;
}

export class Aging extends FromTo {
    fromSeconds: number;
    toSeconds: number;
}


export class PickMethod {
    Method: Array<string>;
    selectedMethod: string;
    isVisible: boolean = true;
}

export class DropdownType {
    options: any = [];
    selectedValue: any;
    isVisible: boolean = true;
}

export class FilterParams {
    state: Status = new Status();
    dateRange: FromTo = new FromTo();
    aging: Aging = new Aging();
    type: Type = new Type();
    priority: FromTo = new FromTo();
    pickMethod: PickMethod = new PickMethod();
    weightRange: FromTo = new FromTo();
    columns: Array<string>;
    site: DropdownType = new DropdownType();
    baseMetric: DropdownType = new DropdownType();
    otherMetric: DropdownType = new DropdownType();

    constructor() {
        this.aging.from = 1;
        this.aging.to = 30;
        this.type.pick = true;
        this.type.pack = false;
        this.type.ship = false;
        this.type.from = 1;
        this.type.to = 1;
        this.type.isVisible = false;
        this.weightRange.isVisible = false;
        this.priority.from = 1;
        this.priority.to = 100;
    }
}