import { Injectable } from '@angular/core';

@Injectable()
export class AdvancedFilterStore {
    private filterStore: object = {};

    getFilter(key) {
        return this.filterStore[key];
    }

    addFilter(key, value) {
        this.filterStore[key] = value;
    }
}
