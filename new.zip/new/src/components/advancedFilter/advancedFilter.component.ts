import { AdvancedFilterStore } from './advancedFilterStore.service';
import { DataGridService } from './../datatable/datagrid.service';
import { Component, Input, Output, EventEmitter } from '@angular/core';
import { FilterParams } from './advancedFilter.data';
declare var moment: any
declare var $: any

@Component({
    selector: 'advanced-filter',
    templateUrl: 'advancedFilter.template.html'
})

export class AdvancedFilterComponent {
    @Input() config: FilterParams;
    @Input("table-id") tableId: string;
    @Input() showFilters: boolean = true;
    @Input() showActions: boolean = true;
    @Input() showFormatting: boolean = true;
    @Input() showSaveFilters: boolean = true;
    @Input() showTimePicker: boolean = false;
    @Input() filterHeight: string;

    @Output() onApply: EventEmitter<FilterParams> = new EventEmitter<FilterParams>();
    @Output() onRemoveFilter: EventEmitter<FilterParams> = new EventEmitter<FilterParams>();
    @Output() onApplyFormatting: EventEmitter<any> = new EventEmitter<any>();
    @Output() onEditCalled: EventEmitter<any> = new EventEmitter<any>();
    @Output() onDeleteCalled: EventEmitter<any> = new EventEmitter<any>();

    public isStateFilter: boolean = true;
    public priorityExpanded: boolean;
    public statusExpanded: boolean;
    public statusExport: boolean;
    public columns: any;
    public dateFrom = { dates: [] };
    public dateTo = { dates: [] };
    public datePickerConfig: any = {
        maxDate: moment(new Date()).endOf('day')._d,
        position: "bottom left",
    }

    constructor(private dataGridService: DataGridService, private filterStore: AdvancedFilterStore) {
        if (this.showTimePicker) {
            this.datePickerConfig.timepicker = true;
            this.datePickerConfig.minutesStep = 15;
            this.datePickerConfig.timeFormat = "hh:ii";
        }
    }

    ngAfterViewInit() {
        if (this.config) {
            this.config.aging.fromSeconds = this.convertToSeconds(this.config.aging.from);
            this.config.aging.toSeconds = this.convertToSeconds(this.config.aging.to);
        }
        if (this.config.state.selectedStates.length === 0) {
            this.isStateFilter = false;
        }
        if (this.tableId)
            this.columns = this.dataGridService.getColumns(this.tableId);

        if (this.filterHeight)
            $("#wrapper").css("min-height", this.filterHeight);
    }

    setStateValues(item, e) {
        item.checked = e;
    }

    setAgingValues(values: Array<number>) {
        this.config.aging.from = values[0];
        this.config.aging.to = values[1];
        this.config.aging.fromSeconds = this.convertToSeconds(values[0]);
        this.config.aging.toSeconds = this.convertToSeconds(values[1]);
    }

    setInputAgingValues(str, value) {
        if (str === 'from') {
            this.config.aging.from = Number(value);
        } else {
            this.config.aging.to = Number(value);
        }
    }

    setTypeValues(values: Array<number | Date>) {
        this.config.type.from = Number(values[0]);
        this.config.type.to = Number(values[1]);
    }

    setPriorityValues(values: Array<number>) {
        this.config.priority.from = Number(values[0]);
        this.config.priority.to = Number(values[1]);
    }
    setInputPriorityValues(v1, v2) {
        let values = [];
        values.push(v1, Number(v2));
        this.setPriorityValues(values);
    }

    setWeightRangeValues(values: Array<number | Date>) {
        this.config.weightRange.from = values[0];
        this.config.weightRange.to = values[1];
    }

    applyFilter() {
        this.onApply.emit(this.config);
    }

    removeFilters() {
        this.config.state.selectedStates.forEach(element => {
            element.checked = false;
        });
        this.onRemoveFilter.emit();
    }
    onEdit(){
        this.onEditCalled.emit()
    }
    onDelete(){
        this.onDeleteCalled.emit()
    }

    setDateFrom(date) {
        this.config.dateRange.from = moment(date.dates[0]).format("MMDDYYYY 00:00:00");
    }

    setDateTo(date) {
        this.config.dateRange.to = moment(date.dates[0]).format("MMDDYYYY 23:59:59");
    }

    convertToSeconds(days: number) {
        return (24 * 60 * 60) * days;
    }

    applyFormatting(columns) {
        this.filterStore.addFilter(this.tableId, columns);
        this.onApplyFormatting.emit(columns);
    }
}
