import { Component, Input, Output, EventEmitter } from '@angular/core';
import { FilterParams } from './advancedFilter.data';
declare var moment: any
@Component({
    selector: 'formatting-tab',
    templateUrl: 'formatting.advancedFilter.template.html'
})

export class FormattingTab {
    @Input() columns: Array<any>;
    @Output() onApplyFormatting: EventEmitter<any> = new EventEmitter<any>();

    applyFilter() {
        this.onApplyFormatting.emit(this.columns);
    }

    clearFilter() {
        this.columns.forEach(col => {
            col.freezeColumn = false;
            col.visible = true;
        });
        this.onApplyFormatting.emit(this.columns);
    }
}