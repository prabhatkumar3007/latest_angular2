import { Component, Input, Output, EventEmitter } from '@angular/core';
import { FilterParams, Status } from './advancedFilter.data';


@Component({
    selector: 'applied-filter-data',
    templateUrl: 'selectedAppliedFilter.component.html'
})

export class AppliedFilterDataComponent {

    @Input() filterParamsData: FilterParams;
    @Output() onRemoveFilter: EventEmitter<FilterParams> = new EventEmitter<FilterParams>();
    public selectedStates: string = "";
    ngOnChanges(changes) {
        if (changes.filterParamsData.currentValue) {
            let stateValues = "";
            this.filterParamsData.state.selectedStates.forEach(element => {
                if (element.checked) {
                    stateValues += element.text + ","
                }
            });
            this.selectedStates = stateValues.slice(0, -1); //remove last comma;
        }
    }

    resetFilter(value) {
        if ((value === 'priority') || (value === 'dateRange')) {
            this.resetvalues(value);
        } else if (value === 'state') {
            this.selectedStates = "";
            this.filterParamsData[value].selectedStates.forEach(element => {
                element.checked = false;
            });
        } else if (value === 'aging'){
            this.filterParamsData[value].from = null;
            this.filterParamsData[value].to = null;
            this.filterParamsData[value].fromSeconds = null;
            this.filterParamsData[value].toSeconds = null;
        }
        this.onRemoveFilter.next(this.filterParamsData);
    }
    resetvalues(val) {
        this.filterParamsData[val].from = null;
        this.filterParamsData[val].to = null;
    }

    parseDate(value) {
        if (value)
            return value.split(" ")[0]
        return "";
    }
}