import { AdvancedFilterStore } from './../advancedFilter/advancedFilterStore.service';
import {
    AfterContentInit,
    Component,
    ElementRef,
    EventEmitter,
    Host,
    Inject,
    Input,
    OnInit,
    Output
} from '@angular/core';
import { DataColumn, DataGridService } from './datagrid.service';
declare var $: any;

@Component({
    selector: 'data-grid',
    template: `<div>
                    <div>
                    <table id="{{tableId}}" style="float:left" class="table table-striped hover nowrap"></table>
                    </div>
                </div>`
})
export class DataGrid {
    @Input() tableId: string;
    @Input() data: any;
    @Input() autoHeight: boolean;
    @Input() isModal: boolean;
    @Input() defaultSortColumn: any;
    @Output() onSort: EventEmitter<any> = new EventEmitter<any>();
    @Input() dtOptions: any = {};
    @Input('redraw-when') reDrawWhen: any = {};
    public dtInstance: Promise<any>;
    public currentCol: number;
    public table: any;
    private defaultColumns: any;


    constructor( @Inject(ElementRef) private el: ElementRef, private service: DataGridService, private filterStore: AdvancedFilterStore) {
    }

    ngAfterViewInit() {
        this.setDtOptions()
    }

    private getWordsBetweenCurlies(str) {
        var results = [], re = /\[\s*(\S+?)\s*\]/g, text;

        while ((text = re.exec(str))) {
            results.push(text[1]);
        }
        return results;
    }

    attachGridEvents() {
        this.dtOptions.fnSortCallback = (colIdx, col) => {
            let sortArgs = this.table.context[0].oInstance.fnSettings().aaSorting;
            if (sortArgs[0][1]) {
                let tmpWords = this.getWordsBetweenCurlies(col.data);
                sortArgs[0][0] = tmpWords.length > 0 ? tmpWords[0] : col.data;
                if (this.currentCol === undefined || this.currentCol === colIdx)
                    sortArgs[0][1] = sortArgs[0][1] === "asc" ? "desc" : "asc"
                else
                    sortArgs[0][1] = "asc";
                this.dtOptions.order = [colIdx, sortArgs[0][1]];
            } else {
                let tmpWords = this.getWordsBetweenCurlies(col.data);
                sortArgs[0] = tmpWords.length > 0 ? tmpWords[0] : col.data;
                if (this.currentCol === undefined || this.currentCol === colIdx)
                    sortArgs[1] = sortArgs[1] === "asc" ? "desc" : "asc"
                else
                    sortArgs[1] = "asc";
                this.dtOptions.order = [colIdx, sortArgs[1]];
            }
            this.onSort.emit(sortArgs);
            this.currentCol = colIdx;
            return;
        }
    }

    ngOnInit() {

        this.attachGridEvents();
        this.service.reset(this.tableId);
        this.dtOptions.order = this.defaultSortColumn ? this.defaultSortColumn : undefined
    }

    ngOnChanges(changes) {
        if (changes.data && changes.data.currentValue) {
            this.initializeGrid();
        }
        if (changes.reDrawWhen !== undefined && changes.reDrawWhen.currentValue !== undefined) {
            setTimeout(() => {
                if (this.table)
                    this.table.draw();
            }, 400);
        }
    }

    setDtOptions() {
        this.dtOptions = $.extend(true, this.dtOptions, $.fn.DataTable.defaults);
        this.dtOptions = Object.assign(this.dtOptions, {
            bFilter: false,
            "paging": false,
            "info": false,
            "scrollCollapse": true,
            "scrollX": true,
            "sScrollX": "100%",
            "autoWidth": false
        });
    }

    initializeGrid() {
        this.dtInstance = new Promise((resolve, reject) => {
            Promise.resolve(this.dtOptions).then(dtOptions => {
                this.setAutoHeight(this.isModal);
                this.dtOptions.aoColumns = this.service.getColumns(this.tableId);
                this.defaultColumns = this.dtOptions.aoColumns.slice(0);
                $.fn.dataTable.ext.errMode = "none";
                let orderByFreezeColumn = this.sortByFrozenColumn(this.dtOptions.aoColumns.slice(0));
                let frozenColumnCount = 0;
                this.dtOptions.aoColumns.forEach((col, idx) => {
                    if (col.freezeColumn) {
                        frozenColumnCount++;
                    }
                });
                if (frozenColumnCount > 0)
                    this.dtOptions.aoColumns = orderByFreezeColumn
                else
                    this.dtOptions.aoColumns = this.defaultColumns.slice(0);
                this.dtOptions.fixedColumns = {
                    leftColumns: frozenColumnCount
                }
                this.dtOptions.aoColumns.forEach((col, idx) => {
                    col.bVisible = col.visible;
                });
                if (this.table)
                    this.table.destroy();
                this.table = $(this.el.nativeElement).find("table.table").DataTable(dtOptions);
                this.table.clear();
                this.table.rows.add(this.data).draw();
                resolve(this.table);
            });
        });
    }

    sortByFrozenColumn(columns) {
        let frozenCols = [], cols = [];
        columns.forEach(col => {
            if (col.freezeColumn)
                frozenCols.push(col);
            else
                cols.push(col);
        });

        return frozenCols.concat(cols);
    }

    setAutoHeight(isModal) {
        if (this.autoHeight === true) {
            this.dtOptions.scrollY = this.service.getHeightForDataTable(isModal);
            this.dtOptions.sScrollY = this.service.getHeightForDataTable(isModal);
        }
    }
}

@Component({
    selector: 'column',
    template: ``
})
export class GridColumn implements AfterContentInit {
    @Input() headerText: string;
    @Input('column-map') columnMap: string;
    @Input() url: string;
    @Input() width: string;
    @Input() formatter: string;
    @Input() orderable: boolean;
    @Input('true-state') trueState: string;
    @Input('false-state') falseState: string;
    @Input('formatter-config') formatterConfig: any;
    @Input('callBackFn') callBackFn: any;

    //http://stackoverflow.com/a/35267202
    constructor(private service: DataGridService, @Host() private parent: DataGrid) { }

    ngAfterContentInit() {
        let tmp = this.parent;
        var col = new DataColumn(this.columnMap, this.headerText, this.columnMap);
        col.trueState = this.trueState;
        col.falseState = this.falseState;
        col.formatType = this.formatter;
        col.width = this.width || "150";
        col.sWidth = this.width || "150";
        col.url = this.url;
        col.callBackFn = this.callBackFn;
        col.formatterConfig = this.formatterConfig;
        if (this.orderable !== undefined)
            col.orderable = this.orderable;
        this.service.addColumn(this.parent.tableId, col);
    }
}