import {
  Component,
  EventEmitter,
  Input,
  Output
} from '@angular/core';

@Component({
  selector: 'page-size',
  template: `<table class="pull-left">
                <tr>
                   <td>
                     <div class="btn-group dropup" dropdown style="margin:20px 0">
                        <a href="#" data-toggle="dropdown" role="button" dropdownToggle><small>{{currentSize}} Records <i class="fa fa-chevron-down fa-1" aria-hidden="true"></i></small></a>
                        <ul class="dropdown-menu" dropdownMenu role="menu" aria-labelledby="simple-btn-keyboard-nav">
                          <li *ngFor="let p of pageSizes" role="menuitem"><a class="dropdown-item" href="javascript:void(0)" (click)="sizeChanged(p)">{{p}}</a></li>
                        </ul>
                    </div>
                  </td>
                  <td>&nbsp;</td>
                  <td><small>Showing {{fromVal}} to {{toVal}} of {{pagerConfig.totalItems}}</small></td>
                </tr>
            </table>` //<td><small>Showing 1 to 10 of 200</small></td>
})

export class PageSizeComponent {
  @Input() pagerConfig: any;
  @Output() onPageSizeChanged: EventEmitter<any> = new EventEmitter<any>();
  pageSizes = [10, 20, 50];
  currentSize = 10;
  fromVal;
  toVal;

  ngOnChanges() {
    if (this.pagerConfig) {
      this.fromVal = (this.pagerConfig.currentPage - 1) < 1 ? 1 : (this.pagerConfig.itemsPerPage * (this.pagerConfig.currentPage - 1));
      this.toVal = this.pagerConfig.itemsPerPage * this.pagerConfig.currentPage;
      if (this.toVal > this.pagerConfig.totalItems)
        this.toVal = this.pagerConfig.totalItems;
    }
  }

  sizeChanged(size: number) {
    this.currentSize = size;
    this.onPageSizeChanged.emit(size);
  }

}