import { AdvancedFilterStore } from './../advancedFilter/advancedFilterStore.service';
import { DatePipe } from '../../pipes/dateFormater.pipe';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
declare var $: any;

class Formatter {
    formatters: any;
    constructor(private router: Router) {
        this.formatters = {};
        this.setupFormatters();
    }

    private getWordsBetweenCurlies(str) {
        var results = [], re = /\[\s*(\S+?)\s*\]/g, text;

        while ((text = re.exec(str))) {
            results.push(text[1]);
        }
        return results;
    }

    private camel2title(camelCase) {
        return camelCase.replace(/([A-Z])/g, (match) => ` ${match}`)
            .replace(/^./, (match) => match.toUpperCase());
    }

    private getUrl(columnDef, value, dataContext) {
        var url = columnDef.url;
        var matches = this.getWordsBetweenCurlies(columnDef.url);
        matches.forEach((param) => {
            if (!url)
                url = columnDef.url.replace("[" + param + "]", this.getValue(dataContext, param));
            else
                url = url.replace("[" + param + "]", this.getValue(dataContext, param));
        });
        return "<a href='#" + url + "'>" + value + "</a>";
    }

    private getData(columnDef, value, dataContext) {
        var data = (' ' + columnDef.mData).slice(1);
        var matches = this.getWordsBetweenCurlies(columnDef.mData);
        matches.forEach((param) => {
            data = data.replace("[" + param + "]", this.getValue(dataContext, param));
        });
        return data;
    }

    private getDateFormateData(columnDef, value, dataContext) {
        var data;
        var datePipe = new DatePipe();
        data = datePipe.transform(value, 'MM/DD/YYYY HH:mm:ss');
        return data;
    }
    private getDateFormate(columnDef, value, dataContext) {
        var data;
        value = value.substr(0, value.indexOf(' '));
        data = value.substr(0, 2) + '/' + value.substr(2, 2) + '/' + value.substr(4, value.length)
        return data;
    }

    private getValue(obj, property) {
        if (property.indexOf(".") >= 0) {
            if (obj[property.split(".")[0]])
                obj = obj[property.split(".")[0]];
        } else {
            obj = obj[property];
            return obj;
        }
        if (Object.prototype.toString.call(obj) === '[object Array]')
            return obj;
        return this.getValue(obj, property.substring(property.indexOf(".") + 1));
    };

    getFormatter(type) {
        return this.formatters[type];
    }

    setupFormatters() {
        let that = this;
        this.formatters.booleanFormatter = (value, type, dataContext, meta) => {
            var columnDef = meta.settings.aoColumns[meta.col];
            if (that.getValue(dataContext, columnDef.id) === 1)
                return columnDef["trueState"]
            else
                return columnDef["falseState"];
        }
        this.formatters.booleanImageFormatter = (value, type, dataContext, meta) => {
            var columnDef = meta.settings.aoColumns[meta.col];
            if (that.getValue(dataContext, columnDef.id) === true)
                return '<i class="fa fa-check" aria-hidden="true" style="width: 90%;text-align: center;"></i>'
            else
                return '';
        }

        this.formatters.multiValueFormatter = (value, type, dataContext, meta) => {
            let columnDef = meta.settings.aoColumns[meta.col];
            let data = that.getData(columnDef, value, dataContext);
            return data;
        }

        this.formatters.checkBoxFormatter = (value, type, dataContext, meta) => {
            let columnDef = meta.settings.aoColumns[meta.col];
            let data = that.getData(columnDef, value, dataContext);

            let el = $(`<div class="checkbox" style="margin-top: 0px; margin-bottom: 0px;">
                                <input class="styled" type="checkbox" value="${data}" > <label></label>                               
                            </div>`).on("click", (e) => {
                    columnDef.callBackFn(dataContext,e);
                });
            setTimeout(function () {
                if ($("table.table").find("tr").eq(meta.row + 2).find("td").eq(meta.col).html() === "")
                    $("table.table").find("tr").eq(meta.row + 2).find("td").eq(meta.col).append(el);
            });
            return "";
        }

        this.formatters.dateFormatFormatter = (value, type, dataContext, meta) => {
            let columnDef = meta.settings.aoColumns[meta.col];
            let data = that.getDateFormateData(columnDef, value, dataContext);
            return data;
        }
        this.formatters.dateFormatter = (value, type, dataContext, meta) => {
            let columnDef = meta.settings.aoColumns[meta.col];
            let data = that.getDateFormate(columnDef, value, dataContext);
            return data;
        }

        this.formatters.urlFormatter = (value, type, dataContext, meta) => {
            var columnDef = meta.settings.aoColumns[meta.col];
            if (!columnDef.url)
                throw ("url not defined on link column");
            return this.getUrl(columnDef, value, dataContext);
        }

        this.formatters.titleCaseFormatter = (value, type, dataContext, meta) => {
            var columnDef = meta.settings.aoColumns[meta.col];
            if (value)
                return this.camel2title(value);
            return "";
        }

        this.formatters.actionFormatter = (value, type1, dataContext, meta) => {
            let columnDef = meta.settings.aoColumns[meta.col];
            if (columnDef.formatterConfig.buttons && columnDef.formatterConfig.buttons.length === 0)
                return;
            let containerElement = [];
            columnDef.formatterConfig.buttons.forEach((element, idx) => {
                let el = $(`<a href="javascript:void(0);" style="${idx > 0 ? 'padding-left:10px' : ''}"><i aria-hidden="true" class="${element.iconClass}"></i>${element.text}</a>`)
                    .on("click", (e) => {
                        e.preventDefault();
                        element.callbackFunc(dataContext);
                    });
                containerElement.push(el);
            });
            setTimeout(function () {
                if ($("table").find("tr").eq(meta.row + 2).find("td").eq(meta.col).html() === "")
                    $("table").find("tr").eq(meta.row + 2).find("td").eq(meta.col).append(containerElement);
            });
            return "";
        }
    }
}

export class DataColumn {
    id: string;
    name: string;
    title: string;
    data: string;
    url: string;
    bSearchable: boolean = false;
    orderable: boolean = true;
    render: any;
    trueState: string;
    falseState: string;
    formatType: string;
    formatterConfig: any;
    width: string;
    sWidth: string;
    callBackFn: any;
    visible: boolean = true;
    freezeColumn: boolean = false;

    constructor(id: string, title: string, data: string) {
        this.id = this.name = id;
        this.title = title;
        this.data = data;
    }

    set formatter(func) {
        this.render = func;
    }
}

@Injectable()
export class DataGridService {
    tableName: string;
    private tableCols: any = {};
    private _columns: Array<DataColumn>

    constructor(private router: Router, private filterStore: AdvancedFilterStore) {
        this._columns = new Array<DataColumn>();
    }

    setName(tableId: string) {
        this.tableName = tableId;
    }

    reset(tableId: string) {
        if (!tableId)
            throw new Error("tablId missing.");
        delete this.tableCols[tableId];
    }


    getColumns(tableId: string) {
        if (!tableId)
            throw new Error("tablId missing.");
        let storedFilter = this.filterStore.getFilter(tableId);
        if (storedFilter)
            return storedFilter;
        if (this.tableCols[tableId])
            return this.tableCols[tableId].columns;
        return null;
    }

    addColumn(tableId: string, col: DataColumn) {
        if (col.formatType)
            col.render = new Formatter(this.router).getFormatter(col.formatType + "Formatter");
        else if (col.data.indexOf("[") >= 0)
            col.render = new Formatter(this.router).getFormatter("multiValueFormatter");
        if (!this.tableCols[tableId])
            this.tableCols[tableId] = { columns: [] };
        this.tableCols[tableId].columns.push(col);
    }

    getHeightForDataTable(isModal?: boolean) {
        var pageHeight = $(window).height() - $("navbar-new").height() - $("nav").height() - $("footer").height() - (!isModal ? 350 : 95);
        return pageHeight;
    }
}  
