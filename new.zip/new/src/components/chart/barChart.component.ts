import { Component, AfterViewInit, Input } from '@angular/core';
declare let d3: any;
declare let moment: any;

@Component({
  selector: 'chart-bar-componet',
  template: `<app-nvd3 [options]="options" [data]="chartData"></app-nvd3>`
})
export class BarChartComponent {
  options;
  chartData: any;
  @Input() chartDataProcess: any;
  @Input() height: number;
  @Input() isXAxisDateType: boolean;
  @Input() isWeek: boolean;
  @Input() decimalPlaces: number;
  @Input() xAxisDateFormat: string;
  @Input() ticks: number;

  private days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]

  ngOnChanges(changes) {
    if (changes.chartDataProcess && changes.chartDataProcess.currentValue) {
      this.chartData = this.chartDataProcess;
    }
  }
  ngOnInit() {
    this.chartData = this.chartDataProcess;
    this.options = {
      chart: {
        type: 'multiBarChart',
        height: this.height || 300,
        margin: {
          top: 40,
          right: 20,
          bottom: 45,
          left: 45
        },
        clipEdge: true,
        duration: 500,
        stacked: false,
        xAxis: {
          tickFormat: (d) => {
            if (this.isXAxisDateType && !this.isWeek) {
              return moment(new Date(d)).format(this.xAxisDateFormat || "YYYY-MM-DD");
            }
            else if (this.isXAxisDateType && this.isWeek) {
              return this.days[d]
            }
            return d;
          },
        },
        yAxis: {
          // axisLabel: 'Units',
          axisLabelDistance: -20,
          tickFormat: function (d) {
            return d;
          }
        }
      }
    }
  }
}
