import { Component, AfterViewInit, Input } from '@angular/core';

@Component({
  selector: 'processRateInfo-chart',
  templateUrl: 'processRateInfo.component.html'
})
export class ProcessRateInfoComponent {
  chartData: any = [];
  @Input() chartDataProcess: any;
  ngAfterViewInit() {
    this.chartData.push(this.chartDataProcess);
    
  }
}
