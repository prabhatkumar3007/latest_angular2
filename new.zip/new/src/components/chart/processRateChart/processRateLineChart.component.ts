import { Component, AfterViewInit, Input } from '@angular/core';

@Component({
  selector: 'process-rate-line-chart',
  template: `
    <line-chart [height]="chartHeight" [chartDataProcess]="processRateData" [isXAxisDateType]="isXAxisDateType"
     [xAxisDateFormat]="xAxisDateFormat" [showLegend]="false" [isWeek]="isWeek" [xTicks]="xTicks" [decimalPlaces]="decimalPlaces"></line-chart>
    <processRateInfo-chart [chartDataProcess]="processRateData"></processRateInfo-chart>    
  `
})
export class ProcessRateLineChartComponent {
  @Input() processRateData: any;
  @Input() chartHeight: number;
  @Input() isXAxisDateType: boolean;
  @Input() isWeek: boolean;
  @Input() xAxisDateFormat: string;
  @Input() xTicks: number;
  @Input() decimalPlaces: number;
  
}

