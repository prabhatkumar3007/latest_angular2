export class ProcessSection {
    Key: string
    Value: number
    PercentageWidth: string

    constructor(key, value) {
        this.Key = key;
        this.Value = value;
    }
}

export class ProcessData {
    Group: string;
    TotalProcess: number
    ProcessTime: string
    DataPoints: ProcessSection[] = []
    constructor(averageProcessTime) {
        this.ProcessTime = averageProcessTime == null ? '00:00:00' : averageProcessTime;
        this.TotalProcess = 0;
    }

    addProcessValues(objProcessSection) {
        this.DataPoints.push(objProcessSection);
        this.TotalProcess += objProcessSection.Value;
    }

    calculatePercentageWidths() {
        this.DataPoints.forEach((section) => {
            section.PercentageWidth = (section.Value / this.TotalProcess * 100) + '%';
        });
    }

}

