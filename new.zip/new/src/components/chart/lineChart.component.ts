import { Component, AfterViewInit, Input, ViewChild } from '@angular/core';
import { SimpleChanges } from '@angular/core';

declare let d3: any;
declare let moment: any;

@Component({
  selector: 'line-chart',
  template: '<app-nvd3 [options]="options" [data]="chartData" *ngIf="chartData"></app-nvd3>'
})
export class LineChartComponent {
  chartData: any;
  @Input() chartDataProcess: any;
  @Input() height: number;
  @Input() showLegend: boolean;
  @Input() isWeek: boolean;
  @Input() xTicks: number;
  @Input() tickValues: any;
  @Input() decimalPlaces: number;
  @Input() isXAxisDateType: boolean;
  @Input() xAxisDateFormat: string;

  private isInitialized: boolean = false;
  options: any;
  private days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]

  ngOnChanges(changes) {
    if (changes.chartDataProcess && changes.chartDataProcess.currentValue && this.isInitialized) {
      if (this.chartDataProcess instanceof Array) {
        this.chartData = null;
        this.chartData = this.chartDataProcess;
      }
      else {
        this.chartData = [this.chartDataProcess];
      }
    }
    if (changes.tickValues && changes.tickValues.currentValue && this.options) {
      this.options.chart.xAxis.tickValues = this.tickValues;
    }
    if (changes.tickValues && changes.tickValues.currentValue === undefined && this.options) {
      this.options.chart.xAxis.tickValues = undefined;
    }
  }

  ngOnInit() {
    if (this.chartDataProcess instanceof Array) {
      this.chartData = null;
      this.chartData = this.chartDataProcess;
    }
    else {
      this.chartData = [this.chartDataProcess];
    }
    this.isInitialized = true;
    this.options = {
      chart: {
        type: 'lineChart',
        height: this.height || 200,
        margin: {
          top: 20,
          right: 20,
          bottom: 45,
          left: 45
        },
        padding: {
          top: 15
        },
        useInteractiveGuideline: true,
        reduceXticks: true,
        // x: function (d) {
        //   return d.x;
        // },
        color: d3.scale.category10().range(),
        showLegend: this.showLegend === undefined ? true : this.showLegend,
        xAxis: {
          // showMaxMin: false,
          ticks: this.tickValues === undefined ? this.xTicks || 0 : undefined,
          rotateLabels: -45,
          tickValues: this.tickValues,
          tickFormat: (d) => {
            if (this.isXAxisDateType && !this.isWeek) {
              return moment(new Date(d)).format(this.xAxisDateFormat || "YYYY-MM-DD");
            }
            else if (this.isXAxisDateType && this.isWeek) {
              return this.days[d]
            }
            // return d;
          },
        },
        yAxis: {
          // axisLabel: "Units",
          axisLabelDistance: -20,
          tickFormat: (d) => {
            if (this.decimalPlaces === undefined)
              return d.toFixed(0);
            else
              return d.toFixed(this.decimalPlaces);
          }
        }
      }
    }
  }
}
