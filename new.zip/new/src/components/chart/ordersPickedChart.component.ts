import { Component, AfterViewInit, Input } from '@angular/core';
//import { OrdersPickedData } from '../chart/chart-data';

declare let d3: any;

@Component({
    selector: 'orders-chart',
    template: `<app-nvd3 [options]="options" [data]="chartData"></app-nvd3>
                <div class="row">
                  <div class="container">
                    <div class="col-sm-12 text_align_center">
                      <span *ngFor="let i of chartData"><div class="circle_div_10" [ngStyle]="{'background-color': i.color}"></div><span class="color-light-gray">{{i.key}}</span></span>                  
                    </div>
                  </div>
                </div>`

})
export class OrdersPickedComponent {
    chartData: any = [];
    @Input() chartDataProcess: any;
    options;

    ngAfterViewInit() {

        this.chartData = this.chartDataProcess;

        this.options = {
            chart: {
                type: 'lineChart',
                height: 300,
                margin: {
                    top: 20,
                    right: 20,
                    bottom: 45,
                    left: 45
                },
                y: function (d) { return d.y; },
                x: function (d) { return d.x; },
                color: d3.scale.category10().range(),
                duration: 300,
                showLegend: false,
                reduceXTicks: true,
                useInteractiveGuideline: true,
                clipVoronoi: false,
                xAxis: {
                    axisLabel: 'Hours',
                    showMaxMin: false,

                },
                yAxis: {
                    axisLabel: "Units",
                    axisLabelDistance: -20,
                    tickFormat: function (d) {
                        return Math.round(d);
                    }
                },
            }
        }
    }
}
