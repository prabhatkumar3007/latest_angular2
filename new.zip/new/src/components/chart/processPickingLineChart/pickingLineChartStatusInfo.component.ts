import { Component, AfterViewInit, Input } from '@angular/core';

@Component({
  selector: 'picking-table-info',
  templateUrl: 'pickingLineChartStatusInfo.html'
})
export class PickingLineChartStatusInfoComponent {
  chartData: any = [];
  @Input() chartDataProcess: any;
  ngAfterViewInit() {
    this.chartData.push(this.chartDataProcess);
    
  }
}