import { AfterViewInit, Component, Input } from '@angular/core';

@Component({
  selector: 'picking-line-chart',
  template: `
    <div class="row">
    <div class="col-sm-8 sparkline1">
    <line-chart [height]="chartHeight" *ngIf="pickingLineData" [chartDataProcess]="pickingLineData" 
      [isXAxisDateType]="isXAxisDateType" [showLegend]="false" [xAxisDateFormat]="xAxisDateFormat" [isWeek]="isWeek" 
      [decimalPlaces]="decimalPlaces" [xTicks]="3">
    </line-chart>
     </div>
     <div class="col-sm-4"><picking-info [chartDataProcess]="pickingLineData"></picking-info></div>
     </div>
  `
})
export class PickingLineChartComponent {
  @Input() pickingLineData: any;
  @Input() chartHeight: number;
  @Input() isXAxisDateType: boolean;
  @Input() xAxisDateFormat: string;
  @Input() isWeek: boolean;
  @Input() decimalPlaces: number;
}
