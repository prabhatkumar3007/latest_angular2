import { AfterViewInit, Component, Input } from '@angular/core';

@Component({
  selector: 'picking-line-chart-table',
  template: `<div></div>`
})
export class PickingLineChartTableComponent {
  @Input() pickingLineData: any;
  @Input() chartHeight: number;
}
