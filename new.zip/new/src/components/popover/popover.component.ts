import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'popover-html',
  templateUrl: 'popover.component.html'
})
export class PopoverHtmlComponent {
  @Input() dropDownTitle: String;
  @Input() dropDownList: any;
  @Input() titleValue: string;
  @Input() value: string;
  @Output() onChange: any = new EventEmitter();

  onDataChange(data) {
    this.onChange.emit(data);
  }
} 