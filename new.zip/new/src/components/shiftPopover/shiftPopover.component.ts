import {
    AfterViewInit,
    Component,
    ElementRef,
    EventEmitter,
    Input,
    Output
} from '@angular/core';
declare var $: any
declare var moment: any

@Component({
    selector: 'shift-popover',
    template: `<popover-html [dropDownTitle]="shiftTitle" [dropDownList]="shifts" title="text" (onChange)="onDataChange($event)"></popover-html>`
})

export class ShiftPopoverComponent {
    @Input() model: any;
    @Output() onShiftChange: any = new EventEmitter();
    public shiftTitle: string;
    public shifts = [
        { text: "All Shifts", timeFrom: "00:00:00", timeTo: "23:59:59" },
        { text: "Morning", timeFrom: "08:00:00", timeTo: "15:59:59" },
        { text: "Evening", timeFrom: "16:00:00", timeTo: "23:59:59" },
        { text: "Night", timeFrom: "00:00:00", timeTo: "07:59:59" }
    ]

    constructor(private elementRef: ElementRef) { }

    ngOnInit() {
        if (this.model)
            this.shiftTitle = this.model;
        else
            this.shiftTitle = this.shifts[0].text;
    }

    onDataChange(data) {
        this.shiftTitle = data.text;
        this.onShiftChange.emit(data);
    }
}   