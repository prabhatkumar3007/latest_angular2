import { NgModule } from '@angular/core';

export * from './decorator/index';
export * from './service/index';
export * from './utility/index';

@NgModule()
export declare class WebStorageModule { }
