import { ModuleWithProviders } from '@angular/core';
export { ChartService } from './components/chart/chart.service';
export { OrdersPickedComponent } from './components/chart/ordersPickedChart.component';
export { BarChartComponent } from './components/chart/barChart.component';
export { LineChartComponent } from './components/chart/lineChart.component';
export { PickingLineChartComponent } from './components/chart/processPickingLineChart/pickingLineChart.component';
export { PickingLineChartInfoComponent } from './components/chart/processPickingLineChart/pickingLineChartInfo.component';
export { PickingLineChartStatusInfoComponent } from './components/chart/processPickingLineChart/pickingLineChartStatusInfo.component';
export { PickingLineChartTableComponent } from './components/chart/processPickingLineChart/pickingLineChartTable.component';
export { ProcessRateInfoComponent } from './components/chart/processRateChart/processRateInfo.component';
export { ProcessRateLineChartComponent } from './components/chart/processRateChart/processRateLineChart.component';
export { LineBarChartComponent } from './components/chart/lineBarChart.component';
export { ProcessData, ProcessSection } from './components/chart/progessBar/services/progressBar.data';
export declare class ChartModule {
    static forRoot(): ModuleWithProviders;
}
