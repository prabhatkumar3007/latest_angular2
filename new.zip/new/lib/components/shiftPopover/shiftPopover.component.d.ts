import { ElementRef } from '@angular/core';
export declare class ShiftPopoverComponent {
    private elementRef;
    model: any;
    onShiftChange: any;
    shiftTitle: string;
    shifts: {
        text: string;
        timeFrom: string;
        timeTo: string;
    }[];
    constructor(elementRef: ElementRef);
    ngOnInit(): void;
    onDataChange(data: any): void;
}
