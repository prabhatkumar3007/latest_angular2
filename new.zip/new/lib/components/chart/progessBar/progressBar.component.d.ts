import { ProcessData } from './services/progressBar.data';
import { EventEmitter } from '@angular/core';
export declare class ProgressBarComponent {
    processData: ProcessData;
    sectionCallback: EventEmitter<any>;
    private hasCallback;
    ngOnInit(): void;
    applyBgColor(key: any): any;
    sectionClickCallback(data: any): void;
}
