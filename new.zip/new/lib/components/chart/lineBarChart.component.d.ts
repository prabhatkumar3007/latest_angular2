export declare class LineBarChartComponent {
    chartData: any;
    options: any;
    chartDataProcess: any;
    height: number;
    isXAxisDateType: boolean;
    isWeek: boolean;
    decimalPlaces: number;
    xAxisDateFormat: string;
    tickValues: any;
    private days;
    ngOnInit(): void;
    ngOnChanges(changes: any): void;
    ngAfterViewInit(): void;
}
