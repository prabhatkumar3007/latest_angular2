export declare class PickingLineChartStatusInfoComponent {
    chartData: any;
    chartDataProcess: any;
    ngAfterViewInit(): void;
}
