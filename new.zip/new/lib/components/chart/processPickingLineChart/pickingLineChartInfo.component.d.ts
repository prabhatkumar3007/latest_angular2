export declare class PickingLineChartInfoComponent {
    chartData: any;
    chartDataProcess: any;
    ngAfterViewInit(): void;
}
