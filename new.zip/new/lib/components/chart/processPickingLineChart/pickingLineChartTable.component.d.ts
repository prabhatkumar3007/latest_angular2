export declare class PickingLineChartTableComponent {
    pickingLineData: any;
    chartHeight: number;
}
