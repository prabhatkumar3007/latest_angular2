export declare class ChartService {
    getTicksForChart(data: any, intervalInMinutes?: number): any[];
    getTicksForChartForAnalysis(data: any, intervalInMinutes?: number): any[];
}
