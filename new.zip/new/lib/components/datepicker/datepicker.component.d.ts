import { ElementRef, EventEmitter } from '@angular/core';
export declare class DatePickerComponent {
    private elementRef;
    isDay: boolean;
    isWeek: boolean;
    datepickerObj: any;
    config: any;
    inSelectionProcess: boolean;
    lastSelectedTS: any;
    roundTimeToMinute: number;
    dates: any;
    showDayWeekOptions: boolean;
    inputWidth: string;
    datepickerConfig: any;
    onDateChanged: EventEmitter<any>;
    constructor(elementRef: ElementRef);
    ngOnInit(): void;
    setDatePickerConfig(isWeek: boolean): void;
    initialiseDatePicker(explicit: boolean): void;
    setDate(isDay: boolean): void;
    toggleWeek(flag: boolean): void;
    dateChange(date: any): void;
}
