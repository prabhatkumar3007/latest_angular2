export declare class AdvancedFilterStore {
    private filterStore;
    getFilter(key: any): any;
    addFilter(key: any, value: any): void;
}
