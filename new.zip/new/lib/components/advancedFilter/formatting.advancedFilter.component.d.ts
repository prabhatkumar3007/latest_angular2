import { EventEmitter } from '@angular/core';
export declare class FormattingTab {
    columns: Array<string>;
    onApplyFormatting: EventEmitter<any>;
    applyFilter(): void;
}
