export declare class AdvancedFilterModule {
}
