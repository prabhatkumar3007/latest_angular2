import { EventEmitter } from '@angular/core';
import { FilterParams } from './advancedFilter.data';
export declare class AppliedFilterDataComponent {
    filterParamsData: FilterParams;
    onRemoveFilter: EventEmitter<FilterParams>;
    selectedStates: string;
    ngOnChanges(changes: any): void;
    resetFilter(value: any): void;
    resetvalues(val: any): void;
    parseDate(value: any): any;
}
