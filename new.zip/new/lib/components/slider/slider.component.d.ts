import { AfterViewInit, ElementRef, EventEmitter } from '@angular/core';
export declare class SliderComponent implements AfterViewInit {
    private el;
    min: number;
    max: number;
    step: number;
    initValue: Array<number> | number;
    value: Array<number> | number;
    onSlide: EventEmitter<any>;
    private sliderElem;
    constructor(el: ElementRef);
    ngAfterViewInit(): void;
    onChange(value: any): void;
    ngOnChanges(changes: any): void;
}
