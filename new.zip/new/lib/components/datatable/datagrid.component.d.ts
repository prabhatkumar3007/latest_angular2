import { AdvancedFilterStore } from './../advancedFilter/advancedFilterStore.service';
import { AfterContentInit, ElementRef, EventEmitter } from '@angular/core';
import { DataGridService } from './datagrid.service';
export declare class DataGrid {
    private el;
    private service;
    private filterStore;
    tableId: string;
    data: any;
    autoHeight: boolean;
    isModal: boolean;
    defaultSortColumn: any;
    onSort: EventEmitter<any>;
    dtOptions: any;
    reDrawWhen: any;
    dtInstance: Promise<any>;
    currentCol: number;
    table: any;
    private defaultColumns;
    constructor(el: ElementRef, service: DataGridService, filterStore: AdvancedFilterStore);
    private getWordsBetweenCurlies(str);
    attachGridEvents(): void;
    ngOnInit(): void;
    ngOnChanges(changes: any): void;
    initializeGrid(): void;
    sortByFrozenColumn(columns: any): any[];
    setAutoHeight(isModal: any): void;
}
export declare class GridColumn implements AfterContentInit {
    private service;
    private parent;
    headerText: string;
    columnMap: string;
    url: string;
    width: string;
    formatter: string;
    orderable: boolean;
    trueState: string;
    falseState: string;
    formatterConfig: any;
    callBackFn: any;
    constructor(service: DataGridService, parent: DataGrid);
    ngAfterContentInit(): void;
}
