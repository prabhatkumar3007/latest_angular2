import { AdvancedFilterStore } from './../advancedFilter/advancedFilterStore.service';
import { Router } from '@angular/router';
export declare class DataColumn {
    id: string;
    name: string;
    title: string;
    data: string;
    url: string;
    bSearchable: boolean;
    orderable: boolean;
    render: any;
    trueState: string;
    falseState: string;
    formatType: string;
    formatterConfig: any;
    width: string;
    sWidth: string;
    callBackFn: any;
    visible: boolean;
    freezeColumn: boolean;
    constructor(id: string, title: string, data: string);
    formatter: any;
}
export declare class DataGridService {
    private router;
    private filterStore;
    tableName: string;
    private tableCols;
    private _columns;
    constructor(router: Router, filterStore: AdvancedFilterStore);
    setName(tableId: string): void;
    reset(tableId: string): void;
    getColumns(tableId: string): any;
    addColumn(tableId: string, col: DataColumn): void;
    getHeightForDataTable(isModal?: boolean): number;
}
