import { PipeTransform } from '@angular/core';
export declare class DatePipe implements PipeTransform {
    transform(date: any, args?: any): any;
}
