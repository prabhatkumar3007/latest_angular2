export declare class FileService {
    readTextFile(event: any): any;
}
